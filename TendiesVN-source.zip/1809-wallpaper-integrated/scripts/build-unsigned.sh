#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build"
BUNDLE_ID="${BID:-com.kamui.escape}"

if [[ "$(uname -s)" != "Darwin" ]] || ! command -v xcodebuild >/dev/null 2>&1; then
    echo "This app requires macOS with Xcode 26 or newer (Swift + iOS 17 SDK APIs)." >&2
    exit 1
fi
XCODE_MAJOR="$(xcodebuild -version | awk '/^Xcode / { split($2, v, "."); print v[1] }')"
if [[ ! "$XCODE_MAJOR" =~ ^[0-9]+$ ]] || (( XCODE_MAJOR < 26 )); then
    echo "Xcode 26 or newer is required. Select it with xcode-select or DEVELOPER_DIR." >&2
    exit 1
fi

python3 "$ROOT/scripts/generate-xcode-project.py"
# The bundled framework predates the source's iOS 27 ATC framing correction.
# Always rebuild from the pinned Rust sources; never silently ship that binary.
export IPHONEOS_DEPLOYMENT_TARGET=17.0
bash "$ROOT/vendor/TendiesWallpaper/scripts/build-airlift.sh"

xcodebuild \
    -project "$ROOT/1809.xcodeproj" \
    -scheme BQTool \
    -configuration Release \
    -sdk iphoneos \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$BUILD/DerivedData" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY= \
    "PRODUCT_BUNDLE_IDENTIFIER=$BUNDLE_ID" \
    "$@" \
    build

APP="$BUILD/DerivedData/Build/Products/Release-iphoneos/BQTool.app"
[[ -d "$APP" ]] || { echo "Build did not produce $APP" >&2; exit 1; }
VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Info.plist")"
PACKAGE="$BUILD/Package"
rm -rf "$PACKAGE"
mkdir -p "$PACKAGE/Payload"
ditto "$APP" "$PACKAGE/Payload/BQTool.app"
IPA="$BUILD/1809-$VERSION-unsigned.ipa"
rm -f "$IPA"
(cd "$PACKAGE" && /usr/bin/zip -qry "$IPA" Payload)
echo "Unsigned IPA: $IPA"
