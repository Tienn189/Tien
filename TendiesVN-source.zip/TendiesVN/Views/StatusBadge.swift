import SwiftUI
import UIKit

/// Semantic colors remain legible in light and dark appearance.
enum AppStatusTone {
    case success, failure, warning, working

    var color: Color {
        Color(uiColor: UIColor { traits in
            let dark = traits.userInterfaceStyle == .dark
            switch self {
            case .success:
                return dark ? UIColor(red: 0.30, green: 0.85, blue: 0.45, alpha: 1)
                    : UIColor(red: 0.09, green: 0.45, blue: 0.22, alpha: 1)
            case .failure:
                return dark ? UIColor(red: 1, green: 0.43, blue: 0.40, alpha: 1)
                    : UIColor(red: 0.74, green: 0.14, blue: 0.10, alpha: 1)
            case .warning:
                return dark ? UIColor(red: 1, green: 0.81, blue: 0.27, alpha: 1)
                    : UIColor(red: 0.55, green: 0.34, blue: 0.02, alpha: 1)
            case .working:
                return dark ? UIColor(red: 0.40, green: 0.69, blue: 1, alpha: 1)
                    : UIColor(red: 0.02, green: 0.33, blue: 0.74, alpha: 1)
            }
        })
    }
}

struct StatusBadge: View {
    let title: String
    let systemImage: String
    let tone: AppStatusTone

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 6) {
            Image(systemName: systemImage)
                .fixedSize()
                .accessibilityHidden(true)
            Text(title)
                .fixedSize(horizontal: false, vertical: true)
        }
            .font(.caption.weight(.semibold))
            .foregroundStyle(tone.color)
            .padding(.horizontal, 11)
            .padding(.vertical, 7)
            .background(tone.color.opacity(0.12), in: Capsule())
            .fixedSize(horizontal: false, vertical: true)
            .accessibilityElement(children: .combine)
    }
}

extension DeviceCapability {
    var tone: AppStatusTone {
        switch self {
        case .localInstallation: return .success
        case .libraryOnly, .unsupported: return .failure
        case .simulator: return .warning
        }
    }

    var systemImage: String {
        switch self {
        case .localInstallation: return "checkmark.circle.fill"
        case .libraryOnly, .unsupported: return "xmark.circle.fill"
        case .simulator: return "info.circle.fill"
        }
    }
}

@MainActor
extension PairingStore {
    var statusTone: AppStatusTone {
        if isBusy { return .working }
        if connection != nil { return .success }
        return lastFailure == nil ? .warning : .failure
    }

    var statusSystemImage: String {
        if isBusy { return "clock.fill" }
        if connection != nil { return "checkmark.shield.fill" }
        if lastFailure != nil { return "exclamationmark.circle.fill" }
        return "antenna.radiowaves.left.and.right"
    }
}
