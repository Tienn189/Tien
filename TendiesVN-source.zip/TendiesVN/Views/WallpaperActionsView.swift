import SwiftUI

/// Install the complete descriptor package; no media gallery or Photos export.
struct WallpaperActionsView: View {
    let package: WallpaperStagedPackage
    @EnvironmentObject private var model: WallpaperModel
    @Environment(\.dismiss) private var dismiss
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @State private var confirmingDelete = false

    var body: some View {
        List {
            Section {
                informationRow("Dung lượng giải nén", value: package.statistics.expandedBytes.fileSize,
                               systemImage: "externaldrive")
                informationRow("Số tệp", value: package.statistics.fileCount.formatted(),
                               systemImage: "doc.on.doc")
                informationRow("Ngày nhập", value: package.importedAt.formatted(date: .abbreviated, time: .shortened),
                               systemImage: "calendar")
            } header: {
                Text(package.displayName).textCase(nil)
            }
            Section {
                Button { model.install(package) } label: {
                    Label("Cài hình nền", systemImage: "plus.rectangle.on.rectangle")
                        .font(.body.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 40)
                }
                .buttonStyle(.borderedProminent)
                .foregroundStyle(AppTheme.foregroundColor(hex: accentHex))
                .disabled(model.isBusy || !DeviceCompatibility.installationSupported)
                .accessibilityHint("Cài gói vào Bộ sưu tập rồi mở PosterBoard để làm mới trong đa nhiệm")
                NavigationLink { WallpaperGuideView() } label: {
                    Label("Hướng dẫn cài và làm mới", systemImage: "questionmark.circle")
                }
            } header: {
                Text("Thao tác")
            } footer: {
                Text(DeviceCompatibility.explanation)
            }
            if let notice = model.successNotice {
                Section {
                    OperationStatusView(status: notice, onDismiss: { model.dismissSuccessNotice() })
                }
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài hình nền")
        .navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) {
            if let status = model.operationStatus {
                OperationStatusView(status: status)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.appBackground.opacity(0.96))
            }
        }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Đóng") { dismiss() }.disabled(model.isBusy)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    ShareLink(item: package.archiveURL) {
                        Label("Xuất gói .tendies", systemImage: "shippingbox")
                    }
                    Button(role: .destructive) { confirmingDelete = true } label: {
                        Label("Xoá gói khỏi thư viện", systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .accessibilityLabel("Tuỳ chọn gói")
                .disabled(model.isBusy)
            }
        }
        .confirmationDialog("Xoá bản nhập trong app?", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("Xoá gói", role: .destructive) { model.delete(package) }
        } message: {
            Text("Chỉ xoá gói trong thư viện. Để gỡ những hình nền đã thêm vào Bộ sưu tập, dùng tab Đã cài.")
        }
        .alert(item: $model.message) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
    }

    private func informationRow(_ title: String, value: String, systemImage: String) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 12) {
                Label(title, systemImage: systemImage).fixedSize()
                Spacer(minLength: 12)
                Text(value).foregroundStyle(.secondary).fixedSize()
            }
            VStack(alignment: .leading, spacing: 6) {
                Label(title, systemImage: systemImage)
                Text(value).foregroundStyle(.secondary)
            }
        }
        .labelStyle(.titleAndIcon)
        .fixedSize(horizontal: false, vertical: true)
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }
}
