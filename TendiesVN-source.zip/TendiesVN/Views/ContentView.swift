// Compatibility target for ZIP workflows shared before version 1.1.
// Those workflows apply a picker patch to this legacy path before building.
// The actual app source is TendiesVN/Views/ContentView.swift and already uses
// the broader file picker. This file is outside the Xcode app source group.
