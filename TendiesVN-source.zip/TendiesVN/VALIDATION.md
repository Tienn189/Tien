# Báo cáo kiểm tra · 1809 3.4.0 / build 18

Ngày: 2026-10-19. Môi trường sửa và kiểm tra: Linux; không có Swift compiler, Xcode/iOS SDK hoặc iPhone/iPad kết nối. **Chưa tạo IPA bằng Xcode và chưa xác nhận cài/gỡ hoặc giao diện trên thiết bị thật.**

## Thay đổi

Khôi phục bridge giới hạn PosterBoard, bộ cài descriptor có journal/rollback/gỡ và launcher từ build 14. Giữ package store hiện tại, sửa luồng màn cài → đóng sheet → mở PosterBoard. Không mở PosterBoard khi nhập gói hoặc khi ghi lỗi. Chỉ đưa hướng dẫn làm mới sau thao tác ghi hoàn tất; nếu mở PosterBoard lỗi thì giữ kết quả ghi và báo riêng.

Bỏ toàn bộ lưu ảnh bằng Photos, quyền Photos, trình xem media và lịch sử Đã lưu khỏi giao diện/mã chạy. Dữ liệu Photos/lịch sử đã tạo bởi phiên bản trước không bị tự xoá. Tab Đã cài đọc journal cũ và mới trong cùng đường dẫn, chỉ hiện các lần đã cài/cần khôi phục.

Thêm ô màu thứ sáu, giữ chọn màu tuỳ chỉnh và sáng/tối. Thu gọn các hàng trạng thái Cài đặt để bỏ khoảng trống lớn; màu xanh/đỏ/vàng vẫn theo trạng thái, tách khỏi màu nhấn. Đây là thay đổi layout nguồn, cần kiểm tra thực tế với kích cỡ chữ thường và trợ năng.

## Phạm vi tương thích

App chạy từ iOS 17.0; backend cũ chỉ có cho **iOS 26.0–26.6.1** và cần kiểm tra quyền ghi thực tế. Không có backend cài tương ứng cho iOS 17, 18, iOS 26 sau 26.6.1 hay iOS 27 (kể cả beta được nhận diện). Pairing được giữ độc lập, không được dùng để biến trạng thái cài thành được hỗ trợ. Simulator không được ghi hệ thống.

Mã khôi phục dùng `bad_query`/API riêng có sẵn trong build 14, không còn tuân theo phạm vi chỉ API công khai của build 15–17. Không thêm backend kernel mới.

## Kiểm tra thực thi

Lệnh: `python3 scripts/run-checks.py`. Đã hoàn tất 11 bộ kiểm tra, không có bài thất bại. Các bài cần Swift/SDK Apple và bộ template tuỳ chọn được báo bỏ qua rõ ràng.

| Bộ kiểm tra | Đạt | Bỏ qua | Phạm vi |
| --- | ---: | ---: | --- |
| Signing | 5 | 0 | Profile/Bundle ID/metadata/manifest qua fixture; không ký IPA thật |
| Build diagnostics | 6 | 0 | Parser lỗi và mock build: mã 65, full log, không tạo IPA giả, chặn Xcode cũ |
| Compatibility | 0 | 1 | Test giới hạn phiên bản thực tế cần Swift |
| ZIP extractor | 3 | 1 | C thực chạy: stored/deflate đúng byte, lỗi checksum/size, giữ tệp và symlink; thiếu template tuỳ chọn |
| Pairing record validation | 0 | 1 | Cần Swift và Security.framework |
| Pairing transport | 1 | 0 | Adapter C với protocol mock và localhost; không bắt tay với iPhone |
| PosterBoard source contract | 5 | 0 | Không còn Photos, launcher một Bundle ID, giữ kiểm tra identity/root và metadata phiên bản |
| PosterBoard path validation | 13 | 0 | C thực chạy: alias, UUID, descendant riêng cho discovery, traversal, NUL, Unicode và giới hạn buffer |
| SwiftUI guide type-check | 0 | 1 | View thật + production compatibility với iOS SDK trên macOS; Linux thiếu SDK |
| Installer transactions | 0 | 1 | Có fixture chạy production installer trong thư mục tạm: commit, giữ dữ liệu gốc, rollback, dọn gián đoạn, symlink; cần macOS Swift |
| Model completion flow | 0 | 1 | Có fixture chạy model thật với worker/launcher mock: chỉ mở sau dismiss, không mở khi lỗi, giữ kết quả ghi nếu launch lỗi; cần macOS SwiftUI |
| **Tổng** | **33** | **6** | Không dùng skip/mock/cú pháp để suy ra hành vi trên máy thật |

Kiểm tra bổ sung: parser cú pháp Swift, Python AST, shell `bash -n`, workflow YAML, Info.plist/version đồng bộ và icon RGB 1024×1024. Parser Swift không thay thế type-check. ZIP nguồn được kiểm CRC và so sánh byte với nguồn khi đóng gói.

Rà soát bộ cài không thấy hồi quy mới so với build 14. Hạn chế đã có: journal lưu URL tuyệt đối của sandbox, nên bản ghi cũ có thể không được nạp nếu đường dẫn container thay đổi; chưa có chuyển đổi đường dẫn cho trường hợp đó.

## Giữ chẩn đoán build

Giữ dạng khởi tạo `Section(content:header:footer:)` hợp lệ từ build 16. Script giữ mã thoát Xcode, lưu `build/xcodebuild.log`, in các lỗi compiler đầu tiên và workflow mẫu tải log khi thất bại. Hai tên IPA `1809-unsigned.ipa`/`TendiesVN-unsigned.ipa` vẫn được giữ cho workflow cũ.

Ảnh lỗi trước chỉ cho thấy mã 65, chưa có compiler error gốc. **Chưa thể xác nhận toàn bộ nguyên nhân của lượt build trước đã được sửa hoặc bản này build native thành công.** Bridge Objective-C và API riêng cần SDK Apple và kiểm thử trên thiết bị; kiểm tra C độc lập không xác nhận chúng.

## Cần xác minh sau build

1. Xcode build Release arm64; cài bằng chữ ký/profile phù hợp, xác nhận 3.4.0/build 18 và dữ liệu app cũ được giữ.
2. Trên iOS 26.0–26.6.1: tạo hình nền Bộ sưu tập của Apple, nhập gói hợp lệ, kiểm tra quyền và cài. Xác nhận sheet đóng trước khi PosterBoard mở, có đúng một journal, không hỏi quyền Photos.
3. Mở đa nhiệm và vuốt đóng PosterBoard, kiểm tra Bộ sưu tập rồi chọn hình nền. Thử nút mở lại; nếu launch bị từ chối phải báo riêng và không cài lại/nhân đôi gói.
4. Gói hỏng/quyền ghi bị từ chối phải hiện lỗi, không hiện cài thành công và không mở PosterBoard. Kiểm tra lần cài gián đoạn có thể dọn qua Đã cài.
5. Chuyển sang hình nền Apple khác rồi gỡ một lần cài; kiểm tra hình nền gốc và lần cài khác được giữ. Xoá bản nhập không xoá descriptor đã cài.
6. Trên iOS 17, 18, 27: cài/gỡ không được bật chỉ từ phiên bản hoặc pairing. Kiểm tra nhập/xuất gói và pairing riêng.
7. Kiểm tra đủ sáu ô màu, màu tuỳ chỉnh, sáng/tối, lưu tuỳ chọn và Cài đặt không còn hàng cao bất thường. Thử chữ trợ năng và VoiceOver.
