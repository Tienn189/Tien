# Báo cáo kiểm tra · 1809 3.3.0 / build 15

Ngày: 2026-10-18. Môi trường kiểm tra: Linux; không có Xcode, Swift compiler hoặc iPhone/iPad được kết nối. **Chưa tạo IPA bằng Xcode và chưa xác nhận hành vi trên thiết bị thật.**

## Kiểm tra đã thực thi

Lệnh: `python3 scripts/run-checks.py`.

| Bộ kiểm tra | Đạt | Bỏ qua | Nội dung đã chạy |
| --- | ---: | ---: | --- |
| Signing | 5 | 0 | Kiểm tra logic profile, Bundle ID, metadata và manifest bằng fixture/mock; không ký IPA thật |
| Compatibility | 0 | 1 | Cần Swift compiler |
| ZIP extractor | 3 | 1 | Biên dịch và chạy C: ZIP stored/deflate đúng byte, gói hỏng/dọn tệp dở, giữ tệp đích và symlink; không có bộ template tuỳ chọn |
| Pairing record validation | 0 | 1 | Cần Swift và Apple Security framework |
| Pairing transport | 1 | 0 | Adapter C với phản hồi mock, yêu cầu xác thực, RSD fallback, thiếu định danh và dọn tài nguyên; không kết nối iPhone thật |
| Public wallpaper contract | 5 | 0 | Quét nguồn, loại backend riêng, Photos add-only, không đọc/xoá Photos và đồng bộ phiên bản |
| Media catalog | 0 | 1 | Test có sẵn, cần macOS ImageIO/AVFoundation và Swift |
| History codec | 0 | 1 | Test có sẵn, cần Swift compiler |
| **Tổng** | **14** | **5** | Không có bài kiểm tra thất bại |

Kiểm tra bổ sung đã đạt:

- Cú pháp 32 tệp Swift sản phẩm/kiểm thử bằng tree-sitter; đây **không phải** type-check hoặc native build.
- Cú pháp 14 tệp Python, 2 script shell, 2 workflow YAML và Info.plist.
- Rà soát source không còn bridge/kernel/sandbox extension/container query/trình mở PosterBoard bằng API riêng.
- Phiên bản 3.3.0/build 15 đồng bộ; icon RGB không alpha, 1024×1024; gói ZIP nguồn được kiểm tra CRC sau đóng gói.

## Chức năng đã triển khai và mức xác nhận

| Chức năng | Mã nguồn hiện tại | Xác nhận thực tế |
| --- | --- | --- |
| Nhập gói `.tendies`/`.zip`, lưu thư viện riêng | Giữ kiểm tra archive, giới hạn, đường dẫn và symlink | C core đã chạy; document picker/File Provider cần iPhone |
| Xem ảnh, kể cả `asset.resource` | ImageIO đọc theo nội dung, thumbnail giảm kích thước | Đã kiểm tra cú pháp; test Apple-framework chưa chạy |
| Xem video | AVFoundation/AVKit, báo lỗi phát và giải phóng quan sát | Cần native build và thiết bị |
| Lưu ảnh/video | Photos add-only, giữ file gốc, chỉ báo thành công khi completion của Photos trả thành công | Chưa thử cấp/từ chối quyền hoặc lưu thật trên iPhone |
| Chia sẻ/Lưu vào Tệp | UIActivityViewController, bản sao có đúng đuôi, dọn sau chia sẻ | Chưa chạy native share sheet |
| Lịch sử Đã lưu | Chỉ ghi sau Photos xác nhận, JSON atomic; xoá bản ghi không xoá ảnh | Codec có test in-memory; chưa chạy do thiếu Swift |
| Sáng/tối và màu chủ đề | AppStorage, preset/custom ColorPicker, màu trạng thái riêng | Chưa thử UI thật hoặc persistence qua khởi động trên iPhone |
| Pairing/LocalDevVPN | Giữ nhập tệp, Keychain và xác thực; công cụ tuỳ chọn | Adapter mock đã chạy; chưa thử bắt tay với thiết bị |
| Cài wallpaper tự động | Đã loại bỏ, không có API công khai tương ứng | Không tuyên bố hỗ trợ trên bất kỳ phiên bản nào |
| Đặt wallpaper thủ công | Có hướng dẫn Cài đặt → Hình nền → Thêm hình nền mới → Ảnh | Thao tác do người dùng thực hiện trong iOS |

## Tương thích iOS

Deployment target là iOS 17.0. Lưu/chia sẻ dùng cùng API công khai trên các phiên bản 17 trở lên, không giới hạn build beta. iOS 27 Developer/Public Beta được nhận diện bằng nhãn tham khảo khi khớp build, không được xem là đã thử trên máy thật. Simulator không được báo đã lưu Photos trong bản này.

## Kiểm tra cần chạy sau khi build bằng Xcode

1. Nhập một gói có ảnh thật; xác nhận đúng ảnh, tên và xem trước. Thử thêm gói không có media có thể đọc và gói ZIP hỏng.
2. Cho phép Photos add-only, lưu một ảnh rồi xác nhận ảnh có trong ứng dụng Ảnh và có đúng một bản ghi. Từ chối quyền trên lần cài mới: phải báo lỗi, không tạo bản ghi.
3. Thử share sheet thành công và huỷ; huỷ không tạo bản ghi Photos. Xoá lịch sử không xoá ảnh. Xoá gói không xoá ảnh đã lưu.
4. Mở hướng dẫn, tự đặt ảnh trong Cài đặt iOS; thử sáng/tối, màu tuỳ chỉnh và mở lại app.
5. Nếu dùng pairing, xác minh nhập hồ sơ và bắt tay với đúng thiết bị; không coi import tệp hoặc có VPN là đã kết nối.

Không có kết quả native/device được suy ra từ cú pháp, mock hoặc bài test bị bỏ qua.
