# Combined application licensing

The original KAMUI sources retain the MIT license in `LICENSE`. The new
wallpaper adapter and the TendiesVN/3105/PocketPoster portions are GPL-3.0-only.
Redistribution of the linked application must comply with GPL version 3,
including providing its corresponding source. The GPL text is included at
`vendor/TendiesWallpaper/LICENSE-GPL-3.0.txt`; original MIT notices are retained.

Wallpaper source archive requested by the app owner:
<https://github.com/Tienn189/Tien/blob/main/TendiesVN-source.zip>.
See `vendor/TendiesWallpaper/README.md` for the archive SHA-256, integration
scope, and `UPSTREAM_THIRD_PARTY_NOTICES.md` for upstream credits and licenses.
Airlift's patched Rust source, Cargo lockfile, and dependency notices are
included with the engine. The legacy idevice pairing UI/transport is excluded;
pairing files are imported through the host's new wallpaper setup screen.

The wallpaper catalog remains SerStars/Nugget-Wallpapers. Downloaded packages
and their assets retain their individual copyrights and notices.
