# Third-party notices and source provenance

TendiesVN is a wallpaper-focused derivative prepared on 2026-10-16. It changes the app interface, packaging and integration while retaining and adapting the upstream wallpaper engine. This project does not claim authorship of the upstream research or code.

## 3105

- Author: YangJiii and contributors.
- Source: <https://github.com/YangJiiii/3105>.
- Pinned source commit: `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.
- License stated by upstream: GNU GPL version 3 for original portions. The complete GPL-3.0 text is included in `LICENSE`.
- Adapted components: wallpaper ZIP extraction, package inspection, PosterBoard layout discovery, descriptor rewriting, install receipts and scoped restoration, together with the MobileContainerManager integration used to reach the PosterBoard container.

Changes in TendiesVN include a Vietnamese wallpaper-only UI, restricted PosterBoard access, project/build configuration and removal of unrelated file-manager, patch, dialer and cleaner flows. Consult the actual source for the final included components.

## Other work acknowledged by 3105

| Project / contributor | Upstream acknowledgment | Source |
| --- | --- | --- |
| LeminLimez and contributors | Pocket Poster, Nugget and the `.tendies` format | [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster), [Nugget](https://github.com/leminlimez/Nugget) |
| 0xjohnnydev and FilzaSlop contributors | MobileHouseArrest app-container access and sandbox-escape foundation | [FilzaSlop](https://github.com/0xjohnnydev/FilzaSlop), [MobileHouseArrest-PoC](https://github.com/0xjohnnydev/MobileHouseArrest-PoC) |
| CrazyMind90 | FilzaSlop sandbox-escape foundation | [Profile](https://github.com/CrazyMind90) |
| forcequitOS | `bad_query` research | [Profile](https://github.com/forcequitOS) |
| opa334 and Dopamine contributors | Kernel-exploit research foundation acknowledged by 3105 | [Dopamine](https://github.com/opa334/Dopamine) |

These are provenance acknowledgments, not a claim that every named project's code is included. TendiesVN does not include the 3105 kernel-exploit chain or a persistent jailbreak component.

Pocket-Poster publishes GPL-3.0. Nugget publishes AGPL-3.0; its file-format documentation was used as a reference, not copied as an application dependency. No CAPlayground editor code or wallpaper assets are bundled. CAPlayground was inspected to verify that its current exporter creates ZIP packages under `descriptors/<UUID>/...`; the exporter is maintained at [CAPlayground/CAPlayground](https://github.com/CAPlayground/CAPlayground).

CAPlayground verification used commit `5f333376f9752d0be25aab9512bec990d83d861e`, including `apps/web/components/editor/ExportDialog.tsx` and local ordinary/gyro templates. These templates were used for extraction checks and are excluded from this handoff.

## Unresolved third-party licensing

The pinned 3105 `THIRD_PARTY_NOTICES.md` explicitly states that FilzaSlop did not expose a repository license when its notices were prepared. It also states that 3105's GPL license covers only material its owner has the right to license. Acknowledging a source does not supply missing redistribution permission.

TendiesVN retains that limitation. This handoff does not assert a verified GPL/LGPL grant for every predecessor of the MobileHouseArrest bridge. Review the included implementation and upstream terms, and obtain any missing permission before redistributing affected source or a compiled derivative. The top-level GPL text does not override third-party rights.

Imported `.tendies` packages and Apple wallpaper data retain their own copyright and license terms. Keep embedded attribution and do not redistribute assets without the necessary rights.

## Warranty and signing

This is research software supplied without warranty, subject to the licenses above. Certificate validity and actual device access depend on the signing configuration and iOS build. No certificate, private signing key, provisioning profile or signed IPA is included.
