# Third-party notices and source provenance

TendiesVN 1.1.0 (build 3) is a wallpaper-focused derivative prepared on 2026-10-16. It adds a configurable, independent bundle identifier and replaces the previous MobileHouseArrest identity requirement with a scoped `bad_query` backend. This project does not claim authorship of upstream research or code. Native compilation and device validation of this new backend remain outstanding for this handoff.

## 3105

- Author: YangJiii and contributors.
- Source: <https://github.com/YangJiiii/3105>.
- Pinned source commit: `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.
- License stated by upstream: GNU GPL version 3 for original portions; the complete text is included in `LICENSE`.
- Adapted wallpaper components: ZIP extraction, package inspection, PosterBoard layout discovery, descriptor rewriting, install receipts and scoped restoration.
- Access integration adapts the MobileContainerManager lookup and `bad_query` foundations in `ThreeOneOSFive/exploit/mcm_bridge.m` and `ThreeOneOSFive/exploit/bad_query.c` at that commit.

TendiesVN changes the Vietnamese UI, packaging, validation and integration. It excludes the unrelated app-data browser, patch engine, dialer themes, cleaner and kernel-exploit chain. The 1.1 bridge has no requirement to sign as `com.apple.mobile.MobileHouseArrest`.

## Independent-identity backend

The new implementation is in `TendiesVN/Engine/PosterBoardBridge.m` and `.h`. It uses exact PosterBoard metadata lookup, validates container identity, and obtains an extension scoped to the validated PosterBoard root. Discovery fallback examines fixed container metadata rather than other applications' content. It does not include a general file browser, broad recursive root grant, kernel exploit or automatic respring.

| Source | Revision / material reviewed | Attribution / terms |
| --- | --- | --- |
| [forcequitOS/bad_query](https://github.com/forcequitOS/bad_query) | Sandbox-extension technique incorporated through the pinned 3105 source above | forcequitOS and contributors; no separate upstream license grant is asserted here. |
| [frs0n/placard](https://github.com/frs0n/placard) | `7dcefb610cc60ae909b6046beee7adb691148e44`, `placard/Exploit/BadQuery.swift` discovery/access implementation reviewed | frs0n and contributors; repository publishes GPL-3.0. |
| [nxtcoreee3/Bad-Poster](https://github.com/nxtcoreee3/Bad-Poster) | `60d845647e04551dad09d5d3f58f7b97e9d63c7f`, `Pocket Poster/Exploit/BadQuery.swift` reviewed | nxtcoreee3, Mak5er, LeminLimez and contributors; derived from Pocket Poster. |

Placard and Bad-Poster were reviewed to understand independent-identity PosterBoard discovery. No complete upstream app, editor, video generator, catalog, artwork, Airlift framework or respring component is bundled by this change. Consult the source for the final implementation.

## Other acknowledged foundations

| Project / contributor | Contribution acknowledged by 3105 | Source |
| --- | --- | --- |
| LeminLimez and contributors | Pocket Poster, Nugget and the `.tendies` format | [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster), [Nugget](https://github.com/leminlimez/Nugget) |
| 0xjohnnydev and FilzaSlop contributors | MobileContainerManager app-container research | [FilzaSlop](https://github.com/0xjohnnydev/FilzaSlop), [MobileHouseArrest-PoC](https://github.com/0xjohnnydev/MobileHouseArrest-PoC) |
| CrazyMind90 | FilzaSlop sandbox-escape foundation | [Profile](https://github.com/CrazyMind90) |
| opa334 and Dopamine contributors | Kernel-exploit research acknowledged by 3105; that chain is excluded here | [Dopamine](https://github.com/opa334/Dopamine) |

These are provenance acknowledgments, not a statement that every named project's code is included. Pocket-Poster publishes GPL-3.0. Nugget publishes AGPL-3.0; its format documentation was a reference, not copied as an application dependency.

No CAPlayground editor code or wallpaper assets are bundled. Format verification used [CAPlayground/CAPlayground](https://github.com/CAPlayground/CAPlayground) commit `5f333376f9752d0be25aab9512bec990d83d861e`, including `apps/web/components/editor/ExportDialog.tsx` and ordinary/gyro templates. Templates used for extraction checks are excluded from the source handoff.

## Unresolved third-party licensing

The pinned 3105 notices state that FilzaSlop did not expose a repository license when those notices were prepared and that 3105's GPL covers only material its owner has the right to license. Placard also notes that upstream `bad_query` may not declare a separate license. Attribution does not supply missing redistribution permission.

TendiesVN retains those limitations. This handoff does not assert a verified GPL/LGPL grant for every predecessor of the container-access code or a separate license from the `bad_query` author. Review the included implementation and upstream terms, and obtain missing permission before redistributing affected source or a compiled derivative. The top-level GPL does not override third-party rights.

Imported `.tendies` packages and Apple wallpaper data retain their own copyright and license terms. Keep embedded attribution and obtain necessary rights before redistributing assets.

## Warranty and signing

This is research software supplied without warranty, subject to the licenses above. The configurable bundle identifier must match its CodeDirectory identifier and be allowed by the signing profile. A valid signature does not establish that the technique works on a particular device. No certificate, private signing key, provisioning profile or signed IPA is included.
