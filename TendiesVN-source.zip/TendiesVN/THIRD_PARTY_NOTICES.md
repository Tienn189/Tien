# Third-party notices and source provenance

1809 3.4.0 (build 18) restores the scoped PosterBoard package installer and launcher from 1809 build 14. The Photos export workflow, media previews and detail gallery have been removed. After a committed write the app opens PosterBoard; the user closes its card in the app switcher and selects wallpaper in iOS Settings.

## 3105 and restored installer

- Author: YangJiii and contributors.
- Source: <https://github.com/YangJiiii/3105>.
- Reference commit: `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.
- License for upstream portions: GNU GPL version 3; included as `LICENSE`.
- Adaptations: bounded ZIP extraction, package inspection, sandbox-local package storage, descriptor parsing/rewriting, installation journals, rollback/restore, scoped PosterBoard access and native launcher.
- `PosterBoardBridge.m` retains the `bad_query` sandbox-extension technique attributed by upstream to forcequitOS. Its bounded filesystem/metadata discovery also follows Placard/Bad-Poster's approach, as noted in the source.
- The bridge checks the fixed Application/UUID root and verifies `MCMMetadataIdentifier` equals `com.apple.PosterBoard` before granting retained root access. This is a private iOS mechanism, not a public-API wallpaper feature.
- The restored bridge and Swift predicate are limited to iOS 26.0–26.6.1. Installation on iOS 17, 18, later iOS 26 or iOS 27 has no corresponding backend in this archive.
- `DeviceCompatibility.swift` retains four informational iOS 27 beta labels from upstream `SupportPolicy.swift`; they do not imply wallpaper installation or device test results.

No new kernel access chain, general system-container browser, Wallet/passcode tool, patch engine, cleaner, editor or Airlift framework is bundled. The launcher is restricted to `com.apple.PosterBoard`; it does not kill system processes or automatically open the app switcher.

## Pocket Poster and format references

- [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster) by LeminLimez and contributors: wallpaper archive/format reference; GPL-3.0.
- 3105 acknowledges Pocket Poster/Nugget for wallpaper formats. The Nugget application is not bundled.

Imported packages, their media and embedded attribution keep their own copyrights. Renaming this application does not change those rights.

## Pairing transport

- [idevice](https://github.com/jkcoxson/idevice), Jackson Coxson and contributors, version `v0.1.68`.
- MIT license included in `ThirdParty/idevice-LICENSE.txt`.
- The build helper downloads the pinned release and verifies its checksum. Pairing uses authenticated device sessions and the user's imported/generated record; it does not supply this installer's wallpaper access.
- LocalDevVPN is a separate linked app and is not bundled.

## System frameworks and 1809 changes

Foundation, SwiftUI, UIKit, UniformTypeIdentifiers, Security, Network and SystemConfiguration are Apple system frameworks. The restored scoped launcher uses private LaunchServices selectors. The app no longer requests Photos authorization or creates Photos assets.

The Vietnamese UI, minimal library, six accent presets/custom appearance, compact settings, status UI, build diagnostics, validation and packaging are adapted or implemented for 1809. No certificate, private signing key, pairing record, provisioning profile, prebuilt dependency archive or signed IPA is included in this source ZIP.
