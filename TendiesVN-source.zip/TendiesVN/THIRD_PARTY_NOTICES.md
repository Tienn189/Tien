# Third-party notices and source provenance

1809 3.1.0 (build 13), updated on 2026-10-18, is a wallpaper-focused application with a Vietnamese SwiftUI interface. Its public source reference is [Pocket-Poster by leminlimez](https://github.com/leminlimez/Pocket-Poster). This project does not claim authorship of upstream research, formats or retained code. The editor and its web runtime have been removed; they are not part of this distribution.

The installer retains source adapted from the projects below. Renaming the app does not change those sources' attribution or licensing requirements.

## 3105

- Author: YangJiii and contributors.
- Source: <https://github.com/YangJiiii/3105>.
- Pinned source commit: `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.
- License stated by upstream: GNU GPL version 3 for original portions; the complete text is included in `LICENSE`.
- Adapted wallpaper components: ZIP extraction, package inspection, PosterBoard layout discovery, descriptor rewriting, install receipts and scoped restoration.
- Access integration adapts the MobileContainerManager lookup and `bad_query` foundations in `ThreeOneOSFive/exploit/mcm_bridge.m` and `ThreeOneOSFive/exploit/bad_query.c` at that commit.
- `PosterBoardRefresh.m` adapts the `LSApplicationWorkspace` launcher in `ThreeOneOSFive/helpers/AppIconHelper.m` at that commit, restricted to the fixed PosterBoard identifier. It does not force-quit a process or open the app switcher automatically.

1809 changes the Vietnamese UI, packaging, validation and integration. It excludes the unrelated app-data browser, patch engine, dialer themes, cleaner and kernel-exploit chain. The 1.1 bridge has no requirement to sign as `com.apple.mobile.MobileHouseArrest`.

## Independent-identity backend

The new implementation is in `TendiesVN/Engine/PosterBoardBridge.m` and `.h`. It uses exact PosterBoard metadata lookup, validates container identity, and obtains an extension scoped to the validated PosterBoard root. Discovery fallback examines fixed container metadata rather than other applications' content. It does not include a general file browser, broad recursive root grant, kernel exploit or automatic respring.

| Source | Revision / material reviewed | Attribution / terms |
| --- | --- | --- |
| [forcequitOS/bad_query](https://github.com/forcequitOS/bad_query) | Sandbox-extension technique incorporated through the pinned 3105 source above | forcequitOS and contributors; no separate upstream license grant is asserted here. |
| [frs0n/placard](https://github.com/frs0n/placard) | `7dcefb610cc60ae909b6046beee7adb691148e44`, `placard/Exploit/BadQuery.swift` discovery/access implementation reviewed | frs0n and contributors; repository publishes GPL-3.0. |
| [nxtcoreee3/Bad-Poster](https://github.com/nxtcoreee3/Bad-Poster) | `60d845647e04551dad09d5d3f58f7b97e9d63c7f`, `Pocket Poster/Exploit/BadQuery.swift` reviewed | nxtcoreee3, Mak5er, LeminLimez and contributors; derived from Pocket Poster. |

Placard and Bad-Poster were reviewed to understand independent-identity PosterBoard discovery. No complete upstream app, editor, video generator, catalog, artwork, Airlift framework or respring component is bundled by this change. Consult the source for the final implementation.

## Other acknowledged foundations

| Project / contributor | Contribution acknowledged by 3105 | Source |
| --- | --- | --- |
| LeminLimez and contributors | Pocket Poster, Nugget and the `.tendies` format | [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster), [Nugget](https://github.com/leminlimez/Nugget) |
| 0xjohnnydev and FilzaSlop contributors | MobileContainerManager app-container research | [FilzaSlop](https://github.com/0xjohnnydev/FilzaSlop), [MobileHouseArrest-PoC](https://github.com/0xjohnnydev/MobileHouseArrest-PoC) |
| CrazyMind90 | FilzaSlop sandbox-escape foundation | [Profile](https://github.com/CrazyMind90) |
| opa334 and Dopamine contributors | Kernel-exploit research acknowledged by 3105; that chain is excluded here | [Dopamine](https://github.com/opa334/Dopamine) |

These are provenance acknowledgments, not a statement that every named project's code is included. Pocket-Poster publishes GPL-3.0. Nugget publishes AGPL-3.0; its format documentation was a reference, not copied as an application dependency.


## Unresolved third-party licensing

The pinned 3105 notices state that FilzaSlop did not expose a repository license when those notices were prepared and that 3105's GPL covers only material its owner has the right to license. Placard also notes that upstream `bad_query` may not declare a separate license. Attribution does not supply missing redistribution permission.

1809 retains those limitations. This handoff does not assert a verified GPL/LGPL grant for every predecessor of the container-access code or a separate license from the `bad_query` author. Review the included implementation and upstream terms, and obtain missing permission before redistributing affected source or a compiled derivative. The top-level GPL does not override third-party rights.

Imported `.tendies` packages and Apple wallpaper data retain their own copyright and license terms. Keep embedded attribution and obtain necessary rights before redistributing assets.

## Warranty and signing

This is research software supplied without warranty, subject to the licenses above. The configurable bundle identifier must match its CodeDirectory identifier and be allowed by the signing profile. A valid signature does not establish that the technique works on a particular device. No certificate, private signing key, provisioning profile or signed IPA is included.


## idevice developer pairing library (3.1.0)

The LocalDevVPN connection and on-device pairing implementation uses [jkcoxson/idevice](https://github.com/jkcoxson/idevice), release **v0.1.68**. Copyright 2026 Jackson Coxson. Its MIT license is reproduced in `ThirdParty/idevice-LICENSE.txt`; dependencies retain their respective upstream licenses.

The pinned release archive is `idevice-xcframework-v0.1.68.zip` with SHA256 `c9eccdd1942de756d746a2569d93302774ab0eff1cff314ec8118f768b3d8dc7`. The app bindings match that archive's header (SHA256 `696286794e8cf1c18a91d4dab5046cef4d9bae352f5e7a1ad33fbc0ba30d7ab4`). `scripts/prepare-idevice.py` verifies both before extracting a selected static-library slice. The source handoff excludes the downloaded archive and build cache.

New integration calls are limited to developer pairing, authenticated session/tunnel establishment, and read-only device identity. Pairing data is stored locally in Keychain and never sent to a web service. The existing PosterBoard installer and its provenance remain as documented above.
