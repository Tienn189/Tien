# Third-party notices and source provenance

1809 3.3.0 (build 15) is a Vietnamese SwiftUI wallpaper package library. The wallpaper flow uses public Apple frameworks to inspect media, add selected resources to Photos and share files. The user sets wallpaper in iOS Settings.

## 3105

- Author: YangJiii and contributors.
- Source: <https://github.com/YangJiiii/3105>.
- Reference commit: `a72617ed4c764a65d8aac1e91aca95231e72a2cb`.
- License for original upstream portions: GNU GPL version 3; included as `LICENSE`.
- Retained adaptations: bounded ZIP extraction, package inspection, sandbox-local library storage and descriptor-format parsing.
- `DeviceCompatibility.swift` retains four iOS 27 beta build labels from upstream `SupportPolicy.swift`. They are informational labels, not installation capability or device test results.

The kernel access chain, MobileContainerManager/bad_query bridge, sandbox-extension access, native PosterBoard launcher, system wallpaper installer and restore implementation are absent from this distribution. No arbitrary system-container browser, patch engine, Wallet/passcode tool, cleaner, editor or Airlift framework is included.

## Pocket Poster and format references

- [Pocket-Poster](https://github.com/leminlimez/Pocket-Poster) by LeminLimez and contributors: wallpaper archive/format reference; GPL-3.0.
- 3105 acknowledges Pocket Poster/Nugget for wallpaper formats. 1809 does not bundle the Nugget application or its implementation.

Imported packages, their media and embedded attribution keep their own copyrights. Renaming the application does not change those rights.

## Pairing transport

- [idevice](https://github.com/jkcoxson/idevice), Jackson Coxson and contributors, version `v0.1.68`.
- The MIT license is included in `ThirdParty/idevice-LICENSE.txt`.
- The build helper downloads the pinned release and verifies its checksum. Pairing uses authenticated device sessions and the user's imported/generated record. It is independent from wallpaper saving and does not supply wallpaper filesystem access.
- LocalDevVPN is a separate app, linked for optional local device connectivity; it is not bundled.

## Apple public frameworks

Photos, ImageIO, CoreGraphics, UniformTypeIdentifiers, AVFoundation/AVKit, SwiftUI and UIKit are system frameworks. Photos authorization is add-only; the wallpaper flow does not read or delete Photos assets or set the system wallpaper.

## Changes in 1809

The Vietnamese UI, minimal library, appearance settings, media catalog, Photos/share export, app-owned save history, validation and packaging are adapted or implemented for 1809. No certificate, private signing key, pairing record, provisioning profile or signed IPA is included in this source archive.
