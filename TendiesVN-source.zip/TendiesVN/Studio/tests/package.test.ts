// @vitest-environment jsdom
import { describe, expect, it } from 'vitest';
import JSZip from 'jszip';
import { writeFile } from 'node:fs/promises';
import { addImage, createDocument, exportPackage, importPackage, makeLayer } from '../src/package';
import { motionAt } from '../src/motion';
import { clearLayerState, easeProgress, interpolateLayer, patchLayerState, resolveLayer, sceneRole } from '../src/states';

const rootPath = 'descriptors/12345678-1234-4234-8234-123456789ABC';
const camlPath = `${rootPath}/versions/1/contents/Original.wallpaper/Wallpaper.ca/main.caml`;

async function fixture(xml: string, extra?: Record<string, Uint8Array | string>) {
  const zip = new JSZip();
  zip.file(camlPath, xml, { createFolders: false });
  zip.file(`${rootPath}/untouched.bin`, new Uint8Array([0, 255, 19]), { createFolders: false });
  for (const [path, data] of Object.entries(extra ?? {})) zip.file(path, data, { createFolders: false });
  return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', platform: 'UNIX' });
}

const importedXML = `<?xml version="1.0"?><caml xmlns="http://www.apple.com/CoreAnimation/1.0" custom="preserve-me">
 <CALayer id="original-root" name="Root" bounds="0 0 390 844" position="195 422" backgroundColor="0 0 0 1">
  <sublayers>
   <CALayer id="group" name="Group" bounds="0 0 300 400" position="195 422"><sublayers>
    <CATextLayer id="title" name="Title" bounds="0 0 220 60" position="150 100" opacity="0.8500" string="Original" fontSize="40" customAttribute="keep">
     <filters><CAFilter type="privateFilter"><input key="opaque" value="do not remove"/></CAFilter></filters>
     <mask><CALayer id="mask-private" name="Internal mask" bounds="0 0 5 5"/></mask>
     <animations><animation type="CAKeyframeAnimation" key="original-animation" keyPath="opacity"><values><real value="0.7"/><real value="1"/></values></animation></animations>
    </CATextLayer>
   </sublayers></CALayer>
   <CAEmitterLayer id="advanced" name="Particles" bounds="0 0 390 844" position="195 422"><emitterCells><CAEmitterCell name="spark" custom="42"/></emitterCells></CAEmitterLayer>
  </sublayers>
 </CALayer><states><LKState name="Locked"><elements><LKStateElement targetId="title" custom="state-data"/></elements></LKState></states>
</caml>`;

describe('TendiesVN package editor', () => {
  it('resizes the CAML player and root together, preserving other plist keys', async () => {
    const doc = createDocument('Dự án đổi cỡ', 390, 844), scene = doc.project.scenes[0];
    const indexPath = scene.camlPath.replace('main.caml', 'index.xml');
    const source = new TextDecoder().decode(doc.files.get(indexPath)!);
    doc.files.set(indexPath, new TextEncoder().encode(source.replace('<plist', '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist')));
    scene.width = 768; scene.height = 1024;
    const result = await exportPackage(doc), zip = await JSZip.loadAsync(result.data);
    const root = new DOMParser().parseFromString(await zip.file(scene.camlPath)!.async('string'), 'application/xml').getElementsByTagName('CALayer')[0];
    expect(root.getAttribute('bounds')).toBe('0 0 768 1024');
    expect(root.getAttribute('position')).toBe('384 512');
    const index = await zip.file(indexPath)!.async('string');
    expect(index).toContain('<key>documentWidth</key><real>768</real>');
    expect(index).toContain('<key>documentHeight</key><real>1024</real>');
    expect(index).toContain('<key>scalesToFitInPlayer</key><true/>');
    const again = await importPackage(result.data, result.filename);
    expect(again.project.scenes[0].width).toBe(768);
  });

  it('exports a real ZIP, escaped text, image assets and editable motion, then reopens exactly', async () => {
    const doc = createDocument('Thử & "chữ"', 390, 844), scene = doc.project.scenes[0];
    const title = makeLayer('text', scene);
    title.text = '<Tendies> & "Việt Nam" 😀'; title.fontWeight = 'bold';
    title.motion = { preset: 'float', duration: 4, delay: 0.5, amount: 18 };
    const shape = makeLayer('shape', scene); shape.color = '#f05c88'; shape.rotation = 15;
    const image = makeLayer('image', scene);
    image.imagePath = addImage(doc, new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]), 'image/png', 'ảnh.png');
    scene.layers.push(shape, image, title);
    const result = await exportPackage(doc);
    expect(result.filename).toBe('Thử & -chữ-.tendies');
    expect([...result.data.slice(0, 2)]).toEqual([0x50, 0x4b]);
    const zip = await JSZip.loadAsync(result.data, { checkCRC32: true });
    const xml = await zip.file(scene.camlPath)!.async('string');
    const parsed = new DOMParser().parseFromString(xml, 'application/xml');
    const text = parsed.getElementsByTagName('CATextLayer')[0];
    expect(text.getElementsByTagName('string')[0].getAttribute('value')).toBe(title.text);
    expect(text.getElementsByTagName('font')[0].getAttribute('value')).toBe('HelveticaNeue-Bold');
    expect(parsed.getElementsByTagName('backgroundColor')[0].getAttribute('type')).toBe('CGColor');
    expect(parsed.getElementsByTagName('animation')[0].getAttribute('key')).toBe('tendiesvn.float');
    expect(await zip.file(image.imagePath)!.async('uint8array')).toEqual(doc.files.get(image.imagePath));
    expect(zip.file('tendiesvn.project.json')).toBeTruthy();
    const again = await importPackage(result.data, result.filename);
    expect(again.project.scenes[0].layers.map(l => [l.id, l.type, l.text, l.color, l.rotation, l.motion])).toEqual(scene.layers.map(l => [l.id, l.type, l.text, l.color, l.rotation, l.motion]));
    const savedImage = again.project.scenes[0].layers.find(l => l.type === 'image')!;
    expect(savedImage.imagePath!.startsWith(scene.descriptorPath + '/')).toBe(true);
    expect(again.files.get(savedImage.imagePath!)).toEqual(doc.files.get(image.imagePath));
    expect(again.project.scenes[0].layers.every(l => l.binding?.startsWith('node:'))).toBe(true);
    const twice = await exportPackage(again);
    const third = await importPackage(twice.data, twice.filename);
    expect(third.project.scenes[0].layers).toEqual(again.project.scenes[0].layers);
  });

  it('creates neutral descriptor metadata, three CA roots and no bundled vendor script or artwork', async () => {
    const doc = createDocument('Tên mới', 390, 844), scene = doc.project.scenes[0];
    const result = await exportPackage(doc), zip = await JSZip.loadAsync(result.data);
    const descriptor = scene.descriptorPath;
    expect(await zip.file(`${descriptor}/com.apple.posterkit.role.identifier`)!.async('string')).toBe('PRPosterRoleLockScreen');
    expect((await zip.file(`${descriptor}/providerInfo.plist`)!.async('string')).startsWith('bplist00')).toBe(true);
    const caRoots = Object.keys(zip.files).filter(p => p.endsWith('/main.caml'));
    expect(caRoots).toHaveLength(3);
    for (const path of caRoots) {
      expect(zip.file(path.replace('main.caml', 'index.xml'))).toBeTruthy();
      expect(zip.file(path.replace('main.caml', 'assetManifest.caml'))).toBeTruthy();
    }
    expect(Object.keys(zip.files).some(path => /\.(?:js|png|jpg)$/i.test(path))).toBe(false);
    if (process.env.STUDIO_FIXTURE_OUT) await writeFile(process.env.STUDIO_FIXTURE_OUT, result.data);
    const unmanifested = new JSZip();
    for (const file of Object.values(zip.files)) if (file.name !== 'tendiesvn.project.json' && !file.dir) unmanifested.file(file.name, await file.async('uint8array'), { createFolders: false });
    const reopened = await importPackage(await unmanifested.generateAsync({ type: 'uint8array' }), 'neutral.tendies');
    expect(reopened.project.scenes).toHaveLength(3); // Asset manifests are preserved, not mistaken for scenes.
  });

  it('changes known text while preserving advanced XML, nested groups, private masks, states and unrelated bytes', async () => {
    const data = await fixture(importedXML), doc = await importPackage(data, 'original.tendies');
    const scene = doc.project.scenes[0], text = scene.layers.find(l => l.type === 'text')!;
    expect(scene.layers).toHaveLength(4); // Editable root + three real layers; mask remains opaque.
    expect(text.parentId).toBe(scene.layers.find(l => l.type === 'group' && !l.isRoot)!.id);
    expect(doc.warnings.length).toBeGreaterThan(0);
    text.text = 'Đã sửa <&>'; text.x += 10;
    const output = await exportPackage(doc), zip = await JSZip.loadAsync(output.data);
    const xml = await zip.file(camlPath)!.async('string'), parsed = new DOMParser().parseFromString(xml, 'application/xml');
    const title = parsed.getElementsByTagName('CATextLayer')[0];
    expect(title.getElementsByTagName('string')[0].getAttribute('value')).toBe('Đã sửa <&>');
    expect(title.getAttribute('opacity')).toBe('0.8500');
    expect(title.getAttribute('customAttribute')).toBe('keep');
    expect(title.getElementsByTagName('mask')[0].getElementsByTagName('CALayer')[0].getAttribute('id')).toBe('mask-private');
    expect(parsed.getElementsByTagName('CAEmitterCell')[0].getAttribute('custom')).toBe('42');
    expect(parsed.getElementsByTagName('LKStateElement')[0].getAttribute('custom')).toBe('state-data');
    expect(parsed.getElementsByTagName('input')[0].getAttribute('value')).toBe('do not remove');
    expect(parsed.getElementsByTagName('animation')[0].getAttribute('key')).toBe('original-animation');
    expect(await zip.file(`${rootPath}/untouched.bin`)!.async('uint8array')).toEqual(new Uint8Array([0, 255, 19]));
  });

  it('preserves an imported image reference unless the image is explicitly replaced', async () => {
    const path = `${rootPath}/versions/1/contents/Original.wallpaper/Wallpaper.ca/assets/picture.png`;
    const xml = `<caml xmlns="http://www.apple.com/CoreAnimation/1.0"><CALayer bounds="0 0 390 844"><sublayers><CALayer name="Photo" bounds="0 0 100 100" position="90 90"><contents type="CGImage" src="assets/picture.png" extra="opaque"/></CALayer></sublayers></CALayer></caml>`;
    const doc = await importPackage(await fixture(xml, { [path]: new Uint8Array([1, 2, 3]) }), 'photo.tendies');
    expect(doc.project.scenes[0].layers.find(layer => layer.type === 'image')!.imagePath).toBe(path);
    const result = await exportPackage(doc), zip = await JSZip.loadAsync(result.data);
    const output = new DOMParser().parseFromString(await zip.file(camlPath)!.async('string'), 'application/xml');
    expect(output.getElementsByTagName('contents')[0].getAttribute('src')).toBe('assets/picture.png');
    expect(output.getElementsByTagName('contents')[0].getAttribute('extra')).toBe('opaque');
  });

  it('replaces a nested CGImage source without creating conflicting property values', async () => {
    const oldAsset = `${rootPath}/versions/1/contents/Original.wallpaper/Wallpaper.ca/assets/old.png`;
    const xml = `<caml xmlns="http://www.apple.com/CoreAnimation/1.0"><CALayer bounds="0 0 390 844"><sublayers><CALayer name="Photo" bounds="0 0 100 100"><contents><CGImage src="assets/old.png" interpolationQuality="high"/></contents></CALayer></sublayers></CALayer></caml>`;
    const doc = await importPackage(await fixture(xml, { [oldAsset]: new Uint8Array([1]) }), 'photo.tendies');
    const layer = doc.project.scenes[0].layers.find(layer => layer.type === 'image')!;
    layer.imagePath = addImage(doc, new Uint8Array([2, 3]), 'image/jpeg', 'new.jpg');
    const result = await exportPackage(doc), zip = await JSZip.loadAsync(result.data);
    const output = new DOMParser().parseFromString(await zip.file(camlPath)!.async('string'), 'application/xml');
    const contents = output.getElementsByTagName('contents')[0], image = contents.getElementsByTagName('CGImage')[0];
    expect(contents.hasAttribute('src')).toBe(false);
    expect(image.getAttribute('src')).not.toBe('assets/old.png');
    expect(image.getAttribute('interpolationQuality')).toBe('high');
    const reopened = await importPackage(result.data, result.filename);
    const path = reopened.project.scenes[0].layers.find(layer => layer.type === 'image')!.imagePath!;
    expect(path.startsWith(rootPath + '/')).toBe(true);
    expect(reopened.files.get(path)).toEqual(new Uint8Array([2, 3]));
  });

  it('rejects traversal, absolute paths, collisions and symbolic links before decompression', async () => {
    for (const path of ['../outside.txt', '/outside.txt', 'assets/../outside.txt', 'C:/outside.txt', 'assets\\outside.txt']) {
      const zip = new JSZip(); zip.file(path, 'bad', { createFolders: false });
      await expect(importPackage(await zip.generateAsync({ type: 'uint8array' }), 'bad.tendies')).rejects.toThrow();
    }
    const collision = new JSZip(); collision.file('Image.png', 'one'); collision.file('image.png', 'two');
    await expect(importPackage(await collision.generateAsync({ type: 'uint8array' }), 'bad.tendies')).rejects.toThrow(/trùng/);
    const symlink = new JSZip(); symlink.file('link', '../outside', { unixPermissions: 0o120777 });
    await expect(importPackage(await symlink.generateAsync({ type: 'uint8array', platform: 'UNIX' }), 'bad.tendies')).rejects.toThrow(/liên kết/);
  });

  it('rejects XML entities and invalid hierarchy without overwriting the source document', async () => {
    const data = await fixture('<!DOCTYPE caml [<!ENTITY x SYSTEM "file:///etc/passwd">]><caml><CALayer string="&x;"/></caml>');
    await expect(importPackage(data, 'entity.tendies')).rejects.toThrow(/XML/);
    const doc = createDocument(), scene = doc.project.scenes[0], layer = makeLayer('group', scene);
    layer.parentId = layer.id; scene.layers.push(layer);
    await expect(exportPackage(doc)).rejects.toThrow(/vòng lặp/);
    expect(doc.files.get(scene.camlPath)).toBeTruthy();
  });

  it('previews motion consistently and keeps delayed motion still', () => {
    const m = { preset: 'float' as const, duration: 4, delay: 1, amount: 12 };
    expect(motionAt(m, 0.5).dy).toBe(0);
    expect(motionAt(m, 2).dy).toBeCloseTo(-12);
    expect(motionAt({ ...m, preset: 'spin' }, 3).rotation).toBeCloseTo(180);
    expect(motionAt({ ...m, preset: 'pulse', amount: 20 }, 2).scale).toBeCloseTo(1.2);
  });
});
