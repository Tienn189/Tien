// @vitest-environment jsdom
import { describe, expect, it } from 'vitest';
import JSZip from 'jszip';
import { writeFile } from 'node:fs/promises';
import { createDocument, exportPackage, importPackage, makeLayer } from '../src/package';
import { clearLayerState, easeProgress, interpolateLayer, patchLayerState, resolveLayer, sceneRole } from '../src/states';

async function systemOnly(data: Uint8Array) {
  const original = await JSZip.loadAsync(data), out = new JSZip();
  for (const file of Object.values(original.files)) if (!file.dir && file.name !== 'tendiesvn.project.json') out.file(file.name, await file.async('uint8array'), { createFolders: false });
  return out.generateAsync({ type: 'uint8array' });
}
function xml(value: string) { return new DOMParser().parseFromString(value, 'application/xml'); }

describe('Real wallpaper states and scene roles', () => {
  it('has distinct Background/Floating documents with editable independent roots', () => {
    const doc = createDocument();
    expect(doc.project.scenes.map(sceneRole)).toEqual(['Background', 'Floating']);
    const [background, floating] = doc.project.scenes;
    expect(background.descriptorPath).toBe(floating.descriptorPath);
    expect(background.camlPath).not.toBe(floating.camlPath);
    expect(background.layers[0].isRoot).toBe(true);
    expect(floating.layers[0].backgroundColor).toBe('#00000000');
    expect(makeLayer('text', floating).parentId).toBe(floating.layers[0].id);
  });

  it('keeps Base and each state separate and interpolates actual resolved appearance', () => {
    const scene = createDocument().project.scenes[0];
    let layer = makeLayer('shape', scene); layer.x = 10; layer.color = '#000000'; layer.backgroundColor = '#000000';
    layer = patchLayerState(layer, 'Locked', { x: 30, scale: .8, color: '#ffffff', visible: false });
    layer = patchLayerState(layer, 'Unlock', { x: 110, opacity: .4 });
    expect(layer.x).toBe(10); expect(resolveLayer(layer, 'Locked').x).toBe(30); expect(resolveLayer(layer, 'Unlock').x).toBe(110);
    const middle = interpolateLayer(resolveLayer(layer, 'Base'), resolveLayer(layer, 'Locked'), .5);
    expect(middle.x).toBe(20); expect(middle.scale).toBeCloseTo(.9); expect(middle.color).toBe('#808080ff');
    expect(middle.visible).toBe(true); expect(interpolateLayer(layer, resolveLayer(layer, 'Locked'), 1).visible).toBe(false);
    expect(resolveLayer(clearLayerState(layer, 'Locked'), 'Locked').x).toBe(10);
    expect(easeProgress(.5, 'easeIn')).toBeLessThan(.5); expect(easeProgress(.5, 'easeOut')).toBeGreaterThan(.5);
    expect(easeProgress(.5, 'easeInOut')).toBeCloseTo(.5); expect(easeProgress(.5, 'linear')).toBe(.5);
  });

  it('exports true LKStateSetValue and animated Locked→Unlock, with fallback values in every system state', async () => {
    const doc = createDocument('Bốn trạng thái'), scene = doc.project.scenes[1];
    scene.transition = { duration: .9, timing: 'easeOut' };
    scene.layers[0] = patchLayerState(scene.layers[0], 'Locked', { opacity: .35, scale: .8 });
    const title = makeLayer('text', scene); title.name = 'State text'; title.x = 12; title.y = 30; title.width = 200;
    title.states = { Locked: { x: 42, rotation: 45, text: 'Đã khoá', color: '#e60000' }, Unlock: { x: 142, rotation: 0, text: 'Mở khoá' } };
    scene.layers.push(title);
    const output = await exportPackage(doc), zip = await JSZip.loadAsync(output.data);
    const document = xml(await zip.file(scene.camlPath)!.async('string'));
    const states = [...document.getElementsByTagName('LKState')];
    expect(states.map(state => state.getAttribute('name'))).toEqual(['Locked', 'Unlock', 'Sleep']);
    const textNode = document.getElementsByTagName('CATextLayer')[0], id = textNode.getAttribute('id');
    for (const state of states) {
      const actions = [...state.getElementsByTagName('LKStateSetValue')].filter(node => node.getAttribute('targetId') === id);
      expect(actions.map(action => action.getAttribute('keyPath'))).toEqual(expect.arrayContaining(['position', 'bounds', 'anchorPoint', 'transform.rotation.z', 'string', 'foregroundColor']));
    }
    const locked = states.find(state => state.getAttribute('name') === 'Locked')!;
    const rotation = [...locked.getElementsByTagName('LKStateSetValue')].find(action => action.getAttribute('targetId') === id && action.getAttribute('keyPath') === 'transform.rotation.z')!;
    expect(Number(rotation.getElementsByTagName('value')[0].getAttribute('value'))).toBeCloseTo(Math.PI / 4);
    const transition = [...document.getElementsByTagName('LKStateTransition')].find(node => node.getAttribute('fromState') === 'Locked' && node.getAttribute('toState') === 'Unlock')!;
    const animation = transition.getElementsByTagName('animation')[0];
    expect(animation.getAttribute('type')).toBe('CABasicAnimation'); expect(animation.getAttribute('duration')).toBe('0.9');
    expect(animation.getAttribute('timingFunction')).toBe('easeOut');
    const reopened = await importPackage(await systemOnly(output.data), 'system-state.tendies');
    const floating = reopened.project.scenes.find(value => sceneRole(value) === 'Floating')!;
    const imported = floating.layers.find(layer => layer.name === title.name)!;
    expect(resolveLayer(imported, 'Base').x).toBe(12); expect(resolveLayer(imported, 'Locked').x).toBe(42); expect(resolveLayer(imported, 'Unlock').x).toBe(142); expect(resolveLayer(imported, 'Sleep').x).toBe(12);
    expect(resolveLayer(imported, 'Locked').rotation).toBeCloseTo(45); expect(resolveLayer(imported, 'Unlock').text).toBe('Mở khoá');
    expect(resolveLayer(floating.layers.find(layer => layer.isRoot)!, 'Locked').opacity).toBe(.35);
    if (process.env.STUDIO_STATES_FIXTURE_OUT) await writeFile(process.env.STUDIO_STATES_FIXTURE_OUT, output.data);
  });

  it('imports root state actions and preserves custom states, unknown actions and transition attributes when edited', async () => {
    const path = 'descriptors/11111111-1111-4111-8111-111111111111/versions/1/contents/Custom.wallpaper/Floating.ca/main.caml';
    const source = `<caml xmlns="http://www.apple.com/CoreAnimation/1.0"><CALayer id="root-node" name="Root Layer" bounds="0 0 390 844" position="195 422"><sublayers/><states>
      <LKState name="Locked"><elements><LKStateSetValue targetId="root-node" keyPath="opacity" custom="retain"><value type="real" value="0.2"/></LKStateSetValue><LKStateSetValue targetId="root-node" keyPath="privateEffect"><value type="string" value="opaque"/></LKStateSetValue></elements></LKState>
      <LKState name="CustomState" custom="custom-state"><elements><LKStateSetValue targetId="root-node" keyPath="speed"><value type="real" value="2"/></LKStateSetValue></elements></LKState>
      </states><stateTransitions><LKStateTransition fromState="Locked" toState="Unlock" custom="transition"><elements><LKStateTransitionElement targetId="root-node" key="opacity" custom="action"><animation type="CASpringAnimation" duration="1.25" damping="18"/></LKStateTransitionElement></elements></LKStateTransition><LKStateTransition fromState="CustomState" toState="Locked"><elements><privateTransition value="preserve"/></elements></LKStateTransition></stateTransitions></CALayer></caml>`;
    const input = new JSZip(); input.file(path, source, { createFolders: false });
    const doc = await importPackage(await input.generateAsync({ type: 'uint8array' }), 'custom.tendies'), scene = doc.project.scenes[0];
    expect(scene.layers).toHaveLength(1); expect(scene.layers[0].isRoot).toBe(true); expect(resolveLayer(scene.layers[0], 'Locked').opacity).toBe(.2);
    scene.layers[0] = patchLayerState(scene.layers[0], 'Locked', { opacity: .6 });
    const out = await exportPackage(doc), zip = await JSZip.loadAsync(out.data), document = xml(await zip.file(path)!.async('string'));
    expect([...document.getElementsByTagName('LKState')].find(node => node.getAttribute('name') === 'CustomState')!.getAttribute('custom')).toBe('custom-state');
    expect([...document.getElementsByTagName('LKStateSetValue')].find(node => node.getAttribute('keyPath') === 'privateEffect')!.getElementsByTagName('value')[0].getAttribute('value')).toBe('opaque');
    expect([...document.getElementsByTagName('LKStateSetValue')].find(node => node.getAttribute('keyPath') === 'opacity')!.getAttribute('custom')).toBe('retain');
    expect(document.getElementsByTagName('privateTransition')[0].getAttribute('value')).toBe('preserve');
    const animation = [...document.getElementsByTagName('animation')].find(node => node.getAttribute('type') === 'CASpringAnimation')!;
    expect(animation.getAttribute('damping')).toBe('18'); expect(animation.getAttribute('duration')).toBe('1.25');
  });

  it('roundtrips gradients, 3D geometry, filters and typed keyframes through system XML', async () => {
    const doc = createDocument(), scene = doc.project.scenes[1], gradient = makeLayer('gradient', scene);
    gradient.name = 'Gradient 3D'; gradient.gradientColors = ['#ff0000', '#0000ff80']; gradient.gradientStart = [0, .25]; gradient.gradientEnd = [1, .75];
    gradient.z = 8; gradient.rotationX = 20; gradient.rotationY = -15; gradient.scale = 1.2; gradient.anchorX = .2; gradient.anchorY = .8;
    gradient.borderColor = '#ffffff'; gradient.borderWidth = 3; gradient.clipContents = true; gradient.blendMode = 'screen';
    gradient.filters = [{ id: 'blur', type: 'gaussianBlur', amount: 12, enabled: true }, { id: 'hue', type: 'hueRotate', amount: 45, enabled: true }, { id: 'sepia', type: 'sepia', amount: .5, enabled: true }];
    gradient.animations = [{ id: 'rotate', property: 'transform.rotation.y', from: -30, to: 30, duration: 2, delay: .4, repeat: true, autoreverses: true, enabled: true }, { id: 'move', property: 'position', from: [10, 20], to: [110, 220], duration: 3, delay: 0, repeat: false, autoreverses: false, enabled: true }, { id: 'bounds', property: 'bounds', from: [100, 200], to: [200, 300], duration: 3, delay: 0, repeat: false, autoreverses: false, enabled: true }];
    scene.layers.push(gradient);
    const out = await exportPackage(doc), reopened = await importPackage(await systemOnly(out.data), 'typed.tendies');
    const imported = reopened.project.scenes.flatMap(value => value.layers).find(layer => layer.name === gradient.name)!;
    expect(imported.type).toBe('gradient'); expect(imported.gradientColors).toEqual(gradient.gradientColors);
    expect(imported.rotationX).toBeCloseTo(20); expect(imported.rotationY).toBeCloseTo(-15); expect(imported.scale).toBe(1.2); expect(imported.anchorX).toBe(.2);
    expect(imported.blendMode).toBe('screen'); expect(imported.filters).toEqual(gradient.filters);
    expect(imported.animations![0].from).toBeCloseTo(-30); expect(imported.animations![0].to).toBeCloseTo(30);
    expect(imported.animations![1].from).toEqual([10, 20]); expect(imported.animations![2].to).toEqual([200, 300]);
  });

  it('upgrades an old manifest without changing child identifiers or losing the existing Floating scene', async () => {
    const doc = createDocument(), scene = doc.project.scenes[0], child = makeLayer('text', scene); scene.layers.push(child);
    const out = await exportPackage(doc), zip = await JSZip.loadAsync(out.data), project = JSON.parse(await zip.file('tendiesvn.project.json')!.async('string'));
    project.scenes = project.scenes.slice(0, 1); project.scenes[0].layers = project.scenes[0].layers.filter((layer: { isRoot?: boolean }) => !layer.isRoot);
    project.scenes[0].layers[0].parentId = null; delete project.scenes[0].role; delete project.scenes[0].transition; delete project.scenes[0].layers[0].states;
    zip.file('tendiesvn.project.json', JSON.stringify(project));
    const reopened = await importPackage(await zip.generateAsync({ type: 'uint8array' }), 'legacy.tendies');
    expect(reopened.project.scenes.map(sceneRole)).toEqual(['Background', 'Floating']);
    const root = reopened.project.scenes[0].layers.find(layer => layer.isRoot)!;
    const upgraded = reopened.project.scenes[0].layers.find(layer => !layer.isRoot)!;
    expect(upgraded.id).toBe(child.id); expect(upgraded.parentId).toBe(root.id);
  });

  it('imports scale aliases and never applies an untargeted action to an unnamed layer', async () => {
    const path = 'descriptors/11111111-1111-4111-8111-111111111111/versions/1/contents/Test.wallpaper/Floating.ca/main.caml';
    const source = `<caml xmlns="http://www.apple.com/CoreAnimation/1.0"><CALayer id="root" bounds="0 0 390 844" position="195 422" transform.scale.xy="0.75"><sublayers><CALayer bounds="0 0 10 10"/></sublayers><states><LKState name="Locked"><elements><LKStateSetValue targetId="root" keyPath="transform.scale.xy"><value type="real" value="0.5"/></LKStateSetValue><LKStateSetValue keyPath="opacity"><value type="real" value="0.1"/></LKStateSetValue></elements></LKState><LKState name="Sleep"><elements><LKStateSetValue targetId="root" keyPath="transform.scale.x"><value type="real" value="0.25"/></LKStateSetValue><LKStateSetValue targetId="root" keyPath="transform.scale.y"><value type="real" value="0.25"/></LKStateSetValue></elements></LKState></states></CALayer></caml>`;
    const zip = new JSZip(); zip.file(path, source, { createFolders: false });
    const doc = await importPackage(await zip.generateAsync({ type: 'uint8array' }), 'aliases.tendies'), scene = doc.project.scenes[0];
    expect(scene.layers[0].scale).toBe(.75); expect(resolveLayer(scene.layers[0], 'Locked').scale).toBe(.5); expect(resolveLayer(scene.layers[0], 'Sleep').scale).toBe(.25);
    expect(resolveLayer(scene.layers[1], 'Locked').opacity).toBe(1);
    scene.layers[0].scale = 1.1; scene.layers[0] = patchLayerState(scene.layers[0], 'Locked', { scale: .8 });
    const output = await exportPackage(doc), exported = await JSZip.loadAsync(output.data), document = xml(await exported.file(path)!.async('string'));
    expect(document.getElementsByTagName('CALayer')[0].getAttribute('transform.scale')).toBe('1.1');
    expect(document.getElementsByTagName('CALayer')[0].hasAttribute('transform.scale.xy')).toBe(false);
    expect([...document.getElementsByTagName('LKStateSetValue')].filter(action => action.getAttribute('targetId') === 'root').every(action => !/transform\.scale\.[xy]/.test(action.getAttribute('keyPath') ?? ''))).toBe(true);
  });

  it('keeps imported shape state colours consistent when changing background opacity', async () => {
    const doc = createDocument(), scene = doc.project.scenes[0], shape = makeLayer('shape', scene); shape.name = 'Colour';
    shape.states = { Locked: { color: '#ff0000', backgroundColor: '#ff0000' } }; scene.layers.push(shape);
    const first = await exportPackage(doc), imported = await importPackage(await systemOnly(first.data), 'colours.tendies');
    const importedScene = imported.project.scenes.find(value => sceneRole(value) === 'Background')!, index = importedScene.layers.findIndex(value => value.name === 'Colour');
    expect(resolveLayer(importedScene.layers[index], 'Locked').backgroundColor).toBe('#ff0000');
    importedScene.layers[index] = patchLayerState(importedScene.layers[index], 'Locked', { backgroundOpacity: .5 });
    const output = await exportPackage(imported), zip = await JSZip.loadAsync(output.data), document = xml(await zip.file(importedScene.camlPath)!.async('string'));
    const target = [...document.getElementsByTagName('CALayer')].find(value => value.getAttribute('name') === 'Colour')!.getAttribute('id');
    const locked = [...document.getElementsByTagName('LKState')].find(value => value.getAttribute('name') === 'Locked')!;
    const action = [...locked.getElementsByTagName('LKStateSetValue')].find(value => value.getAttribute('targetId') === target && value.getAttribute('keyPath') === 'backgroundColor')!;
    const colour = action.getElementsByTagName('value')[0].getAttribute('value')!.split(' ').map(Number);
    expect(colour).toEqual([1, 0, 0, .5]);
  });

  it('removes deleted layer state actions, while preserving actions for unrelated unknown targets', async () => {
    const path = 'descriptors/11111111-1111-4111-8111-111111111111/versions/1/contents/Test.wallpaper/Floating.ca/main.caml';
    const source = `<caml xmlns="http://www.apple.com/CoreAnimation/1.0"><CALayer id="root" bounds="0 0 390 844"><sublayers><CALayer id="deleted" name="Remove me" bounds="0 0 20 20"/></sublayers><states><LKState name="Custom"><elements><LKStateSetValue targetId="deleted" keyPath="opacity"><value type="real" value="0.2"/></LKStateSetValue><LKStateSetValue targetId="foreign" keyPath="speed"><value type="real" value="2"/></LKStateSetValue></elements></LKState></states><stateTransitions><LKStateTransition fromState="Custom" toState="Locked"><elements><LKStateTransitionElement targetId="deleted" key="opacity"/><LKStateTransitionElement targetId="foreign" key="speed"/></elements></LKStateTransition></stateTransitions></CALayer></caml>`;
    const zip = new JSZip(); zip.file(path, source, { createFolders: false });
    const doc = await importPackage(await zip.generateAsync({ type: 'uint8array' }), 'delete.tendies');
    doc.project.scenes[0].layers = doc.project.scenes[0].layers.filter(layer => layer.isRoot);
    const output = await exportPackage(doc), result = await JSZip.loadAsync(output.data), document = xml(await result.file(path)!.async('string'));
    for (const name of ['LKStateSetValue', 'LKStateTransitionElement']) {
      expect([...document.getElementsByTagName(name)].some(action => action.getAttribute('targetId') === 'deleted')).toBe(false);
      expect([...document.getElementsByTagName(name)].some(action => action.getAttribute('targetId') === 'foreign')).toBe(true);
    }
  });

  it('writes four-component bounds animation rectangles without losing their origin', async () => {
    const doc = createDocument(), scene = doc.project.scenes[0], shape = makeLayer('shape', scene); shape.name = 'Bounds';
    shape.animations = [{ id: 'rect', property: 'bounds', from: [10, 20, 100, 200], to: [30, 40, 300, 400], duration: 1, delay: 0, repeat: false, autoreverses: false, enabled: true }]; scene.layers.push(shape);
    const output = await exportPackage(doc), zip = await JSZip.loadAsync(output.data), document = xml(await zip.file(scene.camlPath)!.async('string'));
    const animation = [...document.getElementsByTagName('animation')].find(value => value.getAttribute('key') === 'rect')!;
    expect([...animation.getElementsByTagName('CGRect')].map(value => value.getAttribute('value'))).toEqual(['10 20 100 200', '30 40 300 400']);
  });
});
