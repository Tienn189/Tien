import type { LayerMotion } from './types';

/** The preview uses the same keyframe phases emitted in the CAML exporter. */
export function motionAt(motion: LayerMotion, time: number) {
  const result = { dx: 0, dy: 0, scale: 1, rotation: 0, opacity: 1 };
  if (motion.preset === 'none' || time < motion.delay) return result;
  const duration = Math.max(0.2, Number.isFinite(motion.duration) ? motion.duration : 3);
  const phase = (((time - motion.delay) / duration) % 1 + 1) % 1;
  const wave = Math.sin(phase * Math.PI * 2);
  const amount = Number.isFinite(motion.amount) ? motion.amount : 20;
  switch (motion.preset) {
    case 'float': result.dy = -wave * amount; break;
    case 'pulse': result.scale = 1 + wave * Math.min(Math.abs(amount) / 100, 0.9); break;
    case 'spin': result.rotation = phase * 360; break;
    case 'fade': result.opacity = 1 - ((1 - Math.cos(phase * Math.PI * 2)) / 2) * Math.min(Math.abs(amount) / 100, 1); break;
    case 'bounce': result.dy = -Math.abs(wave) * Math.abs(amount); break;
  }
  return result;
}
