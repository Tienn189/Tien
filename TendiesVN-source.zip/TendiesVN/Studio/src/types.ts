export type MotionPreset = 'none' | 'float' | 'pulse' | 'spin' | 'fade' | 'bounce';

export interface LayerMotion {
  preset: MotionPreset;
  duration: number;
  delay: number;
  amount: number;
}

export interface Layer {
  id: string;
  name: string;
  type: 'image' | 'text' | 'shape' | 'group' | 'unsupported';
  parentId: string | null;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  visible: boolean;
  locked: boolean;
  color: string;
  text: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: 'normal' | 'bold';
  textAlign: 'left' | 'center' | 'right';
  imagePath?: string;
  cornerRadius: number;
  motion: LayerMotion;
  /** Stable identifier for an original XML node. Not an asset URL. */
  binding?: string;
}

export interface Scene {
  id: string;
  name: string;
  width: number;
  height: number;
  background: string;
  layers: Layer[];
  camlPath: string;
  descriptorPath: string;
  /** Original source is retained so unrecognised CAML survives an edit. */
  rootXML?: string;
}

export interface StudioProject {
  version: 1;
  name: string;
  scenes: Scene[];
  activeSceneId: string;
}

export interface StudioDocument {
  project: StudioProject;
  files: Map<string, Uint8Array>;
  warnings: string[];
  sourceName: string;
}
