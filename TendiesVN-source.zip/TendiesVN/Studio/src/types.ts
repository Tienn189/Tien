export type MotionPreset = 'none' | 'float' | 'pulse' | 'spin' | 'fade' | 'bounce';

export interface LayerMotion {
  preset: MotionPreset;
  duration: number;
  delay: number;
  amount: number;
}

export type WallpaperState = 'Base' | 'Locked' | 'Unlock' | 'Sleep';
export type SceneRole = 'Background' | 'Floating' | 'Foreground' | 'Other';
export type TransitionTiming = 'linear' | 'easeIn' | 'easeOut' | 'easeInOut';
export interface LayerFilter { id: string; type: 'gaussianBlur' | 'contrast' | 'hueRotate' | 'invert' | 'saturate' | 'sepia'; amount: number; enabled: boolean }
export type AnimationProperty = 'position' | 'position.x' | 'position.y' | 'transform.rotation.x' | 'transform.rotation.y' | 'transform.rotation.z' | 'transform.scale' | 'opacity' | 'bounds' | 'backgroundColor';
export type AnimationValue = number | number[] | string;
export interface LayerAnimation { id: string; property: AnimationProperty; from: AnimationValue; to: AnimationValue; duration: number; delay: number; repeat: boolean; autoreverses: boolean; enabled: boolean }

export interface Layer {
  id: string;
  name: string;
  type: 'image' | 'text' | 'shape' | 'group' | 'gradient' | 'unsupported';
  parentId: string | null;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  opacity: number;
  visible: boolean;
  locked: boolean;
  color: string;
  text: string;
  fontSize: number;
  fontFamily: string;
  fontWeight: 'normal' | 'bold';
  textAlign: 'left' | 'center' | 'right';
  imagePath?: string;
  cornerRadius: number;
  motion: LayerMotion;
  z?: number;
  scale?: number;
  rotationX?: number;
  rotationY?: number;
  anchorX?: number;
  anchorY?: number;
  backgroundColor?: string;
  backgroundOpacity?: number;
  borderColor?: string;
  borderWidth?: number;
  clipContents?: boolean;
  blendMode?: string;
  gradientColors?: string[];
  gradientStart?: [number, number];
  gradientEnd?: [number, number];
  filters?: LayerFilter[];
  animations?: LayerAnimation[];
  states?: Partial<Record<Exclude<WallpaperState, 'Base'>, Partial<LayerProperties>>>;
  isRoot?: boolean;
  /** Stable identifier for an original XML node. Not an asset URL. */
  binding?: string;
}

export type LayerProperties = Pick<Layer, 'x' | 'y' | 'z' | 'width' | 'height' | 'rotation' | 'rotationX' | 'rotationY' | 'scale' | 'anchorX' | 'anchorY' | 'opacity' | 'visible' | 'color' | 'text' | 'fontSize' | 'fontFamily' | 'fontWeight' | 'textAlign' | 'cornerRadius' | 'backgroundColor' | 'backgroundOpacity' | 'borderColor' | 'borderWidth' | 'clipContents' | 'blendMode' | 'gradientColors' | 'gradientStart' | 'gradientEnd' | 'imagePath'>;

export interface Scene {
  id: string;
  name: string;
  width: number;
  height: number;
  background: string;
  layers: Layer[];
  camlPath: string;
  descriptorPath: string;
  /** Original source is retained so unrecognised CAML survives an edit. */
  rootXML?: string;
  role?: SceneRole;
  transition?: { duration: number; timing: TransitionTiming };
}

export interface StudioProject {
  version: 1;
  name: string;
  scenes: Scene[];
  activeSceneId: string;
}

export interface StudioDocument {
  project: StudioProject;
  files: Map<string, Uint8Array>;
  warnings: string[];
  sourceName: string;
}
