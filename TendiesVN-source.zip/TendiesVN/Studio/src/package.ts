import JSZip from 'jszip';
import type { AnimationProperty, AnimationValue, Layer, LayerAnimation, LayerFilter, LayerMotion, LayerProperties, Scene, StudioDocument, StudioProject, WallpaperState } from './types';
import { motionAt } from './motion';
import { propertyKeys, resolveLayer, sceneRole } from './states';

const NS = 'http://www.apple.com/CoreAnimation/1.0';
const MANIFEST = 'tendiesvn.project.json';
const MAX_BYTES = 128 * 1024 * 1024;
const MAX_XML = 4 * 1024 * 1024;
const MAX_FILES = 4096;
const MAX_LAYERS = 128;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const motionPresets = ['none', 'float', 'pulse', 'spin', 'fade', 'bounce'];
const stateNames = ['Locked', 'Unlock', 'Sleep'] as const;
const animationProperties: AnimationProperty[] = ['position', 'position.x', 'position.y', 'transform.rotation.x', 'transform.rotation.y', 'transform.rotation.z', 'transform.scale', 'opacity', 'bounds', 'backgroundColor'];
const filterNames: Record<LayerFilter['type'], [string, string]> = { gaussianBlur: ['gaussianBlur', 'inputRadius'], contrast: ['colorContrast', 'inputAmount'], hueRotate: ['colorHueRotate', 'inputAngle'], invert: ['colorInvert', 'inputAmount'], saturate: ['colorSaturate', 'inputAmount'], sepia: ['CISepiaTone', 'inputIntensity'] };
const blendNames: Record<string, string> = { multiply: 'multiplyBlendMode', screen: 'screenBlendMode', overlay: 'overlayBlendMode', darken: 'darkenBlendMode', lighten: 'lightenBlendMode', 'color-dodge': 'colorDodgeBlendMode', 'color-burn': 'colorBurnBlendMode', 'soft-light': 'softLightBlendMode', 'hard-light': 'hardLightBlendMode', difference: 'differenceBlendMode', exclusion: 'exclusionBlendMode' };

function uid() { return globalThis.crypto?.randomUUID?.() ?? `studio-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`; }
function uuid() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID().toUpperCase();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const n = Math.floor(Math.random() * 16); return (c === 'x' ? n : (n & 3) | 8).toString(16);
  }).toUpperCase();
}
function fail(message: string): never { throw new Error(message); }
function finite(value: unknown, fallback: number) { if (value === null || value === undefined || value === '') return fallback; const n = Number(value); return Number.isFinite(n) ? n : fallback; }
function clamp(n: number, low: number, high: number) { return Math.min(high, Math.max(low, n)); }
function numbers(value: string | null) { return (value?.trim().split(/[\s,;]+/) ?? []).map(Number).filter(Number.isFinite); }
function basename(path: string) { return path.split('/').at(-1) ?? path; }
function directory(path: string) { return path.slice(0, Math.max(0, path.lastIndexOf('/'))); }
function children(el: Element) { return Array.from(el.childNodes).filter((n): n is Element => n.nodeType === 1); }
function child(el: Element, name: string) { return children(el).find(n => n.localName === name || n.nodeName === name); }
function descendants(el: Element, name: string) { return Array.from(el.getElementsByTagName('*')).filter(n => n.localName === name || n.nodeName === name); }
function isLayer(el: Element) { return /^(?:CA|LK).*Layer$/.test(el.localName || el.nodeName); }
function allLayers(root: Element) {
  const result: Element[] = [];
  const visit = (node: Element) => {
    result.push(node);
    const sublayers = child(node, 'sublayers');
    if (sublayers) for (const sublayer of children(sublayers)) if (isLayer(sublayer)) visit(sublayer);
  };
  visit(root);
  return result;
}
function textBytes(value: string) { return new Uint8Array(encoder.encode(value)); }

export function safePath(path: string, allowDirectory = false): string {
  if (typeof path !== 'string' || path.length === 0 || path.length > 1024 || /[\\:\u0000-\u001f\u007f]/.test(path) || path.startsWith('/')) fail('Đường dẫn trong gói không an toàn.');
  const value = allowDirectory && path.endsWith('/') ? path.slice(0, -1) : path;
  if (!value || value.split('/').some(part => !part || part === '.' || part === '..')) fail('Gói chứa đường dẫn đi ra ngoài thư mục.');
  return value;
}

function parseXML(xml: string) {
  if (xml.length > MAX_XML || /<!DOCTYPE|<!ENTITY/i.test(xml)) fail('XML quá lớn hoặc chứa khai báo không được hỗ trợ.');
  const doc = new DOMParser().parseFromString(xml, 'application/xml');
  if (!doc.documentElement || doc.getElementsByTagName('parsererror').length) fail('Không đọc được XML của hình nền.');
  return doc;
}
function serializeXML(doc: Document) { return new XMLSerializer().serializeToString(doc); }
function caElement(doc: Document, name: string) { return doc.createElementNS(NS, name); }
function layerRoot(doc: Document) {
  const root = doc.documentElement;
  if (isLayer(root)) return root;
  const layer = Array.from(root.getElementsByTagName('*')).find(isLayer);
  return layer ?? fail('Gói không có lớp Core Animation để chỉnh sửa.');
}
function colorHex(raw: string | null, fallback = '#ffffff') {
  if (!raw) return fallback;
  if (/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(raw)) return raw.toLowerCase();
  const c = numbers(raw);
  if (c.length < 3) return fallback;
  const rgb = c.slice(0, 3).map(n => Math.round(clamp(n, 0, 1) * 255).toString(16).padStart(2, '0')).join('');
  const alpha = c.length > 3 && c[3] < 1 ? Math.round(clamp(c[3], 0, 1) * 255).toString(16).padStart(2, '0') : '';
  return '#' + rgb + alpha;
}
function colorCA(hex: string) {
  const h = /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(hex) ? hex.slice(1) : 'ffffff';
  const values = [0, 2, 4].map(i => (parseInt(h.slice(i, i + 2), 16) / 255).toFixed(6));
  return [...values, h.length === 8 ? (parseInt(h.slice(6), 16) / 255).toFixed(6) : '1'].join(' ');
}
function readColor(element: Element, key: string, fallback: string) { return colorHex(element.getAttribute(key) ?? child(element, key)?.getAttribute('value') ?? null, fallback); }
function writeColor(element: Element, key: string, value: string) {
  let node = child(element, key);
  if (!node) { node = caElement(element.ownerDocument, key); element.appendChild(node); }
  node.setAttribute('type', 'CGColor'); node.setAttribute('value', colorCA(value)); element.removeAttribute(key);
}
function relativeAsset(camlPath: string, asset: string) {
  safePath(asset);
  const from = directory(camlPath).split('/').filter(Boolean), to = asset.split('/');
  while (from.length && to.length && from[0] === to[0]) { from.shift(); to.shift(); }
  return [...from.map(() => '..'), ...to].join('/');
}
function resolveAsset(camlPath: string, source: string): string | undefined {
  if (!source || /^(?:[a-z]+:|\/|\\)/i.test(source) || source.includes('\\')) return undefined;
  const stack = directory(camlPath).split('/').filter(Boolean);
  for (const piece of source.split('/')) {
    if (!piece || piece === '.') continue;
    if (piece === '..') { if (!stack.length) return undefined; stack.pop(); }
    else stack.push(piece);
  }
  try { return safePath(stack.join('/')); } catch { return undefined; }
}

export function makeLayer(type: Layer['type'], scene: Scene): Layer {
  const unit = scene.width / 390;
  const w = type === 'text' ? scene.width * 0.8 : scene.width * 0.55;
  const h = type === 'text' ? 84 * unit : type === 'group' ? scene.height : w;
  return {
    id: uid(), name: type === 'text' ? 'Văn bản' : type === 'image' ? 'Hình ảnh' : type === 'group' ? 'Nhóm' : type === 'gradient' ? 'Chuyển sắc' : 'Hình khối',
    type, parentId: scene.layers.find(layer => layer.isRoot)?.id ?? null, x: type === 'group' ? 0 : (scene.width - w) / 2, y: type === 'group' ? 0 : (scene.height - h) / 2,
    width: type === 'group' ? scene.width : w, height: h, rotation: 0, opacity: 1, visible: true, locked: type === 'unsupported',
    color: type === 'text' ? '#ffffff' : '#68e0c6', text: type === 'text' ? 'Xin chào' : '', fontSize: 42 * unit,
    fontFamily: 'HelveticaNeue', fontWeight: 'normal', textAlign: 'center', cornerRadius: type === 'shape' ? 28 * unit : 0,
    motion: { preset: 'none', duration: 3, delay: 0, amount: 20 * unit },
    z: 0, scale: 1, rotationX: 0, rotationY: 0, anchorX: .5, anchorY: .5,
    backgroundColor: type === 'shape' ? '#68e0c6' : '#00000000', backgroundOpacity: 1, borderColor: '#000000', borderWidth: 0, clipContents: false, blendMode: 'normal',
    gradientColors: ['#68e0c6', '#5165df'], gradientStart: [.5, 0], gradientEnd: [.5, 1], filters: [], animations: [], states: {},
  };
}

function parseFilters(element: Element): LayerFilter[] {
  const container = child(element, 'filters'); if (!container) return [];
  const result: LayerFilter[] = [];
  children(container).forEach((node, index) => {
    const type = (Object.keys(filterNames) as LayerFilter['type'][]).find(key => filterNames[key][0] === node.getAttribute('filter'));
    if (!type) return;
    const parameter = filterNames[type][1];
    const raw = node.getAttribute(parameter) ?? child(node, parameter)?.getAttribute('value');
    result.push({ id: node.getAttribute('name') || `xml-filter:${index}`, type, amount: finite(raw, type === 'contrast' || type === 'saturate' || type === 'invert' ? 1 : 0) * (type === 'hueRotate' ? 180 / Math.PI : 1), enabled: !['0', 'false', 'NO'].includes(node.getAttribute('enabled') ?? '1') });
  });
  return result;
}
function animationValue(node: Element, property: AnimationProperty, layer: Layer): AnimationValue {
  const raw = node.getAttribute('value') ?? '';
  if (property === 'backgroundColor') return colorHex(raw);
  const values = numbers(raw);
  if (property === 'position') return [(values[0] ?? 0) - layer.width * (layer.anchorX ?? .5), (values[1] ?? 0) - layer.height * (layer.anchorY ?? .5)];
  if (property === 'bounds') return [values[2] ?? layer.width, values[3] ?? layer.height];
  let value = finite(raw, 0);
  if (property === 'position.x') value -= layer.width * (layer.anchorX ?? .5);
  if (property === 'position.y') value -= layer.height * (layer.anchorY ?? .5);
  if (property.startsWith('transform.rotation.')) value *= 180 / Math.PI;
  return value;
}
function parseAnimations(element: Element, layer: Layer): LayerAnimation[] {
  const container = child(element, 'animations'); if (!container) return [];
  const result: LayerAnimation[] = [];
  children(container).forEach((node, index) => {
    const rawProperty = node.getAttribute('keyPath');
    const property = (rawProperty === 'transform.scale.xy' ? 'transform.scale' : rawProperty) as AnimationProperty, values = child(node, 'values');
    if (!animationProperties.includes(property) || !values || children(values).length !== 2 || node.getAttribute('key')?.match(/^tendiesvn\.(?:float|pulse|spin|fade|bounce)$/)) return;
    result.push({ id: node.getAttribute('key') || `xml-animation:${index}`, property, from: animationValue(children(values)[0], property, layer), to: animationValue(children(values)[1], property, layer), duration: Math.max(.2, finite(node.getAttribute('duration'), 1)), delay: Math.max(0, finite(node.getAttribute('beginTime'), 0)), repeat: (node.getAttribute('repeatCount') ?? '0') !== '0', autoreverses: ['1', 'true', 'YES'].includes(node.getAttribute('autoreverses') ?? '0'), enabled: !['0', 'false'].includes(node.getAttribute('enabled') ?? '1') });
  });
  return result;
}

function decodeStatePatch(layer: Layer, entries: Map<string, Element>, camlPath: string): Partial<LayerProperties> {
  const patch: Partial<LayerProperties> = {};
  const raw = (key: string) => entries.get(key)?.getAttribute('value') ?? null;
  const number = (key: string, field: keyof LayerProperties, ratio = 1) => { if (entries.has(key)) (patch as Record<string, unknown>)[field] = finite(raw(key), 0) * ratio; };
  const bounds = numbers(raw('bounds')), anchor = numbers(raw('anchorPoint'));
  if (bounds.length >= 4) { patch.width = bounds[2]; patch.height = bounds[3]; }
  number('bounds.size.width', 'width'); number('bounds.size.height', 'height');
  if (anchor.length >= 2) { patch.anchorX = anchor[0]; patch.anchorY = anchor[1]; }
  number('anchorPoint.x', 'anchorX'); number('anchorPoint.y', 'anchorY');
  const w = patch.width ?? layer.width, h = patch.height ?? layer.height, ax = patch.anchorX ?? layer.anchorX ?? .5, ay = patch.anchorY ?? layer.anchorY ?? .5;
  const position = numbers(raw('position'));
  if (position.length >= 2) { patch.x = position[0] - w * ax; patch.y = position[1] - h * ay; }
  if (entries.has('position.x')) patch.x = finite(raw('position.x'), 0) - w * ax;
  if (entries.has('position.y')) patch.y = finite(raw('position.y'), 0) - h * ay;
  for (const [key, field, ratio] of [['zPosition', 'z', 1], ['opacity', 'opacity', 1], ['transform.rotation.x', 'rotationX', 180 / Math.PI], ['transform.rotation.y', 'rotationY', 180 / Math.PI], ['transform.rotation.z', 'rotation', 180 / Math.PI], ['transform.scale', 'scale', 1], ['fontSize', 'fontSize', 1], ['cornerRadius', 'cornerRadius', 1], ['borderWidth', 'borderWidth', 1]] as const) number(key, field, ratio);
  if (!entries.has('transform.scale')) {
    if (entries.has('transform.scale.xy')) number('transform.scale.xy', 'scale');
    else if (entries.has('transform.scale.x') && entries.has('transform.scale.y') && finite(raw('transform.scale.x'), 1) === finite(raw('transform.scale.y'), 1)) number('transform.scale.x', 'scale');
  }
  if (entries.has('hidden')) patch.visible = !['1', 'true', 'YES'].includes(raw('hidden') ?? '0');
  if (entries.has('masksToBounds')) patch.clipContents = ['1', 'true', 'YES'].includes(raw('masksToBounds') ?? '0');
  if (entries.has('backgroundColor')) { const value = colorHex(raw('backgroundColor'), '#00000000'); if (layer.type === 'shape') { patch.color = value; patch.backgroundColor = value; } else patch.backgroundColor = value; }
  if (entries.has('foregroundColor')) patch.color = colorHex(raw('foregroundColor'));
  if (entries.has('borderColor')) patch.borderColor = colorHex(raw('borderColor'));
  if (entries.has('string')) patch.text = raw('string') ?? '';
  if (entries.has('font')) { patch.fontFamily = raw('font') ?? 'HelveticaNeue'; patch.fontWeight = /bold/i.test(patch.fontFamily) ? 'bold' : 'normal'; }
  if (entries.has('alignmentMode')) { const value = raw('alignmentMode'); if (value === 'left' || value === 'center' || value === 'right') patch.textAlign = value; }
  for (const [key, field] of [['startPoint', 'gradientStart'], ['endPoint', 'gradientEnd']] as const) { const values = numbers(raw(key)); if (values.length >= 2) patch[field] = [values[0], values[1]]; }
  if (entries.has('colors')) { const list = children(entries.get('colors')!).map(node => colorHex(node.getAttribute('value'))); if (list.length >= 2) patch.gradientColors = list; }
  if (entries.has('contents')) { const source = entries.get('contents')!.getAttribute('src'); if (source) patch.imagePath = resolveAsset(camlPath, source); }
  if (entries.has('compositingFilter')) { const filter = entries.get('compositingFilter')!.getAttribute('filter'); patch.blendMode = Object.keys(blendNames).find(key => blendNames[key] === filter) || 'normal'; }
  return patch;
}

function parseStates(document: Document, scene: Scene, nodes: Element[], map: Map<Element, string>) {
  const targets = new Map<string, Layer>();
  for (const node of nodes) { const id = node.getAttribute('id'), layer = scene.layers.find(value => value.id === map.get(node)); if (id && layer) targets.set(id, layer); }
  for (const state of descendants(document.documentElement, 'LKState')) {
    const name = state.getAttribute('name') as Exclude<WallpaperState, 'Base'>;
    if (!stateNames.includes(name)) continue;
    const grouped = new Map<Layer, Map<string, Element>>();
    for (const action of descendants(state, 'LKStateSetValue')) {
      const target = targets.get(action.getAttribute('targetId') ?? ''), value = child(action, 'value'), key = action.getAttribute('keyPath');
      if (!target || !value || !key) continue;
      if (!grouped.has(target)) grouped.set(target, new Map()); grouped.get(target)!.set(key, value);
    }
    for (const [layer, entries] of grouped) { const patch = decodeStatePatch(layer, entries, scene.camlPath); if (Object.keys(patch).length) layer.states = { ...layer.states, [name]: patch }; }
  }
  const transitions = descendants(document.documentElement, 'LKStateTransition');
  const transition = transitions.find(node => node.getAttribute('fromState') === 'Locked' && node.getAttribute('toState') === 'Unlock') ?? transitions.find(node => node.getAttribute('toState') === 'Unlock');
  const animation = transition && descendants(transition, 'animation')[0];
  const timing = animation?.getAttribute('timingFunction') ?? (animation && child(animation, 'timingFunction')?.getAttribute('name'));
  scene.transition = { duration: Math.max(0, finite(animation?.getAttribute('duration'), .5)), timing: timing === 'linear' || timing === 'easeIn' || timing === 'easeOut' ? timing : 'easeInOut' };
}

function parseScene(xml: string, camlPath: string, descriptorPath: string, name: string, warnings: string[]): Scene {
  const document = parseXML(xml), root = layerRoot(document), bounds = numbers(root.getAttribute('bounds'));
  const scene: Scene = {
    id: uid(), name, width: clamp(bounds[2] || 390, 1, 8192), height: clamp(bounds[3] || 844, 1, 8192),
    background: readColor(root, 'backgroundColor', '#121720'), layers: [], camlPath, descriptorPath, rootXML: xml,
  };
  const nodes = allLayers(root);
  const map = new Map<Element, string>();
  const selected = nodes;
  if (selected.length > MAX_LAYERS) fail('Mỗi cảnh chỉ hỗ trợ tối đa 128 lớp trong trình sửa.');
  for (const element of selected) map.set(element, uid());
  for (const element of selected) {
    const tag = element.localName || element.nodeName;
    const contents = child(element, 'contents');
    const simple = tag === 'CALayer';
    const type: Layer['type'] = tag === 'CATextLayer' ? 'text' : tag === 'CAGradientLayer' ? 'gradient' : simple ? contents ? 'image' : element === root || child(element, 'sublayers') ? 'group' : 'shape' : 'unsupported';
    const layer = makeLayer(type, scene), b = numbers(element.getAttribute('bounds')), p = numbers(element.getAttribute('position'));
    const anchor = numbers(element.getAttribute('anchorPoint'));
    layer.id = map.get(element)!;
    layer.name = element.getAttribute('name') || element.getAttribute('id') || tag;
    layer.binding = `node:${nodes.indexOf(element)}`;
    layer.isRoot = element === root;
    layer.width = b[2] || scene.width; layer.height = b[3] || scene.height;
    layer.x = (p[0] ?? layer.width / 2) - layer.width * (anchor[0] ?? 0.5);
    layer.y = (p[1] ?? layer.height / 2) - layer.height * (anchor[1] ?? 0.5);
    layer.anchorX = anchor[0] ?? .5; layer.anchorY = anchor[1] ?? .5;
    layer.z = finite(element.getAttribute('zPosition'), 0);
    const sx = element.getAttribute('transform.scale.x'), sy = element.getAttribute('transform.scale.y');
    layer.scale = finite(element.getAttribute('transform.scale') ?? element.getAttribute('transform.scale.xy') ?? (sx !== null && sx === sy ? sx : null), 1);
    layer.rotationX = finite(element.getAttribute('transform.rotation.x'), 0) * 180 / Math.PI;
    layer.rotationY = finite(element.getAttribute('transform.rotation.y'), 0) * 180 / Math.PI;
    layer.opacity = clamp(finite(element.getAttribute('opacity') ?? 1, 1), 0, 1);
    layer.visible = !['1', 'true', 'YES'].includes(element.getAttribute('hidden') ?? '0');
    layer.cornerRadius = finite(element.getAttribute('cornerRadius'), 0);
    layer.backgroundColor = readColor(element, 'backgroundColor', '#00000000');
    layer.borderColor = readColor(element, 'borderColor', '#000000'); layer.borderWidth = finite(element.getAttribute('borderWidth'), 0);
    layer.clipContents = ['1', 'true', 'YES'].includes(element.getAttribute('masksToBounds') ?? '0');
    const compositing = child(element, 'compositingFilter');
    const blend = compositing?.getAttribute('filter') || compositing?.getAttribute('name') || '';
    layer.blendMode = Object.keys(blendNames).find(key => blendNames[key] === blend) || 'normal';
    layer.color = readColor(element, type === 'text' ? 'foregroundColor' : 'backgroundColor', type === 'group' ? '#000000' : '#ffffff');
    const rotation = element.getAttribute('transform.rotation.z') || element.getAttribute('transform.rotation');
    if (rotation !== null) layer.rotation = finite(rotation, 0) * 180 / Math.PI;
    const transform = child(element, 'transform');
    if (transform && !rotation) warnings.push(`Lớp “${layer.name}” có biến đổi nâng cao: bản xem trước chỉ gần đúng; dữ liệu gốc vẫn được giữ.`);
    if (type === 'text') {
      const textNode = child(element, 'string');
      layer.text = element.getAttribute('string') ?? textNode?.getAttribute('value') ?? textNode?.textContent ?? '';
      layer.fontSize = finite(element.getAttribute('fontSize'), 42);
      layer.fontFamily = child(element, 'font')?.getAttribute('value') || element.getAttribute('font') || element.getAttribute('fontName') || 'HelveticaNeue';
      layer.fontWeight = /bold/i.test(layer.fontFamily) ? 'bold' : 'normal';
      const align = element.getAttribute('alignmentMode');
      layer.textAlign = align === 'left' || align === 'right' ? align : 'center';
    }
    if (contents) {
      const source = contents.getAttribute('src') || contents.getAttribute('source') || descendants(contents, 'CGImage')[0]?.getAttribute('src') || '';
      layer.imagePath = resolveAsset(camlPath, source);
      if (!layer.imagePath) warnings.push(`Không thể xem trước nguồn ảnh của “${layer.name}”; nguồn gốc vẫn được giữ.`);
    }
    if (type === 'gradient') {
      const colors = child(element, 'colors');
      if (colors) { const list = children(colors).map(node => colorHex(node.getAttribute('value'))); if (list.length >= 2) layer.gradientColors = list; }
      const start = numbers(element.getAttribute('startPoint') ?? child(element, 'startPoint')?.getAttribute('value') ?? null);
      const end = numbers(element.getAttribute('endPoint') ?? child(element, 'endPoint')?.getAttribute('value') ?? null);
      if (start.length >= 2) layer.gradientStart = [start[0], start[1]];
      if (end.length >= 2) layer.gradientEnd = [end[0], end[1]];
    }
    layer.filters = parseFilters(element);
    layer.animations = parseAnimations(element, layer);
    let ancestor: Node | null = element.parentNode;
    while (ancestor) {
      if (ancestor.nodeType === 1 && map.has(ancestor as Element)) { layer.parentId = map.get(ancestor as Element)!; break; }
      ancestor = ancestor.parentNode;
    }
    const animations = child(element, 'animations');
    if (animations && children(animations).some(a => !a.getAttribute('key')?.startsWith('tendiesvn.'))) warnings.push(`Chuyển động gốc của “${layer.name}” được giữ khi xuất; bản xem trước chưa mô phỏng đầy đủ.`);
    if (type === 'unsupported') warnings.push(`Lớp ${tag} được giữ nguyên; trình sửa chưa hỗ trợ hiển thị hiệu ứng này.`);
    if (child(element, 'filters') || child(element, 'compositingFilter') || child(element, 'mask')) warnings.push(`Hiệu ứng nâng cao của “${layer.name}” được giữ nguyên khi xuất.`);
    scene.layers.push(layer);
  }
  scene.role = sceneRole(scene);
  parseStates(document, scene, nodes, map);
  return scene;
}

function checkArchive(data: Uint8Array) {
  if (data.byteLength > MAX_BYTES) fail('Gói vượt quá giới hạn 128 MB của trình sửa.');
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let end = -1;
  for (let p = data.length - 22; p >= Math.max(0, data.length - 65557); p--) {
    if (view.getUint32(p, true) === 0x06054b50 && p + 22 + view.getUint16(p + 20, true) === data.length) { end = p; break; }
  }
  if (end < 0) fail('File không phải gói ZIP/.tendies hợp lệ.');
  const count = view.getUint16(end + 10, true), start = view.getUint32(end + 16, true), length = view.getUint32(end + 12, true);
  if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true) || view.getUint16(end + 8, true) !== count || count === 65535 || count > MAX_FILES || start + length !== end) fail('Không hỗ trợ ZIP nhiều phần, ZIP64 hoặc quá nhiều tệp.');
  const paths = new Set<string>(); let total = 0, cursor = start;
  for (let index = 0; index < count; index++) {
    if (cursor + 46 > end || view.getUint32(cursor, true) !== 0x02014b50) fail('Danh mục ZIP bị hỏng.');
    const flags = view.getUint16(cursor + 8, true), method = view.getUint16(cursor + 10, true), size = view.getUint32(cursor + 24, true);
    const nameLength = view.getUint16(cursor + 28, true), extra = view.getUint16(cursor + 30, true), comment = view.getUint16(cursor + 32, true);
    const attrs = view.getUint32(cursor + 38, true), offset = view.getUint32(cursor + 42, true);
    if (cursor + 46 + nameLength + extra + comment > end) fail('Tên tệp ZIP bị hỏng.');
    const name = decoder.decode(data.subarray(cursor + 46, cursor + 46 + nameLength));
    const clean = safePath(name, true).normalize('NFC').toLocaleLowerCase('en-US');
    if (paths.has(clean)) fail('Gói có đường dẫn trùng nhau.');
    paths.add(clean);
    if ((flags & 1) || ![0, 8].includes(method) || ((attrs >>> 16) & 0xf000) === 0xa000) fail('Không hỗ trợ tệp mã hoá, liên kết tượng trưng hoặc cách nén này.');
    if (offset + 30 > start || view.getUint32(offset, true) !== 0x04034b50) fail('Dữ liệu ZIP bị hỏng.');
    const localFlags = view.getUint16(offset + 6, true), localNameLength = view.getUint16(offset + 26, true), localExtra = view.getUint16(offset + 28, true);
    if ((localFlags & 1) || offset + 30 + localNameLength + localExtra > start || decoder.decode(data.subarray(offset + 30, offset + 30 + localNameLength)) !== name) fail('Đường dẫn ZIP không nhất quán.');
    total += size;
    if (size > 64 * 1024 * 1024 || total > MAX_BYTES) fail('Dữ liệu giải nén vượt giới hạn 128 MB.');
    cursor += 46 + nameLength + extra + comment;
  }
  if (cursor !== end) fail('Danh mục ZIP không nhất quán.');
}

function validateProject(value: unknown): StudioProject {
  const p = value as StudioProject;
  if (!p || p.version !== 1 || typeof p.name !== 'string' || !Array.isArray(p.scenes) || !p.scenes.length || p.scenes.length > 24 || typeof p.activeSceneId !== 'string') fail('Dữ liệu dự án TendiesVN không hợp lệ.');
  const sceneIds = new Set<string>();
  for (const s of p.scenes) {
    if (!s || typeof s.id !== 'string' || sceneIds.has(s.id) || typeof s.name !== 'string' || !Array.isArray(s.layers) || s.layers.length > MAX_LAYERS) fail('Cảnh trong dự án không hợp lệ.');
    sceneIds.add(s.id); safePath(s.camlPath); safePath(s.descriptorPath);
    if (s.role !== undefined && !['Background', 'Floating', 'Foreground', 'Other'].includes(s.role)) fail('Vai trò cảnh không hợp lệ.');
    if (s.transition && (!Number.isFinite(s.transition.duration) || s.transition.duration < 0 || s.transition.duration > 30 || !['linear', 'easeIn', 'easeOut', 'easeInOut'].includes(s.transition.timing))) fail('Chuyển trạng thái không hợp lệ.');
    if (!(s.width > 0 && s.width <= 8192 && s.height > 0 && s.height <= 8192) || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(s.background)) fail('Kích thước hoặc màu cảnh không hợp lệ.');
    if (s.rootXML !== undefined && (typeof s.rootXML !== 'string' || s.rootXML.length > MAX_XML)) fail('XML của dự án không hợp lệ.');
    const ids = new Set<string>();
    for (const l of s.layers) {
      if (!l || typeof l.id !== 'string' || ids.has(l.id) || !['image', 'text', 'shape', 'group', 'gradient', 'unsupported'].includes(l.type) || typeof l.name !== 'string') fail('Lớp trong dự án không hợp lệ.');
      ids.add(l.id);
      for (const key of ['x', 'y', 'width', 'height', 'rotation', 'opacity', 'fontSize', 'cornerRadius'] as const) if (typeof l[key] !== 'number' || !Number.isFinite(l[key]) || Math.abs(l[key]) > 1e6) fail('Thuộc tính lớp không hợp lệ.');
      if (l.width <= 0 || l.height <= 0 || l.opacity < 0 || l.opacity > 1 || typeof l.visible !== 'boolean' || typeof l.locked !== 'boolean' || typeof l.text !== 'string' || l.text.length > 100000 || typeof l.color !== 'string' || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(l.color) || typeof l.fontFamily !== 'string' || !['normal', 'bold'].includes(l.fontWeight) || !['left', 'center', 'right'].includes(l.textAlign)) fail('Nội dung lớp không hợp lệ.');
      if (!l.motion || !motionPresets.includes(l.motion.preset) || ![l.motion.duration, l.motion.delay, l.motion.amount].every(Number.isFinite) || l.motion.duration < 0.2 || l.motion.duration > 3600 || l.motion.delay < 0 || l.motion.delay > 3600 || Math.abs(l.motion.amount) > 10000) fail('Chuyển động của lớp không hợp lệ.');
      if (l.parentId !== null && typeof l.parentId !== 'string') fail('Nhóm lớp không hợp lệ.');
      if (l.imagePath) safePath(l.imagePath);
      if (l.binding !== undefined && (typeof l.binding !== 'string' || !/^node:\d+$/.test(l.binding))) fail('Liên kết XML của lớp không hợp lệ.');
      validateAppearance(l, false);
      if (l.states) {
        if (typeof l.states !== 'object' || Array.isArray(l.states)) fail('Trạng thái lớp không hợp lệ.');
        for (const [state, patch] of Object.entries(l.states)) { if (!stateNames.includes(state as typeof stateNames[number])) fail('Tên trạng thái không hợp lệ.'); validateAppearance(patch, true); }
      }
      if (l.filters && (!Array.isArray(l.filters) || l.filters.length > 32 || l.filters.some(filter => !filter || typeof filter.id !== 'string' || !Object.keys(filterNames).includes(filter.type) || typeof filter.enabled !== 'boolean' || !Number.isFinite(filter.amount) || Math.abs(filter.amount) > 10000))) fail('Bộ lọc không hợp lệ.');
      if (l.animations && (!Array.isArray(l.animations) || l.animations.length > 32 || l.animations.some(animation => !validAnimation(animation)))) fail('Chuyển động không hợp lệ.');
    }
    for (const l of s.layers) {
      let parent = l.parentId; const visited = new Set([l.id]);
      while (parent) {
        if (visited.has(parent)) fail('Các nhóm lớp có vòng lặp.');
        visited.add(parent);
        const ancestor = s.layers.find(v => v.id === parent);
        if (!ancestor || !['group', 'unsupported'].includes(ancestor.type)) fail('Không tìm thấy nhóm chứa lớp.');
        parent = ancestor.parentId;
      }
    }
  }
  if (!sceneIds.has(p.activeSceneId)) p.activeSceneId = p.scenes[0].id;
  return p;
}

function validateAppearance(value: unknown, partial: boolean) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail('Thuộc tính trạng thái không hợp lệ.');
  const data = value as Record<string, unknown>;
  if (partial && Object.keys(data).some(key => !propertyKeys.includes(key as keyof LayerProperties))) fail('Trạng thái chứa thuộc tính không hỗ trợ.');
  for (const key of ['z', 'scale', 'rotationX', 'rotationY', 'anchorX', 'anchorY', 'backgroundOpacity', 'borderWidth', ...(partial ? ['x', 'y', 'width', 'height', 'rotation', 'opacity', 'fontSize', 'cornerRadius'] : [])]) {
    if (data[key] !== undefined && (typeof data[key] !== 'number' || !Number.isFinite(data[key]) || Math.abs(Number(data[key])) > 1e6)) fail('Giá trị hình học không hợp lệ.');
  }
  for (const key of ['backgroundColor', 'borderColor', ...(partial ? ['color'] : [])]) if (data[key] !== undefined && (typeof data[key] !== 'string' || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(data[key] as string))) fail('Màu không hợp lệ.');
  for (const key of ['visible', 'clipContents']) if (data[key] !== undefined && typeof data[key] !== 'boolean') fail('Giá trị hiển thị không hợp lệ.');
  if (data.backgroundOpacity !== undefined && (Number(data.backgroundOpacity) < 0 || Number(data.backgroundOpacity) > 1)) fail('Độ mờ nền không hợp lệ.');
  if (data.opacity !== undefined && (Number(data.opacity) < 0 || Number(data.opacity) > 1)) fail('Độ mờ không hợp lệ.');
  if (data.scale !== undefined && (Number(data.scale) <= 0 || Number(data.scale) > 1000)) fail('Tỷ lệ không hợp lệ.');
  for (const key of ['width', 'height']) if (data[key] !== undefined && Number(data[key]) <= 0) fail('Kích thước trạng thái không hợp lệ.');
  if (data.blendMode !== undefined && data.blendMode !== 'normal' && !Object.keys(blendNames).includes(String(data.blendMode))) fail('Chế độ hòa trộn không hợp lệ.');
  if (data.gradientColors !== undefined && (!Array.isArray(data.gradientColors) || data.gradientColors.length < 2 || data.gradientColors.length > 16 || data.gradientColors.some(color => typeof color !== 'string' || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(color)))) fail('Màu chuyển sắc không hợp lệ.');
  for (const key of ['gradientStart', 'gradientEnd']) if (data[key] !== undefined && (!Array.isArray(data[key]) || (data[key] as unknown[]).length !== 2 || !(data[key] as unknown[]).every(n => typeof n === 'number' && Number.isFinite(n) && Math.abs(n) <= 10000))) fail('Điểm chuyển sắc không hợp lệ.');
  for (const key of ['text', 'fontFamily', 'fontWeight', 'textAlign']) if (data[key] !== undefined && (typeof data[key] !== 'string' || (data[key] as string).length > (key === 'text' ? 100000 : 256))) fail('Nội dung trạng thái không hợp lệ.');
  if (data.fontWeight !== undefined && !['normal', 'bold'].includes(String(data.fontWeight))) fail('Kiểu chữ không hợp lệ.');
  if (data.textAlign !== undefined && !['left', 'center', 'right'].includes(String(data.textAlign))) fail('Căn chữ không hợp lệ.');
  if (data.imagePath !== undefined) safePath(data.imagePath as string);
}
function validAnimation(animation: LayerAnimation) {
  if (!animation || typeof animation.id !== 'string' || !animationProperties.includes(animation.property) || !Number.isFinite(animation.duration) || animation.duration < .2 || animation.duration > 3600 || !Number.isFinite(animation.delay) || animation.delay < 0 || animation.delay > 3600 || ![animation.enabled, animation.repeat, animation.autoreverses].every(value => typeof value === 'boolean')) return false;
  return [animation.from, animation.to].every(value => animation.property === 'backgroundColor' ? typeof value === 'string' && /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(value) : animation.property === 'position' || animation.property === 'bounds' ? Array.isArray(value) && (value.length === 2 || (animation.property === 'bounds' && value.length === 4)) && value.every(n => Number.isFinite(n) && Math.abs(n) <= 1e6) : typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= 1e6);
}

export async function importPackage(data: Uint8Array, filename: string): Promise<StudioDocument> {
  checkArchive(data);
  const zip = await JSZip.loadAsync(data, { checkCRC32: true, createFolders: false });
  const files = new Map<string, Uint8Array>(); let total = 0;
  for (const file of Object.values(zip.files)) {
    if (file.dir) continue;
    const original = (file as typeof file & { unsafeOriginalName?: string }).unsafeOriginalName;
    if (original && original !== file.name) fail('Gói chứa đường dẫn bị thay đổi khi giải nén.');
    safePath(file.name);
    const bytes = await file.async('uint8array'); total += bytes.length;
    if (total > MAX_BYTES) fail('Gói vượt giới hạn bộ nhớ 128 MB.');
    files.set(file.name, bytes);
  }
  const warnings: string[] = [];
  const camlPaths = [...files.keys()].filter(path => /(?:\.caml$|\/main\.xml$)/i.test(path) && /\.ca\//i.test(path));
  if (files.has(MANIFEST)) {
    const bytes = files.get(MANIFEST)!;
    if (bytes.length > 12 * 1024 * 1024) fail('Dữ liệu dự án quá lớn.');
    const project = validateProject(JSON.parse(decoder.decode(bytes)));
    for (const scene of project.scenes) {
      if (!files.has(scene.camlPath)) fail('Dự án thiếu tệp CAML.');
      const xml = decoder.decode(files.get(scene.camlPath)!);
      const parsed = parseScene(xml, scene.camlPath, scene.descriptorPath, scene.name, warnings);
      const parsedRoot = parsed.layers.find(layer => layer.isRoot)!;
      let root = scene.layers.find(layer => layer.isRoot || layer.binding === 'node:0');
      if (!root) {
        root = parsedRoot; scene.layers.unshift(root);
        for (const layer of scene.layers) if (layer !== root && layer.parentId === null) layer.parentId = root.id;
      }
      root.isRoot = true;
      for (const layer of scene.layers) {
        const source = parsed.layers.find(candidate => candidate.binding === layer.binding);
        if (!source) continue;
        for (const key of ['z', 'scale', 'rotationX', 'rotationY', 'anchorX', 'anchorY', 'backgroundColor', 'backgroundOpacity', 'borderColor', 'borderWidth', 'clipContents', 'blendMode', 'gradientColors', 'gradientStart', 'gradientEnd', 'filters', 'animations', 'states'] as const) {
          if (layer[key] === undefined) (layer as unknown as Record<string, unknown>)[key] = source[key];
        }
      }
      scene.role ??= parsed.role; scene.transition ??= parsed.transition;
      scene.rootXML = xml;
    }
    // Older manifests exposed only Background; make their existing Floating CA editable too.
    for (const path of camlPaths) if (/floating[^/]*\.ca\/(?:main\.caml|main\.xml)$/i.test(path) && !project.scenes.some(scene => scene.camlPath === path)) {
      const owner = project.scenes.find(scene => path.startsWith(scene.descriptorPath + '/'));
      if (owner) try { project.scenes.push(parseScene(decoder.decode(files.get(path)!), path, owner.descriptorPath, 'Floating', warnings)); } catch { /* opaque source remains in files */ }
    }
    return { project, files, warnings: [...new Set(warnings)], sourceName: filename };
  }
  const scenes: Scene[] = [];
  for (const path of camlPaths) {
    const match = path.match(/(^|\/)(descriptors\/[^/]+)(?:\/|$)/);
    if (!match) continue;
    const bytes = files.get(path)!;
    if (bytes.length > MAX_XML) fail('Tệp CAML quá lớn để chỉnh sửa.');
    const xml = decoder.decode(bytes);
    if (/<!DOCTYPE|<!ENTITY/i.test(xml)) fail('XML chứa khai báo thực thể không được hỗ trợ.');
    if (!/<(?:[\w-]+:)?(?:CA|LK)[\w]*Layer(?:\s|\/|>)/.test(xml)) continue;
    const name = basename(directory(path)).replace(/\.ca$/i, '') || `Cảnh ${scenes.length + 1}`;
    try {
      scenes.push(parseScene(xml, path, `${path.slice(0, match.index! + match[1].length)}${match[2]}`, name, warnings));
    } catch {
      warnings.push(`Cảnh “${name}” chưa hỗ trợ chỉnh sửa; tệp gốc của cảnh này vẫn được giữ nguyên khi xuất.`);
      continue;
    }
    if (scenes.length > 24) fail('Gói có quá nhiều cảnh để chỉnh sửa.');
  }
  if (!scenes.length) fail('Không tìm thấy cảnh CAML trong gói .tendies. Gói gốc chưa bị thay đổi.');
  const project: StudioProject = { version: 1, name: filename.replace(/\.(?:tendies|zip)$/i, ''), scenes, activeSceneId: scenes[0].id };
  return { project, files, warnings: [...new Set(warnings)], sourceName: filename };
}

export function addImage(doc: StudioDocument, bytes: Uint8Array, mime = 'image/png', filename = 'image.png'): string {
  if (!/^image\/(?:png|jpeg|webp|gif)$/i.test(mime)) fail('Dùng ảnh PNG, JPEG, WebP hoặc GIF.');
  if (bytes.length > 32 * 1024 * 1024) fail('Ảnh lớn hơn 32 MB.');
  const ext = mime === 'image/jpeg' ? 'jpg' : mime.split('/')[1].toLowerCase();
  const stem = filename.replace(/\.[^.]+$/, '').replace(/[^\p{L}\p{N}_-]/gu, '-').slice(0, 48) || 'image';
  const path = `assets/${uid()}-${stem}.${ext}`;
  const total = [...doc.files.values()].reduce((sum, b) => sum + b.length, 0) + bytes.length;
  if (total > MAX_BYTES) fail('Dự án vượt giới hạn 128 MB.');
  doc.files.set(path, bytes.slice()); return path;
}

function freshXML(width: number, height: number, background: string) {
  const doc = new DOMParser().parseFromString(`<caml xmlns="${NS}"><CALayer id="tendiesvn-root" name="Root Layer" bounds="0 0 ${width} ${height}" position="${width / 2} ${height / 2}" geometryFlipped="1"><backgroundColor type="CGColor" value="${colorCA(background)}"/><sublayers/></CALayer></caml>`, 'application/xml');
  return serializeXML(doc);
}

class PlistUID { constructor(readonly value: number) {} }
type PlistValue = string | number | boolean | Uint8Array | PlistUID | PlistValue[] | { [key: string]: PlistValue };
const U = (index: number) => new PlistUID(index);

/** Small original binary-property-list writer. UID records keep keyed archives valid. */
function binaryPlist(value: PlistValue): Uint8Array {
  type RecordNode = { value: PlistValue; refs?: number[]; count?: number };
  const records: RecordNode[] = [];
  function collect(item: PlistValue): number {
    const index = records.length, record: RecordNode = { value: item }; records.push(record);
    if (Array.isArray(item)) { record.refs = item.map(collect); record.count = item.length; }
    else if (typeof item === 'object' && !(item instanceof Uint8Array) && !(item instanceof PlistUID)) {
      const entries = Object.entries(item); record.refs = [...entries.map(([key]) => collect(key)), ...entries.map(([, val]) => collect(val))]; record.count = entries.length;
    }
    return index;
  }
  const top = collect(value);
  const width = (n: number) => n < 256 ? 1 : n < 65536 ? 2 : n < 4294967296 ? 4 : 8;
  const integer = (n: number, size: number) => {
    let big = BigInt(n); if (big < 0n) big += 1n << BigInt(size * 8);
    return Array.from({ length: size }, (_, i) => Number((big >> BigInt((size - 1 - i) * 8)) & 255n));
  };
  const lengthTag = (tag: number, length: number) => length < 15 ? [tag | length] : [tag | 15, 0x10 | Math.log2(width(length)), ...integer(length, width(length))];
  const refSize = width(records.length - 1), output = [...encoder.encode('bplist00')], offsets: number[] = [];
  for (const record of records) {
    offsets.push(output.length); const v = record.value;
    if (typeof v === 'boolean') output.push(v ? 0x09 : 0x08);
    else if (typeof v === 'number') {
      if (!Number.isFinite(v)) fail('Số trong metadata không hợp lệ.');
      if (Number.isSafeInteger(v)) { const size = v < 0 ? 8 : width(v); output.push(0x10 | Math.log2(size), ...integer(v, size)); }
      else { const bytes = new Uint8Array(8); new DataView(bytes.buffer).setFloat64(0, v, false); output.push(0x23, ...bytes); }
    } else if (typeof v === 'string') {
      if (/^[\x00-\x7f]*$/.test(v)) output.push(...lengthTag(0x50, v.length), ...encoder.encode(v));
      else { output.push(...lengthTag(0x60, v.length)); for (let i = 0; i < v.length; i++) output.push(v.charCodeAt(i) >> 8, v.charCodeAt(i) & 255); }
    } else if (v instanceof Uint8Array) output.push(...lengthTag(0x40, v.length), ...v);
    else if (v instanceof PlistUID) { const size = width(v.value); output.push(0x80 | (size - 1), ...integer(v.value, size)); }
    else { output.push(...lengthTag(Array.isArray(v) ? 0xa0 : 0xd0, record.count!)); for (const ref of record.refs!) output.push(...integer(ref, refSize)); }
  }
  const offsetStart = output.length, offsetSize = width(offsetStart);
  for (const offset of offsets) output.push(...integer(offset, offsetSize));
  output.push(0, 0, 0, 0, 0, 0, offsetSize, refSize, ...integer(records.length, 8), ...integer(top, 8), ...integer(offsetStart, 8));
  return new Uint8Array(output);
}

function archive(objects: PlistValue[]) { return binaryPlist({ $version: 100000, $archiver: 'NSKeyedArchiver', $top: { root: U(1) }, $objects: ['$null', ...objects] }); }
function cls(name: string, parents: string[] = []) { return { $classname: name, $classes: [name, ...parents, 'NSObject'] }; }

function generatedMetadata(files: Map<string, Uint8Array>, path: string, name: string, width: number, height: number, identifier: number) {
  const contents = `${path}/versions/1/contents`, bundle = `${contents}/TendiesVN.wallpaper`;
  const put = (relative: string, value: Uint8Array | string) => files.set(`${path}/${relative}`, typeof value === 'string' ? textBytes(value) : value);
  put('com.apple.posterkit.provider.descriptor.identifier', String(identifier));
  put('com.apple.posterkit.role.identifier', 'PRPosterRoleLockScreen');
  put('providerInfo.plist', archive([{ 'NS.keys': [], 'NS.objects': [], $class: U(2) }, cls('NSMutableDictionary', ['NSDictionary'])]));
  put('versions/1/com.apple.posterkit.provider.instance.complicationLayout.plist', archive([
    { $class: U(4), inlineComplication: U(0), complications: U(2) }, { 'NS.objects': [], $class: U(3) }, cls('NSArray'), cls('PRPosterComplicationLayout'),
  ]));
  put('versions/1/com.apple.posterkit.provider.instance.titleStyleConfiguration.plist', archive([
    { $class: U(7), titleColor: U(0), contentsLuminence: U(5), groupName: U(6), alternateDateEnabled: false, timeNumberingSystem: U(0), timeFontConfiguration: U(2), userConfigured: false },
    { timeFontIdentifier: U(3), $class: U(4) }, 'PRTimeFontIdentifierSoft', cls('PRPosterSystemTimeFontConfiguration', ['PRPosterTimeFontConfiguration']), 0, 'PREditingLook', cls('PRPosterTitleStyleConfiguration'),
  ]));
  put('versions/1/contents/.com.apple.posterkit.provider.contents.configurableOptions.plist', archive([
    { preferredHomeScreenConfiguration: U(4), displayNameLocalizationKey: U(0), $class: U(7), preferredTimeFontConfigurations: U(2), preferredTitleColors: U(2) },
    { 'NS.objects': [], $class: U(3) }, cls('NSArray'),
    { preferredStyle: U(5), preferredSolidColors: U(0), $class: U(6), preferredGradientColors: U(0), allowsModifyingLegibilityBlur: true }, 0,
    cls('PRPosterDescriptorHomeScreenConfiguration'), cls('PRPosterConfigurableOptions'),
  ]));
  put('versions/1/contents/com.apple.posterkit.provider.contents.otherMetadata.plist', archive([{ displayNameLocalizationKey: U(0), $class: U(2) }, cls('PRPosterMetadata')]));
  put('versions/1/contents/com.apple.posterkit.provider.contents.userInfo', binaryPlist({ wallpaperRepresentingIdentifier: String(identifier), wallpaperRepresentingFileName: 'TendiesVN.wallpaper', posterEnvironmentOverrides: textBytes('{}') }));
  put('com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist', archive([
    { $class: U(16), lastModifiedDate: U(14), suggestedGalleryItem: U(2), suggestedComplicationsByIdentifier: U(12) },
    { layoutType: 0, source: 2, extensionBundleIdentifier: U(5), titleFontName: U(7), subtitleComplication: U(0), descriptorIdentifier: U(4), spokenNameLocalizationKey: U(0), complications: U(0), modeUUID: U(0), displayNameLocalizationKey: U(6), descriptiveTextLocalizationKey: U(0), blankTemplate: false, $class: U(11), score: U(10), localizedSubtitle: U(0), identifier: U(3), modeSemanticType: U(0), shouldShowAsShuffleStack: false, titleColor: U(8), localizedDisplayName: U(6) },
    uuid(), `${identifier}.DYNAMIC`, 'com.apple.WallpaperKit.CollectionsPoster', name, '', { r: 0, b: 0, g: 0, a: 0, $class: U(9) }, cls('BSColor'), 20, cls('ATXFaceGalleryItem'), { 'NS.keys': [], 'NS.objects': [], $class: U(13) }, cls('NSDictionary'), { 'NS.time': Date.now() / 1000 - 978307200, $class: U(15) }, cls('NSDate'), cls('PRPosterSuggestionMetadata'),
  ]));
  files.set(`${bundle}/Wallpaper.plist`, generatedWallpaper(name, width, height, identifier));
  for (const layer of ['Background', 'Floating', 'Foreground']) {
    const ca = `${bundle}/${layer}.ca`;
    files.set(`${ca}/assetManifest.caml`, textBytes(`<caml xmlns="${NS}"><MicaAssetManifest><modules type="NSArray"/></MicaAssetManifest></caml>`));
    files.set(`${ca}/index.xml`, textBytes(`<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict><key>rootDocument</key><string>main.caml</string><key>assetManifest</key><string>assetManifest.caml</string><key>documentWidth</key><real>${width}</real><key>documentHeight</key><real>${height}</real><key>documentResizesToView</key><false/><key>geometryFlipped</key><false/><key>scalesToFitInPlayer</key><true/><key>loopingEnabled</key><true/><key>loopStart</key><real>0</real><key>loopEnd</key><real>+infinity</real></dict></plist>`));
    if (layer !== 'Background') files.set(`${ca}/main.caml`, textBytes(freshXML(width, height, '#00000000')));
  }
}

function generatedWallpaper(name: string, width: number, height: number, identifier: number) {
  return binaryPlist({
    assets: { lockAndHome: { default: { foregroundAnimationFileName: 'Foreground.ca', name, backgroundAnimationFileName: 'Background.ca', type: 'LayeredAnimation', identifier, floatingAnimationFileNameKey: 'Floating.ca' } } },
    family: 'TendiesVN', logicalScreenClass: `${width}w-${height}h@3x~iphone`, appearanceAware: false, identifier, version: 1, name,
  });
}

/** A neutral, original descriptor; no vendor artwork or template archive is embedded. */
export function createDocument(name = 'Hình nền mới', width = 390, height = 844): StudioDocument {
  width = clamp(Math.round(finite(width, 390)), 64, 4096); height = clamp(Math.round(finite(height, 844)), 64, 4096);
  const descriptorPath = `descriptors/${uuid()}`;
  const camlPath = `${descriptorPath}/versions/1/contents/TendiesVN.wallpaper/Background.ca/main.caml`;
  const files = new Map<string, Uint8Array>();
  files.set(camlPath, textBytes(freshXML(width, height, '#121720')));
  generatedMetadata(files, descriptorPath, name, width, height, 100000 + Math.floor(Math.random() * 1900000000));
  const background = parseScene(decoder.decode(files.get(camlPath)!), camlPath, descriptorPath, 'Background', []);
  const floatingPath = camlPath.replace('/Background.ca/', '/Floating.ca/');
  const floating = parseScene(decoder.decode(files.get(floatingPath)!), floatingPath, descriptorPath, 'Floating', []);
  return { project: { version: 1, name, scenes: [background, floating], activeSceneId: background.id }, files, warnings: [], sourceName: `${name}.tendies` };
}

function setMotion(element: Element, motion: LayerMotion, layer: Layer) {
  const doc = element.ownerDocument;
  let animations = child(element, 'animations');
  if (animations) for (const node of children(animations)) if (node.getAttribute('key')?.startsWith('tendiesvn.')) animations.removeChild(node);
  if (motion.preset === 'none') return;
  if (!animations) { animations = caElement(doc, 'animations'); element.appendChild(animations); }
  const node = caElement(doc, 'animation');
  node.setAttribute('type', 'CAKeyframeAnimation'); node.setAttribute('key', `tendiesvn.${motion.preset}`);
  const anchor = numbers(element.getAttribute('anchorPoint'));
  const centerY = layer.y + layer.height * (anchor[1] ?? 0.5);
  const values = motion.preset === 'spin' ? [layer.rotation * Math.PI / 180, (layer.rotation + 360) * Math.PI / 180] : Array.from({ length: 33 }, (_, i) => {
    // Sampling the same analytic curve keeps native and editor previews aligned.
    const m = motionAt({ ...motion, delay: 0 }, (i === 32 ? 0 : i / 32) * motion.duration);
    return ['float', 'bounce'].includes(motion.preset) ? centerY + m.dy : motion.preset === 'pulse' ? m.scale : layer.opacity * m.opacity;
  });
  node.setAttribute('keyPath', ['float', 'bounce'].includes(motion.preset) ? 'position.y' : motion.preset === 'pulse' ? 'transform.scale' : motion.preset === 'spin' ? 'transform.rotation.z' : 'opacity');
  node.setAttribute('duration', String(motion.duration)); node.setAttribute('beginTime', String(motion.delay));
  node.setAttribute('calculationMode', 'linear');
  node.setAttribute('repeatCount', 'inf'); node.setAttribute('removedOnCompletion', '0'); node.setAttribute('fillMode', 'both');
  const vals = caElement(doc, 'values');
  for (const value of values) { const real = caElement(doc, 'real'); real.setAttribute('value', String(value)); vals.appendChild(real); }
  node.appendChild(vals); animations.appendChild(node);
}

function syncFilters(element: Element, filters: LayerFilter[], previous: LayerFilter[]) {
  let container = child(element, 'filters');
  if (!container && filters.length) { container = caElement(element.ownerDocument, 'filters'); element.appendChild(container); }
  if (!container) return;
  const original = children(container), old = new Map<string, Element>();
  original.forEach((node, index) => old.set(node.getAttribute('name') || `xml-filter:${index}`, node));
  for (const filter of previous) if (!filters.some(value => value.id === filter.id)) old.get(filter.id)?.remove();
  for (const filter of filters) {
    let node = old.get(filter.id);
    if (!node) { node = caElement(element.ownerDocument, filter.type === 'sepia' ? 'CIFilter' : 'CAFilter'); container.appendChild(node); }
    const [name, input] = filterNames[filter.type];
    node.setAttribute('name', filter.id); node.setAttribute('filter', name); node.setAttribute('enabled', filter.enabled ? '1' : '0');
    const amount = filter.amount * (filter.type === 'hueRotate' ? Math.PI / 180 : 1);
    if (filter.type === 'sepia') { let value = child(node, input); if (!value) { value = caElement(element.ownerDocument, input); node.appendChild(value); } value.setAttribute('type', 'real'); value.setAttribute('value', String(amount)); }
    else node.setAttribute(input, String(amount));
  }
}
function writeAnimationValue(document: Document, value: AnimationValue, property: AnimationProperty, layer: Layer) {
  const type = property === 'position' ? 'CGPoint' : property === 'bounds' ? 'CGRect' : property === 'backgroundColor' ? 'CGColor' : 'real';
  const node = caElement(document, type);
  let raw: string;
  if (property === 'position') { const v = value as number[]; raw = `${v[0] + layer.width * (layer.anchorX ?? .5)} ${v[1] + layer.height * (layer.anchorY ?? .5)}`; }
  else if (property === 'bounds') { const v = value as number[]; raw = v.length === 4 ? v.join(' ') : `0 0 ${v[0]} ${v[1]}`; }
  else if (property === 'backgroundColor') raw = colorCA(value as string);
  else { let v = value as number; if (property.startsWith('transform.rotation.')) v *= Math.PI / 180; if (property === 'position.x') v += layer.width * (layer.anchorX ?? .5); if (property === 'position.y') v += layer.height * (layer.anchorY ?? .5); raw = String(v); }
  node.setAttribute('value', raw); return node;
}
function syncAnimations(element: Element, layer: Layer, previous: LayerAnimation[]) {
  const animations = layer.animations ?? []; let container = child(element, 'animations');
  if (!container && animations.some(value => value.enabled)) { container = caElement(element.ownerDocument, 'animations'); element.appendChild(container); }
  if (!container) return;
  const old = new Map<string, Element>(); children(container).forEach((node, index) => old.set(node.getAttribute('key') || `xml-animation:${index}`, node));
  for (const animation of previous) if (!animations.some(value => value.id === animation.id && value.enabled)) old.get(animation.id)?.remove();
  for (const animation of animations) {
    if (!animation.enabled) continue;
    let node = old.get(animation.id);
    if (!node) { node = caElement(element.ownerDocument, 'animation'); container.appendChild(node); }
    node.setAttribute('type', 'CAKeyframeAnimation'); node.setAttribute('key', animation.id); node.setAttribute('keyPath', animation.property);
    node.setAttribute('duration', String(animation.duration)); node.setAttribute('beginTime', String(animation.delay));
    node.setAttribute('repeatCount', animation.repeat ? 'inf' : '0'); node.setAttribute('autoreverses', animation.autoreverses ? '1' : '0');
    node.setAttribute('fillMode', 'both'); node.setAttribute('removedOnCompletion', '0'); node.setAttribute('calculationMode', 'linear');
    child(node, 'values')?.remove(); const values = caElement(element.ownerDocument, 'values');
    for (const value of [animation.from, animation.to]) values.appendChild(writeAnimationValue(element.ownerDocument, value, animation.property, layer)); node.appendChild(values);
  }
}

function stateValues(document: Document, layer: Layer, keys: Set<keyof LayerProperties>, camlPath: string) {
  const l = resolveLayer(layer, 'Base'), result = new Map<string, Element>();
  const add = (key: string, type: string, value: string | number, attrs?: Record<string, string>) => {
    const node = caElement(document, 'value'); node.setAttribute('type', type); if (!['CGImage', 'CAFilter', 'NSArray'].includes(type)) node.setAttribute('value', String(value));
    for (const [name, val] of Object.entries(attrs ?? {})) node.setAttribute(name, val); result.set(key, node); return node;
  };
  const has = (...props: (keyof LayerProperties)[]) => props.some(key => keys.has(key));
  if (has('x', 'y', 'width', 'height', 'anchorX', 'anchorY')) {
    add('position', 'CGPoint', `${l.x + l.width * (l.anchorX ?? .5)} ${l.y + l.height * (l.anchorY ?? .5)}`);
    add('bounds', 'CGRect', `0 0 ${l.width} ${l.height}`); add('anchorPoint', 'CGPoint', `${l.anchorX} ${l.anchorY}`);
  }
  for (const [field, key] of [['z', 'zPosition'], ['scale', 'transform.scale'], ['opacity', 'opacity'], ['fontSize', 'fontSize'], ['cornerRadius', 'cornerRadius'], ['borderWidth', 'borderWidth']] as const) if (keys.has(field)) add(key, 'real', l[field] ?? 0);
  for (const [field, key] of [['rotation', 'transform.rotation.z'], ['rotationX', 'transform.rotation.x'], ['rotationY', 'transform.rotation.y']] as const) if (keys.has(field)) add(key, 'real', (l[field] ?? 0) * Math.PI / 180);
  if (keys.has('visible')) add('hidden', 'integer', l.visible ? 0 : 1);
  if (keys.has('clipContents')) add('masksToBounds', 'integer', l.clipContents ? 1 : 0);
  if (keys.has('color')) add(l.type === 'text' ? 'foregroundColor' : 'backgroundColor', 'CGColor', colorCA(l.color));
  if (has('backgroundColor', 'backgroundOpacity')) {
    const values = numbers(colorCA(l.backgroundColor ?? '#00000000')); values[3] *= l.backgroundOpacity ?? 1;
    add('backgroundColor', 'CGColor', values.join(' '));
  }
  if (keys.has('borderColor')) add('borderColor', 'CGColor', colorCA(l.borderColor ?? '#000000'));
  if (keys.has('text')) add('string', 'string', l.text);
  if (has('fontFamily', 'fontWeight')) { let font = l.fontFamily; if (l.fontWeight === 'bold' && !/bold/i.test(font)) font = /-Regular$/i.test(font) ? font.replace(/-Regular$/i, '-Bold') : font + '-Bold'; add('font', 'string', font); }
  if (keys.has('textAlign')) add('alignmentMode', 'string', l.textAlign);
  if (keys.has('imagePath') && l.imagePath) add('contents', 'CGImage', '', { src: relativeAsset(camlPath, l.imagePath) });
  if (keys.has('blendMode')) add('compositingFilter', 'CAFilter', '', { filter: blendNames[l.blendMode ?? 'normal'] ?? 'normalBlendMode', name: blendNames[l.blendMode ?? 'normal'] ?? 'normalBlendMode' });
  if (keys.has('gradientStart')) add('startPoint', 'CGPoint', (l.gradientStart ?? [.5, 0]).join(' '));
  if (keys.has('gradientEnd')) add('endPoint', 'CGPoint', (l.gradientEnd ?? [.5, 1]).join(' '));
  if (keys.has('gradientColors')) { const node = add('colors', 'NSArray', ''); for (const color of l.gradientColors ?? []) { const item = caElement(document, 'CGColor'); item.setAttribute('value', colorCA(color)); node.appendChild(item); } }
  return result;
}

function syncStates(root: Element, scene: Scene, existing: Map<string, Element>, baseline: Scene) {
  const document = root.ownerDocument;
  let states = child(root, 'states') ?? child(document.documentElement, 'states');
  if (!states) { states = caElement(document, 'states'); root.appendChild(states); }
  for (const name of stateNames) if (!children(states).some(node => node.localName === 'LKState' && node.getAttribute('name') === name)) { const state = caElement(document, 'LKState'); state.setAttribute('name', name); state.appendChild(caElement(document, 'elements')); states.appendChild(state); }
  let transitions = child(root, 'stateTransitions') ?? child(document.documentElement, 'stateTransitions');
  if (!transitions) { transitions = caElement(document, 'stateTransitions'); root.appendChild(transitions); }
  const specs = [['*', 'Locked'], ['Locked', '*'], ['*', 'Unlock'], ['Unlock', '*'], ['*', 'Sleep'], ['Sleep', '*'], ['Locked', 'Unlock'], ['Unlock', 'Locked']];
  for (const [from, to] of specs) if (!children(transitions).some(node => node.getAttribute('fromState') === from && node.getAttribute('toState') === to)) { const transition = caElement(document, 'LKStateTransition'); transition.setAttribute('fromState', from); transition.setAttribute('toState', to); transition.appendChild(caElement(document, 'elements')); transitions.appendChild(transition); }
  const timing = scene.transition ?? { duration: .5, timing: 'easeInOut' };
  for (const layer of scene.layers) {
    const old = baseline.layers.find(value => value.binding === layer.binding);
    const keys = new Set<keyof LayerProperties>(), oldKeys = new Set<keyof LayerProperties>();
    for (const state of stateNames) {
      for (const key of Object.keys(layer.states?.[state] ?? {}) as (keyof LayerProperties)[]) keys.add(key);
      for (const key of Object.keys(old?.states?.[state] ?? {}) as (keyof LayerProperties)[]) oldKeys.add(key);
    }
    if (!keys.size && !oldKeys.size) continue;
    if (old && JSON.stringify(layer.states ?? {}) === JSON.stringify(old.states ?? {}) && propertyKeys.every(key => JSON.stringify(resolveLayer(layer, 'Base')[key]) === JSON.stringify(resolveLayer(old, 'Base')[key])) && JSON.stringify(scene.transition ?? { duration: .5, timing: 'easeInOut' }) === JSON.stringify(baseline.transition ?? { duration: .5, timing: 'easeInOut' })) continue;
    const target = existing.get(layer.id)!; if (!target.getAttribute('id')) target.setAttribute('id', layer.id);
    const targetId = target.getAttribute('id')!;
    const allKeys = new Set([...stateValues(document, layer, keys, scene.camlPath).keys(), ...stateValues(document, layer, oldKeys, scene.camlPath).keys()]);
    // Older tools use scalar sub-key paths; they represent the same known geometry.
    if (allKeys.has('position')) { allKeys.add('position.x'); allKeys.add('position.y'); }
    if (allKeys.has('bounds')) { allKeys.add('bounds.size.width'); allKeys.add('bounds.size.height'); }
    if (allKeys.has('anchorPoint')) { allKeys.add('anchorPoint.x'); allKeys.add('anchorPoint.y'); }
    if (allKeys.has('transform.scale')) { allKeys.add('transform.scale.xy'); allKeys.add('transform.scale.x'); allKeys.add('transform.scale.y'); }
    for (const state of children(states)) {
      const name = state.getAttribute('name') as typeof stateNames[number]; if (!stateNames.includes(name)) continue;
      let elements = child(state, 'elements'); if (!elements) { elements = caElement(document, 'elements'); state.appendChild(elements); }
      const priorActions = new Map<string, Element>();
      for (const action of children(elements)) if (action.localName === 'LKStateSetValue' && action.getAttribute('targetId') === targetId && allKeys.has(action.getAttribute('keyPath') ?? '')) { priorActions.set(action.getAttribute('keyPath')!, action); action.remove(); }
      for (const [key, value] of stateValues(document, resolveLayer(layer, name), keys, scene.camlPath)) {
        const action = priorActions.get(key) ?? caElement(document, 'LKStateSetValue'); action.setAttribute('targetId', targetId); action.setAttribute('keyPath', key); child(action, 'value')?.remove(); action.appendChild(value); elements.appendChild(action);
      }
    }
    for (const transition of children(transitions)) {
      const from = transition.getAttribute('fromState')!, to = transition.getAttribute('toState')!;
      if (!specs.some(([a, b]) => a === from && b === to)) continue;
      let elements = child(transition, 'elements'); if (!elements) { elements = caElement(document, 'elements'); transition.appendChild(elements); }
      const priorActions = new Map<string, Element>();
      for (const action of children(elements)) if (action.localName === 'LKStateTransitionElement' && action.getAttribute('targetId') === targetId && allKeys.has(action.getAttribute('key') ?? '')) { priorActions.set(action.getAttribute('key')!, action); action.remove(); }
      for (const key of stateValues(document, layer, keys, scene.camlPath).keys()) {
        const action = priorActions.get(key) ?? caElement(document, 'LKStateTransitionElement'); action.setAttribute('targetId', targetId); action.setAttribute('key', key);
        let animation = child(action, 'animation');
        const newAnimation = !animation; if (!animation) { animation = caElement(document, 'animation'); animation.setAttribute('type', 'CABasicAnimation'); animation.setAttribute('keyPath', key); animation.setAttribute('fillMode', 'both'); action.appendChild(animation); }
        if (newAnimation || scene.transition?.duration !== baseline.transition?.duration) animation.setAttribute('duration', String(timing.duration));
        if (newAnimation || scene.transition?.timing !== baseline.transition?.timing) { child(animation, 'timingFunction')?.remove(); animation.setAttribute('timingFunction', timing.timing === 'easeInOut' ? 'easeInEaseOut' : timing.timing); }
        elements.appendChild(action);
      }
    }
  }
}

function syncLayer(element: Element, layer: Layer, previous: Layer | undefined, scene: Scene) {
  const changed = (key: keyof Layer) => !previous || JSON.stringify(previous[key]) !== JSON.stringify(layer[key]);
  if (layer.type === 'unsupported') {
    if (changed('visible')) element.setAttribute('hidden', layer.visible ? '0' : '1');
    if (changed('opacity')) element.setAttribute('opacity', String(layer.opacity));
    return;
  }
  if (changed('name')) element.setAttribute('name', layer.name);
  if (!previous) element.setAttribute('id', layer.id);
  if (changed('width') || changed('height')) {
    const original = numbers(element.getAttribute('bounds'));
    element.setAttribute('bounds', `${original[0] || 0} ${original[1] || 0} ${layer.width} ${layer.height}`);
  }
  if (changed('x') || changed('y') || changed('width') || changed('height') || changed('anchorX') || changed('anchorY')) {
    element.setAttribute('position', `${layer.x + layer.width * (layer.anchorX ?? .5)} ${layer.y + layer.height * (layer.anchorY ?? .5)}`);
  }
  if (changed('anchorX') || changed('anchorY')) element.setAttribute('anchorPoint', `${layer.anchorX ?? .5} ${layer.anchorY ?? .5}`);
  if (changed('z')) element.setAttribute('zPosition', String(layer.z ?? 0));
  if (changed('scale')) { for (const key of ['transform.scale.xy', 'transform.scale.x', 'transform.scale.y']) element.removeAttribute(key); element.setAttribute('transform.scale', String(layer.scale ?? 1)); }
  if (changed('rotationX')) element.setAttribute('transform.rotation.x', String((layer.rotationX ?? 0) * Math.PI / 180));
  if (changed('rotationY')) element.setAttribute('transform.rotation.y', String((layer.rotationY ?? 0) * Math.PI / 180));
  if (changed('rotation')) element.setAttribute('transform.rotation.z', String(layer.rotation * Math.PI / 180));
  if (changed('opacity')) element.setAttribute('opacity', String(layer.opacity));
  if (changed('visible')) element.setAttribute('hidden', layer.visible ? '0' : '1');
  if (changed('cornerRadius')) {
    element.setAttribute('cornerRadius', String(layer.cornerRadius));
    if (layer.type === 'image') element.setAttribute('masksToBounds', layer.cornerRadius > 0 ? '1' : '0');
  }
  if (changed('clipContents')) element.setAttribute('masksToBounds', layer.clipContents ? '1' : layer.type === 'image' && layer.cornerRadius > 0 ? '1' : '0');
  if (changed('borderColor')) writeColor(element, 'borderColor', layer.borderColor ?? '#000000');
  if (changed('borderWidth')) element.setAttribute('borderWidth', String(layer.borderWidth ?? 0));
  if (layer.type === 'shape' && changed('color')) writeColor(element, 'backgroundColor', layer.color);
  if (changed('backgroundColor') || changed('backgroundOpacity')) {
    const color = numbers(colorCA(layer.type === 'shape' ? layer.color : layer.backgroundColor ?? '#00000000'));
    color[3] *= layer.backgroundOpacity ?? 1;
    writeColor(element, 'backgroundColor', colorHex(color.join(' '), '#00000000'));
  }
  if (changed('blendMode')) {
    const mode = layer.blendMode ?? 'normal'; let node = child(element, 'compositingFilter');
    if (mode === 'normal') node?.remove();
    else { if (!node) { node = caElement(element.ownerDocument, 'compositingFilter'); element.appendChild(node); } node.setAttribute('type', 'CAFilter'); node.setAttribute('filter', blendNames[mode]); node.setAttribute('name', blendNames[mode]); }
  }
  if (layer.type === 'gradient') {
    if (changed('gradientColors')) { child(element, 'colors')?.remove(); const colors = caElement(element.ownerDocument, 'colors'); for (const value of layer.gradientColors ?? ['#68e0c6', '#5165df']) { const node = caElement(element.ownerDocument, 'CGColor'); node.setAttribute('value', colorCA(value)); colors.appendChild(node); } element.appendChild(colors); }
    if (changed('gradientStart')) element.setAttribute('startPoint', (layer.gradientStart ?? [.5, 0]).join(' '));
    if (changed('gradientEnd')) element.setAttribute('endPoint', (layer.gradientEnd ?? [.5, 1]).join(' '));
    if (!previous) { const type = caElement(element.ownerDocument, 'type'); type.setAttribute('value', 'axial'); element.appendChild(type); }
  }
  if (layer.type === 'text') {
    if (changed('text')) {
      const oldString = child(element, 'string');
      if (oldString) element.removeChild(oldString);
      element.removeAttribute('string');
      const string = caElement(element.ownerDocument, 'string');
      string.setAttribute('type', 'string'); string.setAttribute('value', layer.text); element.appendChild(string);
    }
    if (changed('color')) writeColor(element, 'foregroundColor', layer.color);
    if (changed('fontSize')) element.setAttribute('fontSize', String(layer.fontSize));
    if (changed('fontFamily') || changed('fontWeight')) {
      let font = layer.fontFamily || 'HelveticaNeue';
      const standardFonts: Record<string, [string, string]> = {
        '-apple-system': ['HelveticaNeue', 'HelveticaNeue-Bold'],
        'Helvetica Neue': ['HelveticaNeue', 'HelveticaNeue-Bold'],
        'HelveticaNeue': ['HelveticaNeue', 'HelveticaNeue-Bold'],
        'Arial': ['ArialMT', 'Arial-BoldMT'], 'ArialMT': ['ArialMT', 'Arial-BoldMT'],
        'Georgia': ['Georgia', 'Georgia-Bold'],
        'Times New Roman': ['TimesNewRomanPSMT', 'TimesNewRomanPS-BoldMT'],
        'Courier New': ['CourierNewPSMT', 'CourierNewPS-BoldMT']
      };
      if (standardFonts[font]) font = standardFonts[font][layer.fontWeight === 'bold' ? 1 : 0];
      else if (layer.fontWeight === 'bold' && !/bold/i.test(font)) font += '-Bold';
      else if (layer.fontWeight === 'normal' && previous?.fontWeight === 'bold' && !changed('fontFamily')) font = font.replace(/[- ]?(?:Semi|Demi)?Bold$/i, '') || 'HelveticaNeue';
      let node = child(element, 'font');
      if (!node) { node = caElement(element.ownerDocument, 'font'); element.appendChild(node); }
      node.setAttribute('type', 'string'); node.setAttribute('value', font); element.removeAttribute('font');
    }
    if (changed('textAlign')) element.setAttribute('alignmentMode', layer.textAlign);
    if (!previous) { element.setAttribute('wrapped', '1'); element.setAttribute('contentsScale', '3'); }
  }
  if (layer.type === 'image' && layer.imagePath && changed('imagePath')) {
    let contents = child(element, 'contents');
    if (!contents) { contents = caElement(element.ownerDocument, 'contents'); element.appendChild(contents); }
    const source = relativeAsset(scene.camlPath, layer.imagePath);
    const nestedImage = descendants(contents, 'CGImage')[0];
    if (nestedImage) {
      nestedImage.setAttribute('src', source);
      contents.removeAttribute('src'); contents.removeAttribute('source');
    } else { contents.setAttribute('type', 'CGImage'); contents.setAttribute('src', source); }
    if (!previous) element.setAttribute('contentsGravity', 'resizeAspectFill');
  }
  if (changed('motion')) setMotion(element, layer.motion, layer);
  if (changed('filters')) syncFilters(element, layer.filters ?? [], previous?.filters ?? []);
  if (changed('animations') || (layer.animations?.length && ['x', 'y', 'width', 'height', 'anchorX', 'anchorY'].some(key => changed(key as keyof Layer)))) syncAnimations(element, layer, previous?.animations ?? []);
}

function serializeScene(scene: Scene): { xml: string; bindings: Map<string, string> } {
  const xml = scene.rootXML ?? freshXML(scene.width, scene.height, scene.background);
  const doc = parseXML(xml), root = layerRoot(doc);
  const baseline = parseScene(xml, scene.camlPath, scene.descriptorPath, scene.name, []);
  const rootModel = scene.layers.find(layer => layer.isRoot || layer.binding === 'node:0');
  if (rootModel) {
    if (scene.width !== baseline.width && rootModel.width === baseline.width) rootModel.width = scene.width;
    if (scene.height !== baseline.height && rootModel.height === baseline.height) rootModel.height = scene.height;
  }
  const nodes = allLayers(root), byBinding = new Map(nodes.map((el, index) => [`node:${index}`, el]));
  const previous = new Map(baseline.layers.map(l => [l.binding!, l]));
  const existing = new Map<string, Element>();
  const usedBindings = new Set<string>();
  for (const layer of scene.layers) {
    if (layer.binding && usedBindings.has(layer.binding)) fail('Hai lớp đang trỏ tới cùng một nút XML.');
    if (layer.binding) usedBindings.add(layer.binding);
    const element = layer.binding ? byBinding.get(layer.binding) : undefined;
    if (layer.binding && !element) fail('Liên kết lớp gốc không còn hợp lệ.');
    const target = element ?? caElement(doc, layer.type === 'text' ? 'CATextLayer' : layer.type === 'gradient' ? 'CAGradientLayer' : 'CALayer');
    syncLayer(target, layer, layer.binding ? previous.get(layer.binding) : undefined, scene);
    existing.set(layer.id, target);
  }
  const deletedTargetIds = new Set<string>();
  for (const layer of baseline.layers) {
    if (layer.binding && !usedBindings.has(layer.binding)) {
      const node = byBinding.get(layer.binding);
      if (node && node !== root) { const targetId = node.getAttribute('id'); if (targetId) deletedTargetIds.add(targetId); node.parentNode?.removeChild(node); }
    }
  }
  // Explicit layer deletion also removes its actions, including actions in custom states.
  for (const node of existing.values()) { const targetId = node.getAttribute('id'); if (targetId) deletedTargetIds.delete(targetId); }
  if (deletedTargetIds.size) for (const name of ['LKStateSetValue', 'LKStateTransitionElement']) for (const action of descendants(doc.documentElement, name)) if (deletedTargetIds.has(action.getAttribute('targetId') ?? '')) action.remove();
  // Moving only the layer nodes retains filters, state definitions and unknown XML.
  for (const layer of scene.layers) {
    const element = existing.get(layer.id)!;
    if (element === root) continue;
    const parent = layer.parentId ? existing.get(layer.parentId)! : root;
    let sublayers = child(parent, 'sublayers');
    if (!sublayers) { sublayers = caElement(doc, 'sublayers'); parent.appendChild(sublayers); }
    sublayers.appendChild(element);
  }
  const oldBounds = numbers(root.getAttribute('bounds'));
  if (scene.width !== baseline.width || scene.height !== baseline.height) {
    root.setAttribute('bounds', `${oldBounds[0] || 0} ${oldBounds[1] || 0} ${scene.width} ${scene.height}`);
    const position = numbers(root.getAttribute('position')), anchor = numbers(root.getAttribute('anchorPoint'));
    root.setAttribute('position', rootModel ? `${rootModel.x + rootModel.width * (rootModel.anchorX ?? .5)} ${rootModel.y + rootModel.height * (rootModel.anchorY ?? .5)}` : `${(position[0] ?? baseline.width / 2) + (scene.width - baseline.width) * (anchor[0] ?? .5)} ${(position[1] ?? baseline.height / 2) + (scene.height - baseline.height) * (anchor[1] ?? .5)}`);
  }
  if (scene.background !== baseline.background) writeColor(root, 'backgroundColor', scene.background);
  syncStates(root, scene, existing, baseline);
  const after = allLayers(root), bindings = new Map<string, string>();
  for (const [id, element] of existing) bindings.set(id, `node:${after.indexOf(element)}`);
  return { xml: serializeXML(doc), bindings };
}

export async function exportPackage(document: StudioDocument): Promise<{ data: Uint8Array; filename: string }> {
  validateProject(document.project);
  const zip = new JSZip(), files = new Map(document.files);
  const project = JSON.parse(JSON.stringify(document.project)) as StudioProject;
  for (const scene of project.scenes) {
    const relocate = (source: string, layerName: string) => {
      const asset = files.get(source);
      if (!asset) fail(`Thiếu ảnh của lớp “${layerName}”.`);
      // Native installation copies each descriptor tree, not the ZIP root.
      if (!source.startsWith(`${scene.descriptorPath}/`)) {
        let target = `${directory(scene.camlPath)}/assets/${basename(source)}`;
        if (files.has(target) && files.get(target) !== asset) target = `${directory(scene.camlPath)}/assets/${uid()}-${basename(source)}`;
        files.set(target, asset); return target;
      }
      return source;
    };
    for (const layer of scene.layers) {
      if (layer.type === 'image' && layer.imagePath) layer.imagePath = relocate(layer.imagePath, layer.name);
      for (const state of stateNames) { const patch = layer.states?.[state]; if (patch?.imagePath) patch.imagePath = relocate(patch.imagePath, layer.name); }
    }
    const { xml, bindings } = serializeScene(scene);
    scene.rootXML = xml;
    for (const layer of scene.layers) layer.binding = bindings.get(layer.id);
    files.set(scene.camlPath, textBytes(xml));
    const indexPath = `${directory(scene.camlPath)}/index.xml`;
    if (files.has(indexPath)) {
      const indexSource = decoder.decode(files.get(indexPath)!);
      const index = parseXML(indexSource.replace(/<!DOCTYPE\s+plist\s+PUBLIC\s+"[^"<>]*"\s+"[^"<>]*"\s*>/gi, ''));
      for (const [key, value] of [['documentWidth', scene.width], ['documentHeight', scene.height]] as const) {
        const node = descendants(index.documentElement, 'key').find(item => item.textContent === key)?.nextElementSibling;
        if (node && ['integer', 'real'].includes(node.localName)) node.textContent = String(value);
      }
      files.set(indexPath, textBytes(serializeXML(index)));
    }
    const ownBundle = `${scene.descriptorPath}/versions/1/contents/TendiesVN.wallpaper`;
    if (scene.camlPath === `${ownBundle}/Background.ca/main.caml`) {
      const identifier = Number(decoder.decode(files.get(`${scene.descriptorPath}/com.apple.posterkit.provider.descriptor.identifier`) ?? new Uint8Array()));
      if (Number.isSafeInteger(identifier) && identifier > 0) files.set(`${ownBundle}/Wallpaper.plist`, generatedWallpaper(project.name, scene.width, scene.height, identifier));
    }
  }
  files.set(MANIFEST, textBytes(JSON.stringify(project)));
  let total = 0;
  for (const [path, bytes] of files) {
    safePath(path); total += bytes.length;
    if (total > MAX_BYTES || files.size > MAX_FILES) fail('Dự án vượt giới hạn xuất 128 MB hoặc quá nhiều tệp.');
    zip.file(path, bytes, { date: new Date('2024-01-01T00:00:00Z'), createFolders: false });
  }
  const data = await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 }, platform: 'UNIX' });
  const name = document.project.name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-').replace(/[. ]+$/g, '').trim().slice(0, 100) || 'TendiesVN';
  return { data, filename: `${name}.tendies` };
}
