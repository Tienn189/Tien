import JSZip from 'jszip';
import type { Layer, LayerMotion, Scene, StudioDocument, StudioProject } from './types';
import { motionAt } from './motion';

const NS = 'http://www.apple.com/CoreAnimation/1.0';
const MANIFEST = 'tendiesvn.project.json';
const MAX_BYTES = 128 * 1024 * 1024;
const MAX_XML = 4 * 1024 * 1024;
const MAX_FILES = 4096;
const MAX_LAYERS = 128;
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const motionPresets = ['none', 'float', 'pulse', 'spin', 'fade', 'bounce'];

function uid() { return globalThis.crypto?.randomUUID?.() ?? `studio-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`; }
function uuid() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID().toUpperCase();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const n = Math.floor(Math.random() * 16); return (c === 'x' ? n : (n & 3) | 8).toString(16);
  }).toUpperCase();
}
function fail(message: string): never { throw new Error(message); }
function finite(value: unknown, fallback: number) { if (value === null || value === undefined || value === '') return fallback; const n = Number(value); return Number.isFinite(n) ? n : fallback; }
function clamp(n: number, low: number, high: number) { return Math.min(high, Math.max(low, n)); }
function numbers(value: string | null) { return (value?.trim().split(/[\s,;]+/) ?? []).map(Number).filter(Number.isFinite); }
function basename(path: string) { return path.split('/').at(-1) ?? path; }
function directory(path: string) { return path.slice(0, Math.max(0, path.lastIndexOf('/'))); }
function children(el: Element) { return Array.from(el.childNodes).filter((n): n is Element => n.nodeType === 1); }
function child(el: Element, name: string) { return children(el).find(n => n.localName === name || n.nodeName === name); }
function descendants(el: Element, name: string) { return Array.from(el.getElementsByTagName('*')).filter(n => n.localName === name || n.nodeName === name); }
function isLayer(el: Element) { return /^(?:CA|LK).*Layer$/.test(el.localName || el.nodeName); }
function allLayers(root: Element) {
  const result: Element[] = [];
  const visit = (node: Element) => {
    result.push(node);
    const sublayers = child(node, 'sublayers');
    if (sublayers) for (const sublayer of children(sublayers)) if (isLayer(sublayer)) visit(sublayer);
  };
  visit(root);
  return result;
}
function textBytes(value: string) { return new Uint8Array(encoder.encode(value)); }

export function safePath(path: string, allowDirectory = false): string {
  if (typeof path !== 'string' || path.length === 0 || path.length > 1024 || /[\\:\u0000-\u001f\u007f]/.test(path) || path.startsWith('/')) fail('Đường dẫn trong gói không an toàn.');
  const value = allowDirectory && path.endsWith('/') ? path.slice(0, -1) : path;
  if (!value || value.split('/').some(part => !part || part === '.' || part === '..')) fail('Gói chứa đường dẫn đi ra ngoài thư mục.');
  return value;
}

function parseXML(xml: string) {
  if (xml.length > MAX_XML || /<!DOCTYPE|<!ENTITY/i.test(xml)) fail('XML quá lớn hoặc chứa khai báo không được hỗ trợ.');
  const doc = new DOMParser().parseFromString(xml, 'application/xml');
  if (!doc.documentElement || doc.getElementsByTagName('parsererror').length) fail('Không đọc được XML của hình nền.');
  return doc;
}
function serializeXML(doc: Document) { return new XMLSerializer().serializeToString(doc); }
function caElement(doc: Document, name: string) { return doc.createElementNS(NS, name); }
function layerRoot(doc: Document) {
  const root = doc.documentElement;
  if (isLayer(root)) return root;
  const layer = Array.from(root.getElementsByTagName('*')).find(isLayer);
  return layer ?? fail('Gói không có lớp Core Animation để chỉnh sửa.');
}
function colorHex(raw: string | null, fallback = '#ffffff') {
  if (!raw) return fallback;
  if (/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(raw)) return raw.toLowerCase();
  const c = numbers(raw);
  if (c.length < 3) return fallback;
  const rgb = c.slice(0, 3).map(n => Math.round(clamp(n, 0, 1) * 255).toString(16).padStart(2, '0')).join('');
  const alpha = c.length > 3 && c[3] < 1 ? Math.round(clamp(c[3], 0, 1) * 255).toString(16).padStart(2, '0') : '';
  return '#' + rgb + alpha;
}
function colorCA(hex: string) {
  const h = /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(hex) ? hex.slice(1) : 'ffffff';
  const values = [0, 2, 4].map(i => (parseInt(h.slice(i, i + 2), 16) / 255).toFixed(6));
  return [...values, h.length === 8 ? (parseInt(h.slice(6), 16) / 255).toFixed(6) : '1'].join(' ');
}
function readColor(element: Element, key: string, fallback: string) { return colorHex(element.getAttribute(key) ?? child(element, key)?.getAttribute('value') ?? null, fallback); }
function writeColor(element: Element, key: string, value: string) {
  let node = child(element, key);
  if (!node) { node = caElement(element.ownerDocument, key); element.appendChild(node); }
  node.setAttribute('type', 'CGColor'); node.setAttribute('value', colorCA(value)); element.removeAttribute(key);
}
function relativeAsset(camlPath: string, asset: string) {
  safePath(asset);
  const from = directory(camlPath).split('/').filter(Boolean), to = asset.split('/');
  while (from.length && to.length && from[0] === to[0]) { from.shift(); to.shift(); }
  return [...from.map(() => '..'), ...to].join('/');
}
function resolveAsset(camlPath: string, source: string): string | undefined {
  if (!source || /^(?:[a-z]+:|\/|\\)/i.test(source) || source.includes('\\')) return undefined;
  const stack = directory(camlPath).split('/').filter(Boolean);
  for (const piece of source.split('/')) {
    if (!piece || piece === '.') continue;
    if (piece === '..') { if (!stack.length) return undefined; stack.pop(); }
    else stack.push(piece);
  }
  try { return safePath(stack.join('/')); } catch { return undefined; }
}

export function makeLayer(type: Layer['type'], scene: Scene): Layer {
  const unit = scene.width / 390;
  const w = type === 'text' ? scene.width * 0.8 : scene.width * 0.55;
  const h = type === 'text' ? 84 * unit : type === 'group' ? scene.height : w;
  return {
    id: uid(), name: type === 'text' ? 'Văn bản' : type === 'image' ? 'Hình ảnh' : type === 'group' ? 'Nhóm' : 'Hình khối',
    type, parentId: null, x: type === 'group' ? 0 : (scene.width - w) / 2, y: type === 'group' ? 0 : (scene.height - h) / 2,
    width: type === 'group' ? scene.width : w, height: h, rotation: 0, opacity: 1, visible: true, locked: type === 'unsupported',
    color: type === 'text' ? '#ffffff' : '#68e0c6', text: type === 'text' ? 'Xin chào' : '', fontSize: 42 * unit,
    fontFamily: 'HelveticaNeue', fontWeight: 'normal', textAlign: 'center', cornerRadius: type === 'shape' ? 28 * unit : 0,
    motion: { preset: 'none', duration: 3, delay: 0, amount: 20 * unit },
  };
}

function parseScene(xml: string, camlPath: string, descriptorPath: string, name: string, warnings: string[]): Scene {
  const document = parseXML(xml), root = layerRoot(document), bounds = numbers(root.getAttribute('bounds'));
  const scene: Scene = {
    id: uid(), name, width: clamp(bounds[2] || 390, 1, 8192), height: clamp(bounds[3] || 844, 1, 8192),
    background: readColor(root, 'backgroundColor', '#121720'), layers: [], camlPath, descriptorPath, rootXML: xml,
  };
  const nodes = allLayers(root);
  const map = new Map<Element, string>();
  const wrapper = root.localName === 'CALayer' && !child(root, 'contents');
  const selected = wrapper ? nodes.slice(1) : nodes;
  if (selected.length > MAX_LAYERS) fail('Mỗi cảnh chỉ hỗ trợ tối đa 128 lớp trong trình sửa.');
  for (const element of selected) map.set(element, uid());
  for (const element of selected) {
    const tag = element.localName || element.nodeName;
    const contents = child(element, 'contents');
    const simple = tag === 'CALayer';
    const type: Layer['type'] = tag === 'CATextLayer' ? 'text' : simple ? contents ? 'image' : child(element, 'sublayers') ? 'group' : 'shape' : 'unsupported';
    const layer = makeLayer(type, scene), b = numbers(element.getAttribute('bounds')), p = numbers(element.getAttribute('position'));
    const anchor = numbers(element.getAttribute('anchorPoint'));
    layer.id = map.get(element)!;
    layer.name = element.getAttribute('name') || element.getAttribute('id') || tag;
    layer.binding = `node:${nodes.indexOf(element)}`;
    layer.width = b[2] || scene.width; layer.height = b[3] || scene.height;
    layer.x = (p[0] ?? layer.width / 2) - layer.width * (anchor[0] ?? 0.5);
    layer.y = (p[1] ?? layer.height / 2) - layer.height * (anchor[1] ?? 0.5);
    layer.opacity = clamp(finite(element.getAttribute('opacity') ?? 1, 1), 0, 1);
    layer.visible = !['1', 'true', 'YES'].includes(element.getAttribute('hidden') ?? '0');
    layer.cornerRadius = finite(element.getAttribute('cornerRadius'), 0);
    layer.color = readColor(element, type === 'text' ? 'foregroundColor' : 'backgroundColor', type === 'group' ? '#000000' : '#ffffff');
    const rotation = element.getAttribute('transform.rotation.z') || element.getAttribute('transform.rotation');
    if (rotation !== null) layer.rotation = finite(rotation, 0) * 180 / Math.PI;
    const transform = child(element, 'transform');
    if (transform && !rotation) warnings.push(`Lớp “${layer.name}” có biến đổi nâng cao: bản xem trước chỉ gần đúng; dữ liệu gốc vẫn được giữ.`);
    if (type === 'text') {
      const textNode = child(element, 'string');
      layer.text = element.getAttribute('string') ?? textNode?.getAttribute('value') ?? textNode?.textContent ?? '';
      layer.fontSize = finite(element.getAttribute('fontSize'), 42);
      layer.fontFamily = child(element, 'font')?.getAttribute('value') || element.getAttribute('font') || element.getAttribute('fontName') || 'HelveticaNeue';
      layer.fontWeight = /bold/i.test(layer.fontFamily) ? 'bold' : 'normal';
      const align = element.getAttribute('alignmentMode');
      layer.textAlign = align === 'left' || align === 'right' ? align : 'center';
    }
    if (contents) {
      const source = contents.getAttribute('src') || contents.getAttribute('source') || descendants(contents, 'CGImage')[0]?.getAttribute('src') || '';
      layer.imagePath = resolveAsset(camlPath, source);
      if (!layer.imagePath) warnings.push(`Không thể xem trước nguồn ảnh của “${layer.name}”; nguồn gốc vẫn được giữ.`);
    }
    let ancestor: Node | null = element.parentNode;
    while (ancestor && ancestor !== root) {
      if (ancestor.nodeType === 1 && map.has(ancestor as Element)) { layer.parentId = map.get(ancestor as Element)!; break; }
      ancestor = ancestor.parentNode;
    }
    const animations = child(element, 'animations');
    if (animations && children(animations).some(a => !a.getAttribute('key')?.startsWith('tendiesvn.'))) warnings.push(`Chuyển động gốc của “${layer.name}” được giữ khi xuất; bản xem trước chưa mô phỏng đầy đủ.`);
    if (type === 'unsupported') warnings.push(`Lớp ${tag} được giữ nguyên; trình sửa chưa hỗ trợ hiển thị hiệu ứng này.`);
    if (child(element, 'filters') || child(element, 'compositingFilter') || child(element, 'mask')) warnings.push(`Hiệu ứng nâng cao của “${layer.name}” được giữ nguyên khi xuất.`);
    scene.layers.push(layer);
  }
  return scene;
}

function checkArchive(data: Uint8Array) {
  if (data.byteLength > MAX_BYTES) fail('Gói vượt quá giới hạn 128 MB của trình sửa.');
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let end = -1;
  for (let p = data.length - 22; p >= Math.max(0, data.length - 65557); p--) {
    if (view.getUint32(p, true) === 0x06054b50 && p + 22 + view.getUint16(p + 20, true) === data.length) { end = p; break; }
  }
  if (end < 0) fail('File không phải gói ZIP/.tendies hợp lệ.');
  const count = view.getUint16(end + 10, true), start = view.getUint32(end + 16, true), length = view.getUint32(end + 12, true);
  if (view.getUint16(end + 4, true) || view.getUint16(end + 6, true) || view.getUint16(end + 8, true) !== count || count === 65535 || count > MAX_FILES || start + length !== end) fail('Không hỗ trợ ZIP nhiều phần, ZIP64 hoặc quá nhiều tệp.');
  const paths = new Set<string>(); let total = 0, cursor = start;
  for (let index = 0; index < count; index++) {
    if (cursor + 46 > end || view.getUint32(cursor, true) !== 0x02014b50) fail('Danh mục ZIP bị hỏng.');
    const flags = view.getUint16(cursor + 8, true), method = view.getUint16(cursor + 10, true), size = view.getUint32(cursor + 24, true);
    const nameLength = view.getUint16(cursor + 28, true), extra = view.getUint16(cursor + 30, true), comment = view.getUint16(cursor + 32, true);
    const attrs = view.getUint32(cursor + 38, true), offset = view.getUint32(cursor + 42, true);
    if (cursor + 46 + nameLength + extra + comment > end) fail('Tên tệp ZIP bị hỏng.');
    const name = decoder.decode(data.subarray(cursor + 46, cursor + 46 + nameLength));
    const clean = safePath(name, true).normalize('NFC').toLocaleLowerCase('en-US');
    if (paths.has(clean)) fail('Gói có đường dẫn trùng nhau.');
    paths.add(clean);
    if ((flags & 1) || ![0, 8].includes(method) || ((attrs >>> 16) & 0xf000) === 0xa000) fail('Không hỗ trợ tệp mã hoá, liên kết tượng trưng hoặc cách nén này.');
    if (offset + 30 > start || view.getUint32(offset, true) !== 0x04034b50) fail('Dữ liệu ZIP bị hỏng.');
    const localFlags = view.getUint16(offset + 6, true), localNameLength = view.getUint16(offset + 26, true), localExtra = view.getUint16(offset + 28, true);
    if ((localFlags & 1) || offset + 30 + localNameLength + localExtra > start || decoder.decode(data.subarray(offset + 30, offset + 30 + localNameLength)) !== name) fail('Đường dẫn ZIP không nhất quán.');
    total += size;
    if (size > 64 * 1024 * 1024 || total > MAX_BYTES) fail('Dữ liệu giải nén vượt giới hạn 128 MB.');
    cursor += 46 + nameLength + extra + comment;
  }
  if (cursor !== end) fail('Danh mục ZIP không nhất quán.');
}

function validateProject(value: unknown): StudioProject {
  const p = value as StudioProject;
  if (!p || p.version !== 1 || typeof p.name !== 'string' || !Array.isArray(p.scenes) || !p.scenes.length || p.scenes.length > 24 || typeof p.activeSceneId !== 'string') fail('Dữ liệu dự án TendiesVN không hợp lệ.');
  const sceneIds = new Set<string>();
  for (const s of p.scenes) {
    if (!s || typeof s.id !== 'string' || sceneIds.has(s.id) || typeof s.name !== 'string' || !Array.isArray(s.layers) || s.layers.length > MAX_LAYERS) fail('Cảnh trong dự án không hợp lệ.');
    sceneIds.add(s.id); safePath(s.camlPath); safePath(s.descriptorPath);
    if (!(s.width > 0 && s.width <= 8192 && s.height > 0 && s.height <= 8192) || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(s.background)) fail('Kích thước hoặc màu cảnh không hợp lệ.');
    if (s.rootXML !== undefined && (typeof s.rootXML !== 'string' || s.rootXML.length > MAX_XML)) fail('XML của dự án không hợp lệ.');
    const ids = new Set<string>();
    for (const l of s.layers) {
      if (!l || typeof l.id !== 'string' || ids.has(l.id) || !['image', 'text', 'shape', 'group', 'unsupported'].includes(l.type) || typeof l.name !== 'string') fail('Lớp trong dự án không hợp lệ.');
      ids.add(l.id);
      for (const key of ['x', 'y', 'width', 'height', 'rotation', 'opacity', 'fontSize', 'cornerRadius'] as const) if (typeof l[key] !== 'number' || !Number.isFinite(l[key]) || Math.abs(l[key]) > 1e6) fail('Thuộc tính lớp không hợp lệ.');
      if (l.width <= 0 || l.height <= 0 || l.opacity < 0 || l.opacity > 1 || typeof l.visible !== 'boolean' || typeof l.locked !== 'boolean' || typeof l.text !== 'string' || l.text.length > 100000 || typeof l.color !== 'string' || !/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(l.color) || typeof l.fontFamily !== 'string' || !['normal', 'bold'].includes(l.fontWeight) || !['left', 'center', 'right'].includes(l.textAlign)) fail('Nội dung lớp không hợp lệ.');
      if (!l.motion || !motionPresets.includes(l.motion.preset) || ![l.motion.duration, l.motion.delay, l.motion.amount].every(Number.isFinite) || l.motion.duration < 0.2 || l.motion.duration > 3600 || l.motion.delay < 0 || l.motion.delay > 3600 || Math.abs(l.motion.amount) > 10000) fail('Chuyển động của lớp không hợp lệ.');
      if (l.parentId !== null && typeof l.parentId !== 'string') fail('Nhóm lớp không hợp lệ.');
      if (l.imagePath) safePath(l.imagePath);
      if (l.binding !== undefined && (typeof l.binding !== 'string' || !/^node:\d+$/.test(l.binding))) fail('Liên kết XML của lớp không hợp lệ.');
    }
    for (const l of s.layers) {
      let parent = l.parentId; const visited = new Set([l.id]);
      while (parent) {
        if (visited.has(parent)) fail('Các nhóm lớp có vòng lặp.');
        visited.add(parent);
        const ancestor = s.layers.find(v => v.id === parent);
        if (!ancestor || !['group', 'unsupported'].includes(ancestor.type)) fail('Không tìm thấy nhóm chứa lớp.');
        parent = ancestor.parentId;
      }
    }
  }
  if (!sceneIds.has(p.activeSceneId)) p.activeSceneId = p.scenes[0].id;
  return p;
}

export async function importPackage(data: Uint8Array, filename: string): Promise<StudioDocument> {
  checkArchive(data);
  const zip = await JSZip.loadAsync(data, { checkCRC32: true, createFolders: false });
  const files = new Map<string, Uint8Array>(); let total = 0;
  for (const file of Object.values(zip.files)) {
    if (file.dir) continue;
    const original = (file as typeof file & { unsafeOriginalName?: string }).unsafeOriginalName;
    if (original && original !== file.name) fail('Gói chứa đường dẫn bị thay đổi khi giải nén.');
    safePath(file.name);
    const bytes = await file.async('uint8array'); total += bytes.length;
    if (total > MAX_BYTES) fail('Gói vượt giới hạn bộ nhớ 128 MB.');
    files.set(file.name, bytes);
  }
  const warnings: string[] = [];
  const camlPaths = [...files.keys()].filter(path => /(?:\.caml$|\/main\.xml$)/i.test(path) && /\.ca\//i.test(path));
  if (files.has(MANIFEST)) {
    const bytes = files.get(MANIFEST)!;
    if (bytes.length > 12 * 1024 * 1024) fail('Dữ liệu dự án quá lớn.');
    const project = validateProject(JSON.parse(decoder.decode(bytes)));
    for (const scene of project.scenes) {
      if (!files.has(scene.camlPath)) fail('Dự án thiếu tệp CAML.');
      const xml = decoder.decode(files.get(scene.camlPath)!);
      parseScene(xml, scene.camlPath, scene.descriptorPath, scene.name, warnings);
      scene.rootXML = xml;
    }
    return { project, files, warnings: [...new Set(warnings)], sourceName: filename };
  }
  const scenes: Scene[] = [];
  for (const path of camlPaths) {
    const match = path.match(/(^|\/)(descriptors\/[^/]+)(?:\/|$)/);
    if (!match) continue;
    const bytes = files.get(path)!;
    if (bytes.length > MAX_XML) fail('Tệp CAML quá lớn để chỉnh sửa.');
    const xml = decoder.decode(bytes);
    if (/<!DOCTYPE|<!ENTITY/i.test(xml)) fail('XML chứa khai báo thực thể không được hỗ trợ.');
    if (!/<(?:[\w-]+:)?(?:CA|LK)[\w]*Layer(?:\s|\/|>)/.test(xml)) continue;
    const name = basename(directory(path)).replace(/\.ca$/i, '') || `Cảnh ${scenes.length + 1}`;
    try {
      scenes.push(parseScene(xml, path, `${path.slice(0, match.index! + match[1].length)}${match[2]}`, name, warnings));
    } catch {
      warnings.push(`Cảnh “${name}” chưa hỗ trợ chỉnh sửa; tệp gốc của cảnh này vẫn được giữ nguyên khi xuất.`);
      continue;
    }
    if (scenes.length > 24) fail('Gói có quá nhiều cảnh để chỉnh sửa.');
  }
  if (!scenes.length) fail('Không tìm thấy cảnh CAML trong gói .tendies. Gói gốc chưa bị thay đổi.');
  const project: StudioProject = { version: 1, name: filename.replace(/\.(?:tendies|zip)$/i, ''), scenes, activeSceneId: scenes[0].id };
  return { project, files, warnings: [...new Set(warnings)], sourceName: filename };
}

export function addImage(doc: StudioDocument, bytes: Uint8Array, mime = 'image/png', filename = 'image.png'): string {
  if (!/^image\/(?:png|jpeg|webp|gif)$/i.test(mime)) fail('Dùng ảnh PNG, JPEG, WebP hoặc GIF.');
  if (bytes.length > 32 * 1024 * 1024) fail('Ảnh lớn hơn 32 MB.');
  const ext = mime === 'image/jpeg' ? 'jpg' : mime.split('/')[1].toLowerCase();
  const stem = filename.replace(/\.[^.]+$/, '').replace(/[^\p{L}\p{N}_-]/gu, '-').slice(0, 48) || 'image';
  const path = `assets/${uid()}-${stem}.${ext}`;
  const total = [...doc.files.values()].reduce((sum, b) => sum + b.length, 0) + bytes.length;
  if (total > MAX_BYTES) fail('Dự án vượt giới hạn 128 MB.');
  doc.files.set(path, bytes.slice()); return path;
}

function freshXML(width: number, height: number, background: string) {
  const doc = new DOMParser().parseFromString(`<caml xmlns="${NS}"><CALayer id="tendiesvn-root" name="TendiesVN" bounds="0 0 ${width} ${height}" position="${width / 2} ${height / 2}" geometryFlipped="1"><backgroundColor type="CGColor" value="${colorCA(background)}"/><sublayers/></CALayer></caml>`, 'application/xml');
  return serializeXML(doc);
}

class PlistUID { constructor(readonly value: number) {} }
type PlistValue = string | number | boolean | Uint8Array | PlistUID | PlistValue[] | { [key: string]: PlistValue };
const U = (index: number) => new PlistUID(index);

/** Small original binary-property-list writer. UID records keep keyed archives valid. */
function binaryPlist(value: PlistValue): Uint8Array {
  type RecordNode = { value: PlistValue; refs?: number[]; count?: number };
  const records: RecordNode[] = [];
  function collect(item: PlistValue): number {
    const index = records.length, record: RecordNode = { value: item }; records.push(record);
    if (Array.isArray(item)) { record.refs = item.map(collect); record.count = item.length; }
    else if (typeof item === 'object' && !(item instanceof Uint8Array) && !(item instanceof PlistUID)) {
      const entries = Object.entries(item); record.refs = [...entries.map(([key]) => collect(key)), ...entries.map(([, val]) => collect(val))]; record.count = entries.length;
    }
    return index;
  }
  const top = collect(value);
  const width = (n: number) => n < 256 ? 1 : n < 65536 ? 2 : n < 4294967296 ? 4 : 8;
  const integer = (n: number, size: number) => {
    let big = BigInt(n); if (big < 0n) big += 1n << BigInt(size * 8);
    return Array.from({ length: size }, (_, i) => Number((big >> BigInt((size - 1 - i) * 8)) & 255n));
  };
  const lengthTag = (tag: number, length: number) => length < 15 ? [tag | length] : [tag | 15, 0x10 | Math.log2(width(length)), ...integer(length, width(length))];
  const refSize = width(records.length - 1), output = [...encoder.encode('bplist00')], offsets: number[] = [];
  for (const record of records) {
    offsets.push(output.length); const v = record.value;
    if (typeof v === 'boolean') output.push(v ? 0x09 : 0x08);
    else if (typeof v === 'number') {
      if (!Number.isFinite(v)) fail('Số trong metadata không hợp lệ.');
      if (Number.isSafeInteger(v)) { const size = v < 0 ? 8 : width(v); output.push(0x10 | Math.log2(size), ...integer(v, size)); }
      else { const bytes = new Uint8Array(8); new DataView(bytes.buffer).setFloat64(0, v, false); output.push(0x23, ...bytes); }
    } else if (typeof v === 'string') {
      if (/^[\x00-\x7f]*$/.test(v)) output.push(...lengthTag(0x50, v.length), ...encoder.encode(v));
      else { output.push(...lengthTag(0x60, v.length)); for (let i = 0; i < v.length; i++) output.push(v.charCodeAt(i) >> 8, v.charCodeAt(i) & 255); }
    } else if (v instanceof Uint8Array) output.push(...lengthTag(0x40, v.length), ...v);
    else if (v instanceof PlistUID) { const size = width(v.value); output.push(0x80 | (size - 1), ...integer(v.value, size)); }
    else { output.push(...lengthTag(Array.isArray(v) ? 0xa0 : 0xd0, record.count!)); for (const ref of record.refs!) output.push(...integer(ref, refSize)); }
  }
  const offsetStart = output.length, offsetSize = width(offsetStart);
  for (const offset of offsets) output.push(...integer(offset, offsetSize));
  output.push(0, 0, 0, 0, 0, 0, offsetSize, refSize, ...integer(records.length, 8), ...integer(top, 8), ...integer(offsetStart, 8));
  return new Uint8Array(output);
}

function archive(objects: PlistValue[]) { return binaryPlist({ $version: 100000, $archiver: 'NSKeyedArchiver', $top: { root: U(1) }, $objects: ['$null', ...objects] }); }
function cls(name: string, parents: string[] = []) { return { $classname: name, $classes: [name, ...parents, 'NSObject'] }; }

function generatedMetadata(files: Map<string, Uint8Array>, path: string, name: string, width: number, height: number, identifier: number) {
  const contents = `${path}/versions/1/contents`, bundle = `${contents}/TendiesVN.wallpaper`;
  const put = (relative: string, value: Uint8Array | string) => files.set(`${path}/${relative}`, typeof value === 'string' ? textBytes(value) : value);
  put('com.apple.posterkit.provider.descriptor.identifier', String(identifier));
  put('com.apple.posterkit.role.identifier', 'PRPosterRoleLockScreen');
  put('providerInfo.plist', archive([{ 'NS.keys': [], 'NS.objects': [], $class: U(2) }, cls('NSMutableDictionary', ['NSDictionary'])]));
  put('versions/1/com.apple.posterkit.provider.instance.complicationLayout.plist', archive([
    { $class: U(4), inlineComplication: U(0), complications: U(2) }, { 'NS.objects': [], $class: U(3) }, cls('NSArray'), cls('PRPosterComplicationLayout'),
  ]));
  put('versions/1/com.apple.posterkit.provider.instance.titleStyleConfiguration.plist', archive([
    { $class: U(7), titleColor: U(0), contentsLuminence: U(5), groupName: U(6), alternateDateEnabled: false, timeNumberingSystem: U(0), timeFontConfiguration: U(2), userConfigured: false },
    { timeFontIdentifier: U(3), $class: U(4) }, 'PRTimeFontIdentifierSoft', cls('PRPosterSystemTimeFontConfiguration', ['PRPosterTimeFontConfiguration']), 0, 'PREditingLook', cls('PRPosterTitleStyleConfiguration'),
  ]));
  put('versions/1/contents/.com.apple.posterkit.provider.contents.configurableOptions.plist', archive([
    { preferredHomeScreenConfiguration: U(4), displayNameLocalizationKey: U(0), $class: U(7), preferredTimeFontConfigurations: U(2), preferredTitleColors: U(2) },
    { 'NS.objects': [], $class: U(3) }, cls('NSArray'),
    { preferredStyle: U(5), preferredSolidColors: U(0), $class: U(6), preferredGradientColors: U(0), allowsModifyingLegibilityBlur: true }, 0,
    cls('PRPosterDescriptorHomeScreenConfiguration'), cls('PRPosterConfigurableOptions'),
  ]));
  put('versions/1/contents/com.apple.posterkit.provider.contents.otherMetadata.plist', archive([{ displayNameLocalizationKey: U(0), $class: U(2) }, cls('PRPosterMetadata')]));
  put('versions/1/contents/com.apple.posterkit.provider.contents.userInfo', binaryPlist({ wallpaperRepresentingIdentifier: String(identifier), wallpaperRepresentingFileName: 'TendiesVN.wallpaper', posterEnvironmentOverrides: textBytes('{}') }));
  put('com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist', archive([
    { $class: U(16), lastModifiedDate: U(14), suggestedGalleryItem: U(2), suggestedComplicationsByIdentifier: U(12) },
    { layoutType: 0, source: 2, extensionBundleIdentifier: U(5), titleFontName: U(7), subtitleComplication: U(0), descriptorIdentifier: U(4), spokenNameLocalizationKey: U(0), complications: U(0), modeUUID: U(0), displayNameLocalizationKey: U(6), descriptiveTextLocalizationKey: U(0), blankTemplate: false, $class: U(11), score: U(10), localizedSubtitle: U(0), identifier: U(3), modeSemanticType: U(0), shouldShowAsShuffleStack: false, titleColor: U(8), localizedDisplayName: U(6) },
    uuid(), `${identifier}.DYNAMIC`, 'com.apple.WallpaperKit.CollectionsPoster', name, '', { r: 0, b: 0, g: 0, a: 0, $class: U(9) }, cls('BSColor'), 20, cls('ATXFaceGalleryItem'), { 'NS.keys': [], 'NS.objects': [], $class: U(13) }, cls('NSDictionary'), { 'NS.time': Date.now() / 1000 - 978307200, $class: U(15) }, cls('NSDate'), cls('PRPosterSuggestionMetadata'),
  ]));
  files.set(`${bundle}/Wallpaper.plist`, generatedWallpaper(name, width, height, identifier));
  for (const layer of ['Background', 'Floating', 'Foreground']) {
    const ca = `${bundle}/${layer}.ca`;
    files.set(`${ca}/assetManifest.caml`, textBytes(`<caml xmlns="${NS}"><MicaAssetManifest><modules type="NSArray"/></MicaAssetManifest></caml>`));
    files.set(`${ca}/index.xml`, textBytes(`<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict><key>rootDocument</key><string>main.caml</string><key>assetManifest</key><string>assetManifest.caml</string><key>documentWidth</key><real>${width}</real><key>documentHeight</key><real>${height}</real><key>documentResizesToView</key><false/><key>geometryFlipped</key><false/><key>scalesToFitInPlayer</key><true/><key>loopingEnabled</key><true/><key>loopStart</key><real>0</real><key>loopEnd</key><real>+infinity</real></dict></plist>`));
    if (layer !== 'Background') files.set(`${ca}/main.caml`, textBytes(freshXML(width, height, '#00000000')));
  }
}

function generatedWallpaper(name: string, width: number, height: number, identifier: number) {
  return binaryPlist({
    assets: { lockAndHome: { default: { foregroundAnimationFileName: 'Foreground.ca', name, backgroundAnimationFileName: 'Background.ca', type: 'LayeredAnimation', identifier, floatingAnimationFileNameKey: 'Floating.ca' } } },
    family: 'TendiesVN', logicalScreenClass: `${width}w-${height}h@3x~iphone`, appearanceAware: false, identifier, version: 1, name,
  });
}

/** A neutral, original descriptor; no vendor artwork or template archive is embedded. */
export function createDocument(name = 'Hình nền mới', width = 390, height = 844): StudioDocument {
  width = clamp(Math.round(finite(width, 390)), 64, 4096); height = clamp(Math.round(finite(height, 844)), 64, 4096);
  const descriptorPath = `descriptors/${uuid()}`;
  const camlPath = `${descriptorPath}/versions/1/contents/TendiesVN.wallpaper/Background.ca/main.caml`;
  const scene: Scene = { id: uid(), name: 'Hình nền', width, height, background: '#121720', layers: [], camlPath, descriptorPath, rootXML: freshXML(width, height, '#121720') };
  const files = new Map<string, Uint8Array>();
  files.set(camlPath, textBytes(scene.rootXML!));
  generatedMetadata(files, descriptorPath, name, width, height, 100000 + Math.floor(Math.random() * 1900000000));
  return { project: { version: 1, name, scenes: [scene], activeSceneId: scene.id }, files, warnings: [], sourceName: `${name}.tendies` };
}

function setMotion(element: Element, motion: LayerMotion, layer: Layer) {
  const doc = element.ownerDocument;
  let animations = child(element, 'animations');
  if (animations) for (const node of children(animations)) if (node.getAttribute('key')?.startsWith('tendiesvn.')) animations.removeChild(node);
  if (motion.preset === 'none') return;
  if (!animations) { animations = caElement(doc, 'animations'); element.appendChild(animations); }
  const node = caElement(doc, 'animation');
  node.setAttribute('type', 'CAKeyframeAnimation'); node.setAttribute('key', `tendiesvn.${motion.preset}`);
  const anchor = numbers(element.getAttribute('anchorPoint'));
  const centerY = layer.y + layer.height * (anchor[1] ?? 0.5);
  const values = motion.preset === 'spin' ? [layer.rotation * Math.PI / 180, (layer.rotation + 360) * Math.PI / 180] : Array.from({ length: 33 }, (_, i) => {
    // Sampling the same analytic curve keeps native and editor previews aligned.
    const m = motionAt({ ...motion, delay: 0 }, (i === 32 ? 0 : i / 32) * motion.duration);
    return ['float', 'bounce'].includes(motion.preset) ? centerY + m.dy : motion.preset === 'pulse' ? m.scale : layer.opacity * m.opacity;
  });
  node.setAttribute('keyPath', ['float', 'bounce'].includes(motion.preset) ? 'position.y' : motion.preset === 'pulse' ? 'transform.scale' : motion.preset === 'spin' ? 'transform.rotation.z' : 'opacity');
  node.setAttribute('duration', String(motion.duration)); node.setAttribute('beginTime', String(motion.delay));
  node.setAttribute('calculationMode', 'linear');
  node.setAttribute('repeatCount', 'inf'); node.setAttribute('removedOnCompletion', '0'); node.setAttribute('fillMode', 'both');
  const vals = caElement(doc, 'values');
  for (const value of values) { const real = caElement(doc, 'real'); real.setAttribute('value', String(value)); vals.appendChild(real); }
  node.appendChild(vals); animations.appendChild(node);
}

function syncLayer(element: Element, layer: Layer, previous: Layer | undefined, scene: Scene) {
  const changed = (key: keyof Layer) => !previous || JSON.stringify(previous[key]) !== JSON.stringify(layer[key]);
  if (layer.type === 'unsupported') {
    if (changed('visible')) element.setAttribute('hidden', layer.visible ? '0' : '1');
    if (changed('opacity')) element.setAttribute('opacity', String(layer.opacity));
    return;
  }
  if (changed('name')) element.setAttribute('name', layer.name);
  if (!previous) element.setAttribute('id', layer.id);
  if (changed('width') || changed('height')) {
    const original = numbers(element.getAttribute('bounds'));
    element.setAttribute('bounds', `${original[0] || 0} ${original[1] || 0} ${layer.width} ${layer.height}`);
  }
  if (changed('x') || changed('y') || changed('width') || changed('height')) {
    const anchor = numbers(element.getAttribute('anchorPoint'));
    element.setAttribute('position', `${layer.x + layer.width * (anchor[0] ?? 0.5)} ${layer.y + layer.height * (anchor[1] ?? 0.5)}`);
  }
  if (changed('rotation')) element.setAttribute('transform.rotation.z', String(layer.rotation * Math.PI / 180));
  if (changed('opacity')) element.setAttribute('opacity', String(layer.opacity));
  if (changed('visible')) element.setAttribute('hidden', layer.visible ? '0' : '1');
  if (changed('cornerRadius')) {
    element.setAttribute('cornerRadius', String(layer.cornerRadius));
    if (layer.type === 'image') element.setAttribute('masksToBounds', layer.cornerRadius > 0 ? '1' : '0');
  }
  if (layer.type === 'shape' && changed('color')) writeColor(element, 'backgroundColor', layer.color);
  if (layer.type === 'text') {
    if (changed('text')) {
      const oldString = child(element, 'string');
      if (oldString) element.removeChild(oldString);
      element.removeAttribute('string');
      const string = caElement(element.ownerDocument, 'string');
      string.setAttribute('type', 'string'); string.setAttribute('value', layer.text); element.appendChild(string);
    }
    if (changed('color')) writeColor(element, 'foregroundColor', layer.color);
    if (changed('fontSize')) element.setAttribute('fontSize', String(layer.fontSize));
    if (changed('fontFamily') || changed('fontWeight')) {
      let font = layer.fontFamily || 'HelveticaNeue';
      const standardFonts: Record<string, [string, string]> = {
        '-apple-system': ['HelveticaNeue', 'HelveticaNeue-Bold'],
        'Helvetica Neue': ['HelveticaNeue', 'HelveticaNeue-Bold'],
        'HelveticaNeue': ['HelveticaNeue', 'HelveticaNeue-Bold'],
        'Arial': ['ArialMT', 'Arial-BoldMT'], 'ArialMT': ['ArialMT', 'Arial-BoldMT'],
        'Georgia': ['Georgia', 'Georgia-Bold'],
        'Times New Roman': ['TimesNewRomanPSMT', 'TimesNewRomanPS-BoldMT'],
        'Courier New': ['CourierNewPSMT', 'CourierNewPS-BoldMT']
      };
      if (standardFonts[font]) font = standardFonts[font][layer.fontWeight === 'bold' ? 1 : 0];
      else if (layer.fontWeight === 'bold' && !/bold/i.test(font)) font += '-Bold';
      else if (layer.fontWeight === 'normal' && previous?.fontWeight === 'bold' && !changed('fontFamily')) font = font.replace(/[- ]?(?:Semi|Demi)?Bold$/i, '') || 'HelveticaNeue';
      let node = child(element, 'font');
      if (!node) { node = caElement(element.ownerDocument, 'font'); element.appendChild(node); }
      node.setAttribute('type', 'string'); node.setAttribute('value', font); element.removeAttribute('font');
    }
    if (changed('textAlign')) element.setAttribute('alignmentMode', layer.textAlign);
    if (!previous) { element.setAttribute('wrapped', '1'); element.setAttribute('contentsScale', '3'); }
  }
  if (layer.type === 'image' && layer.imagePath && changed('imagePath')) {
    let contents = child(element, 'contents');
    if (!contents) { contents = caElement(element.ownerDocument, 'contents'); element.appendChild(contents); }
    const source = relativeAsset(scene.camlPath, layer.imagePath);
    const nestedImage = descendants(contents, 'CGImage')[0];
    if (nestedImage) {
      nestedImage.setAttribute('src', source);
      contents.removeAttribute('src'); contents.removeAttribute('source');
    } else { contents.setAttribute('type', 'CGImage'); contents.setAttribute('src', source); }
    if (!previous) element.setAttribute('contentsGravity', 'resizeAspectFill');
  }
  if (changed('motion')) setMotion(element, layer.motion, layer);
}

function serializeScene(scene: Scene): { xml: string; bindings: Map<string, string> } {
  const xml = scene.rootXML ?? freshXML(scene.width, scene.height, scene.background);
  const doc = parseXML(xml), root = layerRoot(doc);
  const baseline = parseScene(xml, scene.camlPath, scene.descriptorPath, scene.name, []);
  const nodes = allLayers(root), byBinding = new Map(nodes.map((el, index) => [`node:${index}`, el]));
  const previous = new Map(baseline.layers.map(l => [l.binding!, l]));
  const existing = new Map<string, Element>();
  const usedBindings = new Set<string>();
  for (const layer of scene.layers) {
    if (layer.binding && usedBindings.has(layer.binding)) fail('Hai lớp đang trỏ tới cùng một nút XML.');
    if (layer.binding) usedBindings.add(layer.binding);
    const element = layer.binding ? byBinding.get(layer.binding) : undefined;
    if (layer.binding && !element) fail('Liên kết lớp gốc không còn hợp lệ.');
    const target = element ?? caElement(doc, layer.type === 'text' ? 'CATextLayer' : 'CALayer');
    syncLayer(target, layer, layer.binding ? previous.get(layer.binding) : undefined, scene);
    existing.set(layer.id, target);
  }
  for (const layer of baseline.layers) {
    if (layer.binding && !usedBindings.has(layer.binding)) {
      const node = byBinding.get(layer.binding);
      if (node && node !== root) node.parentNode?.removeChild(node);
    }
  }
  // Moving only the layer nodes retains filters, state definitions and unknown XML.
  for (const layer of scene.layers) {
    const element = existing.get(layer.id)!;
    if (element === root) continue;
    const parent = layer.parentId ? existing.get(layer.parentId)! : root;
    let sublayers = child(parent, 'sublayers');
    if (!sublayers) { sublayers = caElement(doc, 'sublayers'); parent.appendChild(sublayers); }
    sublayers.appendChild(element);
  }
  const oldBounds = numbers(root.getAttribute('bounds'));
  if (scene.width !== baseline.width || scene.height !== baseline.height) {
    root.setAttribute('bounds', `${oldBounds[0] || 0} ${oldBounds[1] || 0} ${scene.width} ${scene.height}`);
    const position = numbers(root.getAttribute('position')), anchor = numbers(root.getAttribute('anchorPoint'));
    root.setAttribute('position', `${(position[0] ?? baseline.width / 2) + (scene.width - baseline.width) * (anchor[0] ?? .5)} ${(position[1] ?? baseline.height / 2) + (scene.height - baseline.height) * (anchor[1] ?? .5)}`);
  }
  if (scene.background !== baseline.background) writeColor(root, 'backgroundColor', scene.background);
  const after = allLayers(root), bindings = new Map<string, string>();
  for (const [id, element] of existing) bindings.set(id, `node:${after.indexOf(element)}`);
  return { xml: serializeXML(doc), bindings };
}

export async function exportPackage(document: StudioDocument): Promise<{ data: Uint8Array; filename: string }> {
  validateProject(document.project);
  const zip = new JSZip(), files = new Map(document.files);
  const project = JSON.parse(JSON.stringify(document.project)) as StudioProject;
  for (const scene of project.scenes) {
    for (const layer of scene.layers) if (layer.type === 'image' && layer.imagePath) {
      const asset = files.get(layer.imagePath);
      if (!asset) fail(`Thiếu ảnh của lớp “${layer.name}”.`);
      // Native installation copies each descriptor tree, not the ZIP root.
      if (!layer.imagePath.startsWith(`${scene.descriptorPath}/`)) {
        let target = `${directory(scene.camlPath)}/assets/${basename(layer.imagePath)}`;
        if (files.has(target) && files.get(target) !== asset) target = `${directory(scene.camlPath)}/assets/${uid()}-${basename(layer.imagePath)}`;
        files.set(target, asset); layer.imagePath = target;
      }
    }
    const { xml, bindings } = serializeScene(scene);
    scene.rootXML = xml;
    for (const layer of scene.layers) layer.binding = bindings.get(layer.id);
    files.set(scene.camlPath, textBytes(xml));
    const indexPath = `${directory(scene.camlPath)}/index.xml`;
    if (files.has(indexPath)) {
      const indexSource = decoder.decode(files.get(indexPath)!);
      const index = parseXML(indexSource.replace(/<!DOCTYPE\s+plist\s+PUBLIC\s+"[^"<>]*"\s+"[^"<>]*"\s*>/gi, ''));
      for (const [key, value] of [['documentWidth', scene.width], ['documentHeight', scene.height]] as const) {
        const node = descendants(index.documentElement, 'key').find(item => item.textContent === key)?.nextElementSibling;
        if (node && ['integer', 'real'].includes(node.localName)) node.textContent = String(value);
      }
      files.set(indexPath, textBytes(serializeXML(index)));
    }
    const ownBundle = `${scene.descriptorPath}/versions/1/contents/TendiesVN.wallpaper`;
    if (scene.camlPath === `${ownBundle}/Background.ca/main.caml`) {
      const identifier = Number(decoder.decode(files.get(`${scene.descriptorPath}/com.apple.posterkit.provider.descriptor.identifier`) ?? new Uint8Array()));
      if (Number.isSafeInteger(identifier) && identifier > 0) files.set(`${ownBundle}/Wallpaper.plist`, generatedWallpaper(project.name, scene.width, scene.height, identifier));
    }
  }
  files.set(MANIFEST, textBytes(JSON.stringify(project)));
  let total = 0;
  for (const [path, bytes] of files) {
    safePath(path); total += bytes.length;
    if (total > MAX_BYTES || files.size > MAX_FILES) fail('Dự án vượt giới hạn xuất 128 MB hoặc quá nhiều tệp.');
    zip.file(path, bytes, { date: new Date('2024-01-01T00:00:00Z'), createFolders: false });
  }
  const data = await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 }, platform: 'UNIX' });
  const name = document.project.name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-').replace(/[. ]+$/g, '').trim().slice(0, 100) || 'TendiesVN';
  return { data, filename: `${name}.tendies` };
}
