import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as ReactPointerEvent, ReactNode } from 'react';
import type { AnimationValue, Layer, LayerAnimation, LayerProperties, Scene, StudioDocument, TransitionTiming, WallpaperState } from './types';
import { createDocument, exportPackage, importPackage, makeLayer } from './package';
import { motionAt } from './motion';
import { clearLayerState, easeProgress, interpolateLayer, patchLayerState, resolveLayer, sceneRole, wallpaperStates } from './states';
import { nativeExport, postEditorState, registerNativeEditor, requestNativeOpen } from './native';
import Inspector from './Inspector';
import './styles.css';
type IconName = 'sparkles' | 'arrow' | 'add' | 'image' | 'text' | 'shape' | 'layers' | 'sliders' | 'motion' | 'play' | 'pause' | 'undo' | 'redo' | 'more' | 'close' | 'download' | 'folder' | 'new' | 'chevron' | 'up' | 'down' | 'copy' | 'trash' | 'eye' | 'hidden' | 'lock' | 'unlock' | 'check' | 'warning' | 'group' | 'fit' | 'settings' | 'minus' | 'hand' | 'cursor';
const paths: Record<IconName, ReactNode> = {
  minus: <path d="M5 12h14"/>, hand: <><path d="M8 12V5a2 2 0 0 1 4 0v7M12 10V4a2 2 0 0 1 4 0v8M16 10V7a2 2 0 0 1 4 0v9a6 6 0 0 1-6 6h-1a7 7 0 0 1-5-2l-5-6a2 2 0 0 1 3-3l2 2"/></>, cursor: <path d="m4 3 6 18 3-7 7-3L4 3Z"/>,
  sparkles: <><path d="m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6L12 3Z"/><path d="m20 2 .6 1.4L22 4l-1.4.6L20 6l-.6-1.4L18 4l1.4-.6L20 2Z"/></>,
  arrow: <path d="m9 5 7 7-7 7"/>, add: <path d="M12 5v14M5 12h14"/>,
  image: <><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/></>,
  text: <><path d="M5 5h14M12 5v15M8 20h8M5 8V5M19 8V5"/></>,
  shape: <><rect x="3" y="3" width="12" height="12" rx="3"/><circle cx="16" cy="16" r="5"/></>,
  layers: <><path d="m12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5"/></>,
  sliders: <><path d="M5 3v5m0 4v9M12 3v10m0 4v4M19 3v2m0 4v12"/><path d="M2 8h6m1 5h6m1-8h6"/></>,
  motion: <><path d="M3 12c3-10 6 10 9 0s6 10 9 0M3 5h4M17 19h4"/></>,
  play: <path d="m9 5 11 7-11 7V5Z"/>, pause: <><path d="M8 5v14M16 5v14"/></>,
  undo: <><path d="m8 4-5 5 5 5"/><path d="M3 9h11a6 6 0 0 1 0 12h-3"/></>,
  redo: <><path d="m16 4 5 5-5 5"/><path d="M21 9H10a6 6 0 0 0 0 12h3"/></>,
  more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  close: <path d="m6 6 12 12M6 18 18 6"/>,
  download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/></>,
  folder: <path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>,
  new: <><path d="M14 3H5v18h14V8l-5-5ZM14 3v5h5M8 14h8M12 10v8"/></>,
  chevron: <path d="m6 9 6 6 6-6"/>, up: <path d="m5 15 7-7 7 7"/>, down: <path d="m5 9 7 7 7-7"/>,
  copy: <><rect x="8" y="8" width="13" height="13" rx="3"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></>,
  trash: <><path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/></>,
  eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></>,
  hidden: <><path d="m3 3 18 18M9 5.4c5-1.5 10 3 13 6.6-1 1.7-2.2 3.1-3.6 4.2M5.5 6.2C3.4 8.3 2 12 2 12s4 7 10 7c1.3 0 2.5-.3 3.7-.8M10 10a3 3 0 0 0 4 4"/></>,
  lock: <><rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
  unlock: <><rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 7.5-2M12 14v3"/></>,
  check: <path d="m5 12 4 4L19 6"/>, warning: <><path d="m12 3 10 18H2L12 3ZM12 9v5"/><circle cx="12" cy="17" r=".6"/></>,
  group: <><path d="M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5"/><rect x="7" y="7" width="10" height="10" rx="2"/></>,
  fit: <><path d="M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5"/><path d="M8 8h8v8H8z"/></>,
  settings: <><path d="m10 3-.5 3-2 1-3-.5L2 10l2.5 2.5-.5 3L7 18l3-.5 2 1 .5 3h4l.5-3 2-1 3 .5 2.5-3.5L21 12l.5-3L19 6l-3 .5-2-1-.5-2.5Z"/><circle cx="12" cy="12" r="3"/></>,
};
function Icon({ name, size = 20, className = '' }: { name: IconName; size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">{paths[name]}</svg>;
}
function IconButton({ icon, label, onClick, disabled = false, active = false, className = '' }: { icon: IconName; label: string; onClick: () => void; disabled?: boolean; active?: boolean; className?: string }) {
  return <button type="button" className={`icon-button ${active ? 'is-active' : ''} ${className}`} aria-label={label} title={label} onClick={onClick} disabled={disabled}><Icon name={icon}/></button>;
}

const MAX_LAYERS = 128;
const MAX_IMAGE_BYTES = 16 * 1024 * 1024;
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const uid = () => globalThis.crypto?.randomUUID?.() ?? `layer-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const copyDocument = (doc: StudioDocument): StudioDocument => ({ ...doc, project: JSON.parse(JSON.stringify(doc.project)) });
const iconFor: Record<Layer['type'], IconName> = { text: 'text', image: 'image', shape: 'shape', gradient: 'image', group: 'group', unsupported: 'layers' };
const stateNames: Record<WallpaperState, string> = { Base: 'Gốc', Locked: 'Đang khóa', Unlock: 'Mở khóa', Sleep: 'Ngủ' };
const roleLabel = (scene: Scene) => sceneRole(scene) === 'Other' ? scene.name : sceneRole(scene);
const descendants = (layers: Layer[], id: string) => { const ids = new Set([id]); for (let i = 0; i < layers.length; i++) for (const layer of layers) if (layer.parentId && ids.has(layer.parentId)) ids.add(layer.id); return ids; };
const snapshot = (doc: StudioDocument, state: WallpaperState): Map<string, Layer> => new Map<string, Layer>(doc.project.scenes.flatMap(scene => scene.layers.map(layer => [`${scene.id}:${layer.id}`, resolveLayer(layer, state)] as const)));
function flatten(layers: Layer[], parent: string | null = null, depth = 0, seen = new Set<string>()): { layer: Layer; depth: number }[] {
  const rows: { layer: Layer; depth: number }[] = [];
  for (const layer of layers.filter(item => item.parentId === parent).slice().reverse()) { if (seen.has(layer.id)) continue; seen.add(layer.id); rows.push({ layer, depth }); rows.push(...flatten(layers, layer.id, Math.min(depth + 1, 6), seen)); }
  if (parent === null) for (const layer of layers) if (!seen.has(layer.id)) rows.push({ layer, depth: 0 });
  return rows;
}
function useAssetURLs(files: Map<string, Uint8Array>) {
  const urls = useMemo(() => {
    const result = new Map<string, string>();
    for (const [path, data] of files) { const type = ({ png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', avif: 'image/avif', heic: 'image/heic', svg: 'image/svg+xml' } as Record<string, string>)[path.split('.').pop()?.toLowerCase() ?? '']; if (type) result.set(path, URL.createObjectURL(new Blob([new Uint8Array(data)], { type }))); }
    return result;
  }, [files]);
  useEffect(() => () => { for (const url of urls.values()) URL.revokeObjectURL(url); }, [urls]);
  return urls;
}
function NumberField({ label, value, onChange, min = 0, max = 10000, step = 1 }: { label: string; value: number; onChange: (value: number) => void; min?: number; max?: number; step?: number }) {
  const [draft, setDraft] = useState(String(value)); const focused = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(String(Math.round(value * 100) / 100)); }, [value]);
  return <label className="compact-number"><span>{label}</span><input type="number" inputMode={step < 1 ? 'decimal' : 'numeric'} value={draft} min={min} max={max} step={step} onFocus={() => { focused.current = true; }} onChange={event => setDraft(event.target.value)} onBlur={() => { focused.current = false; const n = Number(draft); if (draft.trim() && Number.isFinite(n)) { const next = clamp(n, min, max); setDraft(String(next)); if (next !== value) onChange(next); } else setDraft(String(value)); }} onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}/></label>;
}
function animationLayer(layer: Layer, time: number) {
  let current = { ...layer };
  for (const animation of layer.animations ?? []) {
    if (!animation.enabled || time < animation.delay) continue;
    const duration = Math.max(.01, animation.duration), elapsed = time - animation.delay;
    const cycle = animation.autoreverses ? duration * 2 : duration;
    const local = animation.repeat ? elapsed % cycle : Math.min(elapsed, cycle);
    const phase = animation.autoreverses && local > duration ? 2 - local / duration : Math.min(1, local / duration);
    const apply = (target: Layer, value: AnimationValue): Layer => {
      const numbers = Array.isArray(value) ? value : [];
      switch (animation.property) {
        case 'position': return { ...target, x: numbers[0] ?? target.x, y: numbers[1] ?? target.y };
        case 'position.x': return { ...target, x: typeof value === 'number' ? value : target.x };
        case 'position.y': return { ...target, y: typeof value === 'number' ? value : target.y };
        case 'transform.rotation.x': return { ...target, rotationX: typeof value === 'number' ? value : target.rotationX };
        case 'transform.rotation.y': return { ...target, rotationY: typeof value === 'number' ? value : target.rotationY };
        case 'transform.rotation.z': return { ...target, rotation: typeof value === 'number' ? value : target.rotation };
        case 'transform.scale': return { ...target, scale: typeof value === 'number' ? value : target.scale };
        case 'opacity': return { ...target, opacity: typeof value === 'number' ? value : target.opacity };
        case 'bounds': return { ...target, width: numbers.length >= 4 ? numbers[2] : numbers[0] ?? target.width, height: numbers.length >= 4 ? numbers[3] : numbers[1] ?? target.height };
        case 'backgroundColor': return typeof value === 'string' ? { ...target, backgroundColor: value, ...(target.type === 'shape' ? { color: value } : {}) } : target;
      }
    };
    current = interpolateLayer(apply(current, animation.from), apply(current, animation.to), phase);
  }
  return current;
}
function filterCSS(layer: Layer) { return (layer.filters ?? []).filter(filter => filter.enabled).map(filter => ({ gaussianBlur: `blur(${filter.amount}px)`, contrast: `contrast(${filter.amount})`, hueRotate: `hue-rotate(${filter.amount}deg)`, invert: `invert(${filter.amount})`, saturate: `saturate(${filter.amount})`, sepia: `sepia(${filter.amount})` })[filter.type]).join(' ') || undefined; }

export default function App() {
  const [document, setDocument] = useState<StudioDocument>(() => createDocument('Hình nền mới', 1170, 2532));
  const documentRef = useRef(document);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [state, setState] = useState<WallpaperState>('Base'); const stateRef = useRef<WallpaperState>('Base');
  const [visuals, setVisuals] = useState(() => snapshot(document, 'Base')); const visualsRef = useRef(visuals);
  const transitionRef = useRef<{ frame: number; started: number } | null>(null);
  const playbackTimer = useRef<number | null>(null);
  const [transitioning, setTransitioning] = useState(false);
  const [panels, setPanels] = useState(false); const [panelTab, setPanelTab] = useState<'layers' | 'inspector'>('layers');
  const [menu, setMenu] = useState<'ca' | 'add' | 'states' | 'project' | null>(null);
  const [settings, setSettings] = useState(false); const [confirmNew, setConfirmNew] = useState(false);
  const [showBackground, setShowBackground] = useState(true);
  const [tool, setTool] = useState<'select' | 'pan'>('select');
  const [viewTools, setViewTools] = useState(false);
  const [zoom, setZoom] = useState(1); const [pan, setPan] = useState({ x: 0, y: 0 });
  const [viewport, setViewport] = useState({ width: 390, height: 680 });
  const viewportRef = useRef<HTMLDivElement>(null);
  const [animationPlaying, setAnimationPlaying] = useState(false); const [animationTime, setAnimationTime] = useState(0);
  const [dirty, setDirtyState] = useState(false); const dirtyRef = useRef(false);
  const setDirty = useCallback((value: boolean) => { dirtyRef.current = value; setDirtyState(value); }, []);
  const [busy, setBusy] = useState<string | null>(null); const busyRef = useRef(false);
  const [notice, setNotice] = useState<{ text: string; error: boolean } | null>(null); const [warningOpen, setWarningOpen] = useState(false);
  const history = useRef<{ past: StudioDocument[]; future: StudioDocument[] }>({ past: [], future: [] });
  const [historyCount, setHistoryCount] = useState({ past: 0, future: 0 });
  const imageInput = useRef<HTMLInputElement>(null); const packageInput = useRef<HTMLInputElement>(null); const replaceImageId = useRef<string | null>(null);
  const drag = useRef<{ kind: 'pan' | 'move' | 'resize'; id?: string; pointer: number; clientX: number; clientY: number; x: number; y: number; width: number; height: number; angle: number; rotation: number; factor: number; before: StudioDocument; moved: boolean } | null>(null);
  const scene = document.project.scenes.find(item => item.id === document.project.activeSceneId) ?? document.project.scenes[0];
  const rawSelected = scene?.layers.find(layer => layer.id === selectedId) ?? null;
  const selected = rawSelected ? resolveLayer(rawSelected, state) : null;
  const urls = useAssetURLs(document.files);
  const fitScale = Math.max(.005, Math.min(viewport.width / (scene?.width ?? 1170), viewport.height / (scene?.height ?? 2532)));
  const scale = fitScale * zoom;
  const isNative = !!window.webkit?.messageHandlers?.tendiesStudio;
  const notify = useCallback((text: string, error = false) => setNotice({ text, error }), []);
  const stopTransition = useCallback(() => { if (transitionRef.current) cancelAnimationFrame(transitionRef.current.frame); transitionRef.current = null; setTransitioning(false); if (playbackTimer.current) clearTimeout(playbackTimer.current); playbackTimer.current = null; }, []);
  const setSnapshot = useCallback((next: Map<string, Layer>) => { visualsRef.current = next; setVisuals(next); }, []);
  const saveDocument = useCallback((next: StudioDocument, checkpoint = true, markDirty = true) => {
    if (checkpoint) { history.current.past.push(documentRef.current); if (history.current.past.length > 50) history.current.past.shift(); history.current.future = []; setHistoryCount({ past: history.current.past.length, future: 0 }); }
    documentRef.current = next; setDocument(next); if (markDirty) setDirty(true);
  }, []);
  const editScene = useCallback((update: (active: Scene, next: StudioDocument) => void, checkpoint = true) => {
    stopTransition(); setAnimationPlaying(false);
    const next = copyDocument(documentRef.current); const active = next.project.scenes.find(item => item.id === next.project.activeSceneId) ?? next.project.scenes[0];
    if (!active) return; update(active, next); saveDocument(next, checkpoint);
  }, [saveDocument, stopTransition]);
  const patchSelected = useCallback((patch: Partial<LayerProperties>, id = selectedId, checkpoint = true) => { if (!id) return; editScene(active => { const i = active.layers.findIndex(layer => layer.id === id); if (i >= 0) active.layers[i] = patchLayerState(active.layers[i], stateRef.current, patch); }, checkpoint); }, [editScene, selectedId]);
  const patchBase = useCallback((patch: Partial<Layer>, id = selectedId) => { if (!id) return; editScene(active => { const i = active.layers.findIndex(layer => layer.id === id); if (i >= 0) active.layers[i] = { ...active.layers[i], ...patch }; }); }, [editScene, selectedId]);
  useEffect(() => { if (!transitionRef.current) setSnapshot(snapshot(document, state)); }, [document, state, setSnapshot]);
  const chooseState = useCallback((nextState: WallpaperState, animate = true) => {
    stopTransition(); setAnimationPlaying(false); setMenu(null);
    const from = new Map(visualsRef.current), target = snapshot(documentRef.current, nextState);
    stateRef.current = nextState; setState(nextState);
    const active = documentRef.current.project.scenes.find(item => item.id === documentRef.current.project.activeSceneId) ?? documentRef.current.project.scenes[0];
    const seconds = active?.transition?.duration ?? .8, timing = active?.transition?.timing ?? 'easeInOut';
    if (!animate || seconds <= 0) { setSnapshot(target); return; }
    const started = performance.now(); setTransitioning(true);
    const tick = (now: number) => {
      const progress = Math.min(1, (now - started) / (seconds * 1000)); const eased = easeProgress(progress, timing);
      setSnapshot(new Map([...target].map(([key, to]) => [key, interpolateLayer(from.get(key) ?? to, to, eased)])));
      if (progress < 1) transitionRef.current = { frame: requestAnimationFrame(tick), started };
      else { transitionRef.current = null; setTransitioning(false); }
    };
    transitionRef.current = { frame: requestAnimationFrame(tick), started };
  }, [setSnapshot, stopTransition]);
  const playUnlock = () => { setPanels(false); chooseState('Locked', false); playbackTimer.current = window.setTimeout(() => { playbackTimer.current = null; chooseState('Unlock', true); }, 300); };
  const replaceDocument = useCallback((next: StudioDocument) => { stopTransition(); documentRef.current = next; setDocument(next); history.current = { past: [], future: [] }; setHistoryCount({ past: 0, future: 0 }); setSelectedId(null); stateRef.current = 'Base'; setState('Base'); setSnapshot(snapshot(next, 'Base')); setDirty(false); setPanels(false); setMenu(null); setPan({ x: 0, y: 0 }); setZoom(1); setAnimationPlaying(false); setAnimationTime(0); }, [setSnapshot, stopTransition]);
  const openPackage = useCallback(async (data: Uint8Array, name: string) => { if (busyRef.current) throw new Error('Một thao tác khác đang chạy.'); busyRef.current = true; setBusy('Đang mở hình nền…'); try { const next = await importPackage(data, name); replaceDocument(next); notify('Đã mở hình nền.'); } catch (error) { notify(error instanceof Error ? error.message : 'Không mở được file này.', true); throw error; } finally { busyRef.current = false; setBusy(null); } }, [replaceDocument, notify]);
  const exportCurrent = useCallback(async () => { if (busyRef.current) return; busyRef.current = true; (globalThis.document.activeElement as HTMLElement | null)?.blur(); await new Promise<void>(resolve => requestAnimationFrame(() => resolve())); setBusy('Đang xuất .tendies…'); try { const result = await exportPackage(documentRef.current); await nativeExport(result.data, result.filename); setDirty(false); notify('Đã xuất hình nền .tendies.'); } catch (error) { notify(error instanceof Error ? error.message : 'Không xuất được hình nền.', true); } finally { busyRef.current = false; setBusy(null); } }, [notify]);
  const startNew = useCallback(() => { if (busyRef.current) return; replaceDocument(createDocument('Hình nền mới', 1170, 2532)); setConfirmNew(false); setSettings(true); }, [replaceDocument]);
  const openPicker = async () => { setMenu(null); try { if (!(await requestNativeOpen())) packageInput.current?.click(); } catch { notify('Không mở được Tệp. Hãy thử lại.', true); } };
  useEffect(() => registerNativeEditor({ openPackage, requestExport: exportCurrent, startNew, isDirty: () => dirtyRef.current }), [openPackage, exportCurrent, startNew]);
  useEffect(() => { postEditorState({ dirty, title: document.project.name, busy: busy !== null }); }, [dirty, document.project.name, busy]);
  useEffect(() => { const node = viewportRef.current; if (!node || panels) return; const observer = new ResizeObserver(([entry]) => setViewport({ width: entry.contentRect.width, height: entry.contentRect.height })); observer.observe(node); return () => observer.disconnect(); }, [panels]);
  useEffect(() => { if (!notice) return; const id = window.setTimeout(() => setNotice(null), notice.error ? 10000 : 4000); return () => clearTimeout(id); }, [notice]);
  useEffect(() => () => { if (transitionRef.current) cancelAnimationFrame(transitionRef.current.frame); if (playbackTimer.current) clearTimeout(playbackTimer.current); }, []);
  useEffect(() => { if (!animationPlaying) return; let frame = 0, last = performance.now(), elapsed = 0; const tick = (now: number) => { elapsed += Math.min((now - last) / 1000, .1); last = now; setAnimationTime(elapsed); frame = requestAnimationFrame(tick); }; frame = requestAnimationFrame(tick); return () => cancelAnimationFrame(frame); }, [animationPlaying]);
  const undo = useCallback(() => { const previous = history.current.past.pop(); if (!previous) return; stopTransition(); history.current.future.push(documentRef.current); documentRef.current = previous; setDocument(previous); setDirty(true); setHistoryCount({ past: history.current.past.length, future: history.current.future.length }); }, [stopTransition]);
  const redo = useCallback(() => { const next = history.current.future.pop(); if (!next) return; stopTransition(); history.current.past.push(documentRef.current); documentRef.current = next; setDocument(next); setDirty(true); setHistoryCount({ past: history.current.past.length, future: history.current.future.length }); }, [stopTransition]);
  const deleteLayer = useCallback(() => { if (!rawSelected || rawSelected.locked || rawSelected.isRoot) return; editScene(active => { const ids = descendants(active.layers, rawSelected.id); active.layers = active.layers.filter(layer => !ids.has(layer.id)); }); setSelectedId(null); }, [rawSelected, editScene]);
  const duplicateLayer = () => { if (!rawSelected || !scene || rawSelected.isRoot) return; const ids = descendants(scene.layers, rawSelected.id); if (scene.layers.some(layer => ids.has(layer.id) && layer.type === 'unsupported')) { notify('Không thể nhân đôi lớp chưa được hỗ trợ. Lớp gốc vẫn được giữ.', true); return; } if (scene.layers.length + ids.size > MAX_LAYERS) { notify('Mỗi CA có tối đa 128 lớp.', true); return; } const names = new Map([...ids].map(id => [id, uid()])); const copies = scene.layers.filter(layer => ids.has(layer.id)).map(layer => ({ ...JSON.parse(JSON.stringify(layer)), id: names.get(layer.id), parentId: layer.parentId && names.has(layer.parentId) ? names.get(layer.parentId) : layer.parentId, name: layer.id === rawSelected.id ? `${layer.name} bản sao` : layer.name, x: layer.x + (layer.id === rawSelected.id ? 20 : 0), y: layer.y + (layer.id === rawSelected.id ? 20 : 0), binding: undefined })) as Layer[]; editScene(active => active.layers.push(...copies)); setSelectedId(names.get(rawSelected.id)!); if (rawSelected.binding) notify('Đã nhân đôi phần chỉnh sửa được. Hiệu ứng nâng cao vẫn ở lớp gốc.'); };
  const reorder = (direction: -1 | 1) => { if (!rawSelected || rawSelected.isRoot) return; editScene(active => { const index = active.layers.findIndex(layer => layer.id === rawSelected.id), siblings = active.layers.map((layer, i) => ({ layer, i })).filter(({ layer }) => layer.parentId === rawSelected.parentId), order = siblings.findIndex(({ layer }) => layer.id === rawSelected.id), target = siblings[order + direction]; if (target) [active.layers[index], active.layers[target.i]] = [active.layers[target.i], active.layers[index]]; }); };
  const addLayer = (type: 'text' | 'shape' | 'gradient' | 'group') => { if (!scene) return; if (scene.layers.length >= MAX_LAYERS) { notify('Mỗi CA có tối đa 128 lớp.', true); return; } const layer = makeLayer(type, scene); const root = scene.layers.find(item => item.isRoot); if (root) layer.parentId = root.id; if (rawSelected?.type === 'group' && !rawSelected.locked) { layer.parentId = rawSelected.id; layer.x = Math.max(0, (selected!.width - layer.width) / 2); layer.y = Math.max(0, (selected!.height - layer.height) / 2); } editScene(active => active.layers.push(layer)); setSelectedId(layer.id); setMenu(null); setPanels(false); setTool('select'); };
  const addImage = async (file: File) => {
    if (!scene || busyRef.current) return;
    const replacing = scene.layers.find(layer => layer.id === replaceImageId.current && layer.type === 'image' && !layer.locked); replaceImageId.current = null;
    if (!replacing && scene.layers.length >= MAX_LAYERS) { notify('Mỗi CA có tối đa 128 lớp.', true); return; }
    if (file.size > MAX_IMAGE_BYTES || !file.type.startsWith('image/')) { notify('Chọn file ảnh nhỏ hơn 16 MB.', true); return; }
    busyRef.current = true; setBusy('Đang thêm ảnh…'); let url = '';
    try {
      url = URL.createObjectURL(file); const image = await new Promise<HTMLImageElement>((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = () => reject(new Error('Không đọc được ảnh. Hãy dùng PNG hoặc JPEG.')); img.src = url; });
      const width = image.naturalWidth, height = image.naturalHeight; if (!width || !height) throw new Error('Ảnh không có kích thước hợp lệ.');
      const raster = globalThis.document.createElement('canvas'), factor = Math.min(1, 4096 / Math.max(width, height), Math.sqrt(8_000_000 / (width * height)));
      raster.width = Math.max(1, Math.round(width * factor)); raster.height = Math.max(1, Math.round(height * factor)); const context = raster.getContext('2d'); if (!context) throw new Error('Hãy thử ảnh nhỏ hơn.'); context.drawImage(image, 0, 0, raster.width, raster.height);
      let encoded = await new Promise<Blob | null>(resolve => raster.toBlob(resolve, 'image/png'));
      for (let n = 0; encoded && encoded.size > MAX_IMAGE_BYTES && n < 4; n++) { const small = globalThis.document.createElement('canvas'); small.width = Math.max(1, Math.round(raster.width * .75)); small.height = Math.max(1, Math.round(raster.height * .75)); const smaller = small.getContext('2d'); if (!smaller) throw new Error('Hãy thử ảnh nhỏ hơn.'); smaller.drawImage(raster, 0, 0, small.width, small.height); raster.width = small.width; raster.height = small.height; context.drawImage(small, 0, 0); encoded = await new Promise<Blob | null>(resolve => raster.toBlob(resolve, 'image/png')); }
      if (!encoded || encoded.size > MAX_IMAGE_BYTES) throw new Error('Ảnh quá lớn. Hãy chọn ảnh nhỏ hơn.');
      const bytes = new Uint8Array(await encoded.arrayBuffer()); raster.width = 1; raster.height = 1; const path = `assets/${uid()}.png`;
      const layer = replacing ? patchLayerState(replacing, stateRef.current, { imagePath: path }) : makeLayer('image', scene);
      if (!replacing) { const ratio = Math.min(scene.width * .85 / width, scene.height * .65 / height, 1); layer.width = Math.max(1, Math.round(width * ratio)); layer.height = Math.max(1, Math.round(height * ratio)); layer.x = Math.round((scene.width - layer.width) / 2); layer.y = Math.round((scene.height - layer.height) / 2); layer.name = file.name.replace(/\.[^.]+$/, '') || 'Ảnh'; layer.imagePath = path; const root = scene.layers.find(item => item.isRoot); if (root) layer.parentId = root.id; }
      editScene((active, next) => { next.files = new Map(next.files); next.files.set(path, bytes); if (replacing) { const i = active.layers.findIndex(item => item.id === replacing.id); if (i >= 0) active.layers[i] = layer; } else active.layers.push(layer); }); setSelectedId(layer.id); setPanels(false); setMenu(null);
    } catch (error) { notify(error instanceof Error ? error.message : 'Không thêm được ảnh.', true); } finally { if (url) URL.revokeObjectURL(url); busyRef.current = false; setBusy(null); }
  };
  const changeCA = (id: string) => { stopTransition(); const next = copyDocument(documentRef.current); next.project.activeSceneId = id; saveDocument(next, false, false); setSelectedId(null); setMenu(null); setZoom(1); setPan({ x: 0, y: 0 }); };
  const beginPointer = (event: ReactPointerEvent, layer?: Layer, kind?: 'resize') => {
    if (event.button !== 0 || busy) return; event.stopPropagation(); stopTransition(); setAnimationPlaying(false);
    if (tool === 'pan' || !layer) { if (tool !== 'pan') { setSelectedId(null); return; } event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); drag.current = { kind: 'pan', pointer: event.pointerId, clientX: event.clientX, clientY: event.clientY, x: pan.x, y: pan.y, width: 0, height: 0, angle: 0, rotation: 0, factor: scale, before: documentRef.current, moved: false }; return; }
    setSelectedId(layer.id); if (layer.locked || layer.type === 'unsupported') return;
    event.preventDefault(); event.currentTarget.setPointerCapture(event.pointerId); let parentId = layer.parentId, parentAngle = 0, factor = scale; const seen = new Set<string>();
    while (parentId && !seen.has(parentId)) { seen.add(parentId); const raw = scene.layers.find(item => item.id === parentId); if (!raw) break; const parent = resolveLayer(raw, stateRef.current); parentAngle += parent.rotation; factor *= parent.scale ?? 1; parentId = parent.parentId; }
    drag.current = { kind: kind ?? 'move', id: layer.id, pointer: event.pointerId, clientX: event.clientX, clientY: event.clientY, x: layer.x, y: layer.y, width: layer.width, height: layer.height, angle: (parentAngle + (kind === 'resize' ? layer.rotation : 0)) * Math.PI / 180, rotation: layer.rotation * Math.PI / 180, factor: Math.max(.001, factor * (kind === 'resize' ? layer.scale ?? 1 : 1)), before: documentRef.current, moved: false };
  };
  const movePointer = (event: ReactPointerEvent) => { const d = drag.current; if (!d || d.pointer !== event.pointerId) return; event.stopPropagation(); const sx = event.clientX - d.clientX, sy = event.clientY - d.clientY; if (Math.abs(sx) + Math.abs(sy) < 2 && !d.moved) return; d.moved = true; if (d.kind === 'pan') { setPan({ x: d.x + sx, y: d.y + sy }); return; } const dx = (sx * Math.cos(d.angle) + sy * Math.sin(d.angle)) / d.factor, dy = (-sx * Math.sin(d.angle) + sy * Math.cos(d.angle)) / d.factor; if (d.kind === 'move') patchSelected({ x: Math.round(d.x + dx), y: Math.round(d.y + dy) }, d.id, false); else { const width = Math.max(1, Math.round(d.width + dx)), height = Math.max(1, Math.round(d.height + dy)), dw = (width - d.width) / 2, dh = (height - d.height) / 2; patchSelected({ width, height, x: d.x + (Math.cos(d.rotation) - 1) * dw - Math.sin(d.rotation) * dh, y: d.y + Math.sin(d.rotation) * dw + (Math.cos(d.rotation) - 1) * dh }, d.id, false); } };
  const endPointer = (event: ReactPointerEvent) => { const d = drag.current; if (!d || d.pointer !== event.pointerId) return; if (d.moved && d.kind !== 'pan') { history.current.past.push(d.before); if (history.current.past.length > 50) history.current.past.shift(); history.current.future = []; setHistoryCount({ past: history.current.past.length, future: 0 }); } drag.current = null; };
  useEffect(() => { const listener = (event: KeyboardEvent) => { if (busyRef.current) return; if ((event.target as HTMLElement).closest('input,textarea,select,[contenteditable]')) return; if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? redo() : undo(); } if (event.key === 'Delete' || event.key === 'Backspace') { event.preventDefault(); deleteLayer(); } if (event.key === 'Escape') { setMenu(null); setSettings(false); } if (selected && !selected.locked && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) { event.preventDefault(); const n = event.shiftKey ? 10 : 1; patchSelected({ x: selected.x + (event.key === 'ArrowLeft' ? -n : event.key === 'ArrowRight' ? n : 0), y: selected.y + (event.key === 'ArrowUp' ? -n : event.key === 'ArrowDown' ? n : 0) }); } }; window.addEventListener('keydown', listener); return () => window.removeEventListener('keydown', listener); }, [selected, patchSelected, deleteLayer, undo, redo]);
  const renderLayer = (raw: Layer, owner: Scene, selectable: boolean, parents = new Set<string>()): ReactNode => {
    let layer = visuals.get(`${owner.id}:${raw.id}`) ?? resolveLayer(raw, state); if (!layer.visible || parents.has(layer.id)) return null; const visited = new Set(parents).add(layer.id);
    if (animationPlaying) layer = animationLayer(layer, animationTime); const motion = motionAt(layer.motion, animationPlaying ? animationTime : 0), chosen = selectable && layer.id === selectedId;
    const style = { left: layer.x, top: layer.y, width: Math.max(1, layer.width), height: Math.max(1, layer.height), zIndex: Math.round(layer.z ?? 0), transform: `translate3d(${motion.dx}px,${motion.dy}px,${layer.z ?? 0}px) rotateX(${layer.rotationX ?? 0}deg) rotateY(${layer.rotationY ?? 0}deg) rotateZ(${layer.rotation + motion.rotation}deg) scale(${(layer.scale ?? 1) * motion.scale})`, transformOrigin: `${(layer.anchorX ?? .5) * 100}% ${(layer.anchorY ?? .5) * 100}%`, mixBlendMode: layer.blendMode as CSSProperties['mixBlendMode'], '--canvas-scale': scale, pointerEvents: selectable ? 'auto' : 'none' } as CSSProperties;
    const gradientID = `g-${owner.id}-${layer.id}`.replace(/[^a-zA-Z0-9_-]/g, '');
    return <div key={layer.id} data-layer-id={layer.id} data-layer-name={layer.name} className={`canvas-layer ${chosen ? 'selected' : ''}`} style={style} onPointerDown={event => selectable && beginPointer(event, layer)} onPointerMove={movePointer} onPointerUp={endPointer} onPointerCancel={endPointer}>
      <div className="layer-visual" style={{ opacity: clamp(layer.opacity * motion.opacity, 0, 1), borderRadius: layer.cornerRadius, overflow: layer.clipContents ? 'hidden' : 'visible', filter: filterCSS(layer) }}>
        {layer.type !== 'shape' && <div className="layer-background" style={{ background: layer.backgroundColor, opacity: layer.backgroundOpacity, borderRadius: layer.cornerRadius }}/>}
        {layer.type === 'image' && (layer.imagePath && urls.has(layer.imagePath) ? <img src={urls.get(layer.imagePath)} alt={layer.name} draggable={false} style={{ borderRadius: layer.cornerRadius }}/> : <div className="unsupported-preview"><Icon name="image" size={50}/></div>)}
        {layer.type === 'text' && <div className="canvas-text" style={{ color: layer.color, fontSize: layer.fontSize, fontFamily: `${layer.fontFamily}, -apple-system, BlinkMacSystemFont, sans-serif`, fontWeight: layer.fontWeight === 'bold' ? 700 : 400, textAlign: layer.textAlign }}>{layer.text}</div>}
        {layer.type === 'shape' && <div className="shape-fill" style={{ background: layer.color, opacity: layer.backgroundOpacity, borderRadius: layer.cornerRadius }}/>} 
        {layer.type === 'gradient' && <svg width="100%" height="100%" className="gradient-fill"><defs><linearGradient id={gradientID} x1={layer.gradientStart?.[0] ?? .5} y1={layer.gradientStart?.[1] ?? 0} x2={layer.gradientEnd?.[0] ?? .5} y2={layer.gradientEnd?.[1] ?? 1}>{(layer.gradientColors ?? ['#68e0c6', '#5165df']).map((color, i, colors) => <stop key={i} offset={colors.length === 1 ? 0 : i / (colors.length - 1)} stopColor={color}/>)}</linearGradient></defs><rect width="100%" height="100%" rx={layer.cornerRadius} fill={`url(#${gradientID})`}/></svg>}
        {layer.type === 'unsupported' && <div className="unsupported-preview"><Icon name="layers" size={50}/><span>{layer.name}</span></div>}
        {owner.layers.filter(item => item.parentId === layer.id).map(item => renderLayer(item, owner, selectable, visited))}{(layer.borderWidth ?? 0) > 0 && <div className="layer-border" style={{ border: `${layer.borderWidth}px solid ${layer.borderColor}`, borderRadius: layer.cornerRadius }}/>}
      </div>
      {chosen && <div className="selection-outline"><span className="selection-label">{layer.name}</span>{!layer.locked && layer.type !== 'unsupported' && <button type="button" aria-label="Đổi kích thước lớp" className="resize-handle" onPointerDown={event => beginPointer(event, layer, 'resize')} onPointerMove={movePointer} onPointerUp={endPointer} onPointerCancel={endPointer}/>}</div>}
    </div>;
  };
  const backgroundScene = scene && sceneRole(scene) !== 'Background' && showBackground ? document.project.scenes.find(item => sceneRole(item) === 'Background' && item.descriptorPath === scene.descriptorPath) ?? document.project.scenes.find(item => sceneRole(item) === 'Background') : undefined;
  const renderScene = (owner: Scene, editable: boolean) => <div className={`ca-scene ${editable ? 'active-ca' : 'composite-ca'}`} key={owner.id} data-ca={roleLabel(owner)} style={{ background: owner.layers.some(item => item.isRoot) ? 'transparent' : owner.background, width: owner.width, height: owner.height, pointerEvents: editable ? 'auto' : 'none' }}>{owner.layers.filter(layer => !layer.parentId || !owner.layers.some(item => item.id === layer.parentId)).map(layer => renderLayer(layer, owner, editable))}</div>;
  const transition = scene?.transition ?? { duration: .8, timing: 'easeInOut' as TransitionTiming };
  const rootLayer = scene?.layers.find(layer => layer.isRoot);
  const sceneFill = rootLayer ? resolveLayer(rootLayer, state).backgroundColor ?? scene.background : scene?.background ?? '#00000000';
  const toggleMenu = (next: typeof menu) => setMenu(current => current === next ? null : next);

  return <div className="studio-basic">
    <header className="editor-header"><div className="header-actions"><IconButton icon="undo" label="Hoàn tác" onClick={undo} disabled={!historyCount.past || !!busy}/><IconButton icon="redo" label="Làm lại" onClick={redo} disabled={!historyCount.future || !!busy}/></div><button type="button" className="header-title" aria-label="Tùy chọn dự án" onClick={() => toggleMenu('project')}><strong>{document.project.name || 'Hình nền mới'}</strong><span>{dirty ? 'Đã chỉnh sửa' : 'Tendies Studio'}<Icon name="chevron" size={11}/></span></button>{!isNative && <button type="button" className="browser-export" onClick={() => void exportCurrent()} disabled={!!busy}><Icon name="download" size={17}/><span>Xuất</span></button>}</header>
    {document.warnings.length > 0 && <button type="button" className="warning-strip" onClick={() => setWarningOpen(true)}><Icon name="warning" size={13}/><span>{document.warnings.length} lưu ý về hiệu ứng gốc</span><Icon name="arrow" size={12}/></button>}
    {!panels ? <main className={`canvas-workspace ${tool === 'pan' ? 'pan-tool' : ''}`} ref={viewportRef} onPointerDown={event => beginPointer(event)} onPointerMove={movePointer} onPointerUp={endPointer} onPointerCancel={endPointer} onWheel={event => { if (event.ctrlKey || event.metaKey) setZoom(value => clamp(value * (event.deltaY < 0 ? 1.1 : .9), .2, 8)); }}>
      <div className="canvas-status"><span>{scene ? roleLabel(scene) : ''}</span><i/><span className="state-badge">{state}</span>{transitioning && <small>Đang chuyển…</small>}</div>
      {scene && <div className="canvas-position" style={{ transform: `translate(${pan.x}px,${pan.y}px)`, width: scene.width * scale, height: scene.height * scale }}><div className="canvas-sheet" style={{ width: scene.width, height: scene.height, transform: `scale(${scale})`, '--canvas-scale': scale } as CSSProperties}>{backgroundScene && renderScene(backgroundScene, false)}{renderScene(scene, true)}</div></div>}
      <div className={`canvas-tools ${viewTools ? 'expanded' : ''}`} onPointerDown={event => event.stopPropagation()}>
        <button type="button" className="view-tools-toggle" aria-label="Công cụ khung nhìn" aria-expanded={viewTools} onClick={() => setViewTools(value => !value)}><Icon name={viewTools ? 'close' : tool === 'pan' ? 'hand' : 'fit'} size={18}/></button>
        {viewTools && <><div className="tool-pair"><IconButton icon="cursor" label="Chọn lớp" active={tool === 'select'} onClick={() => setTool('select')}/><IconButton icon="hand" label="Di chuyển khung nhìn" active={tool === 'pan'} onClick={() => setTool('pan')}/></div><div className="zoom-tools"><IconButton icon="add" label="Phóng to" onClick={() => setZoom(value => clamp(value * 1.25, .2, 8))}/><span>{Math.round(zoom * 100)}%</span><IconButton icon="minus" label="Thu nhỏ" onClick={() => setZoom(value => clamp(value / 1.25, .2, 8))}/><IconButton icon="fit" label="Vừa màn hình" onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}/></div><IconButton icon={animationPlaying ? 'pause' : 'play'} label={animationPlaying ? 'Dừng xem hiệu ứng' : 'Xem hiệu ứng'} active={animationPlaying} onClick={() => { stopTransition(); setAnimationTime(0); setAnimationPlaying(value => !value); }}/></>}
      </div>
      {selected && <div className="canvas-bottom-note" onPointerDown={event => event.stopPropagation()}><button type="button" onClick={() => { setPanels(true); setPanelTab('inspector'); }}><Icon name={iconFor[selected.type]} size={14}/><span>{selected.name}</span><span className="state-badge">{state}</span><Icon name="sliders" size={14}/></button></div>}
    </main> : <main className="panels-workspace"><nav className="panel-tabs"><button type="button" aria-label="Layers và States" className={panelTab === 'layers' ? 'selected' : ''} onClick={() => setPanelTab('layers')}><Icon name="layers" size={15}/>Layers & States</button><button type="button" aria-label="Inspector" className={panelTab === 'inspector' ? 'selected' : ''} onClick={() => setPanelTab('inspector')}><Icon name="sliders" size={15}/>Inspector</button></nav><div className="panels-scroll">{panelTab === 'layers' ? <>
      <section className="layers-section"><div className="section-title"><h2>Layers <small>{scene ? roleLabel(scene) : ''}</small></h2><span>{scene?.layers.length ?? 0}</span></div>{!scene?.layers.length ? <div className="plain-empty"><Icon name="layers" size={24}/><p>Chưa có lớp nào.</p><button type="button" onClick={() => toggleMenu('add')}>Thêm lớp</button></div> : <div className="layers-list">{flatten(scene.layers).map(({ layer, depth }) => { const resolved = resolveLayer(layer, state); return <div key={layer.id} className={`layer-row ${selectedId === layer.id ? 'selected' : ''} ${!resolved.visible ? 'layer-hidden' : ''}`} style={{ '--depth': depth } as CSSProperties}><button type="button" className="select-layer" onClick={() => setSelectedId(layer.id)} onDoubleClick={() => { setSelectedId(layer.id); setPanelTab('inspector'); }}><Icon name={iconFor[layer.type]} size={17}/><span>{layer.name}{state !== 'Base' && layer.states?.[state] && <i title="Có giá trị riêng ở trạng thái này"/>}</span></button><IconButton icon={resolved.visible ? 'eye' : 'hidden'} label={resolved.visible ? `Ẩn ${layer.name}` : `Hiện ${layer.name}`} onClick={() => patchSelected({ visible: !resolved.visible }, layer.id)}/><IconButton icon={layer.locked ? 'lock' : 'unlock'} label={layer.locked ? `Mở khóa ${layer.name}` : `Khóa ${layer.name}`} onClick={() => patchBase({ locked: !layer.locked }, layer.id)}/><button className="layer-inspect" type="button" aria-label={`Chỉnh sửa ${layer.name}`} onClick={() => { setSelectedId(layer.id); setPanelTab('inspector'); }}><Icon name="arrow" size={14}/></button></div>; })}</div>}{selected && <div className="layer-order"><button type="button" disabled={selected.isRoot} onClick={() => reorder(1)}><Icon name="up" size={16}/>Lên trước</button><button type="button" disabled={selected.isRoot} onClick={() => reorder(-1)}><Icon name="down" size={16}/>Ra sau</button><button type="button" disabled={selected.isRoot} onClick={duplicateLayer}><Icon name="copy" size={15}/>Nhân đôi</button><button type="button" className="danger" onClick={deleteLayer} disabled={selected.locked || selected.isRoot}><Icon name="trash" size={15}/>Xóa</button></div>}</section>
      <section className="states-section"><div className="section-title"><h2>States</h2><span className="state-badge">{state}</span></div><div className="states-options">{wallpaperStates.map(item => <button type="button" key={item} aria-label={`${item} State`} className={state === item ? 'selected' : ''} onClick={() => chooseState(item)}><strong>{item}</strong><small>{stateNames[item]}</small></button>)}</div><div className="transition-fields"><NumberField label="Thời gian (giây)" value={transition.duration} min={0} max={10} step={.1} onChange={duration => editScene(active => { active.transition = { ...transition, duration }; })}/><label className="compact-select"><span>Đường cong</span><select value={transition.timing} onChange={event => editScene(active => { active.transition = { ...transition, timing: event.target.value as TransitionTiming }; })}><option value="linear">Linear</option><option value="easeIn">Ease in</option><option value="easeOut">Ease out</option><option value="easeInOut">Ease in out</option></select></label></div><button type="button" className="play-unlock" onClick={playUnlock}><Icon name="play" size={16}/>Xem Locked → Unlock</button>{rawSelected && state !== 'Base' && <button type="button" className="reset-state" disabled={!rawSelected.states?.[state]} onClick={() => editScene(active => { const index = active.layers.findIndex(layer => layer.id === rawSelected.id); if (index >= 0) active.layers[index] = clearLayerState(active.layers[index], state); })}>Khôi phục {selected?.name} về Base ở {state}</button>}<p className="state-note">Đang sửa <strong>{state}</strong>. {state === 'Base' ? 'Đây là giá trị mặc định của lớp.' : 'Chỉ giá trị của trạng thái này thay đổi.'}</p></section>
    </> : <Inspector layer={selected} state={state} onPatch={patch => { if (!selected?.locked) patchSelected(patch); }} onRename={name => patchBase({ name })} onFilters={filters => patchBase({ filters })} onAnimations={(animations: LayerAnimation[]) => patchBase({ animations })} onReplaceImage={() => { replaceImageId.current = selectedId; imageInput.current?.click(); }} onDelete={deleteLayer} onDuplicate={duplicateLayer}/>}</div></main>}
    <footer className="editor-footer"><button type="button" aria-label={panels ? 'Hiện Canvas' : 'Mở Panels'} className={panels ? 'selected' : ''} onClick={() => { setPanels(value => !value); setMenu(null); }}><Icon name={panels ? 'close' : 'layers'} size={20}/><span>{panels ? 'Canvas' : 'Lớp'}</span></button><button type="button" aria-label="Chọn CA Background hoặc Floating" className={menu === 'ca' ? 'selected' : ''} onClick={() => toggleMenu('ca')}><span className="ca-mini">CA</span><span>{scene ? roleLabel(scene) : 'Chọn CA'}<Icon name="chevron" size={10}/></span></button><button type="button" className={menu === 'add' ? 'selected add-layer-button' : 'add-layer-button'} onClick={() => toggleMenu('add')} disabled={!!busy}><Icon name="add" size={23}/><span>Thêm</span></button><button type="button" aria-label={`Chọn State: ${state}`} className={menu === 'states' ? 'selected' : ''} onClick={() => toggleMenu('states')}><Icon name="motion" size={20}/><span>States <small>{state}</small></span></button></footer>
    {menu && <><button type="button" className="menu-scrim" aria-label="Đóng menu" onClick={() => setMenu(null)}/><section className={`bottom-menu menu-${menu}`}><div className="menu-title"><strong>{menu === 'ca' ? 'Chọn CA' : menu === 'add' ? 'Add layer' : menu === 'states' ? 'States' : 'Dự án'}</strong><IconButton icon="close" label="Đóng menu" onClick={() => setMenu(null)}/></div>{menu === 'ca' && <><div className="menu-list">{document.project.scenes.map(item => <button type="button" key={item.id} onClick={() => changeCA(item.id)}><span className="ca-symbol">CA</span><span>{roleLabel(item)}{document.project.scenes.filter(s => sceneRole(s) === sceneRole(item)).length > 1 && <small>{item.name}</small>}</span>{item.id === scene?.id && <Icon name="check" size={17}/>}</button>)}</div><label className="background-toggle"><span><Icon name="layers" size={17}/>Show background<small>Hiện CA Background phía sau Floating</small></span><input type="checkbox" checked={showBackground} onChange={event => setShowBackground(event.target.checked)}/><i/></label></>}{menu === 'add' && <div className="add-options">{([{ type: 'text', title: 'Text', detail: 'Văn bản', icon: 'text' }, { type: 'shape', title: 'Basic layer', detail: 'Hình khối', icon: 'shape' }, { type: 'image', title: 'Image', detail: 'Ảnh của bạn', icon: 'image' }, { type: 'gradient', title: 'Gradient', detail: 'Chuyển sắc', icon: 'image' }, { type: 'group', title: 'Group', detail: 'Nhóm lớp', icon: 'group' }] as const).map(item => <button type="button" key={item.type} onClick={() => { if (item.type === 'image') { replaceImageId.current = null; imageInput.current?.click(); setMenu(null); } else addLayer(item.type); }}><Icon name={item.icon} size={20}/><span>{item.title}<small>{item.detail}</small></span><Icon name="add" size={15}/></button>)}</div>}{menu === 'states' && <><div className="menu-list">{wallpaperStates.map(item => <button type="button" key={item} aria-label={`${item} State`} onClick={() => chooseState(item)}><span className="state-dot"/><span>{item}<small>{stateNames[item]}</small></span>{state === item && <Icon name="check" size={17}/>}</button>)}</div><button type="button" className="menu-play" onClick={playUnlock}><Icon name="play" size={16}/>Xem Locked → Unlock</button><button type="button" className="menu-settings" onClick={() => { setMenu(null); setPanels(true); setPanelTab('layers'); }}>Chỉnh thời gian chuyển trạng thái<Icon name="arrow" size={13}/></button></>}{menu === 'project' && <div className="menu-list"><button type="button" onClick={() => { setMenu(null); setSettings(true); }}><Icon name="sliders" size={18}/><span>Tên và kích thước</span></button>{!isNative && <button type="button" onClick={() => void openPicker()}><Icon name="folder" size={18}/><span>Mở .tendies</span></button>}<button type="button" onClick={() => { setMenu(null); if (dirty) setConfirmNew(true); else startNew(); }}><Icon name="new" size={18}/><span>Tạo hình nền mới</span></button></div>}</section></>}
    <input ref={imageInput} type="file" accept="image/*" className="visually-hidden" aria-label="Chọn ảnh" onChange={event => { const file = event.target.files?.[0]; if (file) void addImage(file); event.target.value = ''; }}/><input ref={packageInput} type="file" accept=".tendies,.zip,application/zip,application/octet-stream" className="visually-hidden" aria-label="Mở .tendies" onChange={event => { const file = event.target.files?.[0]; if (file) { if (file.size > 128 * 1024 * 1024) notify('Giới hạn của Studio là 128 MB.', true); else void file.arrayBuffer().then(buffer => openPackage(new Uint8Array(buffer), file.name)).catch(() => notify('Không đọc được file.', true)); } event.target.value = ''; }}/>
    {busy && <div className="busy-overlay" role="status"><span className="spinner"/><p>{busy}</p></div>}
    {notice && <div className={`editor-toast ${notice.error ? 'error' : ''}`} role={notice.error ? 'alert' : 'status'}><Icon name={notice.error ? 'warning' : 'check'} size={17}/><span>{notice.text}</span><IconButton icon="close" label="Đóng thông báo" onClick={() => setNotice(null)}/></div>}
    {warningOpen && <div className="dialog-scrim"><section className="editor-dialog"><div className="dialog-title"><h2>Lưu ý về gói đã mở</h2><IconButton icon="close" label="Đóng lưu ý" onClick={() => setWarningOpen(false)}/></div><div className="warnings-list">{document.warnings.map((warning, index) => <p key={index}>{warning}</p>)}</div><p className="muted">Thành phần chưa hỗ trợ được giữ nguyên khi xuất.</p></section></div>}
    {confirmNew && <div className="dialog-scrim"><section className="editor-dialog"><h2>Tạo hình nền mới?</h2><p>Xuất file để giữ lại thay đổi của dự án đang mở.</p><button type="button" className="dialog-primary" onClick={() => { setConfirmNew(false); void exportCurrent(); }}>Xuất dự án hiện tại</button><button type="button" className="dialog-secondary" onClick={startNew}>Tạo mới và bỏ thay đổi</button><button type="button" className="dialog-quiet" onClick={() => setConfirmNew(false)}>Tiếp tục chỉnh sửa</button></section></div>}
    {settings && <div className="dialog-scrim"><section className="editor-dialog"><div className="dialog-title"><h2>Dự án</h2><IconButton icon="close" label="Đóng cài đặt" onClick={() => setSettings(false)}/></div><label className="project-field"><span>Tên dự án</span><input value={document.project.name} maxLength={80} onChange={event => { const next = copyDocument(documentRef.current); next.project.name = event.target.value; saveDocument(next); }}/></label><label className="project-field"><span>Tên CA</span><input value={scene?.name ?? ''} maxLength={80} onChange={event => editScene(active => { active.name = event.target.value; })}/></label><div className="transition-fields"><NumberField label="Rộng (px)" value={scene?.width ?? 1170} min={128} max={8192} onChange={width => editScene((active, next) => { for (const item of next.project.scenes.filter(item => item.descriptorPath === active.descriptorPath)) { item.width = Math.round(width); const root = item.layers.find(layer => layer.isRoot); if (root) root.width = item.width; } })}/><NumberField label="Cao (px)" value={scene?.height ?? 2532} min={128} max={8192} onChange={height => editScene((active, next) => { for (const item of next.project.scenes.filter(item => item.descriptorPath === active.descriptorPath)) { item.height = Math.round(height); const root = item.layers.find(layer => layer.isRoot); if (root) root.height = item.height; } })}/></div><label className="project-color"><span>Màu nền CA</span><input type="color" value={/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(sceneFill) ? sceneFill.slice(0, 7) : '#000000'} onChange={event => editScene(active => { const root = active.layers.find(layer => layer.isRoot); if (root) { const i = active.layers.indexOf(root); active.layers[i] = patchLayerState(root, stateRef.current, { backgroundColor: event.target.value }); } if (stateRef.current === 'Base') active.background = event.target.value; })}/></label><p className="muted">Giá trị vị trí và kích thước lớp được giữ khi đổi khung.</p><button type="button" className="dialog-primary" onClick={() => setSettings(false)}>Xong</button></section></div>}
  </div>;
}
