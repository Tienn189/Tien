import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, PointerEvent as ReactPointerEvent, ReactNode } from 'react';
import type { Layer, Scene, StudioDocument } from './types';
import { createDocument, exportPackage, importPackage, makeLayer } from './package';
import { motionAt } from './motion';
import { nativeExport, postEditorState, registerNativeEditor, requestNativeOpen } from './native';
import './styles.css';

type IconName = 'sparkles' | 'arrow' | 'add' | 'image' | 'text' | 'shape' | 'layers' | 'sliders' | 'motion' | 'play' | 'pause' | 'undo' | 'redo' | 'more' | 'close' | 'download' | 'folder' | 'new' | 'chevron' | 'up' | 'down' | 'copy' | 'trash' | 'eye' | 'hidden' | 'lock' | 'unlock' | 'check' | 'warning' | 'group' | 'fit' | 'settings';
const paths: Record<IconName, ReactNode> = {
  sparkles: <><path d="m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6L12 3Z"/><path d="m20 2 .6 1.4L22 4l-1.4.6L20 6l-.6-1.4L18 4l1.4-.6L20 2Z"/></>,
  arrow: <path d="m9 5 7 7-7 7"/>, add: <path d="M12 5v14M5 12h14"/>,
  image: <><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/></>,
  text: <><path d="M5 5h14M12 5v15M8 20h8M5 8V5M19 8V5"/></>,
  shape: <><rect x="3" y="3" width="12" height="12" rx="3"/><circle cx="16" cy="16" r="5"/></>,
  layers: <><path d="m12 3 10 5-10 5L2 8l10-5ZM2 12l10 5 10-5M2 16l10 5 10-5"/></>,
  sliders: <><path d="M5 3v5m0 4v9M12 3v10m0 4v4M19 3v2m0 4v12"/><path d="M2 8h6m1 5h6m1-8h6"/></>,
  motion: <><path d="M3 12c3-10 6 10 9 0s6 10 9 0M3 5h4M17 19h4"/></>,
  play: <path d="m9 5 11 7-11 7V5Z"/>, pause: <><path d="M8 5v14M16 5v14"/></>,
  undo: <><path d="m8 4-5 5 5 5"/><path d="M3 9h11a6 6 0 0 1 0 12h-3"/></>,
  redo: <><path d="m16 4 5 5-5 5"/><path d="M21 9H10a6 6 0 0 0 0 12h3"/></>,
  more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  close: <path d="m6 6 12 12M6 18 18 6"/>,
  download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/></>,
  folder: <path d="M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>,
  new: <><path d="M14 3H5v18h14V8l-5-5ZM14 3v5h5M8 14h8M12 10v8"/></>,
  chevron: <path d="m6 9 6 6 6-6"/>, up: <path d="m5 15 7-7 7 7"/>, down: <path d="m5 9 7 7 7-7"/>,
  copy: <><rect x="8" y="8" width="13" height="13" rx="3"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></>,
  trash: <><path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7"/></>,
  eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></>,
  hidden: <><path d="m3 3 18 18M9 5.4c5-1.5 10 3 13 6.6-1 1.7-2.2 3.1-3.6 4.2M5.5 6.2C3.4 8.3 2 12 2 12s4 7 10 7c1.3 0 2.5-.3 3.7-.8M10 10a3 3 0 0 0 4 4"/></>,
  lock: <><rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
  unlock: <><rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 7.5-2M12 14v3"/></>,
  check: <path d="m5 12 4 4L19 6"/>, warning: <><path d="m12 3 10 18H2L12 3ZM12 9v5"/><circle cx="12" cy="17" r=".6"/></>,
  group: <><path d="M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5"/><rect x="7" y="7" width="10" height="10" rx="2"/></>,
  fit: <><path d="M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5"/><path d="M8 8h8v8H8z"/></>,
  settings: <><path d="m10 3-.5 3-2 1-3-.5L2 10l2.5 2.5-.5 3L7 18l3-.5 2 1 .5 3h4l.5-3 2-1 3 .5 2.5-3.5L21 12l.5-3L19 6l-3 .5-2-1-.5-2.5Z"/><circle cx="12" cy="12" r="3"/></>,
};
function Icon({ name, size = 20, className = '' }: { name: IconName; size?: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">{paths[name]}</svg>;
}
function IconButton({ icon, label, onClick, disabled = false, active = false, className = '' }: { icon: IconName; label: string; onClick: () => void; disabled?: boolean; active?: boolean; className?: string }) {
  return <button type="button" className={`icon-button ${active ? 'is-active' : ''} ${className}`} aria-label={label} title={label} onClick={onClick} disabled={disabled}><Icon name={icon}/></button>;
}

const MAX_LAYERS = 128;
const MAX_IMAGE_BYTES = 16 * 1024 * 1024;
const COLOR_SWATCHES = ['#091222', '#14273b', '#ece7de', '#ffffff', '#72edc6', '#87b7ff', '#b9a4fa', '#f4acaf', '#e7c477'];
const LAYER_NAMES: Record<Layer['type'], string> = { image: 'Ảnh', text: 'Văn bản', shape: 'Hình khối', group: 'Nhóm lớp', unsupported: 'Lớp gốc' };
const LAYER_ICONS: Record<Layer['type'], IconName> = { image: 'image', text: 'text', shape: 'shape', group: 'group', unsupported: 'layers' };
const PRESETS: { id: Layer['motion']['preset']; name: string; note: string; icon: IconName }[] = [
  { id: 'none', name: 'Tĩnh', note: 'Giữ nguyên', icon: 'shape' },
  { id: 'float', name: 'Lơ lửng', note: 'Êm và nhẹ', icon: 'motion' },
  { id: 'pulse', name: 'Nhịp thở', note: 'Thu phóng', icon: 'sparkles' },
  { id: 'spin', name: 'Xoay', note: 'Một vòng', icon: 'redo' },
  { id: 'fade', name: 'Ẩn hiện', note: 'Mờ dần', icon: 'eye' },
  { id: 'bounce', name: 'Nảy', note: 'Nhịp nhàng', icon: 'up' },
];
const uid = () => globalThis.crypto?.randomUUID?.() ?? `layer-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const copyProject = (doc: StudioDocument): StudioDocument => ({ ...doc, project: JSON.parse(JSON.stringify(doc.project)) });
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const layerDescendants = (layers: Layer[], parentId: string): Set<string> => {
  const ids = new Set([parentId]);
  for (let i = 0; i < layers.length; i++) for (const layer of layers) if (layer.parentId && ids.has(layer.parentId)) ids.add(layer.id);
  return ids;
};
function flattenLayers(layers: Layer[], parentId: string | null = null, depth = 0, visited = new Set<string>()): { layer: Layer; depth: number }[] {
  const rows: { layer: Layer; depth: number }[] = [];
  const siblings = layers.filter(layer => layer.parentId === parentId).slice().reverse();
  for (const layer of siblings) {
    if (visited.has(layer.id)) continue;
    visited.add(layer.id);
    rows.push({ layer, depth });
    rows.push(...flattenLayers(layers, layer.id, Math.min(depth + 1, 5), visited));
  }
  if (parentId === null) for (const layer of layers) if (!visited.has(layer.id)) { visited.add(layer.id); rows.push({ layer, depth: 0 }); }
  return rows;
}
function useAssetURLs(files: Map<string, Uint8Array>) {
  return useMemo(() => {
    const urls = new Map<string, string>();
    for (const [path, data] of files) {
      const extension = path.split('.').pop()?.toLowerCase();
      const mime = ({ png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', heic: 'image/heic', avif: 'image/avif', svg: 'image/svg+xml' } as Record<string, string>)[extension ?? ''];
      if (mime) urls.set(path, URL.createObjectURL(new Blob([new Uint8Array(data)], { type: mime })));
    }
    return urls;
  }, [files]);
}
function NumericField({ label, value, onChange, min = -100000, max = 100000, step = 1, suffix, disabled }: { label: string; value: number; onChange: (value: number) => void; min?: number; max?: number; step?: number; suffix?: string; disabled?: boolean }) {
  const [draft, setDraft] = useState(String(Math.round(value * 100) / 100));
  const focused = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(String(Math.round(value * 100) / 100)); }, [value]);
  const commit = () => { focused.current = false; const next = Number(draft); if (draft.trim() && Number.isFinite(next)) onChange(clamp(next, min, max)); else setDraft(String(value)); };
  return <label className="number-field"><span>{label}</span><div><input type="number" inputMode={step < 1 ? 'decimal' : 'numeric'} value={draft} min={min} max={max} step={step} disabled={disabled} onFocus={() => { focused.current = true; }} onChange={event => setDraft(event.target.value)} onBlur={commit} onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}/>{suffix && <small>{suffix}</small>}</div></label>;
}
function ColorField({ label, value, onChange, disabled = false }: { label: string; value: string; onChange: (color: string) => void; disabled?: boolean }) {
  const displayValue = /^#[0-9a-f]{6}$/i.test(value) ? value : '#ffffff';
  return <div className="color-field"><div className="field-caption"><span>{label}</span><label className="custom-color" title="Chọn màu"><span style={{ background: displayValue }}/><input aria-label={label} type="color" value={displayValue} onChange={event => onChange(event.target.value)} disabled={disabled}/><span>{displayValue.toUpperCase()}</span></label></div><div className="color-swatches">{COLOR_SWATCHES.map(color => <button type="button" className={color.toLowerCase() === displayValue.toLowerCase() ? 'selected' : ''} key={color} aria-label={`Màu ${color}`} title={color} style={{ '--swatch-color': color } as CSSProperties} disabled={disabled} onClick={() => onChange(color)}>{color.toLowerCase() === displayValue.toLowerCase() && <Icon name="check" size={14}/>}</button>)}</div></div>;
}

export default function App() {
  const [document, setDocument] = useState<StudioDocument>(() => createDocument('Hình nền của tôi', 1170, 2532));
  const documentRef = useRef(document);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [panel, setPanel] = useState<'add' | 'layers' | 'properties' | 'motion'>('add');
  const [dirty, setDirty] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [confirmNew, setConfirmNew] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ message: string; error?: boolean } | null>(null);
  const [warningsOpen, setWarningsOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [historyCount, setHistoryCount] = useState({ past: 0, future: 0 });
  const history = useRef<{ past: StudioDocument[]; future: StudioDocument[] }>({ past: [], future: [] });
  const exporting = useRef(false);
  const imageInput = useRef<HTMLInputElement>(null);
  const replacementImageId = useRef<string | null>(null);
  const packageInput = useRef<HTMLInputElement>(null);
  const previewRef = useRef<HTMLDivElement>(null);
  const [previewSize, setPreviewSize] = useState({ width: 320, height: 460 });
  const drag = useRef<{ id: string; kind: 'move' | 'resize'; pointerId: number; clientX: number; clientY: number; x: number; y: number; width: number; height: number; scale: number; angle: number; rotation: number; before: StudioDocument; moved: boolean } | null>(null);
  const scene = document.project.scenes.find(item => item.id === document.project.activeSceneId) ?? document.project.scenes[0];
  const selected = scene?.layers.find(layer => layer.id === selectedId) ?? null;
  const assetURLs = useAssetURLs(document.files);
  useEffect(() => () => { for (const url of assetURLs.values()) URL.revokeObjectURL(url); }, [assetURLs]);
  const scale = Math.max(0.01, Math.min((previewSize.width - 38) / Math.max(scene?.width ?? 1170, 1), (previewSize.height - 34) / Math.max(scene?.height ?? 2532, 1)));
  const duration = Math.min(60, Math.max(8, ...((scene?.layers ?? []).map(layer => Math.max(1, layer.motion.duration + layer.motion.delay) * 2))));
  const notify = useCallback((message: string, error = false) => setNotice({ message, error }), []);
  const openFilePicker = useCallback(async () => {
    setMenuOpen(false);
    try { if (!(await requestNativeOpen())) packageInput.current?.click(); }
    catch { notify('Không mở được Tệp. Hãy thử lại.', true); }
  }, [notify]);
  const syncHistory = () => setHistoryCount({ past: history.current.past.length, future: history.current.future.length });
  const storeDocument = useCallback((next: StudioDocument, makeHistory = true, markDirty = true) => {
    if (makeHistory) {
      history.current.past.push(documentRef.current);
      if (history.current.past.length > 50) history.current.past.shift();
      history.current.future = [];
      setHistoryCount({ past: history.current.past.length, future: 0 });
    }
    documentRef.current = next;
    setDocument(next);
    if (markDirty) setDirty(true);
  }, []);
  const editScene = useCallback((update: (scene: Scene, doc: StudioDocument) => void, makeHistory = true) => {
    const next = copyProject(documentRef.current);
    const active = next.project.scenes.find(item => item.id === next.project.activeSceneId) ?? next.project.scenes[0];
    if (!active) return;
    update(active, next);
    storeDocument(next, makeHistory);
  }, [storeDocument]);
  const patchLayer = useCallback((id: string, values: Partial<Layer>, makeHistory = true) => editScene(active => {
    const index = active.layers.findIndex(layer => layer.id === id);
    if (index >= 0) active.layers[index] = { ...active.layers[index], ...values };
  }, makeHistory), [editScene]);
  const patchMotion = (values: Partial<Layer['motion']>) => { if (selected && !selected.locked) patchLayer(selected.id, { motion: { ...selected.motion, ...values } }); };
  const replaceDocument = useCallback((next: StudioDocument) => {
    documentRef.current = next;
    setDocument(next);
    history.current = { past: [], future: [] };
    setHistoryCount({ past: 0, future: 0 });
    setSelectedId(null);
    setPanel('add');
    setPlaying(false);
    setTime(0);
    setDirty(false);
    setWarningsOpen(false);
  }, []);
  const openPackage = useCallback(async (data: Uint8Array, name: string) => {
    setBusy('Đang mở hình nền…');
    try {
      const opened = await importPackage(data, name);
      replaceDocument(opened);
      notify(`Đã mở ${opened.project.name}.`);
    } catch (error) { notify(error instanceof Error ? error.message : 'Không mở được gói hình nền này.', true); throw error; }
    finally { setBusy(null); }
  }, [replaceDocument, notify]);
  const exportCurrent = useCallback(async () => {
    if (exporting.current) return;
    exporting.current = true;
    setBusy('Đang đóng gói hình nền…');
    try {
      const result = await exportPackage(documentRef.current);
      await nativeExport(result.data, result.filename);
      setDirty(false);
      notify('Đã tạo file .tendies. Chọn nơi lưu hoặc chia sẻ.');
    } catch (error) { notify(error instanceof Error ? error.message : 'Không xuất được hình nền. Hãy thử lại.', true); }
    finally { exporting.current = false; setBusy(null); }
  }, [notify]);
  const startNew = useCallback(() => {
    replaceDocument(createDocument('Hình nền mới', 1170, 2532));
    setMenuOpen(false);
    setConfirmNew(false);
    setSettingsOpen(true);
  }, [replaceDocument]);
  useEffect(() => {
    const unregister = registerNativeEditor({ openPackage, requestExport: exportCurrent, startNew });
    return typeof unregister === 'function' ? unregister : undefined;
  }, [openPackage, exportCurrent, startNew]);
  useEffect(() => { postEditorState({ dirty, title: document.project.name, busy: busy !== null }); }, [dirty, document.project.name, busy]);
  useEffect(() => {
    const node = previewRef.current;
    if (!node) return;
    const observer = new ResizeObserver(([entry]) => setPreviewSize({ width: entry.contentRect.width, height: entry.contentRect.height }));
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(null), notice.error ? 10000 : 4500);
    return () => clearTimeout(timeout);
  }, [notice]);
  useEffect(() => {
    if (!playing) return;
    let frame = 0;
    let last = performance.now();
    let pending = 0;
    const tick = (now: number) => {
      pending += Math.min((now - last) / 1000, .1);
      last = now;
      if (pending >= 1 / 30) { const delta = pending; pending = 0; setTime(value => (value + delta) % duration); }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing, duration]);
  const undo = useCallback(() => {
    const previous = history.current.past.pop();
    if (!previous) return;
    history.current.future.push(documentRef.current);
    documentRef.current = previous;
    setDocument(previous);
    setDirty(true);
    setHistoryCount({ past: history.current.past.length, future: history.current.future.length });
  }, []);
  const redo = useCallback(() => {
    const next = history.current.future.pop();
    if (!next) return;
    history.current.past.push(documentRef.current);
    documentRef.current = next;
    setDocument(next);
    setDirty(true);
    setHistoryCount({ past: history.current.past.length, future: history.current.future.length });
  }, []);
  const deleteLayer = useCallback((id: string) => {
    editScene(active => { const remove = layerDescendants(active.layers, id); active.layers = active.layers.filter(layer => !remove.has(layer.id)); });
    setSelectedId(null);
  }, [editScene]);
  useEffect(() => {
    const keyboard = (event: KeyboardEvent) => {
      if ((event.target as HTMLElement).closest('input, textarea, select, [contenteditable]')) return;
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? redo() : undo(); }
      if ((event.key === 'Delete' || event.key === 'Backspace') && selected && !selected.locked) { event.preventDefault(); deleteLayer(selected.id); }
      if (event.key === 'Escape') { setSelectedId(null); setMenuOpen(false); setSettingsOpen(false); }
      if (event.code === 'Space') { event.preventDefault(); setPlaying(value => !value); }
      if (selected && !selected.locked && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) {
        event.preventDefault();
        const delta = event.shiftKey ? 10 : 1;
        patchLayer(selected.id, { x: selected.x + (event.key === 'ArrowLeft' ? -delta : event.key === 'ArrowRight' ? delta : 0), y: selected.y + (event.key === 'ArrowUp' ? -delta : event.key === 'ArrowDown' ? delta : 0) });
      }
    };
    window.addEventListener('keydown', keyboard);
    return () => window.removeEventListener('keydown', keyboard);
  }, [selected, undo, redo, deleteLayer, patchLayer]);
  const addLayer = (type: 'text' | 'shape' | 'group') => {
    if (!scene) return;
    if (scene.layers.length >= MAX_LAYERS) { notify('Mỗi hình nền có tối đa 128 lớp.', true); return; }
    const layer = makeLayer(type, scene);
    if (selected?.type === 'group' && !selected.locked) {
      layer.parentId = selected.id;
      layer.x = Math.max(0, (selected.width - layer.width) / 2);
      layer.y = Math.max(0, (selected.height - layer.height) / 2);
    }
    editScene(active => active.layers.push(layer));
    setSelectedId(layer.id);
    setPanel('properties');
  };
  const addImage = async (file: File) => {
    if (!scene) return;
    const replacing = scene.layers.find(layer => layer.id === replacementImageId.current && layer.type === 'image' && !layer.locked);
    replacementImageId.current = null;
    if (!replacing && scene.layers.length >= MAX_LAYERS) { notify('Mỗi hình nền có tối đa 128 lớp.', true); return; }
    if (file.size > MAX_IMAGE_BYTES) { notify('Chọn ảnh nhỏ hơn 16 MB để chỉnh sửa mượt hơn.', true); return; }
    if (!file.type.startsWith('image/')) { notify('Hãy chọn một file ảnh.', true); return; }
    setBusy('Đang thêm ảnh…');
    let imageURL = '';
    try {
      imageURL = URL.createObjectURL(file);
      const image = await new Promise<HTMLImageElement>((resolve, reject) => { const element = new Image(); element.onload = () => resolve(element); element.onerror = () => reject(new Error('Không đọc được ảnh này. Hãy dùng ảnh PNG hoặc JPEG.')); element.src = imageURL; });
      const dimensions = { width: image.naturalWidth, height: image.naturalHeight };
      if (dimensions.width < 1 || dimensions.height < 1) throw new Error('Ảnh không có kích thước hợp lệ.');
      // Bake the browser's orientation and supported decoders into one portable PNG.
      const raster = globalThis.document.createElement('canvas');
      const rasterScale = Math.min(1, 4096 / Math.max(dimensions.width, dimensions.height), Math.sqrt(8_000_000 / (dimensions.width * dimensions.height)));
      raster.width = Math.max(1, Math.round(dimensions.width * rasterScale));
      raster.height = Math.max(1, Math.round(dimensions.height * rasterScale));
      const context = raster.getContext('2d');
      if (!context) throw new Error('Thiết bị chưa tạo được ảnh xem trước. Hãy thử ảnh nhỏ hơn.');
      context.drawImage(image, 0, 0, raster.width, raster.height);
      let encoded = await new Promise<Blob | null>(resolve => raster.toBlob(resolve, 'image/png'));
      for (let attempt = 0; encoded && encoded.size > MAX_IMAGE_BYTES && attempt < 4; attempt++) {
        const smaller = globalThis.document.createElement('canvas');
        smaller.width = Math.max(1, Math.round(raster.width * .75));
        smaller.height = Math.max(1, Math.round(raster.height * .75));
        smaller.getContext('2d')?.drawImage(raster, 0, 0, smaller.width, smaller.height);
        raster.width = smaller.width;
        raster.height = smaller.height;
        context.drawImage(smaller, 0, 0);
        encoded = await new Promise<Blob | null>(resolve => raster.toBlob(resolve, 'image/png'));
      }
      if (!encoded || encoded.size > MAX_IMAGE_BYTES) throw new Error('Ảnh quá lớn sau khi xử lý. Hãy chọn ảnh nhỏ hơn.');
      const bytes = new Uint8Array(await encoded.arrayBuffer());
      raster.width = 1;
      raster.height = 1;
      const path = `assets/${uid()}.png`;
      const layer = replacing ? { ...replacing } : makeLayer('image', scene);
      const maxWidth = scene.width * .85;
      const maxHeight = scene.height * .65;
      const ratio = Math.min(maxWidth / dimensions.width, maxHeight / dimensions.height, 1);
      if (!replacing) {
        layer.width = Math.max(1, Math.round(dimensions.width * ratio));
        layer.height = Math.max(1, Math.round(dimensions.height * ratio));
        layer.x = Math.round((scene.width - layer.width) / 2);
        layer.y = Math.round((scene.height - layer.height) / 2);
        layer.name = file.name.replace(/\.[^.]+$/, '') || 'Ảnh';
      }
      layer.imagePath = path;
      editScene((active, next) => { next.files = new Map(next.files); next.files.set(path, bytes); if (replacing) { const index = active.layers.findIndex(item => item.id === replacing.id); if (index >= 0) active.layers[index] = layer; } else active.layers.push(layer); });
      setSelectedId(layer.id);
      setPanel('properties');
    } catch (error) { notify(error instanceof Error ? error.message : 'Không thêm được ảnh này.', true); }
    finally { if (imageURL) URL.revokeObjectURL(imageURL); setBusy(null); }
  };
  const duplicateLayer = () => {
    if (!selected || !scene) return;
    const descendants = layerDescendants(scene.layers, selected.id);
    if (scene.layers.some(layer => descendants.has(layer.id) && layer.type === 'unsupported')) { notify('Nhóm có thành phần chưa hỗ trợ nhân đôi. Bạn vẫn có thể chỉnh sửa các lớp khác; thành phần gốc được giữ khi xuất.', true); return; }
    if (scene.layers.length + descendants.size > MAX_LAYERS) { notify('Mỗi hình nền có tối đa 128 lớp.', true); return; }
    const ids = new Map([...descendants].map(id => [id, uid()]));
    const copies = scene.layers.filter(layer => descendants.has(layer.id)).map(layer => ({ ...JSON.parse(JSON.stringify(layer)), id: ids.get(layer.id), name: layer.id === selected.id ? `${layer.name} bản sao` : layer.name, parentId: layer.parentId && ids.has(layer.parentId) ? ids.get(layer.parentId) : layer.parentId, x: layer.x + (layer.id === selected.id ? 24 : 0), y: layer.y + (layer.id === selected.id ? 24 : 0), binding: undefined })) as Layer[];
    editScene(active => active.layers.push(...copies));
    setSelectedId(ids.get(selected.id)!);
    if (scene.layers.some(layer => descendants.has(layer.id) && layer.binding)) notify('Đã nhân đôi các thuộc tính chỉnh sửa được. Hiệu ứng nâng cao vẫn nằm trong lớp gốc.');
  };
  const reorderLayer = (id: string, direction: 1 | -1) => editScene(active => {
    const index = active.layers.findIndex(layer => layer.id === id);
    const layer = active.layers[index];
    if (!layer) return;
    const siblings = active.layers.map((entry, i) => ({ entry, i })).filter(({ entry }) => entry.parentId === layer.parentId);
    const siblingIndex = siblings.findIndex(({ entry }) => entry.id === id);
    const target = siblings[siblingIndex + direction];
    if (target) [active.layers[index], active.layers[target.i]] = [active.layers[target.i], active.layers[index]];
  });
  const beginDrag = (event: ReactPointerEvent, layer: Layer, kind: 'move' | 'resize' = 'move') => {
    event.stopPropagation();
    setSelectedId(layer.id);
    if (layer.locked || layer.type === 'unsupported') { setPanel('properties'); return; }
    if (event.button !== 0) return;
    event.preventDefault();
    setPlaying(false);
    setTime(0);
    event.currentTarget.setPointerCapture(event.pointerId);
    let ancestor = layer.parentId;
    let angle = 0;
    const seen = new Set<string>();
    while (ancestor && !seen.has(ancestor)) {
      seen.add(ancestor);
      const parent = scene?.layers.find(item => item.id === ancestor);
      if (!parent) break;
      angle += parent.rotation;
      ancestor = parent.parentId;
    }
    drag.current = { id: layer.id, kind, pointerId: event.pointerId, clientX: event.clientX, clientY: event.clientY, x: layer.x, y: layer.y, width: layer.width, height: layer.height, scale, angle: (angle + (kind === 'resize' ? layer.rotation : 0)) * Math.PI / 180, rotation: layer.rotation * Math.PI / 180, before: documentRef.current, moved: false };
  };
  const moveDrag = (event: ReactPointerEvent) => {
    const state = drag.current;
    if (!state || state.pointerId !== event.pointerId) return;
    event.stopPropagation();
    const screenX = (event.clientX - state.clientX) / state.scale;
    const screenY = (event.clientY - state.clientY) / state.scale;
    const dx = screenX * Math.cos(state.angle) + screenY * Math.sin(state.angle);
    const dy = -screenX * Math.sin(state.angle) + screenY * Math.cos(state.angle);
    if (Math.abs(dx) + Math.abs(dy) < 2 && !state.moved) return;
    state.moved = true;
    if (state.kind === 'move') patchLayer(state.id, { x: Math.round(state.x + dx), y: Math.round(state.y + dy) }, false);
    else {
      const width = Math.max(8, Math.round(state.width + dx));
      const height = Math.max(8, Math.round(state.height + dy));
      const dw = (width - state.width) / 2;
      const dh = (height - state.height) / 2;
      patchLayer(state.id, { width, height, x: state.x + (Math.cos(state.rotation) - 1) * dw - Math.sin(state.rotation) * dh, y: state.y + Math.sin(state.rotation) * dw + (Math.cos(state.rotation) - 1) * dh }, false);
    }
  };
  const endDrag = (event: ReactPointerEvent) => {
    const state = drag.current;
    if (!state || state.pointerId !== event.pointerId) return;
    if (state.moved) { history.current.past.push(state.before); if (history.current.past.length > 50) history.current.past.shift(); history.current.future = []; syncHistory(); }
    drag.current = null;
  };
  const renderLayer = (layer: Layer, ancestry: Set<string> = new Set()) => {
    if (!layer.visible || ancestry.has(layer.id)) return null;
    const lineage = new Set(ancestry).add(layer.id);
    const anim = motionAt(layer.motion, time);
    const isSelected = selectedId === layer.id;
    const style: CSSProperties = {
      left: layer.x, top: layer.y, width: Math.max(1, layer.width), height: Math.max(1, layer.height),
      transform: `translate(${anim.dx}px, ${anim.dy}px) rotate(${layer.rotation + anim.rotation}deg) scale(${anim.scale})`,
      borderRadius: layer.cornerRadius,
      '--canvas-scale': scale,
    } as CSSProperties;
    let content: ReactNode = null;
    if (layer.type === 'image') content = layer.imagePath && assetURLs.has(layer.imagePath) ? <img src={assetURLs.get(layer.imagePath)} alt={layer.name} draggable={false} style={{ borderRadius: layer.cornerRadius }}/> : <div className="missing-image"><Icon name="image" size={72}/><span>Ảnh chưa hỗ trợ xem trước</span></div>;
    if (layer.type === 'text') content = <div className="layer-text" style={{ color: layer.color, fontSize: layer.fontSize, fontFamily: layer.fontFamily || '-apple-system, sans-serif', fontWeight: layer.fontWeight === 'bold' ? 700 : 400, textAlign: layer.textAlign, borderRadius: layer.cornerRadius }}>{layer.text}</div>;
    if (layer.type === 'shape') content = <div className="layer-shape" style={{ background: layer.color, borderRadius: layer.cornerRadius }}/>;
    if (layer.type === 'unsupported') content = <div className="unsupported-layer"><Icon name="layers" size={64}/><span>{layer.name}</span><small>Giữ nguyên khi xuất</small></div>;
    return <div key={layer.id} className={`canvas-layer ${isSelected ? 'is-selected' : ''} ${layer.locked ? 'is-locked' : ''} ${layer.type === 'group' ? 'is-group' : ''}`} style={style} onPointerDown={event => beginDrag(event, layer)} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag}>
      <div className="layer-content" style={{ opacity: clamp(layer.opacity * anim.opacity, 0, 1) }}>{content}{scene.layers.filter(child => child.parentId === layer.id).map(child => renderLayer(child, lineage))}</div>
      {isSelected && <div className="selection-outline"><span className="selection-label">{layer.name}{layer.locked ? ' · Đã khóa' : ''}</span>{!layer.locked && layer.type !== 'unsupported' && <button type="button" className="resize-handle" aria-label="Kéo để đổi kích thước" onPointerDown={event => beginDrag(event, layer, 'resize')} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag}/>}</div>}
    </div>;
  };

  return <div className="studio-app">
    <header className="studio-header">
      <div className="brand-mark"><Icon name="sparkles" size={23}/></div>
      <button className="project-title" type="button" onClick={() => setSettingsOpen(true)} aria-label="Cài đặt dự án"><span className="eyebrow">TENDIES STUDIO</span><span className="project-name">{document.project.name}<Icon name="chevron" size={13}/></span></button>
      <button type="button" className="export-button" onClick={() => void exportCurrent()} disabled={!!busy}><Icon name="download" size={17}/><span>Xuất</span></button>
      <div className="file-menu-anchor"><IconButton icon="more" label="Tùy chọn dự án" onClick={() => setMenuOpen(value => !value)} active={menuOpen}/>{menuOpen && <><button type="button" className="menu-backdrop" aria-label="Đóng tùy chọn" onClick={() => setMenuOpen(false)}/><div className="file-menu"><span className="menu-heading">DỰ ÁN CỦA BẠN</span><button type="button" onClick={() => { setMenuOpen(false); if (dirty) setConfirmNew(true); else startNew(); }}><Icon name="new"/>Tạo hình nền mới</button><button type="button" onClick={() => void openFilePicker()}><Icon name="folder"/>Mở file .tendies</button><button type="button" onClick={() => { setMenuOpen(false); setSettingsOpen(true); }}><Icon name="sliders"/>Kích thước và tên</button><div className="menu-divider"/><button type="button" onClick={() => { setMenuOpen(false); void exportCurrent(); }}><Icon name="download"/>Xuất file .tendies</button></div></>}</div>
    </header>
    <div className="document-bar"><span className={`document-state ${dirty ? 'is-dirty' : ''}`}><i/>{dirty ? 'Có thay đổi chưa xuất' : 'Sẵn sàng sáng tạo'}</span><div className="history-buttons"><IconButton icon="undo" label="Hoàn tác" onClick={undo} disabled={!historyCount.past || !!busy}/><IconButton icon="redo" label="Làm lại" onClick={redo} disabled={!historyCount.future || !!busy}/></div></div>
    <main className="studio-workspace">
      <section className="preview-section" aria-label="Khung xem trước hình nền">
        <div className="preview-toolbar"><label className="scene-select"><Icon name="layers" size={15}/><select aria-label="Chọn hình nền trong gói" value={scene?.id ?? ''} onChange={event => { const next = copyProject(documentRef.current); next.project.activeSceneId = event.target.value; storeDocument(next, false, false); setSelectedId(null); setTime(0); }}>{document.project.scenes.map((item, index) => <option value={item.id} key={item.id}>{document.project.scenes.length > 1 ? `${index + 1}. ` : ''}{item.name || `Hình nền ${index + 1}`}</option>)}</select><Icon name="chevron" size={12}/></label><span className="canvas-dimensions">{scene?.width} × {scene?.height}</span></div>
        {document.warnings.length > 0 && <div className="import-warning"><button type="button" onClick={() => setWarningsOpen(value => !value)}><Icon name="warning" size={15}/><span>{document.warnings.length} lưu ý về gói đã mở</span><Icon name="chevron" size={13}/></button>{warningsOpen && <div className="warning-details">{document.warnings.map((warning, i) => <p key={i}>{warning}</p>)}<p>Các thành phần chưa hỗ trợ vẫn được giữ trong gói khi xuất.</p></div>}</div>}
        <div className="preview-viewport" ref={previewRef} onPointerDown={() => setSelectedId(null)}>
          {scene && <div className="canvas-frame" style={{ width: scene.width * scale, height: scene.height * scale }}><div className="wallpaper-canvas" style={{ width: scene.width, height: scene.height, transform: `scale(${scale})`, background: scene.background }}>
            {scene.layers.filter(layer => !layer.parentId || !scene.layers.some(parent => parent.id === layer.parentId)).map(layer => renderLayer(layer))}
          </div>{!scene.layers.length && <div className="empty-canvas"><div className="empty-canvas-icon"><Icon name="sparkles" size={27}/></div><span>Một ý tưởng.<br/>Một màn hình riêng.</span><small>Thêm ảnh, chữ hoặc hình khối</small></div>}</div>}
          <div className="preview-fit"><Icon name="fit" size={12}/>{Math.round(scale * 100)}%</div>
          {playing && <span className="live-badge"><i/>XEM TRƯỚC</span>}
        </div>
        <div className="playback-bar"><IconButton icon={playing ? 'pause' : 'play'} label={playing ? 'Tạm dừng chuyển động' : 'Phát chuyển động'} onClick={() => setPlaying(value => !value)} active={playing}/><span className="timeline-time">{time.toFixed(1)}<small>s</small></span><input aria-label="Thời điểm xem trước" className="timeline-range" type="range" min="0" max={duration} step="0.05" value={time} onChange={event => { setPlaying(false); setTime(Number(event.target.value)); }}/><span className="timeline-end">{duration.toFixed(0)}s</span></div>
      </section>

      <aside className="editing-panel" aria-label="Công cụ chỉnh sửa">
        <nav className="editor-tabs" aria-label="Công cụ">{([{ id: 'add', name: 'Thêm', icon: 'add' }, { id: 'layers', name: 'Lớp', icon: 'layers' }, { id: 'properties', name: 'Thuộc tính', icon: 'sliders' }, { id: 'motion', name: 'Chuyển động', icon: 'motion' }] as const).map(tab => <button type="button" key={tab.id} className={panel === tab.id ? 'selected' : ''} onClick={() => setPanel(tab.id)} aria-selected={panel === tab.id}><Icon name={tab.icon} size={19}/><span>{tab.name}</span></button>)}</nav>
        <div className="panel-content">
          {panel === 'add' && <div className="add-panel"><div className="panel-heading"><div><span className="eyebrow">BẮT ĐẦU TỪ MỘT LỚP</span><h2>Thêm vào hình nền</h2></div><span className="count-badge">{scene?.layers.length ?? 0}/{MAX_LAYERS}</span></div><div className="add-cards"><button type="button" className="add-card photo-card" onClick={() => { replacementImageId.current = null; imageInput.current?.click(); }} disabled={!!busy}><div className="add-card-icon"><Icon name="image" size={25}/></div><span>Ảnh của bạn</span><small>Từ thư viện hoặc Tệp</small><Icon className="add-card-plus" name="add" size={16}/></button><button type="button" className="add-card text-card" onClick={() => addLayer('text')} disabled={!!busy}><div className="add-card-icon"><span>Aa</span></div><span>Văn bản</span><small>Viết điều bạn thích</small><Icon className="add-card-plus" name="add" size={16}/></button><button type="button" className="add-card shape-card" onClick={() => addLayer('shape')} disabled={!!busy}><div className="add-card-icon"><Icon name="shape" size={25}/></div><span>Hình khối</span><small>Màu sắc và hình dáng</small><Icon className="add-card-plus" name="add" size={16}/></button><button type="button" className="add-card group-card" onClick={() => addLayer('group')} disabled={!!busy}><div className="add-card-icon"><Icon name="group" size={25}/></div><span>Nhóm lớp</span><small>Sắp xếp cùng nhau</small><Icon className="add-card-plus" name="add" size={16}/></button></div><div className="panel-divider"/><ColorField label="Màu nền" value={scene?.background ?? '#091222'} onChange={color => editScene(active => { active.background = color; })}/><p className="panel-tip"><Icon name="sparkles" size={16}/>Chạm vào lớp để chọn. Kéo trực tiếp trên màn hình để sắp xếp.</p><button type="button" className="inline-open" onClick={() => void openFilePicker()}><Icon name="folder" size={18}/><span>Đã có hình nền? <strong>Mở file .tendies</strong></span><Icon name="arrow" size={14}/></button></div>}

          {panel === 'layers' && <div className="layers-panel"><div className="panel-heading"><div><span className="eyebrow">TỪ TRƯỚC RA SAU</span><h2>Các lớp của bạn</h2></div><IconButton icon="add" label="Thêm lớp" onClick={() => setPanel('add')}/></div>{!scene?.layers.length ? <div className="panel-empty"><Icon name="layers" size={30}/><h3>Chưa có lớp nào</h3><p>Thêm một tấm ảnh hoặc dòng chữ để bắt đầu.</p><button type="button" className="small-primary" onClick={() => setPanel('add')}>Thêm lớp đầu tiên</button></div> : <><div className="layer-list">{flattenLayers(scene.layers).map(({ layer, depth }) => <div key={layer.id} className={`layer-row ${selectedId === layer.id ? 'selected' : ''} ${!layer.visible ? 'is-hidden' : ''}`} style={{ '--layer-depth': depth } as CSSProperties}><button type="button" className="layer-select" onClick={() => setSelectedId(layer.id)} aria-pressed={selectedId === layer.id}><span className="layer-thumbnail">{layer.type === 'image' && layer.imagePath && assetURLs.get(layer.imagePath) ? <img src={assetURLs.get(layer.imagePath)} alt=""/> : layer.type === 'shape' ? <i style={{ background: layer.color, borderRadius: Math.min(layer.cornerRadius, 12) }}/> : <Icon name={LAYER_ICONS[layer.type]} size={19}/>}</span><span className="layer-name"><strong>{layer.name}</strong><small>{LAYER_NAMES[layer.type]}{layer.motion.preset !== 'none' ? ' · Chuyển động' : ''}</small></span></button><IconButton icon={layer.visible ? 'eye' : 'hidden'} label={layer.visible ? `Ẩn ${layer.name}` : `Hiện ${layer.name}`} onClick={() => patchLayer(layer.id, { visible: !layer.visible })}/><IconButton icon={layer.locked ? 'lock' : 'unlock'} label={layer.locked ? `Mở khóa ${layer.name}` : `Khóa ${layer.name}`} onClick={() => patchLayer(layer.id, { locked: !layer.locked })}/></div>)}</div>{selected && <div className="layer-actions"><button type="button" onClick={() => reorderLayer(selected.id, 1)}><Icon name="up" size={18}/><span>Lên trước</span></button><button type="button" onClick={() => reorderLayer(selected.id, -1)}><Icon name="down" size={18}/><span>Ra sau</span></button><button type="button" onClick={duplicateLayer} disabled={selected.type === 'unsupported'}><Icon name="copy" size={18}/><span>Nhân đôi</span></button><button type="button" className="danger" disabled={selected.locked} onClick={() => deleteLayer(selected.id)}><Icon name="trash" size={18}/><span>Xóa lớp</span></button></div>}</> }</div>}

          {panel === 'properties' && <div className="properties-panel">{selected ? <><div className="panel-heading"><div><span className="eyebrow">{LAYER_NAMES[selected.type].toUpperCase()}</span><h2>{selected.name}</h2></div><IconButton icon={selected.locked ? 'lock' : 'unlock'} label={selected.locked ? 'Mở khóa lớp' : 'Khóa lớp'} active={selected.locked} onClick={() => patchLayer(selected.id, { locked: !selected.locked })}/></div>{selected.type === 'unsupported' ? <div className="preserved-notice"><Icon name="layers" size={22}/><p>Lớp này được giữ nguyên khi xuất. Một số hiệu ứng gốc chưa thể chỉnh sửa hoặc xem trước trong Studio.</p></div> : <><label className="text-field"><span>Tên lớp</span><input value={selected.name} maxLength={100} disabled={selected.locked} onChange={event => patchLayer(selected.id, { name: event.target.value })}/></label>{selected.type === 'image' && <button type="button" className="replace-image-button" disabled={selected.locked || !!busy} onClick={() => { replacementImageId.current = selected.id; imageInput.current?.click(); }}><Icon name="image" size={17}/>Thay ảnh của lớp này<Icon name="arrow" size={13}/></button>}{selected.type === 'shape' && <div className="shape-presets"><button type="button" disabled={selected.locked} onClick={() => patchLayer(selected.id, { cornerRadius: 0 })}><span className="shape-square"/>Vuông</button><button type="button" disabled={selected.locked} onClick={() => patchLayer(selected.id, { height: selected.width, cornerRadius: selected.width / 2 })}><span className="shape-circle"/>Tròn</button><button type="button" disabled={selected.locked} onClick={() => patchLayer(selected.id, { cornerRadius: Math.min(selected.width, selected.height) / 2 })}><span className="shape-pill"/>Viên</button></div>}{selected.locked && <p className="locked-notice"><Icon name="lock" size={14}/>Mở khóa để chỉnh sửa lớp này.</p>}<div className="field-grid"><NumericField label="Vị trí X" value={selected.x} disabled={selected.locked} onChange={x => patchLayer(selected.id, { x })}/><NumericField label="Vị trí Y" value={selected.y} disabled={selected.locked} onChange={y => patchLayer(selected.id, { y })}/><NumericField label="Chiều rộng" value={selected.width} min={1} max={16384} suffix="px" disabled={selected.locked} onChange={width => patchLayer(selected.id, { width })}/><NumericField label="Chiều cao" value={selected.height} min={1} max={16384} suffix="px" disabled={selected.locked} onChange={height => patchLayer(selected.id, { height })}/><NumericField label="Góc xoay" value={selected.rotation} min={-3600} max={3600} suffix="°" disabled={selected.locked} onChange={rotation => patchLayer(selected.id, { rotation })}/><NumericField label="Bo góc" value={selected.cornerRadius} min={0} max={8192} suffix="px" disabled={selected.locked} onChange={cornerRadius => patchLayer(selected.id, { cornerRadius })}/></div><label className="range-field"><span>Độ hiện rõ<strong>{Math.round(selected.opacity * 100)}%</strong></span><input type="range" min="0" max="1" step="0.01" value={selected.opacity} disabled={selected.locked} onChange={event => patchLayer(selected.id, { opacity: Number(event.target.value) })}/></label>{selected.type === 'text' && <><div className="panel-divider"/><label className="text-field"><span>Nội dung</span><textarea value={selected.text} rows={3} maxLength={5000} disabled={selected.locked} onChange={event => patchLayer(selected.id, { text: event.target.value })}/></label><div className="field-grid"><NumericField label="Cỡ chữ" value={selected.fontSize} min={4} max={1000} suffix="px" disabled={selected.locked} onChange={fontSize => patchLayer(selected.id, { fontSize })}/><label className="select-field"><span>Kiểu chữ</span><select value={selected.fontWeight} disabled={selected.locked} onChange={event => patchLayer(selected.id, { fontWeight: event.target.value as Layer['fontWeight'] })}><option value="normal">Thường</option><option value="bold">Đậm</option></select></label></div><label className="select-field font-select"><span>Phông chữ</span><select value={selected.fontFamily} disabled={selected.locked} onChange={event => patchLayer(selected.id, { fontFamily: event.target.value })}>{!['-apple-system', 'Helvetica Neue', 'Arial', 'Georgia', 'Times New Roman', 'Courier New'].includes(selected.fontFamily) && <option value={selected.fontFamily}>{selected.fontFamily || 'Hệ thống'}</option>}<option value="-apple-system">Hệ thống</option><option value="Helvetica Neue">Helvetica Neue</option><option value="Arial">Arial</option><option value="Georgia">Georgia</option><option value="Times New Roman">Times New Roman</option><option value="Courier New">Courier New</option></select></label><div className="alignment-control"><span>Căn dòng</span><div>{(['left', 'center', 'right'] as const).map((align, index) => <button type="button" key={align} className={selected.textAlign === align ? 'selected' : ''} disabled={selected.locked} aria-label={['Căn trái', 'Căn giữa', 'Căn phải'][index]} onClick={() => patchLayer(selected.id, { textAlign: align })}><span style={{ textAlign: align }}>≡</span></button>)}</div></div></>}{(selected.type === 'text' || selected.type === 'shape') && <ColorField label={selected.type === 'text' ? 'Màu chữ' : 'Màu hình khối'} value={selected.color} disabled={selected.locked} onChange={color => patchLayer(selected.id, { color })}/>}<div className="panel-divider"/><div className="property-actions"><button type="button" onClick={duplicateLayer}><Icon name="copy" size={17}/>Nhân đôi</button><button type="button" className="danger" disabled={selected.locked} onClick={() => deleteLayer(selected.id)}><Icon name="trash" size={17}/>Xóa lớp</button></div></>}</> : <div className="panel-empty"><Icon name="sliders" size={30}/><h3>Chọn một lớp để chỉnh sửa</h3><p>Chạm vào hình nền hoặc chọn lớp trong danh sách.</p><button type="button" className="small-primary" onClick={() => setPanel(scene?.layers.length ? 'layers' : 'add')}>{scene?.layers.length ? 'Xem các lớp' : 'Thêm lớp'}</button></div>}</div>}

          {panel === 'motion' && <div className="motion-panel">{selected && selected.type !== 'unsupported' ? <><div className="panel-heading"><div><span className="eyebrow">THÊM CHÚT SỐNG ĐỘNG</span><h2>Chuyển động</h2></div><span className="selected-layer-chip"><Icon name={LAYER_ICONS[selected.type]} size={13}/>{selected.name}</span></div><div className="motion-presets">{PRESETS.map(preset => <button type="button" key={preset.id} className={selected.motion.preset === preset.id ? 'selected' : ''} disabled={selected.locked} onClick={() => { patchMotion({ preset: preset.id }); setTime(0); if (preset.id !== 'none') setPlaying(true); }}><Icon name={preset.icon} size={24}/><strong>{preset.name}</strong><small>{preset.note}</small>{selected.motion.preset === preset.id && <span className="preset-check"><Icon name="check" size={11}/></span>}</button>)}</div>{selected.motion.preset !== 'none' && <><div className="field-grid"><NumericField label="Một vòng" value={selected.motion.duration} min={.2} max={30} step={.1} suffix="giây" disabled={selected.locked} onChange={duration => patchMotion({ duration })}/><NumericField label="Độ trễ" value={selected.motion.delay} min={0} max={30} step={.1} suffix="giây" disabled={selected.locked} onChange={delay => patchMotion({ delay })}/></div><label className="range-field"><span>{selected.motion.preset === 'float' || selected.motion.preset === 'bounce' ? 'Khoảng di chuyển' : 'Cường độ'}<strong>{Math.round(selected.motion.amount)}{selected.motion.preset === 'float' || selected.motion.preset === 'bounce' ? ' px' : '%'}</strong></span><input type="range" min="1" max={selected.motion.preset === 'float' || selected.motion.preset === 'bounce' ? Math.max(100, Math.round((scene?.height ?? 844) * .2)) : 100} step="1" value={selected.motion.amount} disabled={selected.locked} onChange={event => patchMotion({ amount: Number(event.target.value) })}/></label><button type="button" className="preview-motion-button" onClick={() => { setTime(0); setPlaying(value => !value); }}><Icon name={playing ? 'pause' : 'play'} size={17}/>{playing ? 'Tạm dừng xem trước' : 'Xem chuyển động'}</button></>}<p className="panel-tip"><Icon name="motion" size={16}/>Kéo thanh thời gian để xem từng khoảnh khắc. Hiệu ứng gốc không được hỗ trợ vẫn được giữ khi xuất.</p></> : <div className="panel-empty"><Icon name="motion" size={32}/><h3>{selected?.type === 'unsupported' ? 'Giữ lại chuyển động gốc' : 'Cho từng lớp một nhịp riêng'}</h3><p>{selected?.type === 'unsupported' ? 'Hiệu ứng của lớp này chưa hỗ trợ chỉnh sửa. Bạn có thể thêm lớp mới với chuyển động riêng.' : 'Chọn một lớp ảnh, văn bản hoặc hình khối để thêm hiệu ứng.'}</p><button type="button" className="small-primary" onClick={() => setPanel(scene?.layers.length ? 'layers' : 'add')}>{scene?.layers.length ? 'Chọn lớp' : 'Thêm lớp'}</button></div>}</div>}
        </div>
      </aside>
    </main>

    <input ref={imageInput} type="file" accept="image/*" className="visually-hidden" aria-label="Chọn ảnh để thêm" onChange={event => { const file = event.target.files?.[0]; if (file) void addImage(file); event.target.value = ''; }}/>
    <input ref={packageInput} type="file" accept=".tendies,.zip,application/zip,application/octet-stream" className="visually-hidden" aria-label="Mở gói hình nền" onChange={event => { const file = event.target.files?.[0]; if (file) { if (file.size > 128 * 1024 * 1024) notify('Gói quá lớn để chỉnh sửa. Giới hạn của Studio là 128 MB.', true); else void file.arrayBuffer().then(buffer => openPackage(new Uint8Array(buffer), file.name)).catch(() => notify('Không đọc được file này.', true)); } event.target.value = ''; }}/>
    {busy && <div className="busy-overlay" role="status" aria-live="polite"><div className="busy-card"><span className="spinner"/><strong>{busy}</strong><small>Giữ Studio mở trong giây lát</small></div></div>}
    {notice && <div className={`toast ${notice.error ? 'error' : ''}`} role={notice.error ? 'alert' : 'status'}><span className="toast-icon"><Icon name={notice.error ? 'warning' : 'check'} size={18}/></span><span>{notice.message}</span><IconButton icon="close" label="Đóng thông báo" onClick={() => setNotice(null)}/></div>}
    {confirmNew && <div className="modal-backdrop"><section className="dialog-card" role="dialog" aria-modal="true" aria-labelledby="new-dialog-title"><div className="dialog-icon"><Icon name="new" size={26}/></div><h2 id="new-dialog-title">Tạo một hình nền mới?</h2><p>Hãy xuất file để giữ lại các thay đổi của dự án đang mở.</p><button type="button" className="full-primary" onClick={async () => { setConfirmNew(false); await exportCurrent(); }}>Xuất dự án hiện tại</button><button type="button" className="secondary-button" onClick={startNew}>Tạo mới và bỏ thay đổi</button><button type="button" className="quiet-button" onClick={() => setConfirmNew(false)}>Tiếp tục chỉnh sửa</button></section></div>}
    {settingsOpen && <div className="modal-backdrop" onPointerDown={event => { if (event.currentTarget === event.target) setSettingsOpen(false); }}><section className="settings-card" role="dialog" aria-modal="true" aria-labelledby="project-settings-title"><div className="panel-heading"><div><span className="eyebrow">KHÔNG GIAN SÁNG TẠO</span><h2 id="project-settings-title">Dự án của bạn</h2></div><IconButton icon="close" label="Đóng cài đặt dự án" onClick={() => setSettingsOpen(false)}/></div><label className="text-field"><span>Tên dự án</span><input value={document.project.name} maxLength={80} onChange={event => { const next = copyProject(documentRef.current); next.project.name = event.target.value; storeDocument(next); }}/></label><label className="text-field"><span>Tên hình nền</span><input value={scene?.name ?? ''} maxLength={80} onChange={event => editScene(active => { active.name = event.target.value; })}/></label><div className="field-grid"><NumericField label="Chiều rộng" value={scene?.width ?? 1170} min={128} max={8192} suffix="px" onChange={width => editScene(active => { active.width = Math.round(width); })}/><NumericField label="Chiều cao" value={scene?.height ?? 2532} min={128} max={8192} suffix="px" onChange={height => editScene(active => { active.height = Math.round(height); })}/></div><div className="size-presets"><button type="button" onClick={() => editScene(active => { active.width = 1170; active.height = 2532; })}>iPhone · 1170 × 2532</button><button type="button" onClick={() => editScene(active => { active.width = 1290; active.height = 2796; })}>iPhone lớn · 1290 × 2796</button><button type="button" onClick={() => editScene(active => { active.width = 2048; active.height = 2732; })}>iPad · 2048 × 2732</button></div><p className="panel-tip"><Icon name="fit" size={16}/>Đổi kích thước khung không tự thay đổi vị trí và kích thước các lớp.</p><button type="button" className="full-primary" onClick={() => setSettingsOpen(false)}>Xong</button></section></div>}
  </div>;
}
