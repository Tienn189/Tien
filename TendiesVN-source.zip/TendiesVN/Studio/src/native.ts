type EditorHandlers = {
  openPackage: (data: Uint8Array, name: string) => Promise<void>;
  requestExport: () => Promise<void>;
  startNew: () => void;
};

type NativeReply = { sessionID?: string; success?: boolean };
type StudioAPI = {
  beginImport: (name: string, expectedBytes: number) => void;
  appendImport: (base64: string, index: number) => void;
  finishImport: () => Promise<void>;
  requestExport: () => Promise<void>;
  startNew: () => void;
};

declare global {
  interface Window {
    webkit?: { messageHandlers?: { tendiesStudio?: { postMessage: (message: unknown) => Promise<NativeReply> } } };
    TendiesStudio?: StudioAPI;
  }
}

const maxInputBytes = 128 * 1024 * 1024;
let incoming: { name: string; expected: number; received: number; index: number; chunks: Uint8Array[] } | undefined;

function nativeHandler() {
  return window.webkit?.messageHandlers?.tendiesStudio;
}

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  for (let offset = 0; offset < bytes.length; offset += 8192) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
  }
  return btoa(binary);
}

export function registerNativeEditor(handlers: EditorHandlers): () => void {
  document.documentElement.classList.toggle("native-host", !!nativeHandler());
  const api: StudioAPI = {
    beginImport(name, expectedBytes) {
      if (!Number.isSafeInteger(expectedBytes) || expectedBytes < 22 || expectedBytes > maxInputBytes) {
        throw new Error("Gói quá lớn để chỉnh sửa. Giới hạn của Studio là 128 MB.");
      }
      incoming = { name, expected: expectedBytes, received: 0, index: 0, chunks: [] };
    },
    appendImport(base64, index) {
      if (!incoming || incoming.index !== index || base64.length > 128 * 1024) {
        incoming = undefined;
        throw new Error("Luồng đọc gói bị gián đoạn. Hãy mở lại gói.");
      }
      const binary = atob(base64);
      const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
      incoming.received += bytes.length;
      if (incoming.received > incoming.expected) {
        incoming = undefined;
        throw new Error("Dung lượng gói không khớp.");
      }
      incoming.chunks.push(bytes);
      incoming.index++;
    },
    async finishImport() {
      const transfer = incoming;
      incoming = undefined;
      if (!transfer || transfer.expected !== transfer.received) throw new Error("Gói chưa được đọc đầy đủ.");
      const bytes = new Uint8Array(transfer.expected);
      let offset = 0;
      for (const chunk of transfer.chunks) { bytes.set(chunk, offset); offset += chunk.length; }
      await handlers.openPackage(bytes, transfer.name);
    },
    requestExport: handlers.requestExport,
    startNew: handlers.startNew
  };
  window.TendiesStudio = api;
  void nativeHandler()?.postMessage({ type: "ready" }).catch(() => undefined);
  return () => {
    if (window.TendiesStudio === api) delete window.TendiesStudio;
    incoming = undefined;
  };
}

export function postEditorState(state: { dirty: boolean; title: string; busy: boolean }): void {
  void nativeHandler()?.postMessage({ type: "state", dirty: state.dirty, title: state.title.slice(0, 120), busy: state.busy }).catch(() => undefined);
}

export async function requestNativeOpen(): Promise<boolean> {
  const handler = nativeHandler();
  if (!handler) return false;
  await handler.postMessage({ type: "openRequest" });
  return true;
}

export async function nativeExport(data: Uint8Array, filename: string): Promise<void> {
  const handler = nativeHandler();
  if (!handler) {
    const copy = new Uint8Array(data);
    const url = URL.createObjectURL(new Blob([copy.buffer], { type: "application/zip" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    return;
  }
  const reply = await handler.postMessage({ type: "begin", filename, expectedBytes: data.byteLength });
  if (!reply.sessionID) throw new Error("Không khởi tạo được tệp xuất.");
  const sessionID = reply.sessionID;
  try {
    let index = 0;
    for (let offset = 0; offset < data.length; offset += 64 * 1024) {
      const base64Chunk = toBase64(data.subarray(offset, offset + 64 * 1024));
      await handler.postMessage({ type: "append", sessionID, index, base64Chunk });
      index++;
    }
    await handler.postMessage({ type: "finish", sessionID });
  } catch (error) {
    await handler.postMessage({ type: "cancel", sessionID }).catch(() => undefined);
    throw error;
  }
}
