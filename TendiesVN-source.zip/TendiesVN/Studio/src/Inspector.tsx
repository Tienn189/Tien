import { useEffect, useRef, useState } from 'react';
import type { CSSProperties, ReactNode } from 'react';
import type { AnimationProperty, AnimationValue, Layer, LayerAnimation, LayerFilter, LayerProperties, WallpaperState } from './types';
import './Inspector.css';

type InspectorProps = {
  layer: Layer | null;
  state: WallpaperState;
  onPatch: (patch: Partial<LayerProperties>) => void;
  onRename: (name: string) => void;
  onFilters: (filters: LayerFilter[]) => void;
  onAnimations: (animations: LayerAnimation[]) => void;
  onReplaceImage: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
};
type Category = 'geometry' | 'compositing' | 'content' | 'media' | 'animations' | 'filters';
const categories: { id: Category; label: string; icon: ReactNode }[] = [
  { id: 'geometry', label: 'Geometry', icon: <><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4 7.5 8 5 8-5M12 12.5V21"/></> },
  { id: 'compositing', label: 'Compositing', icon: <><path d="m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5"/></> },
  { id: 'content', label: 'Content', icon: <><path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1.4-3.4 1.5 1.5 0 0 1 1.1-2.6H17a4 4 0 0 0 4-4c0-4.5-4-8-9-8Z"/><circle cx="7" cy="10" r=".7"/><circle cx="10" cy="7" r=".7"/><circle cx="15" cy="7" r=".7"/><circle cx="17" cy="11" r=".7"/></> },
  { id: 'media', label: 'Image / Text', icon: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8" cy="8" r="1.5"/><path d="m3 17 5-5 4 4 4-6 5 7"/></> },
  { id: 'animations', label: 'Animations', icon: <path d="m7 3 14 9L7 21V3Z"/> },
  { id: 'filters', label: 'Filters', icon: <path d="M3 4h18l-7 8v8l-4-2v-6L3 4Z"/> },
];
const stateNames: Record<WallpaperState, string> = { Base: 'Base State', Locked: 'Locked', Unlock: 'Unlock', Sleep: 'Sleep' };
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const rounded = (value: number) => String(Math.round(value * 1000) / 1000);
const uid = () => globalThis.crypto?.randomUUID?.() ?? `effect-${Date.now()}-${Math.random().toString(36).slice(2)}`;

function NumberField({ label, value, onChange, min = -100000, max = 100000, step = 1, suffix }: {
  label: string; value: number; onChange: (value: number) => void; min?: number; max?: number; step?: number; suffix?: string;
}) {
  const [draft, setDraft] = useState(rounded(value));
  const focused = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(rounded(value)); }, [value]);
  const commit = () => {
    focused.current = false;
    const parsed = Number(draft.trim().replace(',', '.'));
    if (!draft.trim() || !Number.isFinite(parsed)) { setDraft(rounded(value)); return; }
    const next = clamp(parsed, min, max);
    setDraft(rounded(next));
    if (next !== value) onChange(next);
  };
  return <label className="si-field"><span>{label}</span><span className="si-input-wrap"><input aria-label={label} type="text" inputMode={min < 0 ? 'text' : 'decimal'} value={draft} onFocus={() => { focused.current = true; }} onChange={event => setDraft(event.target.value)} onBlur={commit} onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}/>{suffix && <small>{suffix}</small>}</span></label>;
}
function TextField({ label, value, onChange, multiline = false, maxLength = 120 }: {
  label: string; value: string; onChange: (value: string) => void; multiline?: boolean; maxLength?: number;
}) {
  const [draft, setDraft] = useState(value);
  const focused = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(value); }, [value]);
  const shared = {
    'aria-label': label, value: draft, maxLength,
    onFocus: () => { focused.current = true; },
    onChange: (event: { target: { value: string } }) => setDraft(event.target.value),
    onBlur: () => { focused.current = false; if (draft !== value) onChange(draft); },
  };
  return <label className="si-field"><span>{label}</span>{multiline ? <textarea {...shared} rows={4}/> : <input {...shared} type="text" onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}/>}</label>;
}
function Toggle({ label, checked, onChange, note }: { label: string; checked: boolean; onChange: (value: boolean) => void; note?: string }) {
  return <label className="si-toggle-row"><span><strong>{label}</strong>{note && <small>{note}</small>}</span><input type="checkbox" checked={checked} onChange={event => onChange(event.target.checked)}/><span className="si-switch" aria-hidden="true"/></label>;
}
function RangeField({ label, value, onChange, min = 0, max = 1, step = .01, factor = 1, suffix }: {
  label: string; value: number; onChange: (value: number) => void; min?: number; max?: number; step?: number; factor?: number; suffix?: string;
}) {
  const [draft, setDraft] = useState(value);
  const focused = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(value); }, [value]);
  const commit = () => { if (!focused.current) return; focused.current = false; if (draft !== value) onChange(draft); };
  return <div className="si-range-field"><label><span>{label}</span><input aria-label={`${label} slider`} type="range" min={min} max={max} step={step} value={draft} onFocus={() => { focused.current = true; }} onChange={event => { focused.current = true; setDraft(Number(event.target.value)); }} onPointerUp={event => { event.currentTarget.blur(); commit(); }} onBlur={commit}/></label><NumberField label={label} value={draft * factor} onChange={next => onChange(next / factor)} min={min * factor} max={max * factor} step={step * factor} suffix={suffix}/></div>;
}
function ColorField({ label, value, onChange, transparent = false }: { label: string; value: string; onChange: (value: string) => void; transparent?: boolean }) {
  const [draft, setDraft] = useState(value);
  const focused = useRef(false);
  useEffect(() => { if (!focused.current) setDraft(value); }, [value]);
  const solid = /^#[\da-f]{6}(?:[\da-f]{2})?$/i.test(value) ? value.slice(0, 7) : '#ffffff';
  const commit = () => {
    focused.current = false;
    const next = draft.trim();
    if (/^#[\da-f]{6}(?:[\da-f]{2})?$/i.test(next)) { if (next.toLowerCase() !== value.toLowerCase()) onChange(next); }
    else setDraft(value);
  };
  return <div className="si-color-field"><span>{label}</span><div className="si-color-controls"><label className="si-color-swatch" style={{ '--si-color': value } as CSSProperties}><input type="color" aria-label={label} value={solid} onChange={event => onChange(event.target.value)}/></label><input aria-label={`${label} hex`} type="text" value={draft} maxLength={9} spellCheck={false} onFocus={() => { focused.current = true; }} onChange={event => setDraft(event.target.value)} onBlur={commit} onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }}/>{transparent && <button type="button" className="si-clear-color" title="Trong suốt" aria-label={`${label}: Trong suốt`} onClick={() => onChange('#00000000')}>∅</button>}</div></div>;
}
function SelectField({ label, value, onChange, children }: { label: string; value: string; onChange: (value: string) => void; children: ReactNode }) {
  return <label className="si-field"><span>{label}</span><select aria-label={label} value={value} onChange={event => onChange(event.target.value)}>{children}</select></label>;
}
function Section({ title, children, note }: { title?: string; children: ReactNode; note?: string }) {
  return <section className="si-section">{title && <h3>{title}</h3>}{note && <p className="si-note">{note}</p>}{children}</section>;
}

const animationProperties: AnimationProperty[] = ['position', 'position.x', 'position.y', 'transform.rotation.x', 'transform.rotation.y', 'transform.rotation.z', 'transform.scale', 'opacity', 'bounds', 'backgroundColor'];
const filterTypes: { type: LayerFilter['type']; name: string; min: number; max: number; step: number; initial: number; suffix?: string }[] = [
  { type: 'gaussianBlur', name: 'Gaussian Blur', min: 0, max: 100, step: .5, initial: 8, suffix: 'px' },
  { type: 'contrast', name: 'Contrast', min: 0, max: 5, step: .01, initial: 1.2 },
  { type: 'hueRotate', name: 'Hue Rotate', min: -360, max: 360, step: 1, initial: 45, suffix: '°' },
  { type: 'invert', name: 'Invert', min: 0, max: 1, step: .01, initial: 1 },
  { type: 'saturate', name: 'Saturate', min: 0, max: 5, step: .01, initial: 1.4 },
  { type: 'sepia', name: 'Sepia', min: 0, max: 1, step: .01, initial: 1 },
];
function animationDefaults(property: AnimationProperty, layer: Layer): Pick<LayerAnimation, 'from' | 'to'> {
  switch (property) {
    case 'position': return { from: [layer.x, layer.y], to: [layer.x, layer.y - 80] };
    case 'position.x': return { from: layer.x, to: layer.x + 80 };
    case 'position.y': return { from: layer.y, to: layer.y - 80 };
    case 'transform.rotation.x': return { from: layer.rotationX ?? 0, to: (layer.rotationX ?? 0) + 360 };
    case 'transform.rotation.y': return { from: layer.rotationY ?? 0, to: (layer.rotationY ?? 0) + 360 };
    case 'transform.rotation.z': return { from: layer.rotation, to: layer.rotation + 360 };
    case 'transform.scale': return { from: layer.scale ?? 1, to: (layer.scale ?? 1) * 1.2 };
    case 'opacity': return { from: layer.opacity, to: 0 };
    case 'bounds': return { from: [layer.width, layer.height], to: [layer.width * 1.2, layer.height * 1.2] };
    case 'backgroundColor': return { from: layer.backgroundColor ?? layer.color, to: '#68e0c6' };
  }
}
function AnimationValueField({ label, property, value, onChange }: { label: string; property: AnimationProperty; value: AnimationValue; onChange: (value: AnimationValue) => void }) {
  if (property === 'backgroundColor') return <ColorField label={label} value={typeof value === 'string' ? value : '#ffffff'} onChange={onChange} transparent/>;
  if (property === 'position' || property === 'bounds') {
    const values = Array.isArray(value) ? value : [0, 0];
    const isBounds = property === 'bounds';
    // Older CAML bounds can retain [originX, originY, width, height].
    const offset = isBounds && values.length >= 4 ? 2 : 0;
    return <fieldset className="si-value-group"><legend>{label}</legend><div className="si-grid"><NumberField label={isBounds ? 'Width' : 'X'} value={values[offset] ?? 0} min={isBounds ? 1 : -100000} onChange={next => { const copy = [...values]; copy[offset] = next; onChange(copy); }}/><NumberField label={isBounds ? 'Height' : 'Y'} value={values[offset + 1] ?? 0} min={isBounds ? 1 : -100000} onChange={next => { const copy = [...values]; copy[offset + 1] = next; onChange(copy); }}/></div></fieldset>;
  }
  const number = typeof value === 'number' ? value : 0;
  return <NumberField label={label} value={number} onChange={onChange} min={property === 'opacity' ? 0 : property === 'transform.scale' ? .001 : -100000} max={property === 'opacity' ? 1 : 100000} step={property === 'opacity' || property === 'transform.scale' ? .01 : 1} suffix={property.startsWith('transform.rotation') ? '°' : undefined}/>;
}

export default function Inspector({ layer, state, onPatch, onRename, onFilters, onAnimations, onReplaceImage, onDelete, onDuplicate }: InspectorProps) {
  const [category, setCategory] = useState<Category>('geometry');
  const [newAnimation, setNewAnimation] = useState('');
  const [newFilter, setNewFilter] = useState('');
  const [expandedAnimation, setExpandedAnimation] = useState<string | null>(null);
  const [expandedFilter, setExpandedFilter] = useState<string | null>(null);
  useEffect(() => { setExpandedAnimation(null); setExpandedFilter(null); setNewAnimation(''); setNewFilter(''); }, [layer?.id]);
  const selectedCategory = categories.find(item => item.id === category)!;
  if (!layer) return <div className="si-inspector si-empty"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5"/></svg><p>Chọn một lớp để chỉnh sửa.</p></div>;
  const animations = layer.animations ?? [];
  const filters = layer.filters ?? [];
  const patchAnimation = (id: string, patch: Partial<LayerAnimation>) => onAnimations(animations.map(animation => animation.id === id ? { ...animation, ...patch } : animation));
  const patchFilter = (id: string, patch: Partial<LayerFilter>) => onFilters(filters.map(filter => filter.id === id ? { ...filter, ...patch } : filter));
  const addAnimation = (property: string) => {
    if (!animationProperties.includes(property as AnimationProperty) || animations.length >= 32) return;
    const next: LayerAnimation = { id: uid(), property: property as AnimationProperty, ...animationDefaults(property as AnimationProperty, layer), duration: 2, delay: 0, repeat: true, autoreverses: true, enabled: true };
    onAnimations([...animations, next]); setExpandedAnimation(next.id); setNewAnimation('');
  };
  const addFilter = (type: string) => {
    const spec = filterTypes.find(item => item.type === type);
    if (!spec || filters.length >= 16) return;
    const next: LayerFilter = { id: uid(), type: spec.type, amount: spec.initial, enabled: true };
    onFilters([...filters, next]); setExpandedFilter(next.id); setNewFilter('');
  };
  return <div className="si-inspector">
    <div className="si-toolbar"><strong>Inspector</strong><div role="tablist" aria-label="Nhóm thuộc tính">{categories.map(item => <button type="button" role="tab" key={item.id} aria-label={item.label} title={item.label} aria-selected={category === item.id} onClick={() => setCategory(item.id)}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{item.icon}</svg></button>)}</div></div>
    <div className="si-context"><h2>{selectedCategory.label}</h2><span className="si-state-badge" title="Các thuộc tính được lưu riêng cho trạng thái này">{stateNames[state]}</span></div>
    <fieldset className="si-edit-fields" disabled={layer.locked} key={`${layer.id}-${state}`}>
      {category === 'geometry' && <>
        <Section><TextField label="Tên lớp" value={layer.name} onChange={onRename}/><div className="si-grid"><NumberField label="X" value={layer.x} onChange={x => onPatch({ x })}/><NumberField label="Y" value={layer.y} onChange={y => onPatch({ y })}/></div><NumberField label="Z" value={layer.z ?? 0} onChange={z => onPatch({ z })}/><div className="si-grid"><NumberField label="Width" value={layer.width} onChange={width => onPatch({ width })} min={1}/><NumberField label="Height" value={layer.height} onChange={height => onPatch({ height })} min={1}/></div><RangeField label="Scale" value={layer.scale ?? 1} onChange={scale => onPatch({ scale })} min={.01} max={4} step={.01} factor={100} suffix="%"/></Section>
        <Section title="Rotation (deg)"><div className="si-grid si-three"><NumberField label="X" value={layer.rotationX ?? 0} onChange={rotationX => onPatch({ rotationX })} suffix="°"/><NumberField label="Y" value={layer.rotationY ?? 0} onChange={rotationY => onPatch({ rotationY })} suffix="°"/><NumberField label="Z" value={layer.rotation} onChange={rotation => onPatch({ rotation })} suffix="°"/></div></Section>
        <Section title="Anchor Point"><div className="si-anchor-grid" role="group" aria-label="Anchor Point">{[0, .5, 1].flatMap(y => [0, .5, 1].map(x => <button key={`${x}-${y}`} type="button" aria-label={`Anchor ${x}, ${y}`} aria-pressed={Math.abs((layer.anchorX ?? .5) - x) < .001 && Math.abs((layer.anchorY ?? .5) - y) < .001} onClick={() => onPatch({ anchorX: x, anchorY: y })}><span className="si-anchor-dot"/>{x}, {y}</button>))}</div><div className="si-grid"><NumberField label="Anchor X" value={layer.anchorX ?? .5} onChange={anchorX => onPatch({ anchorX })} min={0} max={1} step={.01}/><NumberField label="Anchor Y" value={layer.anchorY ?? .5} onChange={anchorY => onPatch({ anchorY })} min={0} max={1} step={.01}/></div></Section>
      </>}
      {category === 'compositing' && <>
        <Section><SelectField label="Blending" value={layer.blendMode ?? 'normal'} onChange={blendMode => onPatch({ blendMode })}>{['normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'color-burn', 'soft-light', 'hard-light', 'difference', 'exclusion'].map(mode => <option key={mode} value={mode}>{mode === 'normal' ? 'Normal' : mode.replaceAll('-', ' ')}</option>)}</SelectField><RangeField label="Opacity" value={layer.opacity} onChange={opacity => onPatch({ opacity })} factor={100} suffix="%"/><NumberField label="Corner Radius" value={layer.cornerRadius} onChange={cornerRadius => onPatch({ cornerRadius })} min={0} suffix="px"/><Toggle label="Clip contents" checked={layer.clipContents ?? false} onChange={clipContents => onPatch({ clipContents })} note="Cắt các lớp con theo khung của lớp này."/><Toggle label="Visible" checked={layer.visible} onChange={visible => onPatch({ visible })}/></Section>
      </>}
      {category === 'content' && <>
        <Section><ColorField label={layer.type === 'shape' ? 'Màu hình khối' : layer.type === 'text' ? 'Màu chữ' : 'Màu lớp'} value={layer.color} onChange={color => onPatch({ color })}/><ColorField label="Background colour" value={layer.backgroundColor ?? '#00000000'} onChange={backgroundColor => onPatch({ backgroundColor })} transparent/><RangeField label="Background opacity" value={layer.backgroundOpacity ?? 1} onChange={backgroundOpacity => onPatch({ backgroundOpacity })} factor={100} suffix="%"/><div className="si-grid"><ColorField label="Border colour" value={layer.borderColor ?? '#000000'} onChange={borderColor => onPatch({ borderColor })}/><NumberField label="Border width" value={layer.borderWidth ?? 0} onChange={borderWidth => onPatch({ borderWidth })} min={0} suffix="px"/></div></Section>
        {layer.type === 'gradient' && <Section title="Gradient"><div className="si-gradient-preview" style={{ background: `linear-gradient(180deg, ${(layer.gradientColors ?? ['#68e0c6', '#5165df']).join(', ')})` }}/>{(layer.gradientColors ?? ['#68e0c6', '#5165df']).map((color, index, colors) => <div className="si-gradient-stop" key={index}><ColorField label={`Màu ${index + 1}`} value={color} onChange={next => onPatch({ gradientColors: colors.map((entry, i) => i === index ? next : entry) })}/>{colors.length > 2 && <button type="button" className="si-remove" aria-label={`Xóa màu ${index + 1}`} onClick={() => onPatch({ gradientColors: colors.filter((_, i) => i !== index) })}>×</button>}</div>)}<button type="button" className="si-outline" disabled={(layer.gradientColors?.length ?? 2) >= 8} onClick={() => onPatch({ gradientColors: [...(layer.gradientColors ?? ['#68e0c6', '#5165df']), '#ffffff'] })}>+ Thêm màu</button><div className="si-grid"><fieldset className="si-value-group"><legend>Start</legend><NumberField label="Start X" value={layer.gradientStart?.[0] ?? .5} onChange={x => onPatch({ gradientStart: [x, layer.gradientStart?.[1] ?? 0] })} min={0} max={1} step={.01}/><NumberField label="Start Y" value={layer.gradientStart?.[1] ?? 0} onChange={y => onPatch({ gradientStart: [layer.gradientStart?.[0] ?? .5, y] })} min={0} max={1} step={.01}/></fieldset><fieldset className="si-value-group"><legend>End</legend><NumberField label="End X" value={layer.gradientEnd?.[0] ?? .5} onChange={x => onPatch({ gradientEnd: [x, layer.gradientEnd?.[1] ?? 1] })} min={0} max={1} step={.01}/><NumberField label="End Y" value={layer.gradientEnd?.[1] ?? 1} onChange={y => onPatch({ gradientEnd: [layer.gradientEnd?.[0] ?? .5, y] })} min={0} max={1} step={.01}/></fieldset></div></Section>}
      </>}
      {category === 'media' && <>
        {layer.type === 'text' ? <Section><TextField label="Nội dung chữ" value={layer.text} onChange={text => onPatch({ text })} multiline maxLength={16000}/><TextField label="Font family" value={layer.fontFamily} onChange={fontFamily => onPatch({ fontFamily })}/><div className="si-grid"><NumberField label="Font size" value={layer.fontSize} onChange={fontSize => onPatch({ fontSize })} min={1} max={2000}/><SelectField label="Font weight" value={layer.fontWeight} onChange={fontWeight => onPatch({ fontWeight: fontWeight === 'bold' ? 'bold' : 'normal' })}><option value="normal">Normal</option><option value="bold">Bold</option></SelectField></div><SelectField label="Alignment" value={layer.textAlign} onChange={textAlign => onPatch({ textAlign: textAlign as Layer['textAlign'] })}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></SelectField><ColorField label="Màu chữ" value={layer.color} onChange={color => onPatch({ color })}/></Section> : layer.type === 'image' ? <Section><p className="si-note si-file-name">{layer.imagePath?.split('/').pop() ?? 'Chưa có ảnh'}</p><button type="button" className="si-outline" onClick={onReplaceImage}>Thay ảnh…</button><p className="si-note">Ảnh mới thay nội dung của lớp, giữ nguyên vị trí và các trạng thái.</p></Section> : <Section><p className="si-note">Chọn lớp ảnh hoặc văn bản để sửa nội dung.</p></Section>}
      </>}
      {category === 'animations' && <>
        <Section note="Animation chạy độc lập với States. Chuyển động Locked → Unlock được chỉnh ở bảng States."><select aria-label="Add animation" className="si-add-select" value={newAnimation} onChange={event => { setNewAnimation(event.target.value); addAnimation(event.target.value); }} disabled={animations.length >= 32}><option value="">+ Add animation</option>{animationProperties.map(property => <option value={property} key={property}>{property}</option>)}</select></Section>
        {animations.map(animation => <section className="si-effect" key={animation.id}><div className="si-effect-head"><button type="button" className="si-effect-title" onClick={() => setExpandedAnimation(expandedAnimation === animation.id ? null : animation.id)} aria-expanded={expandedAnimation === animation.id}><span>{expandedAnimation === animation.id ? '⌄' : '›'}</span>{animation.property}</button><input type="checkbox" aria-label={`Bật animation ${animation.property}`} checked={animation.enabled} onChange={event => patchAnimation(animation.id, { enabled: event.target.checked })}/><button type="button" className="si-remove" aria-label={`Xóa animation ${animation.property}`} onClick={() => onAnimations(animations.filter(item => item.id !== animation.id))}>×</button></div>{expandedAnimation === animation.id && <div className="si-effect-body"><SelectField label="Property" value={animation.property} onChange={property => patchAnimation(animation.id, { property: property as AnimationProperty, ...animationDefaults(property as AnimationProperty, layer) })}>{animationProperties.map(property => <option key={property} value={property}>{property}</option>)}</SelectField><AnimationValueField label="From" property={animation.property} value={animation.from} onChange={from => patchAnimation(animation.id, { from })}/><AnimationValueField label="To" property={animation.property} value={animation.to} onChange={to => patchAnimation(animation.id, { to })}/><div className="si-grid"><NumberField label="Duration" value={animation.duration} onChange={duration => patchAnimation(animation.id, { duration })} min={.05} max={300} step={.05} suffix="s"/><NumberField label="Delay" value={animation.delay} onChange={delay => patchAnimation(animation.id, { delay })} min={0} max={300} step={.05} suffix="s"/></div><Toggle label="Repeat" checked={animation.repeat} onChange={repeat => patchAnimation(animation.id, { repeat })}/><Toggle label="Autoreverse" checked={animation.autoreverses} onChange={autoreverses => patchAnimation(animation.id, { autoreverses })}/></div>}</section>)}
        {animations.length === 0 && <p className="si-note si-empty-note">Chưa có animation.</p>}
      </>}
      {category === 'filters' && <>
        <Section note="Filters áp dụng cho lớp ở mọi trạng thái."><select aria-label="Add filter" className="si-add-select" value={newFilter} onChange={event => { setNewFilter(event.target.value); addFilter(event.target.value); }} disabled={filters.length >= 16}><option value="">+ Add filter</option>{filterTypes.map(filter => <option key={filter.type} value={filter.type}>{filter.name}</option>)}</select></Section>
        {filters.map(filter => { const spec = filterTypes.find(item => item.type === filter.type); if (!spec) return null; return <section className="si-effect" key={filter.id}><div className="si-effect-head"><button type="button" className="si-effect-title" onClick={() => setExpandedFilter(expandedFilter === filter.id ? null : filter.id)} aria-expanded={expandedFilter === filter.id}><span>{expandedFilter === filter.id ? '⌄' : '›'}</span>{spec.name}</button><input type="checkbox" aria-label={`Bật filter ${spec.name}`} checked={filter.enabled} onChange={event => patchFilter(filter.id, { enabled: event.target.checked })}/><button type="button" className="si-remove" aria-label={`Xóa filter ${spec.name}`} onClick={() => onFilters(filters.filter(item => item.id !== filter.id))}>×</button></div>{expandedFilter === filter.id && <div className="si-effect-body"><RangeField label="Amount" value={filter.amount} onChange={amount => patchFilter(filter.id, { amount })} min={spec.min} max={spec.max} step={spec.step} suffix={spec.suffix}/></div>}</section>; })}
        {filters.length === 0 && <p className="si-note si-empty-note">Chưa có filter.</p>}
      </>}
    </fieldset>
    {layer.locked && <p className="si-locked-note">Lớp đang khóa. Mở khóa trong Layers để chỉnh sửa.</p>}
    {!layer.isRoot && <div className="si-layer-actions"><button type="button" onClick={onDuplicate} disabled={layer.locked}>Nhân bản</button><button type="button" className="si-danger" onClick={onDelete} disabled={layer.locked}>Xóa lớp</button></div>}
  </div>;
}
