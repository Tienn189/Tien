import type { Layer, LayerProperties, Scene, SceneRole, TransitionTiming, WallpaperState } from './types';

export const wallpaperStates: WallpaperState[] = ['Base', 'Locked', 'Unlock', 'Sleep'];
export const propertyKeys: (keyof LayerProperties)[] = ['x', 'y', 'z', 'width', 'height', 'rotation', 'rotationX', 'rotationY', 'scale', 'anchorX', 'anchorY', 'opacity', 'visible', 'color', 'text', 'fontSize', 'fontFamily', 'fontWeight', 'textAlign', 'cornerRadius', 'backgroundColor', 'backgroundOpacity', 'borderColor', 'borderWidth', 'clipContents', 'blendMode', 'gradientColors', 'gradientStart', 'gradientEnd', 'imagePath'];

export function resolveLayer(layer: Layer, state: WallpaperState): Layer {
  const patch = state === 'Base' ? {} : layer.states?.[state] ?? {};
  return {
    z: 0, scale: 1, rotationX: 0, rotationY: 0, anchorX: .5, anchorY: .5,
    backgroundColor: '#00000000', backgroundOpacity: 1, borderColor: '#000000', borderWidth: 0, clipContents: false,
    blendMode: 'normal', gradientColors: ['#68e0c6', '#5165df'], gradientStart: [.5, 0], gradientEnd: [.5, 1], filters: [], animations: [],
    ...layer, ...patch,
  };
}

export function patchLayerState(layer: Layer, state: WallpaperState, patch: Partial<LayerProperties>): Layer {
  const accepted = Object.fromEntries(Object.entries(patch).filter(([key]) => propertyKeys.includes(key as keyof LayerProperties))) as Partial<LayerProperties>;
  if (layer.type === 'shape') {
    if (accepted.backgroundColor !== undefined && accepted.color === undefined) accepted.color = accepted.backgroundColor;
    if (accepted.color !== undefined && accepted.backgroundColor === undefined) accepted.backgroundColor = accepted.color;
  }
  if (state === 'Base') return { ...layer, ...accepted };
  const next = { ...layer.states?.[state], ...accepted };
  for (const key of Object.keys(next) as (keyof LayerProperties)[]) if (next[key] === undefined) delete next[key];
  return { ...layer, states: { ...layer.states, [state]: next } };
}

export function clearLayerState(layer: Layer, state: WallpaperState): Layer {
  if (state === 'Base') return layer;
  const states = { ...layer.states }; delete states[state];
  return { ...layer, states };
}

function parseColor(value: string) {
  const h = value.slice(1); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16), h.length === 8 ? parseInt(h.slice(6, 8), 16) : 255];
}
function colorBetween(a: string, b: string, t: number) {
  const from = parseColor(a), to = parseColor(b);
  return '#' + from.map((v, i) => Math.round(v + (to[i] - v) * t).toString(16).padStart(2, '0')).join('');
}

export function interpolateLayer(from: Layer, to: Layer, progress: number): Layer {
  const t = Math.max(0, Math.min(1, progress)), a = resolveLayer(from, 'Base'), b = resolveLayer(to, 'Base');
  if (t === 0) return a; if (t === 1) return b;
  const result: Layer = { ...a };
  for (const key of propertyKeys) {
    const start = a[key], end = b[key]; let value: unknown = start;
    if (typeof start === 'number' && typeof end === 'number') value = start + (end - start) * t;
    else if (typeof start === 'string' && typeof end === 'string' && /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(start) && /^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/i.test(end)) value = colorBetween(start, end, t);
    else if (Array.isArray(start) && Array.isArray(end) && start.length === end.length) value = start.map((entry, i) => typeof entry === 'number' && typeof end[i] === 'number' ? entry + (Number(end[i]) - entry) * t : typeof entry === 'string' && typeof end[i] === 'string' && entry.startsWith('#') && String(end[i]).startsWith('#') ? colorBetween(entry, String(end[i]), t) : entry);
    (result as unknown as Record<string, unknown>)[key] = value;
  }
  return result;
}

export function easeProgress(progress: number, timing: TransitionTiming): number {
  const x = Math.max(0, Math.min(1, progress)); if (timing === 'linear' || x === 0 || x === 1) return x;
  const [x1, y1, x2, y2] = timing === 'easeIn' ? [.42, 0, 1, 1] : timing === 'easeOut' ? [0, 0, .58, 1] : [.42, 0, .58, 1];
  const curve = (t: number, a: number, b: number) => 3 * (1 - t) ** 2 * t * a + 3 * (1 - t) * t ** 2 * b + t ** 3;
  let lo = 0, hi = 1;
  for (let i = 0; i < 24; i++) { const middle = (lo + hi) / 2; if (curve(middle, x1, x2) < x) lo = middle; else hi = middle; }
  return curve((lo + hi) / 2, y1, y2);
}

export function sceneRole(scene: Scene): SceneRole {
  if (scene.role) return scene.role;
  const value = `${scene.name} ${scene.camlPath}`;
  return /foreground/i.test(value) ? 'Foreground' : /floating/i.test(value) ? 'Floating' : /background/i.test(value) ? 'Background' : 'Other';
}
