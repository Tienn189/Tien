# 1809 — Wallpaper Studio theo YanDevin

- Tên hiển thị của app là **1809**; chỉnh phần hình nền theo YanDevin trên nền mã UIKit KAMUI/TendiesVN được cung cấp, giữ các chức năng MobileGestalt và thứ tự tab hiện có.
- Giữ tên nguồn **TendiesVN-source.zip** và IPA **1809-<version>-unsigned.ipa** / **1809-unsigned.ipa** để workflow hiện có tiếp tục hoạt động. Executable/target `BQTool` và bundle ID mặc định `com.kamui.escape` là định danh kỹ thuật được giữ cho cấu hình build/ký và bản cài hiện có.

- Sửa lỗi `typedef redefinition` trong `BQCore.m` với SDK mới: dùng tên kiểu nội bộ `bq_xpc_object_t` cho con trỏ XPC động, không ghi đè kiểu SDK `xpc_object_t`.
- Sửa lỗi build `redefinition of module 'AirliftFFI'` trong log Codemagic/Xcode 26.3: bỏ đường dẫn modulemap trùng trong cấu hình Swift, giữ liên kết XCFramework chuẩn. In lỗi Xcode đầu tiên ở cuối log khi build thất bại.
- Thư viện dạng lưới có ảnh xem trước, số descriptor và provider.
- Lưu lựa chọn tối đa 5 gói, cài các gói đã chọn hoặc cài riêng trong màn hình xem trước.
- Nhập gói được kiểm tra trên hàng đợi nền; lưu bộ nhớ đệm đã giải nén và thumbnail để mở lại nhanh hơn. Nhấn giữ một gói để xóa bản sao đã nhập.
- Thêm Kiểm tra PosterBoard và sao chép kết quả.
- BadQuery: dùng generation mới nhất trong kho, xử lý alias Collections/Mercury, tạo thư mục provider còn thiếu và giữ biên nhận hoàn tác. Gói container giữ nội dung identifier gốc; tránh ghi đè thư mục đã có.
- Thêm dấu làm mới PosterBoard; lỗi làm mới sau khi ghi không báo sai thành lỗi cài đặt.
- PocketPoster kiểm tra quyền ghi đích thật trước khi cài.
- Bổ sung ImageIO/AVFoundation và kiểm tra Swift cho GitHub Actions/macOS.

Kiểm tra mã nguồn trong Linux: 24 đạt, 2 bỏ qua (archive mẫu và Swift/macOS). Chưa xác nhận cài hình nền trên thiết bị thật. Sau khi cập nhật ZIP, cần build lại và ký/cài IPA mới để tên hiển thị **1809** có hiệu lực. Build bằng `bash ./build.sh` trên macOS/Xcode 26+, hoặc chạy Actions → Build unsigned iOS app. Xem `docs/WALLPAPER-INTEGRATION.vi.md` để biết phiên bản iOS/backend được hỗ trợ.

Các ghi chú KAMUI gốc bên dưới là lịch sử của dự án trước tích hợp, không phải kết quả kiểm tra của bản sửa này. Giấy phép bản kết hợp: xem `THIRD_PARTY_NOTICES.md`.

---

# KAMUI 2.4.3 — iOS 27.0.1–27.2 sandbox escape + MobileGestalt editor

**Open source, MIT licensed and free for everyone.** There is no tester list,
private group or allowlist. Anyone can use, modify and redistribute KAMUI and
the MobileGestalt editor.

## Assets

- `KAMUI-2.4.3.ipa` — the app. Install it on any supported device.
- Source code and build instructions are in the repository.

## What's new in 2.4.3

- **Languages**: English, Russian, Korean, Arabic, Turkish, Ukrainian and
  Vietnamese. Settings → Language switches the app language and offers System
  default. Arabic uses RTL layout.
- **`.tendies` fix**: descriptors are written to both
  `com.apple.WallpaperKit.CollectionsPoster` and
  `com.apple.Posters.CollectionsPosterApp`, and the PosterBoard refresh marker
  (`com.apple.PosterBoard.unprotectedUserDefaults.plist`) is written. This
  targets the gray-poster/dummy-wallpaper problem. Container-format packs keep
  their original descriptor UUIDs.
- **Class-12 geod built-in container**: direct part-3 token for
  `com.apple.geod` (flags `0x8000000000`, `0x0800000000`, `0x8100000000`), then
  a symlinked `Library/Caches` to the target. This is the free-certificate
  route that does not require an app group or a restricted bundle ID.
- **Free-certificate bad_query file form**: class 13, MobileGestalt
  SystemGroup, part 3, an 8-level `..` traversal to
  `com.apple.MobileGestalt.plist`, flags `0x8000000000` (no include-path bit).
  This is the form used by GestaltEdit on iOS 27 and the one that has worked
  for some free Apple ID signatures.
- **Class-2 `RENAME_SWAP` probe**: atomically swaps `Library/Caches` with a
  symlink to the target, queries class 2, then swaps back. This may bypass the
  plain-rename denial without moving Library or causing the 2.2 crash.
- **Class-2 staged symlink probe**: a fake `Library/Caches` tree inside the
  app’s own Caches, resolved through a `partDomain` symlink. It is safe, needs
  no app group, and verifies the token against the target before reporting
  success.
- **Class-2 subpath probe**: creates a temporary symlink inside the app’s own
  `Library/Caches` and asks MCM for part 3 with a `partDomain`. It is safe and
  needs no app group. Successful tokens are verified by opening the target.
- **All app groups**: class 7 tries every app group in the running build, not
  just the first one.
- The opt-in class-2 parent fallback and its crash guard remain from 2.3.1.
- The “MCM query returned no sandbox token” error is localized and points to
  `Documents/bqtool.log`.

## Runtime requirement

The primary 27.2 class-7 strategy needs at least one
`com.apple.security.application-groups` entitlement in the running app. If
there is none, KAMUI tries the safe class-2 subpath probe. The class-2 parent
fallback is opt-in in Settings because some builds terminate the app when
`Library` is moved.

## Tested

iOS 27.2 (24B115): MG read/write, PosterBoard descriptors, `.tendies` pipeline,
live Dynamic Island. 27.0.1–27.2 use the same MCM query; open an issue with
`Documents/bqtool.log` if a strategy fails.

## Warnings

iPadOS mode, AI/Siri spoofing, ResearchFuse, Store Demo Mode and version
spoofing are high risk. They can break Face ID, layout, OTA updates or boot
behavior. Keep `OriginalGestalt.plist` and use Revert if anything misbehaves.

## License

MIT. Use it, fork it, ship it, sell it — keep the copyright and permission
notice. See `LICENSE`.

## Disclosure

KAMUI is public research. If you find a bug in the app, open an issue. If you
want to report the underlying MCM behavior to Apple, use Apple Security
Bounty. See `SECURITY.md`.
