# Đối chiếu hỗ trợ iOS · 1809 build 19

Đối chiếu mã nguồn chính thức ngày 2026-10-19. Không chạy mã upstream hay thử trên iPhone trong môi trường này. Phạm vi dưới đây là cơ chế có trong nguồn, không thay thế kết quả trên thiết bị.

## Vì sao các app hỗ trợ khác nhau

| App / phiên bản đã đọc | Cơ chế liên quan | Điều 1809 hiện có / còn thiếu |
| --- | --- | --- |
| Pocket-Poster `fb07aa4` | Bộ cài đời cũ dùng `.Trash`/`trashItem` và UUID container PosterBoard; lấy UUID bằng Nugget trên máy tính | 1809 chưa tích hợp bộ cài đời cũ hoặc luồng nhận UUID này cho iOS 17/18 |
| Placard `7dcefb6` | BadQuery cho iOS 26.0–26.6.1 và các build 27.0 beta cụ thể; Airlift là backend riêng cần pairing | BadQuery giữ nguyên; AirliftFFI được dùng cho iOS 27.0–27.0.1 qua pairing |
| 3105 `a72617e` | Thêm chuỗi kernel R/W/sandbox-access và resolver container, với điều kiện ký/Bundle ID riêng | 1809 không có chuỗi kernel này; công cụ pairing không thay thế được nó |

Không thể kết luận “iOS 17/18 không cài được hình nền”. Phần thiếu là backend trong 1809. Ngược lại, cũng không thể coi một phiên bản là được hỗ trợ chỉ vì app khác hiển thị nhãn đó.

## Phần đã bổ sung cho iOS 27 beta

Placard có cùng đường query/sandbox-token mà bridge 1809 đã dùng. Bản trước chặn mọi iOS 27 trong `SupportedSystemVersion()`, kể cả những build Placard cho phép. Build 19 dùng một predicate C chung cho giao diện Swift và bridge native, giữ kiểm tra metadata container và probe quyền ghi trước khi cài:

| Phiên bản | Build được nhận |
| --- | --- |
| iOS 26.0–26.6.1 | So sánh số phiên bản |
| iOS 27.0 Developer Beta 1 | `24A5355q` |
| iOS 27.0 Developer Beta 2 | `24A5370h` |
| iOS 27.0 Developer Beta 3 | `24A5380h` |
| iPadOS 27.0 Developer Beta 3 bản sửa | `24A5380l` |
| iOS 27.0 Developer Beta 4 | `24A5390f` |

Nhãn Public Beta 1/2 đang dùng trong 1809 tham khảo 3105, nhưng BadQuery **quyết định bằng build thực tế**, không bằng tên Public/Developer Beta. Airlift xử lý stable 27.0–27.0.1 qua pairing; phiên bản 27.1 hoặc bản khác trong tương lai không tự được bật.

Các build BadQuery này không cần pairing cho bộ cài cục bộ. Airlift cần pairing đã nhập và LocalDevVPN/transport tương ứng; 1809 giữ pairing record trong Keychain và một bản app-owned để gọi FFI.

Đây là đối chiếu và tích hợp policy với hai backend; **chưa xác nhận đã cài thành công trên iOS 27 thật**. Nếu pairing, container hoặc quyền ghi không khả dụng thì app phải báo lỗi, không báo thành công từ allowlist.

## iOS 18 và giới hạn còn lại

Pocket-Poster yêu cầu AppHash từ máy tính; helper Nugget tìm executable `Pocket Poster` (hoặc LiveContainer), nên không tự nhận app đã đổi tên thành 1809. Muốn dùng cơ chế đó cần tích hợp cả backend đời cũ, luồng cấp UUID đúng ứng dụng và kiểm chứng, không chỉ thêm ô nhập UUID hay đổi gate.

3105 tại commit đã đọc gọi `KernelExploit.run()` trước khi truy cập dữ liệu. 1809 không sao chép chuỗi kernel đó; iOS 18 hiện được hỗ trợ ở mức app/thư viện, chưa bật cài Tendies wallpaper.

Placard hiện đặt deployment target iOS 26.0, nên nguồn hiện tại của Placard không chứng minh hỗ trợ app trên 17/18.

## Nguồn chính thức đã ghim

- [Pocket-Poster: yêu cầu Nugget/máy tính](https://github.com/leminlimez/Pocket-Poster/blob/fb07aa45586ea4d2590c6f6d258777b207e1b8c9/README.md#L22-L28).
- [Pocket-Poster: trình cài đời cũ](https://github.com/leminlimez/Pocket-Poster/blob/fb07aa45586ea4d2590c6f6d258777b207e1b8c9/Pocket%20Poster/Controllers/PosterBoardManager.swift#L185-L231) và [helper phụ thuộc UUID](https://github.com/leminlimez/Pocket-Poster/blob/fb07aa45586ea4d2590c6f6d258777b207e1b8c9/Pocket%20Poster/Controllers/SymHandler.swift#L37-L64).
- [Nugget: tìm ứng dụng và truyền AppHash](https://github.com/leminlimez/Nugget/blob/26e0c50ec114ca3a4ff6ab2fb4ae309abfd39fa1/src/devicemanagement/device_manager.py#L292-L328).
- [Placard: policy đúng phiên bản/build](https://github.com/frs0n/placard/blob/7dcefb610cc60ae909b6046beee7adb691148e44/placard/SystemCompatibility.swift#L3-L24) và [route BadQuery native](https://github.com/frs0n/placard/blob/7dcefb610cc60ae909b6046beee7adb691148e44/placard/Exploit/bad_query.c#L81-L129).
- [Placard: chọn backend](https://github.com/frs0n/placard/blob/7dcefb610cc60ae909b6046beee7adb691148e44/placard/WallpaperInstaller.swift#L198-L205) và [Airlift yêu cầu pairing](https://github.com/frs0n/placard/blob/7dcefb610cc60ae909b6046beee7adb691148e44/placard/Airlift/AirliftWallpaperService.swift#L27-L44).
- [3105: policy](https://github.com/YangJiiii/3105/blob/a72617ed4c764a65d8aac1e91aca95231e72a2cb/ThreeOneOSFive/helpers/SupportPolicy.swift#L23-L48), [khởi tạo quyền](https://github.com/YangJiiii/3105/blob/a72617ed4c764a65d8aac1e91aca95231e72a2cb/ThreeOneOSFive/App.swift#L118-L199), [KernelExploit](https://github.com/YangJiiii/3105/blob/a72617ed4c764a65d8aac1e91aca95231e72a2cb/ThreeOneOSFive/helpers/KernelExploit.swift#L25-L73) và [điều kiện ký](https://github.com/YangJiiii/3105/blob/a72617ed4c764a65d8aac1e91aca95231e72a2cb/README.md#L80-L85).
