#pragma once
#import <UIKit/UIKit.h>

@interface PosterBoardVC : UIViewController <UIDocumentPickerDelegate>
@end
