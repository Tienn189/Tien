// SPDX-License-Identifier: GPL-3.0-only
// Wallpaper Studio interaction adapted from YanDevin (Minhhozhang).
// Native UIKit presentation; installation remains in the TendiesVN engine.
#import "PosterBoardVC.h"
#import "BQCore.h"
#import "BQUI.h"
#import "TendiesExploreVC.h"
#import "WallpaperEngine.h"
#import "WallpaperSetupVC.h"

static UIColor *TNAccent(void) { return [UIColor colorWithRed:0.13 green:0.57 blue:0.39 alpha:1]; }
static NSString * const TNSelectionKey = @"1809.wallpaper.selectedPacks";

@interface TNWallpaperCell : UICollectionViewCell
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UIButton *selectionButton;
@property (nonatomic, copy) void (^onSelect)(void);
@end

@implementation TNWallpaperCell
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.contentView.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
        self.contentView.layer.cornerRadius = 18;
        self.contentView.clipsToBounds = YES;
        _imageView = [[UIImageView alloc] init];
        _imageView.contentMode = UIViewContentModeScaleAspectFill;
        _imageView.clipsToBounds = YES;
        _imageView.tintColor = TNAccent();
        _imageView.backgroundColor = [TNAccent() colorWithAlphaComponent:0.10];
        [self.contentView addSubview:_imageView];
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline];
        _titleLabel.numberOfLines = 2;
        [self.contentView addSubview:_titleLabel];
        _detailLabel = [[UILabel alloc] init];
        _detailLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
        _detailLabel.textColor = UIColor.secondaryLabelColor;
        _detailLabel.numberOfLines = 2;
        [self.contentView addSubview:_detailLabel];
        _selectionButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _selectionButton.tintColor = TNAccent();
        _selectionButton.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
        _selectionButton.layer.cornerRadius = 20;
        [_selectionButton addTarget:self action:@selector(selectPack) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_selectionButton];
    }
    return self;
}
- (void)selectPack { if (self.onSelect) self.onSelect(); }
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.contentView.bounds.size.width;
    CGFloat h = self.contentView.bounds.size.height;
    self.imageView.frame = CGRectMake(0, 0, w, MAX(100, h - 90));
    self.titleLabel.frame = CGRectMake(12, h - 82, w - 24, 40);
    self.detailLabel.frame = CGRectMake(12, h - 40, w - 24, 34);
    self.selectionButton.frame = CGRectMake(w - 48, 8, 40, 40);
}
- (void)prepareForReuse {
    [super prepareForReuse];
    self.imageView.image = nil;
    self.onSelect = nil;
}
@end

@interface TNWallpaperPreviewVC : UIViewController
@property (nonatomic, copy) NSDictionary *info;
@property (nonatomic, copy) NSString *packName;
@property (nonatomic, copy) void (^onApply)(void);
@property (nonatomic, copy) void (^onDelete)(void);
@end

@implementation TNWallpaperPreviewVC
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.packName;
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemClose target:self action:@selector(close)];
    UIImageView *image = [[UIImageView alloc] init];
    image.translatesAutoresizingMaskIntoConstraints = NO;
    image.contentMode = UIViewContentModeScaleAspectFit;
    NSString *preview = self.info[@"previewPath"];
    image.image = preview.length ? [UIImage imageWithContentsOfFile:preview] : [UIImage systemImageNamed:@"photo.on.rectangle.angled"];
    image.tintColor = TNAccent();
    image.layer.cornerRadius = 24;
    image.clipsToBounds = YES;
    [self.view addSubview:image];
    UILabel *details = [[UILabel alloc] init];
    details.numberOfLines = 0;
    details.textAlignment = NSTextAlignmentCenter;
    details.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    details.textColor = UIColor.secondaryLabelColor;
    details.text = [NSString stringWithFormat:@"%@ · %@ hình nền · %@\nẢnh xem trước từ gói; hiệu ứng động hiển thị trong PosterBoard.", self.info[@"providerTitle"] ?: @"PosterBoard", self.info[@"descriptorCount"] ?: @0,
                    [NSByteCountFormatter stringFromByteCount:[self.info[@"expandedBytes"] longLongValue] countStyle:NSByteCountFormatterCountStyleFile]];
    UIButton *apply = [UIButton buttonWithType:UIButtonTypeSystem];
    UIButtonConfiguration *config = [UIButtonConfiguration filledButtonConfiguration];
    config.title = @"Cài gói này";
    config.image = [UIImage systemImageNamed:@"checkmark.circle.fill"];
    config.imagePadding = 8;
    config.baseBackgroundColor = TNAccent();
    config.cornerStyle = UIButtonConfigurationCornerStyleLarge;
    apply.configuration = config;
    [apply addTarget:self action:@selector(apply) forControlEvents:UIControlEventTouchUpInside];
    UIButton *remove = [UIButton buttonWithType:UIButtonTypeSystem];
    [remove setTitle:@"Xóa gói đã nhập" forState:UIControlStateNormal];
    remove.tintColor = UIColor.systemRedColor;
    [remove addTarget:self action:@selector(remove) forControlEvents:UIControlEventTouchUpInside];
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[details, apply, remove]];
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 16;
    [self.view addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [image.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],
        [image.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:24],
        [image.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-24],
        [image.bottomAnchor constraintEqualToAnchor:stack.topAnchor constant:-20],
        [stack.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:24],
        [stack.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-24],
        [stack.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-12],
        [apply.heightAnchor constraintGreaterThanOrEqualToConstant:50],
    ]];
}
- (void)finishWithCompletion:(void (^)(void))completion {
    // A delete confirmation may still be presented above this controller.
    // Dismiss the whole preview navigation stack from its original presenter.
    UIViewController *presenter = self.navigationController.presentingViewController ?: self.presentingViewController;
    if (presenter) [presenter dismissViewControllerAnimated:YES completion:completion];
    else if (completion) completion();
}
- (void)close { [self finishWithCompletion:nil]; }
- (void)apply { [self finishWithCompletion:self.onApply]; }
- (void)remove {
    BQConfirm(self, @"Xóa gói này?", @"Chỉ xóa bản sao đã nhập. Hình nền đã cài trong PosterBoard vẫn được giữ lại.", ^{
        [self finishWithCompletion:self.onDelete];
    });
}
@end

@interface PosterBoardVC () <UICollectionViewDataSource, UICollectionViewDelegate>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSArray<NSString *> *files;
@property (nonatomic, strong) NSMutableSet<NSString *> *selected;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSDictionary *> *metadata;
@property (nonatomic, strong) NSCache<NSString *, UIImage *> *thumbnails;
@property (nonatomic, assign) BOOL working;
@property (nonatomic, assign) BOOL loading;
@property (nonatomic, assign) NSUInteger reloadGeneration;
@property (nonatomic, copy) NSString *diagnostic;
@end

@implementation PosterBoardVC
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"PosterBoard";
    self.view.tintColor = TNAccent();
    self.files = @[];
    self.metadata = [NSMutableDictionary dictionary];
    self.selected = [NSMutableSet setWithArray:[NSUserDefaults.standardUserDefaults stringArrayForKey:TNSelectionKey] ?: @[]];
    self.thumbnails = [[NSCache alloc] init];
    self.thumbnails.countLimit = 30;
    __weak typeof(self) weakSelf = self;
    UICollectionViewCompositionalLayout *layout = [[UICollectionViewCompositionalLayout alloc] initWithSectionProvider:^NSCollectionLayoutSection *(NSInteger section, id<NSCollectionLayoutEnvironment> env) {
        BOOL grid = section == 1 && weakSelf.files.count > 0;
        CGFloat height = grid ? 286 : (section == 0 ? 196 : (section == 1 ? 142 : 56));
        NSCollectionLayoutDimension *rowHeight = grid ? [NSCollectionLayoutDimension absoluteDimension:height] : [NSCollectionLayoutDimension estimatedDimension:height];
        NSCollectionLayoutDimension *itemHeight = grid ? [NSCollectionLayoutDimension fractionalHeightDimension:1] : [NSCollectionLayoutDimension estimatedDimension:height];
        NSCollectionLayoutSize *itemSize = [NSCollectionLayoutSize sizeWithWidthDimension:[NSCollectionLayoutDimension fractionalWidthDimension:1] heightDimension:itemHeight];
        NSCollectionLayoutItem *item = [NSCollectionLayoutItem itemWithLayoutSize:itemSize];
        NSCollectionLayoutSize *groupSize = [NSCollectionLayoutSize sizeWithWidthDimension:[NSCollectionLayoutDimension fractionalWidthDimension:1] heightDimension:rowHeight];
        NSInteger count = grid ? (env.container.effectiveContentSize.width >= 700 ? 3 : 2) : 1;
        NSCollectionLayoutGroup *group = [NSCollectionLayoutGroup horizontalGroupWithLayoutSize:groupSize subitem:item count:count];
        group.interItemSpacing = [NSCollectionLayoutSpacing fixedSpacing:12];
        NSCollectionLayoutSection *result = [NSCollectionLayoutSection sectionWithGroup:group];
        result.interGroupSpacing = 12;
        result.contentInsets = NSDirectionalEdgeInsetsMake(8, 16, 14, 16);
        return result;
    }];
    self.collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    self.collectionView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.collectionView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    [self.collectionView registerClass:TNWallpaperCell.class forCellWithReuseIdentifier:@"pack"];
    [self.collectionView registerClass:UICollectionViewListCell.class forCellWithReuseIdentifier:@"text"];
    UIRefreshControl *refresh = [[UIRefreshControl alloc] init];
    [refresh addTarget:self action:@selector(reloadFiles) forControlEvents:UIControlEventValueChanged];
    self.collectionView.refreshControl = refresh;
    [self.view addSubview:self.collectionView];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(importTendies)];
    [self reloadFiles];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    // Includes packs downloaded in Explore and files copied through file sharing.
    if (self.collectionView && !self.working && !self.loading) [self reloadFiles];
}

- (void)setWorking:(BOOL)working {
    _working = working;
    self.collectionView.userInteractionEnabled = !working;
    self.navigationItem.rightBarButtonItem.enabled = !working;
    self.navigationItem.hidesBackButton = working;
    self.navigationController.interactivePopGestureRecognizer.enabled = !working;
    self.tabBarController.tabBar.userInteractionEnabled = !working;
}

- (void)persistSelection {
    [NSUserDefaults.standardUserDefaults setObject:self.selected.allObjects forKey:TNSelectionKey];
}

- (void)reloadFiles {
    if (self.working) { [self.collectionView.refreshControl endRefreshing]; return; }
    NSString *dir = [BQDocuments() stringByAppendingPathComponent:@"tendies"];
    NSFileManager *fm = NSFileManager.defaultManager;
    [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    NSMutableArray *files = [NSMutableArray array];
    for (NSString *name in [fm contentsOfDirectoryAtPath:dir error:nil] ?: @[]) {
        NSString *ext = name.pathExtension.lowercaseString;
        NSDictionary *attributes = [fm attributesOfItemAtPath:[dir stringByAppendingPathComponent:name] error:nil];
        if (([ext isEqualToString:@"tendies"] || [ext isEqualToString:@"zip"]) && [attributes[NSFileType] isEqual:NSFileTypeRegular]) {
            [files addObject:[dir stringByAppendingPathComponent:name]];
        }
    }
    [files sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    self.files = files;
    NSMutableSet *names = [NSMutableSet set];
    for (NSString *path in files) [names addObject:path.lastPathComponent];
    [self.selected intersectSet:names];
    [self persistSelection];
    [self.metadata removeAllObjects];
    [self.thumbnails removeAllObjects];
    NSUInteger generation = ++self.reloadGeneration;
    self.loading = YES;
    [self.collectionView reloadData];
    [self.collectionView.refreshControl endRefreshing];
    NSArray *snapshot = self.files.copy;
    dispatch_async(BQWorkQueue(), ^{
        for (NSString *path in snapshot) {
            NSError *error = nil;
            NSDictionary *info = [TNWallpaperEngine packageInfoForURL:[NSURL fileURLWithPath:path] error:&error];
            NSDictionary *result = info ?: @{@"error":error.localizedDescription ?: @"Gói không hợp lệ"};
            dispatch_async(dispatch_get_main_queue(), ^{
                if (generation != self.reloadGeneration) return;
                self.metadata[path] = result;
                [self.collectionView reloadData];
            });
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (generation != self.reloadGeneration) return;
            self.loading = NO;
            [self.collectionView reloadData];
        });
    });
}

- (void)togglePath:(NSString *)path {
    if (self.working) return;
    if ([self.selected containsObject:path.lastPathComponent]) [self.selected removeObject:path.lastPathComponent];
    else {
        if (!self.metadata[path] || self.metadata[path][@"error"]) return;
        if (self.selected.count >= 5) {
            BQAlert(self, @"Tối đa 5 gói", @"Hãy cài tối đa 5 gói mỗi lần như hướng dẫn của YanDevin, rồi chọn lượt tiếp theo.");
            return;
        }
        [self.selected addObject:path.lastPathComponent];
    }
    [self persistSelection];
    [self.collectionView reloadData];
}

- (void)previewPath:(NSString *)path {
    if (self.working || self.presentedViewController || !self.view.window || ![self.files containsObject:path]) return;
    NSDictionary *info = self.metadata[path];
    if (!info) { BQAlert(self, @"Đang đọc gói", @"Đợi kiểm tra và tạo ảnh xem trước hoàn tất."); return; }
    if (info[@"error"]) { BQAlert(self, @"Gói không hợp lệ", info[@"error"]); return; }
    TNWallpaperPreviewVC *preview = [[TNWallpaperPreviewVC alloc] init];
    preview.packName = info[@"displayName"] ?: path.lastPathComponent;
    preview.info = info;
    __weak typeof(self) weakSelf = self;
    preview.onApply = ^{ [weakSelf applyPaths:@[path]]; };
    preview.onDelete = ^{ [weakSelf deletePath:path]; };
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:preview] animated:YES completion:nil];
}

- (void)deletePath:(NSString *)path {
    if (self.working) return;
    self.working = YES;
    dispatch_async(BQWorkQueue(), ^{
        NSError *error = nil;
        BOOL removed = [NSFileManager.defaultManager removeItemAtPath:path error:&error];
        if (removed) [TNWallpaperEngine removeCachedPackageForURL:[NSURL fileURLWithPath:path]];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.working = NO;
            if (removed) { [self.selected removeObject:path.lastPathComponent]; [self persistSelection]; }
            else BQAlert(self, @"Không thể xóa gói", error.localizedDescription);
            [self reloadFiles];
        });
    });
}

- (BOOL)ensureInstallationReady {
    if ([TNWallpaperEngine installationSupported] && [TNWallpaperEngine installationReady]) return YES;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Thiết lập hình nền" message:[TNWallpaperEngine compatibilitySummary] preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Mở thiết lập" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { [self wallpaperSetup]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
    return NO;
}

- (void)applySelected {
    NSMutableArray *paths = [NSMutableArray array];
    for (NSString *path in self.files) if ([self.selected containsObject:path.lastPathComponent]) [paths addObject:path];
    [self applyPaths:paths];
}

- (void)applyPaths:(NSArray<NSString *> *)paths {
    if (self.working) return;
    if (!paths.count) { BQAlert(self, @"Chưa chọn gói", @"Chạm dấu tròn trên gói muốn cài, hoặc mở xem trước rồi chọn Cài gói này."); return; }
    if (![self ensureInstallationReady]) return;
    self.working = YES;
    BQBusyView *busy = [BQBusyView showInView:self.view text:@"Đang cài hình nền…"];
    NSArray *snapshot = paths.copy;
    dispatch_async(BQWorkQueue(), ^{
        int total = 0;
        NSMutableArray *errors = [NSMutableArray array];
        for (NSString *path in snapshot) {
            NSString *error = nil;
            int count = 0;
            if (BQApplyTendies([NSURL fileURLWithPath:path], &count, &error)) total += count;
            else [errors addObject:[NSString stringWithFormat:@"%@: %@", path.lastPathComponent, error ?: @"Không thể cài"]];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [busy hide];
            self.working = NO;
            NSString *message = [NSString stringWithFormat:@"Đã ghi %d descriptor.\nMở PosterBoard, rồi vuốt đóng trong đa nhiệm để làm mới Bộ sưu tập. Có thể dùng Respring nếu chưa thấy thay đổi.", total];
            if (errors.count) message = [message stringByAppendingFormat:@"\n\n%@", [errors componentsJoinedByString:@"\n"]];
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:(errors.count ? (total ? @"Đã cài một phần" : @"Cài thất bại") : @"Đã cài hình nền") message:message preferredStyle:UIAlertControllerStyleAlert];
            if (total > 0) {
                [alert addAction:[UIAlertAction actionWithTitle:@"Mở PosterBoard" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { [self openPosterBoard]; }]];
                [alert addAction:[UIAlertAction actionWithTitle:@"Respring" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { [self respring]; }]];
            }
            [alert addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        });
    });
}

- (void)importTendies {
    if (self.working) return;
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
    picker.delegate = self;
    picker.allowsMultipleSelection = YES;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    if (!urls.count || self.working) return;
    self.working = YES;
    // Discard pending metadata callbacks while this batch changes the library.
    ++self.reloadGeneration;
    BQBusyView *busy = [BQBusyView showInView:self.view text:@"Đang nhập và kiểm tra gói…"];
    dispatch_async(BQWorkQueue(), ^{
        NSMutableArray *errors = [NSMutableArray array];
        NSMutableArray *imported = [NSMutableArray array];
        NSFileManager *fm = NSFileManager.defaultManager;
        NSString *dir = [BQDocuments() stringByAppendingPathComponent:@"tendies"];
        [fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
        for (NSURL *url in urls) {
            NSString *ext = url.pathExtension.lowercaseString;
            if (![@[@"tendies", @"zip"] containsObject:ext]) {
                [errors addObject:[NSString stringWithFormat:@"%@: chỉ nhận .tendies hoặc .zip", url.lastPathComponent]];
                continue;
            }
            BOOL scoped = [url startAccessingSecurityScopedResource];
            NSString *destination = [dir stringByAppendingPathComponent:url.lastPathComponent];
            if ([fm fileExistsAtPath:destination]) destination = [dir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", NSUUID.UUID.UUIDString, url.lastPathComponent]];
            __block NSError *copyError = nil;
            NSError *coordinationError = nil;
            [[NSFileCoordinator new] coordinateReadingItemAtURL:url options:0 error:&coordinationError byAccessor:^(NSURL *readURL) {
                NSDictionary *attributes = [fm attributesOfItemAtPath:readURL.path error:&copyError];
                if (!attributes) return;
                if (![attributes[NSFileType] isEqual:NSFileTypeRegular] || [attributes[NSFileSize] unsignedLongLongValue] > 512ULL * 1024 * 1024) {
                    copyError = [NSError errorWithDomain:@"1809.Wallpaper" code:1 userInfo:@{NSLocalizedDescriptionKey:@"Gói phải là tệp thường, tối đa 512 MiB."}];
                    return;
                }
                [fm copyItemAtURL:readURL toURL:[NSURL fileURLWithPath:destination] error:&copyError];
            }];
            if (scoped) [url stopAccessingSecurityScopedResource];
            NSError *error = copyError ?: coordinationError;
            NSDictionary *info = error ? nil : [TNWallpaperEngine packageInfoForURL:[NSURL fileURLWithPath:destination] error:&error];
            if (info) [imported addObject:destination];
            else {
                [TNWallpaperEngine removeCachedPackageForURL:[NSURL fileURLWithPath:destination]];
                [fm removeItemAtPath:destination error:nil];
                [errors addObject:[NSString stringWithFormat:@"%@: %@", url.lastPathComponent, error.localizedDescription ?: @"Gói không hợp lệ"]];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [busy hide];
            self.working = NO;
            self.loading = NO;
            [self reloadFiles];
            if (errors.count) BQAlert(self, @"Kết quả nhập gói", [errors componentsJoinedByString:@"\n"]);
            else if (imported.count == 1) {
                // Cached inspection is immediate; make preview available before the queued refresh.
                NSString *path = imported.firstObject;
                dispatch_async(BQWorkQueue(), ^{
                    NSDictionary *info = [TNWallpaperEngine packageInfoForURL:[NSURL fileURLWithPath:path] error:nil];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (info && !self.presentedViewController && !self.working && self.view.window && self.navigationController.topViewController == self) {
                            self.metadata[path] = info;
                            [self previewPath:path];
                        }
                    });
                });
            }
        });
    });
}

- (void)checkPosterBoard {
    if (self.working) return;
    self.working = YES;
    BQBusyView *busy = [BQBusyView showInView:self.view text:@"Đang kiểm tra PosterBoard…"];
    dispatch_async(BQWorkQueue(), ^{
        NSString *report = [TNWallpaperEngine checkPosterBoard];
        dispatch_async(dispatch_get_main_queue(), ^{
            [busy hide];
            self.working = NO;
            self.diagnostic = report;
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Kiểm tra PosterBoard" message:report preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"Sao chép" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { UIPasteboard.generalPasteboard.string = report; }]];
            [alert addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        });
    });
}

- (void)restoreLastInstall {
    if (self.working) return;
    BQConfirm(self, @"Hoàn tác lần cài gần nhất?", @"Gỡ descriptor của lần cài BadQuery gần nhất có biên nhận; giữ các hình nền có sẵn. PocketPoster/Airlift: xóa hình nền qua Cài đặt iOS.", ^{
        self.working = YES;
        BQBusyView *busy = [BQBusyView showInView:self.view text:@"Đang hoàn tác…"];
        dispatch_async(BQWorkQueue(), ^{
            NSError *error = nil;
            BOOL ok = [TNWallpaperEngine restoreLastInstall:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                [busy hide]; self.working = NO;
                BQAlert(self, ok ? @"Đã hoàn tác" : @"Không thể hoàn tác", ok ? @"Mở PosterBoard rồi vuốt đóng trong đa nhiệm để làm mới Bộ sưu tập." : error.localizedDescription);
            });
        });
    });
}

- (void)wallpaperSetup { if (!self.working) [self.navigationController pushViewController:[[WallpaperSetupVC alloc] init] animated:YES]; }
- (void)openPosterBoard { if (!self.working && !BQOpenPosterBoard()) BQAlert(self, @"Không thể mở", @"Không mở được com.apple.PosterBoard."); }
- (void)explore {
    if (self.working) return;
    TendiesExploreVC *vc = [[TendiesExploreVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)respring { if (!self.working) BQConfirm(self, @"Respring?", @"Khởi động lại SpringBoard để áp dụng thay đổi hình nền.", ^{ BQRespring(); }); }

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView { return 3; }
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section { return section == 0 ? 1 : (section == 1 ? MAX(1, self.files.count) : 8); }
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 1 && self.files.count) {
        TNWallpaperCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"pack" forIndexPath:indexPath];
        NSString *path = self.files[indexPath.item];
        NSDictionary *info = self.metadata[path];
        cell.titleLabel.text = info[@"displayName"] ?: path.lastPathComponent.stringByDeletingPathExtension;
        cell.detailLabel.text = info[@"error"] ? @"Gói không hợp lệ · giữ để xem lỗi" : (info ? [NSString stringWithFormat:@"%@ · %@ hình nền", info[@"providerTitle"], info[@"descriptorCount"]] : @"Đang kiểm tra gói…");
        NSString *preview = info[@"previewPath"];
        UIImage *image = preview.length ? [self.thumbnails objectForKey:preview] : nil;
        if (!image && preview.length) {
            image = [UIImage imageWithContentsOfFile:preview];
            if (image) [self.thumbnails setObject:image forKey:preview];
        }
        cell.imageView.image = image ?: [UIImage systemImageNamed:info[@"error"] ? @"exclamationmark.triangle" : @"photo.on.rectangle.angled"];
        cell.imageView.contentMode = image ? UIViewContentModeScaleAspectFill : UIViewContentModeCenter;
        BOOL selected = [self.selected containsObject:path.lastPathComponent];
        [cell.selectionButton setImage:[UIImage systemImageNamed:selected ? @"checkmark.circle.fill" : @"circle"] forState:UIControlStateNormal];
        cell.selectionButton.accessibilityLabel = [NSString stringWithFormat:@"%@ %@", selected ? @"Bỏ chọn" : @"Chọn", cell.titleLabel.text];
        cell.selectionButton.enabled = !self.working && (selected || (info && !info[@"error"]));
        cell.contentView.layer.borderWidth = selected ? 2 : 0;
        cell.contentView.layer.borderColor = TNAccent().CGColor;
        __weak typeof(self) weakSelf = self;
        cell.onSelect = ^{ [weakSelf togglePath:path]; };
        return cell;
    }
    UICollectionViewListCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"text" forIndexPath:indexPath];
    UIListContentConfiguration *content = [UIListContentConfiguration subtitleCellConfiguration];
    UIBackgroundConfiguration *background = [UIBackgroundConfiguration clearConfiguration];
    background.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    background.cornerRadius = 16;
    cell.accessories = @[];
    content.textProperties.color = UIColor.labelColor;
    content.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    if (indexPath.section == 0) {
        NSInteger count = 0;
        for (NSDictionary *info in self.metadata.allValues) count += [info[@"descriptorCount"] integerValue];
        content.text = @"Wallpaper Studio";
        content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle2];
        content.textProperties.color = UIColor.whiteColor;
        content.secondaryText = [NSString stringWithFormat:@"Nhập .tendies hoặc .zip, xem trước rồi cài vào PosterBoard. Chọn tối đa 5 gói mỗi lần.\n\n%lu gói   ·   %ld hình nền   ·   %lu đã chọn%@", (unsigned long)self.files.count, (long)count, (unsigned long)self.selected.count, self.loading ? @"\nĐang đọc thư viện…" : @""];
        content.secondaryTextProperties.color = [UIColor.whiteColor colorWithAlphaComponent:0.9];
        content.secondaryTextProperties.numberOfLines = 0;
        background.backgroundColor = TNAccent();
    } else if (indexPath.section == 1) {
        content.text = @"Chưa có gói hình nền";
        content.secondaryText = @"Nhấn + để nhập .tendies / .zip hoặc mở Khám phá hình nền bên dưới.";
        content.secondaryTextProperties.numberOfLines = 0;
        content.image = [UIImage systemImageNamed:@"photo.stack"];
    } else {
        NSArray *titles = @[@"Nhập .tendies / .zip", @"Cài các gói đã chọn", @"Khám phá hình nền", @"Kiểm tra PosterBoard", @"Mở PosterBoard", @"Thiết lập hình nền / Pairing", @"Respring", @"Hoàn tác lần cài gần nhất"];
        NSArray *symbols = @[@"square.and.arrow.down", @"checkmark.circle.fill", @"globe", @"stethoscope", @"arrow.up.right.square", @"gearshape", @"arrow.clockwise", @"arrow.uturn.backward"];
        content.text = titles[indexPath.item];
        content.image = [UIImage systemImageNamed:symbols[indexPath.item]];
        content.imageProperties.tintColor = TNAccent();
        content.textProperties.color = indexPath.item == 7 ? UIColor.systemRedColor : TNAccent();
        content.textProperties.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        if (indexPath.item == 1) content.secondaryText = [NSString stringWithFormat:@"%lu / 5 gói", (unsigned long)self.selected.count];
        if (indexPath.item == 5) cell.accessories = @[[UICellAccessoryDisclosureIndicator new]];
    }
    cell.contentConfiguration = content;
    cell.backgroundConfiguration = background;
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    if (self.working) return;
    if (indexPath.section == 1 && self.files.count) { [self previewPath:self.files[indexPath.item]]; return; }
    if (indexPath.section != 2) return;
    switch (indexPath.item) {
        case 0: [self importTendies]; break;
        case 1: [self applySelected]; break;
        case 2: [self explore]; break;
        case 3: [self checkPosterBoard]; break;
        case 4: [self openPosterBoard]; break;
        case 5: [self wallpaperSetup]; break;
        case 6: [self respring]; break;
        case 7: [self restoreLastInstall]; break;
    }
}
- (UIContextMenuConfiguration *)collectionView:(UICollectionView *)collectionView contextMenuConfigurationForItemsAtIndexPaths:(NSArray<NSIndexPath *> *)indexPaths point:(CGPoint)point {
    NSIndexPath *indexPath = indexPaths.firstObject;
    if (self.working || indexPaths.count != 1 || indexPath.section != 1 || indexPath.item >= self.files.count) return nil;
    NSString *path = self.files[indexPath.item];
    __weak typeof(self) weakSelf = self;
    return [UIContextMenuConfiguration configurationWithIdentifier:nil previewProvider:nil actionProvider:^UIMenu *(NSArray<UIMenuElement *> *suggested) {
        UIAction *preview = [UIAction actionWithTitle:@"Xem trước" image:[UIImage systemImageNamed:@"eye"] identifier:nil handler:^(UIAction *a) { [weakSelf previewPath:path]; }];
        UIAction *remove = [UIAction actionWithTitle:@"Xóa gói đã nhập" image:[UIImage systemImageNamed:@"trash"] identifier:nil handler:^(UIAction *a) {
            BQConfirm(weakSelf, @"Xóa gói này?", @"Bản sao đã nhập sẽ bị xóa. Hình nền đã cài vẫn được giữ lại.", ^{ [weakSelf deletePath:path]; });
        }];
        remove.attributes = UIMenuElementAttributesDestructive;
        return [UIMenu menuWithTitle:@"" children:@[preview, remove]];
    }];
}
@end
