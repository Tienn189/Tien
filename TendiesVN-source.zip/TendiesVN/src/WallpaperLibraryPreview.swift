// SPDX-License-Identifier: GPL-3.0-only
// Bounded, persistent previews for validated .tendies packages.
import Foundation
import CoreGraphics
import ImageIO
import AVFoundation
import UniformTypeIdentifiers

enum WallpaperLibraryPreview {
    private static let maximumDimension = 1_000
    private static let previewName = ".1809-preview-v1.jpg"
    private static let noPreviewName = ".1809-preview-v1.none"

    static func make(for package: WallpaperStagedPackage) -> URL? {
        let output = package.packageDirectoryURL.appendingPathComponent(previewName)
        let absent = package.packageDirectoryURL.appendingPathComponent(noPreviewName)
        let files = FileManager.default
        if files.fileExists(atPath: output.path) { return output }
        if files.fileExists(atPath: absent.path) { return nil }
        guard let entries = files.enumerator(
            at: package.extractedURL,
            includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey],
            options: [.skipsHiddenFiles]
        ) else { return nil }
        var images: [(url: URL, score: Int)] = []
        var videos: [(url: URL, size: Int)] = []
        for case let item as URL in entries {
            let values = try? item.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
            guard values?.isRegularFile == true, values?.isSymbolicLink != true else { continue }
            let size = values?.fileSize ?? 0
            let name = item.lastPathComponent.lowercased()
            if ["mov", "mp4", "m4v"].contains(item.pathExtension.lowercased()) {
                videos.append((item, size))
                continue
            }
            guard isImageCandidate(item) else { continue }
            var score = min(size / 20_000, 50)
            if name.contains("wallpaper") { score += 90 }
            if name.contains("preview") { score += 80 }
            if name.contains("backdrop") || name.contains("background") { score += 60 }
            if name.contains("foreground") { score += 40 }
            if name.contains("thumb") { score -= 20 }
            images.append((item, score))
        }
        // Downsample directly through ImageIO, avoiding UIImage's full-size
        // decode of potentially very large HEIC/PNG assets.
        for candidate in images.sorted(by: { $0.score > $1.score }).prefix(32) {
            if let image = thumbnail(at: candidate.url), write(image, to: output) { return output }
        }
        for candidate in videos.sorted(by: { $0.size > $1.size }).prefix(4) {
            let generator = AVAssetImageGenerator(asset: AVURLAsset(url: candidate.url))
            generator.appliesPreferredTrackTransform = true
            generator.maximumSize = CGSize(width: CGFloat(maximumDimension), height: CGFloat(maximumDimension))
            generator.requestedTimeToleranceBefore = CMTime(seconds: 1, preferredTimescale: 600)
            generator.requestedTimeToleranceAfter = CMTime(seconds: 1, preferredTimescale: 600)
            if let image = try? generator.copyCGImage(at: .zero, actualTime: nil),
               write(image, to: output) { return output }
        }
        try? Data().write(to: absent, options: .atomic)
        return nil
    }

    private static func thumbnail(at url: URL) -> CGImage? {
        guard let source = CGImageSourceCreateWithURL(
            url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary
        ) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maximumDimension,
            kCGImageSourceShouldCacheImmediately: true
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    }

    private static func write(_ image: CGImage, to url: URL) -> Bool {
        let temporary = url.deletingLastPathComponent().appendingPathComponent(".preview-\(UUID().uuidString).jpg")
        defer { try? FileManager.default.removeItem(at: temporary) }
        guard let destination = CGImageDestinationCreateWithURL(
            temporary as CFURL, UTType.jpeg.identifier as CFString, 1, nil
        ) else { return false }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.82] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { return false }
        do {
            try FileManager.default.moveItem(at: temporary, to: url)
            return true
        } catch { return false }
    }

    private static func isImageCandidate(_ url: URL) -> Bool {
        if ["jpg", "jpeg", "png", "heic", "heif", "webp", "gif", "avif", "tif", "tiff"].contains(url.pathExtension.lowercased()) {
            return true
        }
        // Several exported wallpaper assets have no filename extension.
        guard let reader = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? reader.close() }
        guard let data = try? reader.read(upToCount: 12), data.count >= 4 else { return false }
        let bytes = [UInt8](data)
        if bytes[0] == 0xFF, bytes[1] == 0xD8 { return true }
        if bytes.starts(with: [0x89, 0x50, 0x4E, 0x47]) { return true }
        if bytes.starts(with: [0x47, 0x49, 0x46]) { return true }
        if bytes.count >= 12, Array(bytes[4..<8]) == [0x66, 0x74, 0x79, 0x70] { return true }
        if bytes.starts(with: [0x52, 0x49, 0x46, 0x46]) { return true }
        return false
    }
}
