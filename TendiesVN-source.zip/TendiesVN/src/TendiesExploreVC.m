#import "TendiesExploreVC.h"
#import "BQCore.h"
#import "BQUI.h"
#import "WallpaperEngine.h"

static NSString * const kCatalogBase = @"https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/";
static NSString * const kCustomCatalog = @"https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/wallpapers-custom.json";
static NSString * const kAppleCatalog = @"https://raw.githubusercontent.com/SerStars/Nugget-Wallpapers/main/wallpapers-apple.json";

@interface TendiesExploreVC ()
@property (nonatomic, strong) NSArray<NSDictionary *> *items;
@property (nonatomic, strong) NSArray<NSDictionary *> *filtered;
@property (nonatomic, strong) UISearchController *search;
@property (nonatomic, assign) BOOL loading;
@property (nonatomic, assign) BOOL working;
@end

@implementation TendiesExploreVC

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Explore Wallpapers", nil);
    self.search = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.search.searchResultsUpdater = self;
    self.search.obscuresBackgroundDuringPresentation = NO;
    self.search.searchBar.placeholder = NSLocalizedString(@"Search wallpapers", nil);
    self.navigationItem.searchController = self.search;
    self.navigationItem.hidesSearchBarWhenScrolling = NO;
    self.definesPresentationContext = YES;

    UIRefreshControl *rc = [[UIRefreshControl alloc] init];
    [rc addTarget:self action:@selector(loadCatalog) forControlEvents:UIControlEventValueChanged];
    self.refreshControl = rc;
    [self loadCatalog];
}

- (void)loadCatalog {
    if (self.loading || self.working) { [self.refreshControl endRefreshing]; return; }
    self.loading = YES;
    dispatch_group_t group = dispatch_group_create();
    __block NSMutableArray *all = [NSMutableArray array];
    __block NSString *firstError = nil;

    void (^fetch)(NSString *) = ^(NSString *urlString) {
        dispatch_group_enter(group);
        NSURL *u = [NSURL URLWithString:urlString];
        [[NSURLSession.sharedSession dataTaskWithURL:u completionHandler:^(NSData *data, NSURLResponse *resp, NSError *error) {
            id obj = data.length ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            @synchronized (all) {
                if ([obj isKindOfClass:[NSArray class]]) {
                    [all addObjectsFromArray:obj];
                } else if (!firstError) {
                    firstError = error.localizedDescription ?: @"catalog is not an array";
                }
            }
            dispatch_group_leave(group);
        }] resume];
    };
    fetch(kCustomCatalog);
    fetch(kAppleCatalog);

    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        self.loading = NO;
        [self.refreshControl endRefreshing];
        NSMutableArray *unique = [NSMutableArray array];
        NSMutableSet *seen = [NSMutableSet set];
        for (id x in all) {
            if (![x isKindOfClass:[NSDictionary class]]) continue;
            NSDictionary *d = x;
            NSString *url = d[@"url"];
            NSString *name = d[@"name"];
            if (![url isKindOfClass:[NSString class]] || !url.length) continue;
            if (![name isKindOfClass:[NSString class]] || !name.length) continue;
            if ([seen containsObject:url]) continue;
            [seen addObject:url];
            NSMutableDictionary *entry = [d mutableCopy];
            if (![entry[@"authors"] isKindOfClass:NSString.class]) entry[@"authors"] = @"";
            if (![entry[@"description"] isKindOfClass:NSString.class]) entry[@"description"] = @"";
            [unique addObject:entry];
        }
        [unique sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
            return [a[@"name"] localizedCaseInsensitiveCompare:b[@"name"]];
        }];
        self.items = unique;
        self.filtered = unique;
        [self.tableView reloadData];
        if (firstError && unique.count == 0) BQAlert(self, NSLocalizedString(@"Catalog failed", nil), firstError);
        BQLog(@"tendies catalog: %lu entries", (unsigned long)unique.count);
    });
}

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController {
    NSString *q = searchController.searchBar.text ?: @"";
    if (!q.length) { self.filtered = self.items; [self.tableView reloadData]; return; }
    NSMutableArray *a = [NSMutableArray array];
    for (NSDictionary *d in self.items) {
        NSString *name = d[@"name"] ?: @"";
        NSString *desc = d[@"description"] ?: @"";
        NSString *authors = d[@"authors"] ?: @"";
        if ([name localizedCaseInsensitiveContainsString:q] ||
            [desc localizedCaseInsensitiveContainsString:q] ||
            [authors localizedCaseInsensitiveContainsString:q]) {
            [a addObject:d];
        }
    }
    self.filtered = a;
    [self.tableView reloadData];
}

- (void)setWorking:(BOOL)working {
    _working = working;
    self.tableView.userInteractionEnabled = !working;
    self.navigationItem.hidesBackButton = working;
}

- (void)applyDownloadedPath:(NSString *)path {
    if (self.working) return;
    if (![TNWallpaperEngine installationSupported] || ![TNWallpaperEngine installationReady]) {
        BQAlert(self, @"Thiết lập hình nền", [TNWallpaperEngine compatibilitySummary]);
        return;
    }
    self.working = YES;
    BQBusyView *work = [BQBusyView showInView:self.view text:NSLocalizedString(@"Applying wallpaper...", nil)];
    dispatch_async(BQWorkQueue(), ^{
        NSString *err = nil;
        int count = 0;
        BOOL ok = BQApplyTendies([NSURL fileURLWithPath:path], &count, &err);
        dispatch_async(dispatch_get_main_queue(), ^{
            [work hide];
            self.working = NO;
            if (!ok) { BQAlert(self, NSLocalizedString(@"Apply failed", nil), err ?: NSLocalizedString(@"unknown error", nil)); return; }
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Applied", nil)
                                                                         message:[NSString stringWithFormat:NSLocalizedString(@"%d descriptor(s) written. Open PosterBoard and close it from the App Switcher, or respring.", nil), count]
                                                                  preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Open PosterBoard", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                if (!BQOpenPosterBoard()) BQAlert(self, NSLocalizedString(@"Open failed", nil), NSLocalizedString(@"Could not open PosterBoard.", nil));
            }]];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Respring", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) { BQRespring(); }]];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
        });
    });
}

- (void)download:(NSDictionary *)item {
    if (self.working) return;
    NSString *relative = item[@"url"];
    NSURL *url = [NSURL URLWithString:[kCatalogBase stringByAppendingString:relative]];
    if (!url || ![url.scheme isEqualToString:@"https"]) {
        BQAlert(self, NSLocalizedString(@"Download failed", nil), @"Địa chỉ tải không hợp lệ.");
        return;
    }
    NSString *name = item[@"name"] ?: relative.lastPathComponent;
    self.working = YES;
    BQBusyView *busy = [BQBusyView showInView:self.view text:[NSString stringWithFormat:NSLocalizedString(@"Downloading %@...", nil), name]];
    [[NSURLSession.sharedSession dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [busy hide];
            self.working = NO;
            NSInteger status = [response isKindOfClass:NSHTTPURLResponse.class] ? ((NSHTTPURLResponse *)response).statusCode : 0;
            if (error || data.length == 0 || status < 200 || status >= 300) {
                NSString *detail = error.localizedDescription ?: [NSString stringWithFormat:@"HTTP %ld", (long)status];
                BQAlert(self, NSLocalizedString(@"Download failed", nil), detail);
                return;
            }
            // Check the ZIP signature before adding a response to the library.
            const unsigned char *bytes = data.bytes;
            if (data.length < 4 || bytes[0] != 'P' || bytes[1] != 'K') {
                BQAlert(self, NSLocalizedString(@"Download failed", nil), @"Máy chủ không trả về gói .tendies/ZIP.");
                return;
            }
            NSString *directory = [BQDocuments() stringByAppendingPathComponent:@"tendies"];
            [[NSFileManager defaultManager] createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];
            NSString *leaf = relative.lastPathComponent.length ? relative.lastPathComponent : @"wallpaper.tendies";
            if (![leaf.pathExtension.lowercaseString isEqualToString:@"tendies"] && ![leaf.pathExtension.lowercaseString isEqualToString:@"zip"]) leaf = [leaf stringByAppendingPathExtension:@"tendies"];
            NSString *destination = [directory stringByAppendingPathComponent:leaf];
            if ([[NSFileManager defaultManager] fileExistsAtPath:destination]) {
                destination = [directory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", NSUUID.UUID.UUIDString, leaf]];
            }
            NSError *saveError = nil;
            if (![data writeToURL:[NSURL fileURLWithPath:destination] options:NSDataWritingAtomic error:&saveError]) {
                BQAlert(self, NSLocalizedString(@"Save failed", nil), saveError.localizedDescription ?: @"write error");
                return;
            }
            BQLog(@"downloaded wallpaper (%lu bytes)", (unsigned long)data.length);
            if (self.onDownload) self.onDownload();
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Downloaded", nil)
                                                                         message:[NSString stringWithFormat:NSLocalizedString(@"%@ saved to Documents/tendies.\nApply now?", nil), name]
                                                                  preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Apply now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self applyDownloadedPath:destination];
            }]];
            [self presentViewController:alert animated:YES completion:nil];
        });
    }] resume];
}

#pragma mark - Table

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 1; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.filtered.count; }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"item"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"item"];
    NSDictionary *d = self.filtered[indexPath.row];
    cell.textLabel.text = d[@"name"];
    NSString *authors = d[@"authors"];
    NSString *desc = d[@"description"];
    cell.detailTextLabel.text = authors.length ? authors : (desc.length ? desc : @"");
    cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
    cell.detailTextLabel.numberOfLines = 2;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return NSLocalizedString(@"Catalog: SerStars/Nugget-Wallpapers. Downloads are saved to Documents/tendies.", nil);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (!self.working) [self download:self.filtered[indexPath.row]];
}

@end
