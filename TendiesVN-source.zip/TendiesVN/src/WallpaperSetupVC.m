#import "WallpaperSetupVC.h"
#import "WallpaperEngine.h"
#import "BQCore.h"
#import "BQUI.h"

@interface WallpaperSetupVC ()
@property (nonatomic, assign) BOOL importing;
@end

@implementation WallpaperSetupVC

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Thiết lập hình nền";
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == 0 ? 1 : (section == 1 ? 3 : 1);
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @[@"Hỗ trợ thiết bị", @"Airlift · iOS 27.0–27.0.1", @"PocketPoster · iOS 17–18"][section];
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return [[TNWallpaperEngine compatibilitySummary] stringByAppendingString:@"\n\nPhạm vi theo mã nguồn: iOS 17.0–17.7, 18.0–18.7.1, 26.0–26.6.1, 27.0–27.0.1. BadQuery trên iOS 27 chỉ nhận đúng build beta; các bản 27.0/27.0.1 còn lại dùng Airlift. Đây là phạm vi backend của nguồn, chưa phải kết quả thử trên mọi thiết bị."];
    if (section == 1) {
        return @"Trên bản iOS 27 dùng Airlift: bật LocalDevVPN, cài ứng dụng Sách của Apple và mở Sách ít nhất một lần. Nhập hồ sơ pairing của chính thiết bị này (.mobiledevicepairing, .mobilepair hoặc .plist). Giữ thiết bị mở khóa khi cài. Địa chỉ mặc định là 10.7.0.1; chỉ đổi nếu cấu hình VPN của bạn dùng địa chỉ khác.";
    }
    return @"App tự tìm container PosterBoard khi cài lần đầu trên iOS 17–18. Có thể nhập UUID container thủ công làm phương án dự phòng. Để trống để xóa giá trị đã lưu và tự tìm lại.";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"setup"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"setup"];
    cell.detailTextLabel.numberOfLines = 0;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.textLabel.textColor = self.view.tintColor;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if (indexPath.section == 0) {
        cell.textLabel.text = [TNWallpaperEngine installationReady] ? @"Sẵn sàng cài hình nền" : ([TNWallpaperEngine installationSupported] ? @"Cần thiết lập" : @"Chưa có bộ cài phù hợp");
        cell.detailTextLabel.text = [NSString stringWithFormat:@"iOS %@ · %@", UIDevice.currentDevice.systemVersion,
                                     [TNWallpaperEngine usesAirlift] ? @"Airlift" : ([TNWallpaperEngine usesLegacy] ? @"3105 / PocketPoster" : ([TNWallpaperEngine installationSupported] ? @"BadQuery" : @"Chưa có bộ cài"))];
        cell.textLabel.textColor = UIColor.labelColor;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    } else if (indexPath.section == 1) {
        cell.textLabel.text = @[@"Nhập hồ sơ pairing", @"Địa chỉ thiết bị qua VPN", @"Xóa hồ sơ pairing"][indexPath.row];
        if (indexPath.row == 0) cell.detailTextLabel.text = [TNWallpaperEngine hasPairing] ? @"Đã lưu hồ sơ · thay thế bằng tệp khác" : @"Chọn tệp trong ứng dụng Tệp";
        if (indexPath.row == 1) cell.detailTextLabel.text = [TNWallpaperEngine targetHost];
        if (indexPath.row == 2) {
            cell.detailTextLabel.text = [TNWallpaperEngine hasPairing] ? @"Gỡ bản sao riêng trong app" : @"Chưa có hồ sơ";
            cell.textLabel.textColor = UIColor.systemRedColor;
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
    } else {
        cell.textLabel.text = @"UUID container PosterBoard";
        NSString *identifier = [TNWallpaperEngine legacyContainerID];
        cell.detailTextLabel.text = identifier.length ? identifier : @"Tự động tìm trên thiết bị";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.importing) return;
    if (indexPath.section == 1 && indexPath.row == 0) {
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
        picker.delegate = self;
        picker.allowsMultipleSelection = NO;
        [self presentViewController:picker animated:YES completion:nil];
    } else if (indexPath.section == 1 && indexPath.row == 1) {
        [self editValueWithTitle:@"Địa chỉ thiết bị qua VPN"
                       message:@"Nhập địa chỉ IPv4 mà LocalDevVPN cung cấp, thường là 10.7.0.1."
                         value:[TNWallpaperEngine targetHost]
                    placeholder:@"10.7.0.1"
                         legacy:NO];
    } else if (indexPath.section == 1 && indexPath.row == 2) {
        if (![TNWallpaperEngine hasPairing]) return;
        BQConfirm(self, @"Xóa hồ sơ pairing?", @"Bạn cần nhập lại hồ sơ để dùng Airlift.", ^{
            [TNWallpaperEngine removePairing];
            [self.tableView reloadData];
        });
    } else if (indexPath.section == 2) {
        [self editValueWithTitle:@"UUID container PosterBoard"
                       message:@"Chỉ nhập UUID của container com.apple.PosterBoard trên thiết bị này. Để trống để tự tìm lại."
                         value:[TNWallpaperEngine legacyContainerID]
                   placeholder:@"XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
                        legacy:YES];
    }
}

- (void)editValueWithTitle:(NSString *)title message:(NSString *)message value:(NSString *)value placeholder:(NSString *)placeholder legacy:(BOOL)legacy {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.text = value;
        field.placeholder = placeholder;
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.spellCheckingType = UITextSpellCheckingTypeNo;
        field.keyboardType = UIKeyboardTypeASCIICapable;
    }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Lưu" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSError *error = nil;
        NSString *text = alert.textFields.firstObject.text ?: @"";
        BOOL saved = legacy ? [TNWallpaperEngine setLegacyContainerID:text error:&error] : [TNWallpaperEngine setTargetHost:text error:&error];
        if (!saved) BQAlert(self, @"Không thể lưu", error.localizedDescription ?: @"Giá trị không hợp lệ.");
        [self.tableView reloadData];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject;
    if (!url || self.importing) return;
    self.importing = YES;
    self.tableView.userInteractionEnabled = NO;
    BQBusyView *busy = [BQBusyView showInView:self.view text:@"Đang nhập pairing..."];
    dispatch_async(BQWorkQueue(), ^{
        NSError *error = nil;
        BOOL ok = [TNWallpaperEngine importPairingURL:url error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [busy hide];
            self.importing = NO;
            self.tableView.userInteractionEnabled = YES;
            [self.tableView reloadData];
            BQAlert(self, ok ? @"Đã nhập hồ sơ" : @"Nhập pairing thất bại",
                    ok ? @"Hồ sơ đã được lưu riêng trong app. Airlift sẽ xác thực kết nối khi bạn cài hình nền." : (error.localizedDescription ?: @"Hồ sơ pairing không hợp lệ."));
        });
    });
}

@end
