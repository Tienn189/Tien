// SPDX-License-Identifier: GPL-3.0-only
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
// Implemented by WallpaperEngine.swift. Do not import this declaration into
// Swift's bridging header: the Swift class supplies the Objective-C runtime API.
@interface TNWallpaperEngine : NSObject
+ (NSString *)compatibilitySummary;
+ (BOOL)installationSupported;
+ (BOOL)installationReady;
+ (BOOL)usesAirlift;
+ (BOOL)usesLegacy;
+ (BOOL)hasPairing;
+ (NSString *)targetHost;
+ (BOOL)setTargetHost:(NSString *)host error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)importPairingURL:(NSURL *)url error:(NSError * _Nullable * _Nullable)error;
+ (void)removePairing;
+ (NSString *)legacyContainerID;
+ (BOOL)setLegacyContainerID:(NSString *)value error:(NSError * _Nullable * _Nullable)error;
// Blocking mutations. Call on BQWorkQueue, never on the main thread.
+ (BOOL)applyURL:(NSURL *)url count:(NSInteger * _Nullable)count error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)restoreLastInstall:(NSError * _Nullable * _Nullable)error;
+ (BOOL)canRestore;
@end
NS_ASSUME_NONNULL_END
