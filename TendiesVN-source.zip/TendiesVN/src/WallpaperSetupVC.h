#pragma once
#import <UIKit/UIKit.h>

@interface WallpaperSetupVC : UITableViewController <UIDocumentPickerDelegate>
@end
