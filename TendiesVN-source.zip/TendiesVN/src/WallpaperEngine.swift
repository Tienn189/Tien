// SPDX-License-Identifier: GPL-3.0-only
// Host adapter for the TendiesVN wallpaper engine. Upstream implementation and
// source provenance are preserved in vendor/TendiesWallpaper.
import Foundation
import Darwin
import CryptoKit

@objc(TNWallpaperEngine)
final class TNWallpaperEngine: NSObject {
    // The imported engines retain process-wide state and perform filesystem
    // mutations. Serialize settings/imports with installs, including callers
    // outside the existing Objective-C work queue.
    private static let mutationLock = NSRecursiveLock()
    private static let hostKey = "1809.pairing.deviceIP"
    private static let libraryIndexKey = "1809.wallpaper.library.v1"
    private static let libraryIdentityPrefix = "1809.library:"
    private struct LibraryRecord: Codable {
        let signature: String
        let packageID: UUID
    }
    private static var libraryIndex: [String: LibraryRecord]?
    private static var libraryPackages: [UUID: WallpaperStagedPackage] = [:]

    private static func failure(_ message: String) -> NSError {
        NSError(domain: "1809.Wallpaper", code: 1,
                userInfo: [NSLocalizedDescriptionKey: message])
    }

    @objc class func installationSupported() -> Bool { DeviceCompatibility.installationSupported }
    @objc class func installationReady() -> Bool { DeviceCompatibility.installationReady }
    @objc class func usesAirlift() -> Bool { AirliftWallpaperService.shouldUse }
    @objc class func usesLegacy() -> Bool { PocketPosterWallpaperService.shouldUse }
    @objc class func hasPairing() -> Bool { AirliftPairingStore.hasPairing }

    @objc class func compatibilitySummary() -> String {
        let version = DeviceCompatibility.osVersionText
        let route: String
        if DeviceCompatibility.isSimulator {
            route = "Chỉ quản lý gói trên Simulator; cần iPhone/iPad thật để cài."
        } else if DeviceCompatibility.directInstallationSupported {
            route = "BadQuery · tự nhận diện kho PosterBoard và kiểm tra quyền ghi khi cài."
        } else if usesLegacy() {
            route = "3105/PocketPoster · tự tìm container trên thiết bị."
        } else if usesAirlift() {
            route = hasPairing()
                ? "Airlift · đã lưu pairing; kết nối sẽ được xác thực khi cài."
                : "Airlift · cần nhập hồ sơ pairing trong Thiết lập hình nền."
        } else {
            route = "Chưa có bộ cài hình nền cho phiên bản/build này; vẫn có thể nhập và tải gói."
        }
        return "\(version)\n\(route)"
    }

    @objc class func targetHost() -> String {
        UserDefaults.standard.string(forKey: hostKey) ?? "10.7.0.1"
    }

    @objc(setTargetHost:error:)
    class func setTargetHost(_ host: String, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        let value = host.trimmingCharacters(in: .whitespacesAndNewlines)
        // Airlift's Rust connector parses Ipv4Addr and ignores other strings.
        var ipv4 = in_addr()
        guard value.withCString({ inet_pton(AF_INET, $0, &ipv4) == 1 }) else {
            errorOut?.pointee = failure("Nhập địa chỉ IPv4 hợp lệ, không kèm http:// hay cổng. Mặc định LocalDevVPN: 10.7.0.1.")
            return false
        }
        UserDefaults.standard.set(value, forKey: hostKey)
        return true
    }

    @objc(importPairingURL:error:)
    class func importPairingURL(_ url: URL, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        do {
            guard url.isFileURL, ["plist", "mobiledevicepairing", "mobilepair"].contains(url.pathExtension.lowercased()) else {
                throw PairingImportError.invalidFile
            }
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            var coordinationError: NSError?
            var readError: Error?
            var data: Data?
            NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { accessible in
                do {
                    let handle = try FileHandle(forReadingFrom: accessible)
                    defer { try? handle.close() }
                    data = try handle.read(upToCount: PairingRecordValidator.maximumBytes + 1)
                } catch { readError = error }
            }
            if let readError { throw readError }
            if let coordinationError { throw coordinationError }
            guard let data else { throw PairingImportError.invalidRecord }
            _ = try PairingRecordValidator.validate(data)
            // Match upstream Airlift: it consumes the original validated plist,
            // while nativeData() is only for the separate idevice transport.
            try AirliftPairingStore.save(data)
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            var pairingURL = AirliftPairingStore.pairingURL
            try pairingURL.setResourceValues(values)
            try FileManager.default.setAttributes(
                [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                ofItemAtPath: pairingURL.path
            )
            UserDefaults.standard.set(false, forKey: "1809.pairing.verified")
            return true
        } catch {
            errorOut?.pointee = error as NSError
            return false
        }
    }

    @objc class func removePairing() {
        mutationLock.lock(); defer { mutationLock.unlock() }
        AirliftPairingStore.remove()
        UserDefaults.standard.removeObject(forKey: "1809.pairing.verified")
    }

    @objc class func legacyContainerID() -> String { PocketPosterConfiguration.appHash ?? "" }

    @objc(setLegacyContainerID:error:)
    class func setLegacyContainerID(_ value: String, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        do {
            if value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                PocketPosterConfiguration.clearAppHash()
            } else {
                try PocketPosterConfiguration.saveAppHash(value)
            }
            return true
        } catch {
            errorOut?.pointee = error as NSError
            return false
        }
    }

    // The archive remains the source of truth. Keep one extracted, validated
    // copy per source path and file identity so opening previews and applying
    // the same pack does not repeatedly unpack hundreds of megabytes.
    private static func archiveSignature(_ url: URL) throws -> String {
        guard url.isFileURL else { throw WallpaperLabError.unsupportedPackage }
        var information = stat()
        guard lstat(url.path, &information) == 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        guard information.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG),
              information.st_size >= 22 else {
            throw WallpaperLabError.unsupportedPackage
        }
        guard information.st_size <= WallpaperLabLimits.maximumArchiveBytes else {
            throw WallpaperLabError.packageTooLarge
        }
        // Files providers can preserve modification dates when overwriting an
        // archive. Nanosecond change time also detects that in-place edit.
        return "\(information.st_dev):\(information.st_ino):\(information.st_size):\(information.st_mtimespec.tv_sec):\(information.st_mtimespec.tv_nsec):\(information.st_ctimespec.tv_sec):\(information.st_ctimespec.tv_nsec)"
    }

    private static func saveLibraryIndex() {
        if let data = try? PropertyListEncoder().encode(libraryIndex ?? [:]) {
            UserDefaults.standard.set(data, forKey: libraryIndexKey)
        }
    }

    private static func loadLibraryIfNeeded() {
        guard libraryIndex == nil else { return }
        let data = UserDefaults.standard.data(forKey: libraryIndexKey)
        libraryIndex = data.flatMap { try? PropertyListDecoder().decode([String: LibraryRecord].self, from: $0) } ?? [:]
        let packages = WallpaperPackageStore.packages()
        for package in packages where package.repositoryIdentity?.hasPrefix(libraryIdentityPrefix) == true {
            libraryPackages[package.id] = package
        }
        pruneMissingLibrarySources()
    }

    private static func pruneMissingLibrarySources() {
        // Recover after an interrupted import/delete, and discard extracted
        // copies whose original archive was removed through Files.
        var changed = false
        for (path, record) in libraryIndex ?? [:] {
            if !FileManager.default.fileExists(atPath: path) || libraryPackages[record.packageID] == nil {
                libraryIndex?.removeValue(forKey: path)
                changed = true
            }
        }
        let retainedIDs = Set((libraryIndex ?? [:]).values.map(\.packageID))
        for package in Array(libraryPackages.values) where !retainedIDs.contains(package.id) {
            try? WallpaperPackageStore.delete(package)
            libraryPackages.removeValue(forKey: package.id)
            changed = true
        }
        if changed { saveLibraryIndex() }
    }

    private static func cachedPackage(for rawURL: URL) throws -> WallpaperStagedPackage {
        let url = rawURL.standardizedFileURL
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        loadLibraryIfNeeded()
        pruneMissingLibrarySources()
        let signature = try archiveSignature(url)
        if let record = libraryIndex?[url.path], record.signature == signature,
           let package = libraryPackages[record.packageID],
           FileManager.default.fileExists(atPath: package.extractedURL.path) {
            return package
        }
        // A changed file at the same path replaces its old cache only after
        // the new archive has passed extraction and descriptor validation.
        let identity = libraryIdentityPrefix + SHA256.hash(data: Data(url.path.utf8)).map { String(format: "%02x", $0) }.joined()
        let package = try WallpaperPackageStore.importPackage(from: url, repositoryIdentity: identity)
        guard (try? archiveSignature(url)) == signature else {
            try? WallpaperPackageStore.delete(package)
            throw failure("Tệp đã thay đổi trong khi nhập. Hãy thử nhập lại.")
        }
        if let old = libraryIndex?[url.path], let oldPackage = libraryPackages.removeValue(forKey: old.packageID) {
            try? WallpaperPackageStore.delete(oldPackage)
        }
        libraryPackages[package.id] = package
        libraryIndex?[url.path] = LibraryRecord(signature: signature, packageID: package.id)
        saveLibraryIndex()
        return package
    }

    @objc(packageInfoForURL:error:)
    class func packageInfoForURL(_ url: URL, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> [String: Any]? {
        mutationLock.lock(); defer { mutationLock.unlock() }
        guard !Thread.isMainThread else {
            errorOut?.pointee = failure("Đọc gói hình nền phải chạy trên hàng đợi nền.")
            return nil
        }
        do {
            let package = try cachedPackage(for: url)
            let providers = Set(package.payload.descriptors.map { descriptor -> String in
                let identifier = descriptor.extensionIdentifier.lowercased()
                if identifier.contains("photos") { return "Ảnh & Video" }
                if identifier.contains("mercury") { return "Mercury Poster" }
                if identifier.contains("collectionsposter") { return "Collections" }
                return descriptor.extensionIdentifier
            }).sorted()
            var info: [String: Any] = [
                "displayName": package.displayName,
                "descriptorCount": package.payload.descriptors.count,
                "providerTitle": providers.joined(separator: " · "),
                "expandedBytes": package.statistics.expandedBytes
            ]
            if let preview = WallpaperLibraryPreview.make(for: package) { info["previewPath"] = preview.path }
            return info
        } catch {
            errorOut?.pointee = error as NSError
            return nil
        }
    }

    @objc(removeCachedPackageForURL:)
    class func removeCachedPackageForURL(_ rawURL: URL) {
        mutationLock.lock(); defer { mutationLock.unlock() }
        loadLibraryIfNeeded()
        if let record = libraryIndex?.removeValue(forKey: rawURL.standardizedFileURL.path),
           let package = libraryPackages.removeValue(forKey: record.packageID) {
            try? WallpaperPackageStore.delete(package)
        }
        saveLibraryIndex()
    }

    @objc class func checkPosterBoard() -> String {
        mutationLock.lock(); defer { mutationLock.unlock() }
        guard !Thread.isMainThread else { return "Chạy kiểm tra PosterBoard trên hàng đợi nền." }
        var lines = [compatibilitySummary()]
        guard installationSupported() else { return lines.joined(separator: "\n\n") }
        if usesAirlift() {
            lines += ["Địa chỉ VPN: \(targetHost())", hasPairing() ? "Đã lưu hồ sơ pairing." : "Chưa nhập hồ sơ pairing.",
                      "Airlift xác thực kết nối và quyền ghi khi cài. Bật LocalDevVPN và giữ thiết bị mở khóa."]
            return lines.joined(separator: "\n\n")
        }
        do {
            let report = try WallpaperDeviceAccessService.report()
            lines += ["Kho: \(report.layout.storeURL.path)", "Generation: \(report.layout.generation)",
                      "\(report.descriptorCount) descriptor · \(report.customDescriptorCount) tùy chỉnh",
                      report.canInstall ? "Có thể cài hình nền." : "Chưa có quyền ghi cho bộ cài."]
            lines += report.layout.extensionDescriptorDirectories.keys.sorted()
            if !report.deniedExtensionIdentifiers.isEmpty {
                lines.append("Không thể ghi: " + report.deniedExtensionIdentifiers.joined(separator: ", "))
            }
        } catch { lines.append(error.localizedDescription) }
        return lines.joined(separator: "\n\n")
    }

    @objc(applyURL:count:error:)
    class func applyURL(_ url: URL, count: UnsafeMutablePointer<Int>?, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        count?.pointee = 0
        guard installationSupported() else {
            errorOut?.pointee = failure("Phiên bản/build này chưa có bộ cài hình nền. Xem Thiết lập hình nền để biết phạm vi hỗ trợ.")
            return false
        }
        guard installationReady() else {
            errorOut?.pointee = failure("Hãy nhập hồ sơ pairing của thiết bị trong Thiết lập hình nền, bật LocalDevVPN và mở khoá thiết bị trước khi cài.")
            return false
        }
        guard !Thread.isMainThread else {
            errorOut?.pointee = failure("Bộ cài phải chạy trên hàng đợi nền.")
            return false
        }
        do {
            let package = try cachedPackage(for: url)
            _ = try WallpaperDeviceAccessService.install(package)
            count?.pointee = package.payload.descriptors.count
            return true
        } catch {
            if usesAirlift() || usesLegacy() {
                errorOut?.pointee = failure(error.localizedDescription + "\nNếu lỗi xảy ra giữa lúc ghi, một phần gói có thể đã được cài. Kiểm tra PosterBoard trước khi thử lại.")
            } else {
                errorOut?.pointee = error as NSError
            }
            return false
        }
    }

    @objc class func canRestore() -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        return DeviceCompatibility.directInstallationSupported && WallpaperDeviceAccessService.receipts().contains {
            $0.status == .installed || $0.status == .preparing
        }
    }

    @objc(restoreLastInstall:)
    class func restoreLastInstall(_ errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        guard !Thread.isMainThread, DeviceCompatibility.directInstallationSupported else {
            errorOut?.pointee = failure("Khôi phục bằng biên nhận chỉ hỗ trợ các lần cài BadQuery của bộ cài mới. PocketPoster/Airlift: xoá hình nền trong Cài đặt iOS.")
            return false
        }
        do {
            guard let receipt = WallpaperDeviceAccessService.receipts().first(where: {
                $0.status == .installed || $0.status == .preparing
            }) else { throw WallpaperLabError.restoreFailed }
            _ = try WallpaperDeviceAccessService.restore(receipt: receipt)
            return true
        } catch {
            errorOut?.pointee = error as NSError
            return false
        }
    }
}
