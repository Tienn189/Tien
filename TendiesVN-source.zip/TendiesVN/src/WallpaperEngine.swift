// SPDX-License-Identifier: GPL-3.0-only
// Host adapter for the TendiesVN wallpaper engine. Upstream implementation and
// source provenance are preserved in vendor/TendiesWallpaper.
import Foundation
import Darwin

@objc(TNWallpaperEngine)
final class TNWallpaperEngine: NSObject {
    // The imported engines retain process-wide state and perform filesystem
    // mutations. Serialize settings/imports with installs, including callers
    // outside the existing Objective-C work queue.
    private static let mutationLock = NSRecursiveLock()
    private static let hostKey = "1809.pairing.deviceIP"

    private static func failure(_ message: String) -> NSError {
        NSError(domain: "1809.Wallpaper", code: 1,
                userInfo: [NSLocalizedDescriptionKey: message])
    }

    @objc class func installationSupported() -> Bool { DeviceCompatibility.installationSupported }
    @objc class func installationReady() -> Bool { DeviceCompatibility.installationReady }
    @objc class func usesAirlift() -> Bool { AirliftWallpaperService.shouldUse }
    @objc class func usesLegacy() -> Bool { PocketPosterWallpaperService.shouldUse }
    @objc class func hasPairing() -> Bool { AirliftPairingStore.hasPairing }

    @objc class func compatibilitySummary() -> String {
        let version = DeviceCompatibility.osVersionText
        let route: String
        if DeviceCompatibility.isSimulator {
            route = "Chỉ quản lý gói trên Simulator; cần iPhone/iPad thật để cài."
        } else if DeviceCompatibility.directInstallationSupported {
            route = "BadQuery · tự nhận diện kho PosterBoard và kiểm tra quyền ghi khi cài."
        } else if usesLegacy() {
            route = "3105/PocketPoster · tự tìm container trên thiết bị."
        } else if usesAirlift() {
            route = hasPairing()
                ? "Airlift · đã lưu pairing; kết nối sẽ được xác thực khi cài."
                : "Airlift · cần nhập hồ sơ pairing trong Thiết lập hình nền."
        } else {
            route = "Chưa có bộ cài hình nền cho phiên bản/build này; vẫn có thể nhập và tải gói."
        }
        return "\(version)\n\(route)"
    }

    @objc class func targetHost() -> String {
        UserDefaults.standard.string(forKey: hostKey) ?? "10.7.0.1"
    }

    @objc(setTargetHost:error:)
    class func setTargetHost(_ host: String, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        let value = host.trimmingCharacters(in: .whitespacesAndNewlines)
        // Airlift's Rust connector parses Ipv4Addr and ignores other strings.
        var ipv4 = in_addr()
        guard value.withCString({ inet_pton(AF_INET, $0, &ipv4) == 1 }) else {
            errorOut?.pointee = failure("Nhập địa chỉ IPv4 hợp lệ, không kèm http:// hay cổng. Mặc định LocalDevVPN: 10.7.0.1.")
            return false
        }
        UserDefaults.standard.set(value, forKey: hostKey)
        return true
    }

    @objc(importPairingURL:error:)
    class func importPairingURL(_ url: URL, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        do {
            guard url.isFileURL, ["plist", "mobiledevicepairing", "mobilepair"].contains(url.pathExtension.lowercased()) else {
                throw PairingImportError.invalidFile
            }
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            var coordinationError: NSError?
            var readError: Error?
            var data: Data?
            NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { accessible in
                do {
                    let handle = try FileHandle(forReadingFrom: accessible)
                    defer { try? handle.close() }
                    data = try handle.read(upToCount: PairingRecordValidator.maximumBytes + 1)
                } catch { readError = error }
            }
            if let readError { throw readError }
            if let coordinationError { throw coordinationError }
            guard let data else { throw PairingImportError.invalidRecord }
            _ = try PairingRecordValidator.validate(data)
            // Match upstream Airlift: it consumes the original validated plist,
            // while nativeData() is only for the separate idevice transport.
            try AirliftPairingStore.save(data)
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            var pairingURL = AirliftPairingStore.pairingURL
            try pairingURL.setResourceValues(values)
            try FileManager.default.setAttributes(
                [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication],
                ofItemAtPath: pairingURL.path
            )
            UserDefaults.standard.set(false, forKey: "1809.pairing.verified")
            return true
        } catch {
            errorOut?.pointee = error as NSError
            return false
        }
    }

    @objc class func removePairing() {
        mutationLock.lock(); defer { mutationLock.unlock() }
        AirliftPairingStore.remove()
        UserDefaults.standard.removeObject(forKey: "1809.pairing.verified")
    }

    @objc class func legacyContainerID() -> String { PocketPosterConfiguration.appHash ?? "" }

    @objc(setLegacyContainerID:error:)
    class func setLegacyContainerID(_ value: String, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        do {
            if value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                PocketPosterConfiguration.clearAppHash()
            } else {
                try PocketPosterConfiguration.saveAppHash(value)
            }
            return true
        } catch {
            errorOut?.pointee = error as NSError
            return false
        }
    }

    @objc(applyURL:count:error:)
    class func applyURL(_ url: URL, count: UnsafeMutablePointer<Int>?, error errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        count?.pointee = 0
        guard installationSupported() else {
            errorOut?.pointee = failure("Phiên bản/build này chưa có bộ cài hình nền. Xem Thiết lập hình nền để biết phạm vi hỗ trợ.")
            return false
        }
        guard installationReady() else {
            errorOut?.pointee = failure("Hãy nhập hồ sơ pairing của thiết bị trong Thiết lập hình nền, bật LocalDevVPN và mở khoá thiết bị trước khi cài.")
            return false
        }
        guard !Thread.isMainThread else {
            errorOut?.pointee = failure("Bộ cài phải chạy trên hàng đợi nền.")
            return false
        }
        do {
            let package = try WallpaperPackageStore.importPackage(from: url)
            // The host already owns the original pack in Documents/tendies.
            // Receipts have their own durable store and survive staging cleanup.
            defer { try? WallpaperPackageStore.delete(package) }
            _ = try WallpaperDeviceAccessService.install(package)
            count?.pointee = package.payload.descriptors.count
            return true
        } catch {
            if usesAirlift() || usesLegacy() {
                errorOut?.pointee = failure(error.localizedDescription + "\nNếu lỗi xảy ra giữa lúc ghi, một phần gói có thể đã được cài. Kiểm tra PosterBoard trước khi thử lại.")
            } else {
                errorOut?.pointee = error as NSError
            }
            return false
        }
    }

    @objc class func canRestore() -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        return DeviceCompatibility.directInstallationSupported && WallpaperDeviceAccessService.receipts().contains {
            $0.status == .installed || $0.status == .preparing
        }
    }

    @objc(restoreLastInstall:)
    class func restoreLastInstall(_ errorOut: AutoreleasingUnsafeMutablePointer<NSError?>?) -> Bool {
        mutationLock.lock(); defer { mutationLock.unlock() }
        guard !Thread.isMainThread, DeviceCompatibility.directInstallationSupported else {
            errorOut?.pointee = failure("Khôi phục bằng biên nhận chỉ hỗ trợ các lần cài BadQuery của bộ cài mới. PocketPoster/Airlift: xoá hình nền trong Cài đặt iOS.")
            return false
        }
        do {
            guard let receipt = WallpaperDeviceAccessService.receipts().first(where: {
                $0.status == .installed || $0.status == .preparing
            }) else { throw WallpaperLabError.restoreFailed }
            _ = try WallpaperDeviceAccessService.restore(receipt: receipt)
            return true
        } catch {
            errorOut?.pointee = error as NSError
            return false
        }
    }
}
