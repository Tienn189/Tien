#!/usr/bin/env bash
# Build the complete Objective-C + Swift app and package an unsigned IPA.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT/scripts/build-unsigned.sh" "$@"
