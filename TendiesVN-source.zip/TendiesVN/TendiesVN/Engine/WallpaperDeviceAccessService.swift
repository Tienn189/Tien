// SPDX-License-Identifier: GPL-3.0-only
// Restored from 1809 build 14; adapted from 3105 (YangJiii and contributors).
// Fixed PosterBoard scope; no general-purpose filesystem API.
import Foundation
import Darwin

struct WallpaperAccessReport: Equatable {
    let layout: WallpaperPosterLayout
    let descriptorCount: Int
    let customDescriptorCount: Int
    let canInstall: Bool
    let deniedExtensionIdentifiers: [String]
}

enum WallpaperAccessProbe {
    static func probe(
        containerURL: URL,
        rootValidator: WallpaperLayoutScanner.RootValidator,
        requiredExtensionIdentifiers: Set<String>? = nil,
        fileManager: FileManager = .default
    ) throws -> WallpaperAccessReport {
        let layout = try WallpaperLayoutScanner.scan(
            containerURL: containerURL,
            rootValidator: rootValidator,
            fileManager: fileManager
        )
        var descriptorCount = 0
        var customDescriptorCount = 0
        for descriptorDirectory in layout.extensionDescriptorDirectories.values {
            let children = (try? fileManager.contentsOfDirectory(
                at: descriptorDirectory,
                includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey]
            )) ?? []
            for child in children {
                let name = child.lastPathComponent
                if name.hasPrefix(".") && !name.hasPrefix(".tendiesvn-wallpaper-") { continue }
                let values = try? child.resourceValues(
                    forKeys: [.isDirectoryKey, .isSymbolicLinkKey]
                )
                guard values?.isDirectory == true, values?.isSymbolicLink != true else { continue }
                descriptorCount += 1
                if WallpaperDescriptorIdentity.isCustom(at: child, fileManager: fileManager) {
                    customDescriptorCount += 1
                }
            }
        }

        let requiredIdentifiers: [String]
        if let requiredExtensionIdentifiers {
            requiredIdentifiers = requiredExtensionIdentifiers.sorted()
        } else if layout.supportsCollections {
            requiredIdentifiers = [WallpaperPosterLayout.collectionsExtension]
        } else {
            requiredIdentifiers = layout.extensionDescriptorDirectories.keys.sorted()
        }
        var deniedIdentifiers = requiredIdentifiers.filter {
            layout.extensionDescriptorDirectories[$0] == nil
        }

        for identifier in requiredIdentifiers where !deniedIdentifiers.contains(identifier) {
            guard let descriptorDirectory = layout.extensionDescriptorDirectories[identifier] else {
                continue
            }

            let probeURL = descriptorDirectory.appendingPathComponent(
                ".tendiesvn-wallpaper-probe-\(UUID().uuidString)",
                isDirectory: true
            )
            let created = mkdir(probeURL.path, 0o700) == 0
            if created {
                let descriptor = open(
                    probeURL.path,
                    O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW
                )
                if descriptor >= 0 { close(descriptor) }
                if rmdir(probeURL.path) != 0 || descriptor < 0 {
                    deniedIdentifiers.append(identifier)
                    try? fileManager.removeItem(at: probeURL)
                }
            } else {
                deniedIdentifiers.append(identifier)
            }
        }

        return WallpaperAccessReport(
            layout: layout,
            descriptorCount: descriptorCount,
            customDescriptorCount: customDescriptorCount,
            canInstall: !requiredIdentifiers.isEmpty
                && deniedIdentifiers.isEmpty,
            deniedExtensionIdentifiers: deniedIdentifiers
        )
    }
}

private struct WallpaperDeviceAccessFailure: LocalizedError {
    let diagnostic: String

    var errorDescription: String? {
        WallpaperLabError.accessDenied.localizedDescription + "\n" + diagnostic
    }
}

/// Device operations are deliberately restricted to PosterBoard and this app's receipts.
/// Call these blocking operations from a background task, serializing mutations.
enum WallpaperDeviceAccessService {
    static func report(
        requiredExtensionIdentifiers: Set<String>? = nil
    ) throws -> WallpaperAccessReport {
        if PocketPosterWallpaperService.supportsCurrentVersion
            && !DeviceCompatibility.directInstallationSupported {
            return try PocketPosterWallpaperService.report(
                requiredExtensionIdentifiers: requiredExtensionIdentifiers
            )
        }
        let root = try posterBoardRoot()
        return try WallpaperAccessProbe.probe(
            containerURL: root,
            rootValidator: { $0.standardizedFileURL == root.standardizedFileURL },
            requiredExtensionIdentifiers: requiredExtensionIdentifiers
        )
    }

    static func install(
        _ package: WallpaperStagedPackage
    ) throws -> WallpaperAccessReport {
        if AirliftWallpaperService.shouldUse {
            return try AirliftWallpaperService.install(package)
        }
        if PocketPosterWallpaperService.supportsCurrentVersion
            && !DeviceCompatibility.directInstallationSupported {
            return try PocketPosterWallpaperService.install(package)
        }
        // Reopen app-owned metadata and validate the complete descriptor trees.
        let validatedPackage = try WallpaperPackageStore.validated(package)
        let requiredExtensions = Set(
            validatedPackage.payload.descriptors.map(\.extensionIdentifier)
        )
        let currentReport = try report(requiredExtensionIdentifiers: requiredExtensions)
        guard currentReport.canInstall else { throw WallpaperLabError.accessDenied }
        _ = try WallpaperInstaller.install(
            payload: validatedPackage.payload,
            layout: currentReport.layout,
            backupRoot: WallpaperPackageStore.backupRoot()
        )
        // Keep the source package and receipt for reapply and rollback. A refresh
        // failure after a committed install must not report installation failure.
        let refreshed = (try? report(requiredExtensionIdentifiers: requiredExtensions))
            ?? currentReport
        return refreshed
    }

    static func receipts() -> [WallpaperInstallReceipt] {
        guard let root = try? WallpaperPackageStore.backupRoot() else { return [] }
        return WallpaperInstaller.receipts(in: root)
    }

    static func restore(
        receipt: WallpaperInstallReceipt
    ) throws -> WallpaperAccessReport {
        // Never accept paths from a caller-supplied receipt. Load the stored
        // journal by identity, which also permits recovery of .preparing installs.
        guard let storedReceipt = receipts().first(where: { $0.id == receipt.id }),
              storedReceipt.status == .installed || storedReceipt.status == .preparing else {
            throw WallpaperLabError.restoreFailed
        }
        let currentReport = try report()
        let root = try posterBoardRoot()
        try WallpaperInstaller.restore(
            receipt: storedReceipt,
            containerURL: root,
            rootValidator: { $0.standardizedFileURL == root.standardizedFileURL }
        )
        return (try? report()) ?? currentReport
    }

    private static func posterBoardRoot() throws -> URL {
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-wallpaper-data") {
            let root = FileManager.default.temporaryDirectory.appendingPathComponent(
                "TendiesVN-Simulated-PosterBoard", isDirectory: true
            )
            for identifier in [
                WallpaperPosterLayout.collectionsExtension,
                WallpaperPosterLayout.photosExtension,
                WallpaperPosterLayout.mercuryExtension
            ] {
                let descriptors = root.appendingPathComponent(
                    "\(WallpaperLayoutScanner.storeRelativePath)/72/Extensions/\(identifier)/descriptors",
                    isDirectory: true
                )
                try FileManager.default.createDirectory(at: descriptors, withIntermediateDirectories: true)
            }
            return root.standardizedFileURL
        }
#endif
        var detail: NSString?
        guard let path = TendiesPosterBoardContainerPath(&detail) else {
            throw WallpaperDeviceAccessFailure(
                diagnostic: detail.map { $0 as String } ?? "TP00: PosterBoard access failed"
            )
        }
        // Foundation can shorten /private/var to /var on Darwin. Validate the
        // two aliases lexically, without comparing a standardized path to a
        // literal /private prefix. The native bridge already checked identity.
        guard let canonical = TendiesCanonicalPosterBoardRootPath(path) else {
            throw WallpaperLabError.unsafeContainerRoot
        }
        return URL(fileURLWithPath: canonical, isDirectory: true)
    }
}

