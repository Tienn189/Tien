// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105, YangJiii and contributors; modified 2026-10-17.
// Uses forcequitOS' bad_query technique without a fixed host Bundle ID.
// This bridge exposes only the PosterBoard container required by TendiesVN.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Returns a validated, retained-access PosterBoard root on iOS 26.0–26.6.1.
/// Works with the host app's normal Bundle ID. Call on a background queue;
/// initial, bounded metadata discovery can take time. No arbitrary-path API.
NSString * _Nullable TendiesPosterBoardContainerPath(
    NSString * _Nullable * _Nullable error
);
/// Returns only the manually configured UUID, or nil for automatic discovery.
/// Reads preferences without performing discovery or requesting access.
NSString * _Nullable TendiesConfiguredPosterBoardContainerUUID(void);

/// Validates and saves a PosterBoard UUID, never an arbitrary path or app ID.
/// Trims whitespace; nil or an empty string restores automatic discovery and
/// releases the cached lease. Failed validation preserves the prior setting.
/// Call on a background queue: validation may synchronously request access.
/// This checks metadata identity and root access, without probing writes.
BOOL TendiesSetPosterBoardContainerUUID(
    NSString * _Nullable uuid,
    NSString * _Nullable * _Nullable error
);
NS_ASSUME_NONNULL_END
