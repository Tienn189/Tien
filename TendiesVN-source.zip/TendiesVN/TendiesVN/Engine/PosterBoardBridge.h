// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105 mcm_bridge, YangJiii and contributors; modified 2026-10-16.
// This bridge exposes only the PosterBoard container required by TendiesVN.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Returns a retained-access PosterBoard root, or nil when iOS denies access.
NSString * _Nullable TendiesPosterBoardContainerPath(
    NSString * _Nullable * _Nullable error
);
NS_ASSUME_NONNULL_END
