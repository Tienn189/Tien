// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105, YangJiii and contributors; modified 2026-10-16.
// Uses forcequitOS' bad_query technique without a fixed host Bundle ID.
// This bridge exposes only the PosterBoard container required by TendiesVN.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
/// Returns a validated, retained-access PosterBoard root on iOS 26.0–26.6.1.
/// Works with the host app's normal Bundle ID. Call on a background queue;
/// initial, bounded metadata discovery can take time. No arbitrary-path API.
NSString * _Nullable TendiesPosterBoardContainerPath(
    NSString * _Nullable * _Nullable error
);
NS_ASSUME_NONNULL_END
