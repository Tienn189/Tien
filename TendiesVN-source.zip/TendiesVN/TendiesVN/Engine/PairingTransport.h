#ifndef APP1809_PAIRING_TRANSPORT_H
#define APP1809_PAIRING_TRANSPORT_H
#include <stddef.h>
#include <stdint.h>

typedef struct {
    char *identifier;
    char *name;
    char *model;
    char *version;
    char *transport;
    uint8_t *updated_record;
    size_t updated_record_size;
} TDPairingResult;

// Authenticated, read-only pairing check. Remote records open an RSD tunnel;
// classic records perform StartSession/TLS before reading device information.
int td_pairing_verify(const uint8_t *record, size_t size, const char *host,
                      uint16_t remote_port, int is_remote,
                      TDPairingResult *result, char **error);
void td_pairing_result_free(TDPairingResult *result);
void td_pairing_string_free(char *value);
#endif
