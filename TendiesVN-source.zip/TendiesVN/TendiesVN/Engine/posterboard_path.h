// SPDX-License-Identifier: GPL-3.0-only
// TendiesVN fixed PosterBoard path validation; added 2026-10-17.
#ifndef TENDIES_POSTERBOARD_PATH_H
#define TENDIES_POSTERBOARD_PATH_H

#include <stddef.h>

#define TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE \
    (sizeof("/private/var/mobile/Containers/Data/Application/") + 36)

// Pure lexical validation. Accepts only the /private/var or /var Application
// container root followed by one strict 36-byte UUID, with at most one trailing
// slash. Preserves UUID case, writes a /private/var root and returns 1 on success.
// Input length excludes a terminator; embedded NUL bytes are rejected. On
// failure, clears output when its pointer and capacity permit, and returns 0.
// No filesystem calls, sandbox grants, or general-purpose path normalization.
int tendies_canonical_posterboard_root_path(
    const char *input,
    size_t input_length,
    char *output,
    size_t output_capacity
);

// Scan-only extraction from a kernel-returned root or descendant path. Validates
// every component (maximum 4096 input bytes), then returns only the strict
// Application/UUID root. This function must never replace strict root validation
// for grants or public APIs.
int tendies_posterboard_candidate_root_path(
    const char *input,
    size_t input_length,
    char *output,
    size_t output_capacity
);

#endif
