// SPDX-License-Identifier: GPL-3.0-only
// TendiesVN editor export transfer, added 2026-10-17.

import Foundation
import Darwin

/// Receives one editor ZIP export at a time, without accepting JavaScript paths.
/// Await an acknowledgement after every chunk. All file I/O stays on this actor;
/// finish returns only after the existing package importer validates and copies
/// the archive into a new library entry, leaving imported originals untouched.
actor EditorTransferStore {
    private static let maximumEncodedChunkBytes = 128 * 1_024
    private static let maximumDecodedChunkBytes = 96 * 1_024
    private var activeSession: EditorTransferSession?

    /// Starts a native UUID session, cancelling any unfinished previous export.
    func begin(filename: String, expectedBytes: Int64) throws -> String {
        activeSession = nil
        let displayName = try Self.validatedDisplayName(filename)
        guard expectedBytes >= 22,
              expectedBytes <= WallpaperLabLimits.maximumArchiveBytes else {
            throw EditorTransferFailure.invalidSize
        }

        let fileManager = FileManager.default
        var createdDirectory: URL?
        do {
            let root = fileManager.temporaryDirectory.appendingPathComponent(
                "EditorTransfers", isDirectory: true
            )
            if !fileManager.fileExists(atPath: root.path) {
                try fileManager.createDirectory(
                    at: root,
                    withIntermediateDirectories: false,
                    attributes: [.posixPermissions: 0o700]
                )
            }
            let values = try root.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isDirectory == true, values.isSymbolicLink != true else {
                throw EditorTransferFailure.storageUnavailable
            }

            let id = UUID().uuidString
            let directory = root.appendingPathComponent(id, isDirectory: true)
            try fileManager.createDirectory(
                at: directory,
                withIntermediateDirectories: false,
                attributes: [.posixPermissions: 0o700]
            )
            createdDirectory = directory
            let archive = directory.appendingPathComponent("Export.tendies")
            let descriptor = open(
                archive.path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0o600
            )
            guard descriptor >= 0 else {
                throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
            }
            let handle = FileHandle(fileDescriptor: descriptor, closeOnDealloc: true)
            activeSession = EditorTransferSession(
                id: id,
                directoryURL: directory,
                archiveURL: archive,
                displayName: displayName,
                expectedBytes: expectedBytes,
                handle: handle
            )
            return id
        } catch {
            if let createdDirectory { try? fileManager.removeItem(at: createdDirectory) }
            if let failure = error as? EditorTransferFailure { throw failure }
            throw EditorTransferStorageFailure(underlyingError: error as NSError)
        }
    }

    /// Appends exactly the next chunk; raw 64 KiB chunks fit these bounds.
    /// A failed chunk aborts its session and removes any partial archive.
    func append(sessionID: String, index: Int, base64Chunk: String) throws {
        let session = try currentSession(matching: sessionID)
        do {
            guard index == session.nextIndex else { throw EditorTransferFailure.outOfOrder }
            let encodedCount = base64Chunk.utf8.count
            guard encodedCount > 0,
                  encodedCount <= Self.maximumEncodedChunkBytes,
                  encodedCount.isMultiple(of: 4),
                  let chunk = Data(base64Encoded: base64Chunk, options: []),
                  !chunk.isEmpty,
                  chunk.count <= Self.maximumDecodedChunkBytes else {
                throw EditorTransferFailure.invalidChunk
            }
            let count = Int64(chunk.count)
            guard count <= session.expectedBytes - session.receivedBytes,
                  count <= WallpaperLabLimits.maximumArchiveBytes - session.receivedBytes else {
                throw EditorTransferFailure.sizeMismatch
            }
            try session.handle.write(contentsOf: chunk)
            session.receivedBytes += count
            session.nextIndex += 1
        } catch {
            cancel(sessionID: session.id)
            if let failure = error as? EditorTransferFailure { throw failure }
            throw EditorTransferStorageFailure(underlyingError: error as NSError)
        }
    }

    /// Closes the exact-length transfer, then runs normal ZIP and descriptor
    /// validation through WallpaperPackageStore. Always removes transfer files.
    func finish(sessionID: String) throws -> WallpaperStagedPackage {
        let session = try currentSession(matching: sessionID)
        defer { cancel(sessionID: session.id) }
        guard session.receivedBytes == session.expectedBytes else {
            throw EditorTransferFailure.sizeMismatch
        }
        do {
            try session.closeAfterSynchronizing()
        } catch {
            throw EditorTransferStorageFailure(underlyingError: error as NSError)
        }
        return try WallpaperPackageStore.importPackage(
            from: session.archiveURL,
            displayName: session.displayName
        )
    }

    /// Cancels only the matching native session; stale messages cannot discard
    /// a newer export. Session ownership cleans the handle and private directory.
    func cancel(sessionID: String) {
        guard activeSession?.id == sessionID else { return }
        activeSession = nil
    }

    private func currentSession(matching id: String) throws -> EditorTransferSession {
        guard let session = activeSession, session.id == id else {
            throw EditorTransferFailure.missingSession
        }
        return session
    }

    private static func validatedDisplayName(_ rawFilename: String) throws -> String {
        guard rawFilename.utf8.count <= 255 else { throw EditorTransferFailure.invalidFilename }
        let filename = rawFilename.trimmingCharacters(in: .whitespacesAndNewlines)
        guard filename.utf8.count <= 255,
              !filename.contains("/"), !filename.contains("\\"),
              !filename.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains),
              filename.lowercased().hasSuffix(".tendies") else {
            throw EditorTransferFailure.invalidFilename
        }
        let displayName = String(filename.dropLast(".tendies".count))
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !displayName.isEmpty, displayName != ".", displayName != ".." else {
            throw EditorTransferFailure.invalidFilename
        }
        return displayName
    }
}

/// Kept private to the actor. Resource cleanup also runs when the owning editor
/// releases its store, without requiring actor work from a deinitializer.
private final class EditorTransferSession {
    let id: String
    let directoryURL: URL
    let archiveURL: URL
    let displayName: String
    let expectedBytes: Int64
    let handle: FileHandle
    var receivedBytes: Int64 = 0
    var nextIndex = 0
    private var closed = false

    init(
        id: String,
        directoryURL: URL,
        archiveURL: URL,
        displayName: String,
        expectedBytes: Int64,
        handle: FileHandle
    ) {
        self.id = id
        self.directoryURL = directoryURL
        self.archiveURL = archiveURL
        self.displayName = displayName
        self.expectedBytes = expectedBytes
        self.handle = handle
    }

    func closeAfterSynchronizing() throws {
        guard !closed else { return }
        guard fsync(handle.fileDescriptor) == 0 else {
            throw NSError(domain: NSPOSIXErrorDomain, code: Int(errno))
        }
        try handle.close()
        closed = true
    }

    deinit {
        if !closed { try? handle.close() }
        try? FileManager.default.removeItem(at: directoryURL)
    }
}

private enum EditorTransferFailure: LocalizedError {
    case invalidFilename
    case invalidSize
    case missingSession
    case outOfOrder
    case invalidChunk
    case sizeMismatch
    case storageUnavailable

    var errorDescription: String? {
        switch self {
        case .invalidFilename:
            return "Tên tệp xuất phải kết thúc bằng .tendies, không chứa đường dẫn và dài tối đa 255 byte."
        case .invalidSize:
            return "Tệp xuất phải có dung lượng từ 22 byte đến 512 MiB."
        case .missingSession:
            return "Phiên xuất đã đóng hoặc không còn hợp lệ. Hãy xuất lại hình nền."
        case .outOfOrder:
            return "Dữ liệu xuất đến sai thứ tự. Hãy xuất lại hình nền."
        case .invalidChunk:
            return "Một phần dữ liệu xuất không hợp lệ hoặc vượt giới hạn. Hãy xuất lại hình nền."
        case .sizeMismatch:
            return "Dung lượng nhận được không khớp với tệp xuất. Hãy xuất lại hình nền."
        case .storageUnavailable:
            return "Không thể tạo thư mục riêng để nhận tệp xuất."
        }
    }
}

private struct EditorTransferStorageFailure: LocalizedError {
    let underlyingError: NSError

    var errorDescription: String? {
        // Discard file URLs and provider details from NSError.userInfo.
        let systemError = NSError(domain: underlyingError.domain, code: underlyingError.code)
        return "Không thể lưu tệp xuất. " + systemError.localizedDescription +
            " [\(underlyingError.domain):\(underlyingError.code)]"
    }
}
