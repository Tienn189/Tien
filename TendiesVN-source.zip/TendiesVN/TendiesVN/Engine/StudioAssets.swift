import Foundation
import CryptoKit
import Darwin

struct StudioWebLocation {
    let rootURL: URL
    let indexURL: URL
}

struct StudioImportSource {
    let sessionID: String
    let filename: String
    let expectedBytes: Int64
}

struct StudioImportChunk {
    let index: Int
    let base64: String
}

/// Asset preparation, library import, and archive streaming stay off the UI
/// executor. The web editor receives bytes, never native filesystem paths.
actor StudioAssets {
    static let shared = StudioAssets()
    static let maximumImportBytes: Int64 = 128 * 1_024 * 1_024
    private var reads: [String: StudioArchiveRead] = [:]

    func prepare() throws -> StudioWebLocation {
        let manager = FileManager.default
        guard let archive = Bundle.main.url(forResource: "StudioEditor", withExtension: "zip")
            ?? Bundle.main.url(forResource: "StudioEditor", withExtension: "zip", subdirectory: "Resources") else {
            throw StudioAssetFailure.missingEditor
        }
        let values = try archive.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else {
            throw StudioAssetFailure.missingEditor
        }
        let digest = try sha256(of: archive)
        let support = try manager.url(
            for: .applicationSupportDirectory, in: .userDomainMask,
            appropriateFor: nil, create: true
        )
        let webRoot = support.appendingPathComponent("StudioWeb", isDirectory: true)
        try ensurePrivateDirectory(webRoot)
        let destination = webRoot.appendingPathComponent(digest, isDirectory: true)
        if validEditor(at: destination) {
            return StudioWebLocation(rootURL: destination, indexURL: destination.appendingPathComponent("index.html"))
        }
        if manager.fileExists(atPath: destination.path) {
            try manager.removeItem(at: destination)
        }
        let staging = webRoot.appendingPathComponent(".extracting-" + UUID().uuidString, isDirectory: true)
        defer { try? manager.removeItem(at: staging) }
        _ = try SecureZIPArchive.extract(archiveURL: archive, destinationURL: staging)
        try manager.setAttributes([.posixPermissions: 0o700], ofItemAtPath: staging.path)
        guard validEditor(at: staging) else { throw StudioAssetFailure.missingEditor }
        try manager.moveItem(at: staging, to: destination)
        return StudioWebLocation(rootURL: destination, indexURL: destination.appendingPathComponent("index.html"))
    }

    func importPackage(from url: URL) throws -> WallpaperStagedPackage {
        try WallpaperPackageStore.importPackage(from: url)
    }

    func beginRead(_ package: WallpaperStagedPackage) throws -> StudioImportSource {
        let validated = try WallpaperPackageStore.validated(package)
        let descriptor = open(validated.archiveURL.path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK)
        guard descriptor >= 0 else { throw StudioAssetFailure.unreadablePackage }
        var information = stat()
        guard fstat(descriptor, &information) == 0,
              information.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG) else {
            close(descriptor)
            throw StudioAssetFailure.unreadablePackage
        }
        guard information.st_size >= 22, information.st_size <= Self.maximumImportBytes else {
            close(descriptor)
            throw StudioAssetFailure.importTooLarge
        }
        let sessionID = UUID().uuidString
        reads[sessionID] = StudioArchiveRead(
            handle: FileHandle(fileDescriptor: descriptor, closeOnDealloc: true),
            expectedBytes: Int64(information.st_size)
        )
        return StudioImportSource(
            sessionID: sessionID,
            filename: safeFilename(validated.displayName),
            expectedBytes: Int64(information.st_size)
        )
    }

    func nextChunk(sessionID: String) throws -> StudioImportChunk? {
        guard let read = reads[sessionID] else { throw StudioAssetFailure.closedImport }
        do {
            guard let data = try read.handle.read(upToCount: 64 * 1_024), !data.isEmpty else {
                guard read.receivedBytes == read.expectedBytes else { throw StudioAssetFailure.unreadablePackage }
                reads[sessionID] = nil
                return nil
            }
            read.receivedBytes += Int64(data.count)
            guard read.receivedBytes <= read.expectedBytes,
                  read.receivedBytes <= Self.maximumImportBytes else {
                throw StudioAssetFailure.unreadablePackage
            }
            let index = read.nextIndex
            read.nextIndex += 1
            return StudioImportChunk(index: index, base64: data.base64EncodedString())
        } catch {
            reads[sessionID] = nil
            throw error
        }
    }

    func cancelRead(sessionID: String) {
        reads[sessionID] = nil
    }

    func shareCopy(of package: WallpaperStagedPackage) throws -> URL {
        let validated = try WallpaperPackageStore.validated(package)
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("StudioExports", isDirectory: true)
        try ensurePrivateDirectory(root)
        let directory = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(
            at: directory, withIntermediateDirectories: false,
            attributes: [.posixPermissions: 0o700]
        )
        do {
            let target = directory.appendingPathComponent(safeFilename(validated.displayName))
            try FileManager.default.copyItem(at: validated.archiveURL, to: target)
            return target
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }

    func removeShareCopy(_ url: URL) {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("StudioExports", isDirectory: true).standardizedFileURL
        let directory = url.deletingLastPathComponent().standardizedFileURL
        guard directory.deletingLastPathComponent() == root,
              UUID(uuidString: directory.lastPathComponent) != nil else { return }
        try? FileManager.default.removeItem(at: directory)
    }

    private func ensurePrivateDirectory(_ url: URL) throws {
        let manager = FileManager.default
        if !manager.fileExists(atPath: url.path) {
            try manager.createDirectory(
                at: url, withIntermediateDirectories: false,
                attributes: [.posixPermissions: 0o700]
            )
        }
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else {
            throw StudioAssetFailure.unavailableStorage
        }
    }

    private func validEditor(at root: URL) -> Bool {
        guard let rootValues = try? root.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey]),
              rootValues.isDirectory == true, rootValues.isSymbolicLink != true else { return false }
        let index = root.appendingPathComponent("index.html")
        guard let values = try? index.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]) else { return false }
        return values.isRegularFile == true && values.isSymbolicLink != true && (values.fileSize ?? 0) > 0
    }

    private func sha256(of url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while let chunk = try handle.read(upToCount: 1_024 * 1_024), !chunk.isEmpty {
            hash.update(data: chunk)
        }
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private func safeFilename(_ raw: String) -> String {
        var name = String(String.UnicodeScalarView(raw.unicodeScalars.filter {
            !CharacterSet.controlCharacters.contains($0) && !"/\\:".unicodeScalars.contains($0)
        })).trimmingCharacters(in: .whitespacesAndNewlines)
        while name.utf8.count > 180 { name.removeLast() }
        if name.isEmpty || name == "." || name == ".." { name = "Hinh nen" }
        return name + ".tendies"
    }
}

private final class StudioArchiveRead {
    let handle: FileHandle
    let expectedBytes: Int64
    var receivedBytes: Int64 = 0
    var nextIndex = 0

    init(handle: FileHandle, expectedBytes: Int64) {
        self.handle = handle
        self.expectedBytes = expectedBytes
    }

    deinit { try? handle.close() }
}

enum StudioAssetFailure: LocalizedError {
    case missingEditor
    case unavailableStorage
    case unreadablePackage
    case importTooLarge
    case closedImport

    var errorDescription: String? {
        switch self {
        case .missingEditor: return "Không tìm thấy bộ soạn thảo trong ứng dụng. Hãy cài lại bản mới nhất."
        case .unavailableStorage: return "Không thể chuẩn bị bộ nhớ riêng cho trình soạn thảo."
        case .unreadablePackage: return "Không đọc được toàn bộ gói hình nền. Hãy nhập lại tệp gốc."
        case .importTooLarge: return "Trình soạn thảo hỗ trợ gói từ 22 byte đến 128 MiB."
        case .closedImport: return "Phiên mở gói đã đóng. Hãy mở lại gói hình nền."
        }
    }
}
