// SPDX-License-Identifier: GPL-3.0-only
// Container discovery adapted from 3105 (YangJiii and contributors).

import Foundation
#if canImport(Darwin)
import Darwin
#endif

enum LegacyPosterBoardContainerResolver {
    /// Last native resolver diagnostic. This is deliberately kept in memory
    /// only so the UI can explain why discovery failed without persisting a
    /// path or any private container metadata.
    private(set) static var lastError: String?

    /// Find PosterBoard's application-container UUID after the 3105 kernel
    /// primitive is active. The UUID is cached by PocketPosterConfiguration;
    /// callers do not need Nugget or another helper app.
    static func discover() -> String? {
        lastError = nil
        guard DeviceCompatibility.supportsPocketPoster(DeviceCompatibility.currentVersion),
              TendiesKernelExploit.activate() else {
            lastError = "kernel exploit không khả dụng hoặc phiên bản iOS không được hỗ trợ"
            return nil
        }
        var detail: NSString?
        guard let path = TendiesLegacyPosterBoardContainerPath(&detail) else {
            lastError = detail.map { String(describing: $0) }
            if let detail { print("[1809] iOS 17–18 PosterBoard discovery failed: \(detail)") }
            return nil
        }
        let root = URL(fileURLWithPath: path, isDirectory: true)
        let uuid = root.lastPathComponent
        guard UUID(uuidString: uuid) != nil else {
            lastError = "resolver trả về container UUID không hợp lệ"
            return nil
        }
        return uuid.uppercased()
    }
}

