// SPDX-License-Identifier: GPL-3.0-only
// Container discovery adapted from 3105 (YangJiii and contributors).

import Foundation
#if canImport(Darwin)
import Darwin
#endif

enum LegacyPosterBoardContainerResolver {
    /// Find PosterBoard's application-container UUID after the 3105 kernel
    /// primitive is active. The UUID is cached by PocketPosterConfiguration;
    /// callers do not need Nugget or another helper app.
    static func discover() -> String? {
        guard DeviceCompatibility.supportsPocketPoster(DeviceCompatibility.currentVersion),
              TendiesKernelExploit.activate() else {
            return nil
        }
        var detail: NSString?
        guard let path = TendiesLegacyPosterBoardContainerPath(&detail) else {
            if let detail { print("[1809] iOS 17–18 PosterBoard discovery failed: \(detail)") }
            return nil
        }
        let root = URL(fileURLWithPath: path, isDirectory: true)
        let uuid = root.lastPathComponent
        guard UUID(uuidString: uuid) != nil else { return nil }
        return uuid.uppercased()
    }
}

