// SPDX-License-Identifier: GPL-3.0-only
#include "wallpaper_zip.h"
#include "PairingTransport.h"
#include "IDevice/idevice.h"
