// SPDX-License-Identifier: GPL-3.0-only
#import "PosterBoardBridge.h"
#import "PosterBoardRefresh.h"
#include "wallpaper_zip.h"
#include "posterboard_support.h"
#include "PairingTransport.h"
#include "IDevice/idevice.h"

// 3105's device-local kernel read/write primitive is used only by the
// opt-in iOS 17–18 PosterBoard resolver. Keep it isolated from the normal
// BadQuery/Airlift paths so newer systems never enter this code.
#include "KernelExploit/bad_query.h"
#include "KernelExploit/kexploit_opa334.h"
#include "KernelExploit/sandbox_escape.h"
#include "KernelExploit/kutils.h"
