import Foundation

/// Logical file sizes in the complete extracted archive, including resources
/// outside descriptor folders. Directory entries do not count as files.
struct WallpaperPackageStatistics: Equatable {
    let expandedBytes: Int64
    let fileCount: Int

    static func inspect(
        at rawRoot: URL,
        fileManager: FileManager = .default
    ) throws -> WallpaperPackageStatistics {
        let root = rawRoot.standardizedFileURL
        guard root.isFileURL else { throw WallpaperLabError.unsafeArchive }
        try WallpaperLayoutScanner.validateDirectory(root, fileManager: fileManager)
        var traversalError: Error?
        guard let entries = fileManager.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey],
            options: [],
            errorHandler: { _, error in
                traversalError = error
                return false
            }
        ) else { throw WallpaperLabError.unsupportedPackage }
        var files = 0
        var bytes: Int64 = 0
        for case let item as URL in entries {
            guard item.path.utf8.count <= WallpaperLabLimits.maximumPathBytes,
                  WallpaperLayoutScanner.isContained(item, in: root) else {
                throw WallpaperLabError.unsafeArchive
            }
            let values = try item.resourceValues(forKeys: [
                .isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey
            ])
            guard values.isSymbolicLink != true else {
                throw WallpaperLabError.symbolicLinkUnsupported
            }
            if values.isRegularFile == true {
                guard let size = values.fileSize, size >= 0,
                      Int64(size) <= WallpaperLabLimits.maximumEntryBytes else {
                    throw WallpaperLabError.packageTooLarge
                }
                files += 1
                bytes += Int64(size)
                guard files <= WallpaperLabLimits.maximumEntryCount,
                      bytes <= WallpaperLabLimits.maximumExpandedBytes else {
                    throw WallpaperLabError.packageTooLarge
                }
            } else if values.isDirectory != true {
                throw WallpaperLabError.unsupportedPackage
            }
        }
        if let traversalError { throw traversalError }
        return WallpaperPackageStatistics(expandedBytes: bytes, fileCount: files)
    }
}
