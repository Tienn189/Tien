import Foundation
import Combine
import Security

struct PairingRecordSummary: Codable, Equatable {
    let fileName: String
    let importedAt: Date
    /// A filename or plist identifier is only a label. Public iOS APIs do not
    /// expose the current UDID, so it cannot establish a device match.
    let deviceIdentifier: String?

    var maskedDeviceIdentifier: String? {
        guard let deviceIdentifier else { return nil }
        return String(deviceIdentifier.prefix(4)) + "…" + String(deviceIdentifier.suffix(4))
    }
}

private struct StoredPairingRecord: Codable {
    let summary: PairingRecordSummary
    let plistData: Data
}

private enum PairingImportError: LocalizedError {
    case invalidFile
    case tooLarge
    case invalidRecord
    case missingField(String)
    case invalidCertificate
    case invalidPrivateKey
    case mismatchedKey
    case keychain(OSStatus)

    var errorDescription: String? {
        switch self {
        case .invalidFile:
            return "Chọn tệp pairing .mobiledevicepairing hoặc .plist được tạo trên máy tính."
        case .tooLarge:
            return "Tệp pairing vượt quá giới hạn 1 MB."
        case .invalidRecord:
            return "Tệp không phải bản ghi pairing hợp lệ. Tạo lại bản ghi bằng JitterbugPair trên máy tính."
        case .missingField(let field):
            return "Bản ghi pairing thiếu hoặc sai trường \(field). Hãy tạo lại bản ghi trên máy tính."
        case .invalidCertificate:
            return "Chứng chỉ trong bản ghi pairing không hợp lệ."
        case .invalidPrivateKey:
            return "Khoá riêng trong bản ghi pairing không hợp lệ hoặc có mã hoá."
        case .mismatchedKey:
            return "Khoá và chứng chỉ trong bản ghi pairing không khớp nhau."
        case .keychain(let status):
            if status == errSecInteractionNotAllowed {
                return "Mở khoá thiết bị rồi thử lại để truy cập bản ghi pairing trong Keychain."
            }
            return "Không thể cập nhật bản ghi pairing trong Keychain (\(status))."
        }
    }
}

/// Validates the local credential structure and key pairs only. It does not
/// contact lockdownd or attest that this record belongs to the running device.
enum PairingRecordValidator {
    static let maximumBytes = 1_024 * 1_024

    static func validate(_ data: Data) throws -> [String: Any] {
        guard !data.isEmpty else { throw PairingImportError.invalidRecord }
        guard data.count <= maximumBytes else { throw PairingImportError.tooLarge }
        guard let plist = try? PropertyListSerialization.propertyList(
            from: data, options: [], format: nil
        ), let record = plist as? [String: Any] else {
            throw PairingImportError.invalidRecord
        }
        for name in ["HostID", "SystemBUID"] {
            guard let identifier = record[name] as? String,
                  UUID(uuidString: identifier) != nil else {
                throw PairingImportError.missingField(name)
            }
        }
        let hostCertificate = try certificate(record, field: "HostCertificate")
        let rootCertificate = try certificate(record, field: "RootCertificate")
        _ = try certificate(record, field: "DeviceCertificate")
        let hostKey = try privateKey(record, field: "HostPrivateKey")
        let rootKey = try privateKey(record, field: "RootPrivateKey")
        try validateKeyPair(hostKey, certificate: hostCertificate)
        try validateKeyPair(rootKey, certificate: rootCertificate)
        if let escrow = record["EscrowBag"] {
            guard let bytes = escrow as? Data, !bytes.isEmpty,
                  bytes.count <= maximumBytes / 2 else {
                throw PairingImportError.missingField("EscrowBag")
            }
        }
        return record
    }

    private static func bytes(_ record: [String: Any], field: String) throws -> Data {
        let data: Data
        if let value = record[field] as? Data {
            data = value
        } else if let value = record[field] as? String, let bytes = value.data(using: .utf8) {
            data = bytes
        } else {
            throw PairingImportError.missingField(field)
        }
        guard !data.isEmpty, data.count <= 128 * 1_024 else {
            throw PairingImportError.missingField(field)
        }
        return data
    }

    private static func der(_ data: Data, labels: [String]) throws -> Data {
        guard let text = String(data: data, encoding: .utf8), text.contains("-----BEGIN ") else {
            return data
        }
        let content = text.trimmingCharacters(in: .whitespacesAndNewlines)
        for label in labels {
            let begin = "-----BEGIN \(label)-----"
            let end = "-----END \(label)-----"
            guard content.hasPrefix(begin), content.hasSuffix(end) else { continue }
            let body = content.dropFirst(begin.count).dropLast(end.count)
            let compact = body.filter { !$0.isWhitespace }
            guard let decoded = Data(base64Encoded: String(compact)), !decoded.isEmpty else {
                throw PairingImportError.invalidRecord
            }
            return decoded
        }
        throw PairingImportError.invalidRecord
    }

    private static func certificate(_ record: [String: Any], field: String) throws -> SecCertificate {
        let data = try der(bytes(record, field: field), labels: ["CERTIFICATE"])
        guard let certificate = SecCertificateCreateWithData(nil, data as CFData) else {
            throw PairingImportError.invalidCertificate
        }
        return certificate
    }

    private static func privateKey(_ record: [String: Any], field: String) throws -> SecKey {
        let encoded = try der(bytes(record, field: field), labels: ["RSA PRIVATE KEY", "PRIVATE KEY"])
        let data = try rsaPrivateKeyData(encoded)
        let attributes: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeyClass as String: kSecAttrKeyClassPrivate
        ]
        guard let key = SecKeyCreateWithData(data as CFData, attributes as CFDictionary, nil) else {
            throw PairingImportError.invalidPrivateKey
        }
        return key
    }

    /// SecKeyCreateWithData expects an RSA PKCS#1 key on iOS. OpenSSL tools
    /// also export PKCS#8 (BEGIN PRIVATE KEY), so unwrap that bounded DER
    /// container after checking the rsaEncryption algorithm identifier.
    private static func rsaPrivateKeyData(_ data: Data) throws -> Data {
        var document = DERReader(data)
        let sequence = try document.read(tag: 0x30)
        guard document.isAtEnd else { throw PairingImportError.invalidPrivateKey }
        var content = DERReader(sequence)
        let version = try content.read(tag: 0x02)
        if content.nextTag == 0x02 { return data } // PKCS#1, parsed by Security.
        guard version == Data([0]), content.nextTag == 0x30 else {
            throw PairingImportError.invalidPrivateKey
        }
        var algorithm = DERReader(try content.read(tag: 0x30))
        let rsaEncryptionOID = Data([0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01])
        guard try algorithm.read(tag: 0x06) == rsaEncryptionOID else {
            throw PairingImportError.invalidPrivateKey
        }
        if !algorithm.isAtEnd {
            guard try algorithm.read(tag: 0x05).isEmpty, algorithm.isAtEnd else {
                throw PairingImportError.invalidPrivateKey
            }
        }
        let privateKey = try content.read(tag: 0x04)
        // PrivateKeyInfo may carry optional context-specific attributes.
        if !content.isAtEnd { _ = try content.read(tag: 0xA0) }
        guard content.isAtEnd, !privateKey.isEmpty else {
            throw PairingImportError.invalidPrivateKey
        }
        return privateKey
    }

    private struct DERReader {
        private let bytes: [UInt8]
        private var offset = 0

        init(_ data: Data) { bytes = Array(data) }
        var isAtEnd: Bool { offset == bytes.count }
        var nextTag: UInt8? { offset < bytes.count ? bytes[offset] : nil }

        mutating func read(tag: UInt8) throws -> Data {
            guard offset < bytes.count, bytes[offset] == tag else {
                throw PairingImportError.invalidPrivateKey
            }
            offset += 1
            guard offset < bytes.count else { throw PairingImportError.invalidPrivateKey }
            let firstLength = bytes[offset]
            offset += 1
            var length = Int(firstLength)
            if firstLength & 0x80 != 0 {
                let count = Int(firstLength & 0x7F)
                guard count > 0, count <= 4, count <= bytes.count - offset,
                      bytes[offset] != 0 else { throw PairingImportError.invalidPrivateKey }
                length = 0
                for byte in bytes[offset..<(offset + count)] {
                    length = (length << 8) | Int(byte)
                }
                offset += count
                guard length >= 128 else { throw PairingImportError.invalidPrivateKey }
            }
            guard length <= bytes.count - offset else { throw PairingImportError.invalidPrivateKey }
            let value = Data(bytes[offset..<(offset + length)])
            offset += length
            return value
        }
    }

    private static func validateKeyPair(_ key: SecKey, certificate: SecCertificate) throws {
        guard let publicKey = SecCertificateCopyKey(certificate),
              SecKeyIsAlgorithmSupported(key, .sign, .rsaSignatureMessagePKCS1v15SHA256),
              SecKeyIsAlgorithmSupported(publicKey, .verify, .rsaSignatureMessagePKCS1v15SHA256) else {
            throw PairingImportError.invalidPrivateKey
        }
        // This is a local consistency check, never a claim of a device session.
        let challenge = Data(UUID().uuidString.utf8)
        guard let signature = SecKeyCreateSignature(
            key, .rsaSignatureMessagePKCS1v15SHA256, challenge as CFData, nil
        ), SecKeyVerifySignature(
            publicKey, .rsaSignatureMessagePKCS1v15SHA256,
            challenge as CFData, signature, nil
        ) else {
            throw PairingImportError.mismatchedKey
        }
    }

    static func deviceIdentifier(record: [String: Any], fileName: String) -> String? {
        let candidates = [record["UDID"] as? String, record["UniqueDeviceID"] as? String,
                          URL(fileURLWithPath: fileName).deletingPathExtension().lastPathComponent]
        return candidates.compactMap { $0 }.first { candidate in
            // Modern devices use an 8-16 hexadecimal UDID; older devices use 40.
            let groups = candidate.split(separator: "-", omittingEmptySubsequences: false)
            let validLength = (groups.count == 2 && groups[0].count == 8 && groups[1].count == 16)
                || (groups.count == 1 && candidate.count == 40)
            let allowed = CharacterSet(charactersIn: "0123456789abcdefABCDEF-")
            return validLength && candidate.unicodeScalars.allSatisfy(allowed.contains)
        }
    }
}

private enum PairingKeychain {
    private static var query: [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: (Bundle.main.bundleIdentifier ?? "app.1809") + ".pairing",
            kSecAttrAccount as String: "device-pairing-record-v1",
            kSecAttrSynchronizable as String: false
        ]
    }

    static func read() throws -> Data? {
        var attributes = query
        attributes[kSecReturnData as String] = true
        attributes[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(attributes as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else {
            throw PairingImportError.keychain(status)
        }
        return data
    }

    static func write(_ data: Data) throws {
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            let insertStatus = SecItemAdd(query.merging(attributes) { _, value in value } as CFDictionary, nil)
            guard insertStatus == errSecSuccess else { throw PairingImportError.keychain(insertStatus) }
        } else if status != errSecSuccess {
            throw PairingImportError.keychain(status)
        }
    }

    static func remove() throws {
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw PairingImportError.keychain(status)
        }
    }
}

private actor PairingWorker {
    func load() throws -> PairingRecordSummary? {
        guard let data = try PairingKeychain.read() else { return nil }
        let stored = try PropertyListDecoder().decode(StoredPairingRecord.self, from: data)
        _ = try PairingRecordValidator.validate(stored.plistData)
        return stored.summary
    }

    func importRecord(from url: URL) throws -> PairingRecordSummary {
        guard url.isFileURL,
              ["mobiledevicepairing", "plist"].contains(url.pathExtension.lowercased()) else {
            throw PairingImportError.invalidFile
        }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else {
            throw PairingImportError.invalidFile
        }
        guard let size = values.fileSize, size > 0,
              size <= PairingRecordValidator.maximumBytes else {
            throw PairingImportError.tooLarge
        }
        // Bound the actual read too, including when a provider changes the file
        // after resourceValues was obtained. Do not copy credentials to disk.
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var data = Data()
        let maximumRead = PairingRecordValidator.maximumBytes + 1
        while data.count < maximumRead {
            let chunk = try handle.read(upToCount: min(64 * 1_024, maximumRead - data.count)) ?? Data()
            if chunk.isEmpty { break }
            data.append(chunk)
        }
        let record = try PairingRecordValidator.validate(data)
        let summary = PairingRecordSummary(
            fileName: String(url.lastPathComponent.prefix(255)),
            importedAt: Date(),
            deviceIdentifier: PairingRecordValidator.deviceIdentifier(record: record, fileName: url.lastPathComponent)
        )
        let stored = StoredPairingRecord(summary: summary, plistData: data)
        try PairingKeychain.write(PropertyListEncoder().encode(stored))
        return summary
    }

    func remove() throws { try PairingKeychain.remove() }
}

@MainActor
final class PairingStore: ObservableObject {
    static let shared = PairingStore()

    @Published private(set) var record: PairingRecordSummary?
    @Published private(set) var isImporting = false
    @Published var errorMessage: String?
    private let worker = PairingWorker()

    var statusText: String { record == nil ? "Chưa có bản ghi" : "Đã lưu bản ghi" }

    var detailText: String {
        if record == nil {
            return "iOS 27 trở lên yêu cầu pairing. Bản này cho phép nhập và lưu bản ghi; chưa có kết nối pairing để cài hình nền."
        }
        return "Bản ghi được bảo vệ trong Keychain trên thiết bị này. Chưa xác minh bản ghi thuộc thiết bị hiện tại và chưa thiết lập kết nối pairing. Bản này chưa có cơ chế cài hình nền qua pairing."
    }

    func refresh() async {
        guard !isImporting else { return }
        isImporting = true
        defer { isImporting = false }
        do {
            record = try await worker.load()
            errorMessage = nil
        } catch {
            record = nil
            errorMessage = "Không thể đọc bản ghi đã lưu. " + error.localizedDescription
        }
    }

    func importRecord(from url: URL) async {
        guard !isImporting else { return }
        isImporting = true
        defer { isImporting = false }
        do {
            record = try await worker.importRecord(from: url)
            errorMessage = nil
        } catch {
            // An invalid replacement never destroys the existing valid record.
            errorMessage = error.localizedDescription
        }
    }

    func removeRecord() async {
        guard !isImporting else { return }
        isImporting = true
        defer { isImporting = false }
        do {
            try await worker.remove()
            record = nil
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
