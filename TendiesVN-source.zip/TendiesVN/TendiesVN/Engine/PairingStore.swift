import Foundation
import Combine
import Security

private enum PairingKeychain {
    private static var query: [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: (Bundle.main.bundleIdentifier ?? "app.1809") + ".pairing",
            kSecAttrAccount as String: "device-pairing-record-v1",
            kSecAttrSynchronizable as String: false
        ]
    }

    static func read() throws -> Data? {
        var attributes = query
        attributes[kSecReturnData as String] = true
        attributes[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(attributes as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else {
            throw PairingImportError.keychain(status)
        }
        return data
    }

    static func write(_ data: Data) throws {
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            let insertStatus = SecItemAdd(query.merging(attributes) { _, value in value } as CFDictionary, nil)
            guard insertStatus == errSecSuccess else { throw PairingImportError.keychain(insertStatus) }
        } else if status != errSecSuccess {
            throw PairingImportError.keychain(status)
        }
    }

    static func remove() throws {
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw PairingImportError.keychain(status)
        }
    }
}

struct PairingConnectionInfo: Equatable {
    let identifier: String
    let deviceName: String
    let model: String
    let version: String
    let transport: String
    let verifiedAt: Date
}

private struct PairingConnectionFailure: LocalizedError {
    let detail: String
    var errorDescription: String? { detail }
}

private actor PairingWorker {
    func load() throws -> PairingRecordSummary? {
        guard let data = try PairingKeychain.read() else { return nil }
        let stored = try PropertyListDecoder().decode(StoredPairingRecord.self, from: data)
        let values = try PairingRecordValidator.validate(stored.plistData)
        var summary = stored.summary
        summary.kind = PairingRecordValidator.kind(of: values)
        summary.byteCount = stored.plistData.count
        return summary
    }

    func importRecord(from url: URL) throws -> PairingRecordSummary {
        guard url.isFileURL else { throw PairingImportError.invalidFile }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        var data: Data?
        var readError: Error?
        var coordinationError: NSError?
        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { local in
            do {
                let values = try local.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
                guard values.isRegularFile == true, values.isSymbolicLink != true else {
                    throw PairingImportError.invalidFile
                }
                let handle = try FileHandle(forReadingFrom: local)
                defer { try? handle.close() }
                var result = Data()
                let maximum = PairingRecordValidator.maximumBytes + 1
                while result.count < maximum {
                    let chunk = try handle.read(upToCount: min(64 * 1_024, maximum - result.count)) ?? Data()
                    if chunk.isEmpty { break }
                    result.append(chunk)
                }
                data = result
            } catch { readError = error }
        }
        if let readError { throw readError }
        if let coordinationError { throw coordinationError }
        guard let data else { throw PairingImportError.invalidFile }
        return try save(data, fileName: url.lastPathComponent)
    }

    func save(_ data: Data, fileName: String, deviceIdentifier: String? = nil) throws -> PairingRecordSummary {
        let values = try PairingRecordValidator.validate(data)
        var summary = PairingRecordSummary(
            fileName: String(fileName.prefix(255)), importedAt: Date(),
            deviceIdentifier: deviceIdentifier ?? PairingRecordValidator.deviceIdentifier(record: values, fileName: fileName)
        )
        summary.kind = PairingRecordValidator.kind(of: values)
        summary.byteCount = data.count
        let stored = StoredPairingRecord(summary: summary, plistData: data)
        try PairingKeychain.write(PropertyListEncoder().encode(stored))
        return summary
    }

    func verify(host: String, port: UInt16) throws -> PairingConnectionInfo {
        guard let data = try PairingKeychain.read() else {
            throw PairingConnectionFailure(detail: "Nhập hồ sơ pairing trước khi kết nối.")
        }
        let stored = try PropertyListDecoder().decode(StoredPairingRecord.self, from: data)
        let values = try PairingRecordValidator.validate(stored.plistData)
        let normalized = try PairingRecordValidator.nativeData(values)
        var result = TDPairingResult()
        var error: UnsafeMutablePointer<CChar>?
        let status = normalized.withUnsafeBytes { bytes in
            host.withCString { address in
                td_pairing_verify(bytes.bindMemory(to: UInt8.self).baseAddress, bytes.count, address, port,
                                  PairingRecordValidator.kind(of: values) == .remote ? 1 : 0, &result, &error)
            }
        }
        defer { td_pairing_result_free(&result); td_pairing_string_free(error) }
        guard status == 0 else {
            let diagnostic = error.map { String(cString: $0) } ?? "Không nhận được phản hồi xác thực."
            throw PairingConnectionFailure(detail: "Không xác thực được kết nối. Bật LocalDevVPN, mở khoá thiết bị và kiểm tra IP, quyền Mạng cục bộ cùng hồ sơ pairing.\n\n\(diagnostic)")
        }
        func string(_ value: UnsafeMutablePointer<CChar>?) -> String {
            value.map { String(cString: $0) } ?? ""
        }
        let identity = string(result.identifier)
        let model = string(result.model)
        if let expected = stored.summary.deviceIdentifier, !model.isEmpty,
           expected.caseInsensitiveCompare(identity) != .orderedSame {
            throw PairingConnectionFailure(detail: "Hồ sơ không khớp với thiết bị trả lời tại IP này. Kiểm tra lại IP thiết bị trong LocalDevVPN và nhập hồ sơ của đúng máy.")
        }
        if !model.isEmpty, model != DeviceCompatibility.hardwareModel {
            throw PairingConnectionFailure(detail: "Thiết bị trả lời có model \(model), khác máy đang chạy 1809. Kiểm tra IP trong LocalDevVPN trước khi tiếp tục.")
        }
        if let bytes = result.updated_record, result.updated_record_size > 0 {
            let updated = Data(bytes: bytes, count: result.updated_record_size)
            _ = try PairingRecordValidator.validate(updated)
            var summary = stored.summary
            summary.kind = .remote
            summary.byteCount = updated.count
            let changed = StoredPairingRecord(summary: summary, plistData: updated)
            try PairingKeychain.write(PropertyListEncoder().encode(changed))
        }
        return PairingConnectionInfo(
            identifier: identity, deviceName: string(result.name), model: model,
            version: string(result.version), transport: string(result.transport), verifiedAt: Date()
        )
    }

    func remove() throws { try PairingKeychain.remove() }
}

@MainActor
final class PairingStore: ObservableObject {
    static let shared = PairingStore()
    @Published private(set) var record: PairingRecordSummary?
    @Published private(set) var isImporting = false
    @Published private(set) var isConnecting = false
    @Published private(set) var isPairing = false
    @Published private(set) var connection: PairingConnectionInfo?
    @Published private(set) var network = LocalVPNSnapshot()
    @Published private(set) var lastFailure: String?
    @Published var errorMessage: String? {
        didSet {
            if let errorMessage { lastFailure = errorMessage }
        }
    }
    @Published var deviceIP = UserDefaults.standard.string(forKey: "1809.pairing.deviceIP") ?? "10.7.0.1" {
        didSet {
            UserDefaults.standard.set(deviceIP, forKey: "1809.pairing.deviceIP")
            invalidateConnection()
        }
    }
    @Published var remotePort = UserDefaults.standard.string(forKey: "1809.pairing.remotePort") ?? "49152" {
        didSet {
            UserDefaults.standard.set(remotePort, forKey: "1809.pairing.remotePort")
            invalidateConnection()
        }
    }
    private let worker = PairingWorker()
    private var generation = UUID()

    var isBusy: Bool { isImporting || isConnecting || isPairing }
    var statusText: String {
        if isPairing { return "Đang ghép đôi trên thiết bị" }
        if isImporting { return "Đang đọc hồ sơ…" }
        if isConnecting { return "Đang xác thực kết nối…" }
        if connection != nil { return "Kết nối đã xác thực" }
        if lastFailure != nil { return "Pairing chưa thành công" }
        return record == nil ? "Chưa có hồ sơ pairing" : "Đã nhập · chưa xác thực"
    }
    var detailText: String {
        if let connection {
            return "Thiết bị đã chấp nhận hồ sơ qua \(connection.transport). Kiểm tra lúc \(connection.verifiedAt.formatted(date: .omitted, time: .shortened))."
        }
        if let lastFailure { return lastFailure }
        return "Bật LocalDevVPN, nhập IP thiết bị rồi chọn Kiểm tra kết nối. Hồ sơ chỉ được báo xác thực sau khi thiết bị chấp nhận ghép đôi."
    }

    func invalidateConnection() {
        generation = UUID()
        connection = nil
    }

    func refreshNetwork() {
        network = LocalVPNStatus.snapshot(host: deviceIP)
        if !network.hasTunnel || (connection.map { Date().timeIntervalSince($0.verifiedAt) > 90 } ?? false) {
            invalidateConnection()
        }
    }

    func refresh() async {
        refreshNetwork()
        guard !isBusy else { return }
        isImporting = true
        defer { isImporting = false }
        do {
            record = try await worker.load()
        } catch {
            record = nil
            invalidateConnection()
            errorMessage = "Không đọc được hồ sơ đã lưu. " + error.localizedDescription
        }
    }

    func importRecord(from url: URL) async {
        guard !isBusy else { errorMessage = "Chờ thao tác pairing hiện tại hoàn tất rồi nhập lại tệp."; return }
        isImporting = true
        do {
            let imported = try await worker.importRecord(from: url)
            record = imported
            invalidateConnection()
            lastFailure = nil
            errorMessage = nil
            isImporting = false
            refreshNetwork()
            if network.targetUsesTunnel { await verifyConnection() }
        } catch {
            isImporting = false
            errorMessage = error.localizedDescription
        }
    }

    func verifyConnection() async {
        guard !isBusy, record != nil else { return }
        let host = LocalVPNStatus.normalizeHost(deviceIP)
        guard LocalVPNStatus.isValidHost(host), let port = UInt16(remotePort.trimmingCharacters(in: .whitespacesAndNewlines)), port > 0 else {
            errorMessage = "Nhập IP cục bộ hợp lệ từ LocalDevVPN và cổng RSD từ 1 đến 65535."
            return
        }
        if record?.kind == .remote && host.hasPrefix("127.") {
            errorMessage = "RPPairing cần IP thiết bị trong LocalDevVPN, chẳng hạn 10.7.0.1. Không dùng địa chỉ 127.0.0.1 cho hồ sơ này."
            return
        }
        isConnecting = true
        lastFailure = nil
        errorMessage = nil
        invalidateConnection()
        let request = generation
        defer { isConnecting = false }
        do {
            let verified = try await worker.verify(host: host, port: port)
            guard request == generation else { return }
            connection = verified
            lastFailure = nil
            errorMessage = nil
        } catch {
            guard request == generation else { return }
            errorMessage = error.localizedDescription
        }
    }

    func pairOnDevice() async {
        guard !isBusy else { return }
        guard DeviceCompatibility.requiresPairing else {
            errorMessage = "Ghép đôi trực tiếp trong Cài đặt cần iOS 27 trở lên. Trên iOS cũ hơn, nhập hồ sơ từ máy tính hoặc SideStore."
            return
        }
        isPairing = true
        lastFailure = nil
        errorMessage = nil
        invalidateConnection()
        do {
            let result = try await PairingHost.shared.start()
            record = try await worker.save(result.data, fileName: "1809-pairing.plist", deviceIdentifier: result.deviceIdentifier)
            lastFailure = nil
            errorMessage = nil
            isPairing = false
            refreshNetwork()
            if network.targetUsesTunnel { await verifyConnection() }
        } catch is CancellationError {
            isPairing = false
        } catch {
            isPairing = false
            errorMessage = error.localizedDescription
        }
    }

    func cancelPairing() { PairingHost.shared.cancel() }

    func removeRecord() async {
        guard !isBusy else { return }
        isImporting = true
        defer { isImporting = false }
        do {
            try await worker.remove()
            record = nil
            invalidateConnection()
            lastFailure = nil
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }
}

