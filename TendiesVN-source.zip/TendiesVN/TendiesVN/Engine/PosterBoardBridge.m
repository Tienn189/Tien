// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105 (https://github.com/YangJiiii/3105), YangJiii and contributors.
// Modified for TendiesVN on 2026-10-16: single PosterBoard lookup; removed
// enumeration, arbitrary identifier/class access, and non-wallpaper dependencies.
// See LICENSE and THIRD_PARTY_NOTICES.md in the project root.
#import "PosterBoardBridge.h"
#import <dlfcn.h>
#import <errno.h>
#import <fcntl.h>
#import <stdlib.h>
#import <unistd.h>
#import <xpc/xpc.h>

typedef void *(*MCMQueryCreate)(void);
typedef void (*MCMQuerySetU64)(void *, uint64_t);
typedef void (*MCMQuerySetXPC)(void *, xpc_object_t);
typedef void *(*MCMQueryGetPointer)(void *);
typedef char *(*MCMCopyToken)(void *);
typedef const char *(*MCMGetString)(void *);
typedef void *(*MCMObjectCopy)(void *);
typedef bool (*MCMObjectActivate)(void *, bool);
typedef void (*MCMObjectFree)(void *);
typedef int (*MCMErrorGetInt)(void *);
typedef void (*MCMQueryFree)(void *);

typedef struct {
    void *handle;
    MCMQueryCreate queryCreate;
    MCMQuerySetU64 querySetClass;
    MCMQuerySetXPC querySetIdentifiers;
    MCMQuerySetU64 querySetFlags;
    MCMQuerySetU64 querySetPart;
    MCMQueryGetPointer queryGetSingle;
    MCMQueryGetPointer queryGetLastError;
    MCMQueryFree queryFree;
    MCMGetString objectGetPath;
    MCMGetString objectGetIdentifier;
    MCMObjectCopy objectCopy;
    MCMCopyToken objectCopyToken;
    MCMObjectActivate objectActivate;
    MCMObjectFree objectFree;
    MCMErrorGetInt errorGetPOSIX;
    MCMGetString errorGetMessage;
} MCMAPI;

static MCMAPI *MCMSharedAPI(void) {
    static MCMAPI api;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        api.handle = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
        void *handle = api.handle ?: RTLD_DEFAULT;
#define LOAD(field, symbol) api.field = (__typeof(api.field))dlsym(handle, symbol)
        LOAD(queryCreate, "container_query_create");
        LOAD(querySetClass, "container_query_set_class");
        LOAD(querySetIdentifiers, "container_query_set_identifiers");
        LOAD(querySetFlags, "container_query_operation_set_flags");
        LOAD(querySetPart, "container_query_operation_set_part");
        LOAD(queryGetSingle, "container_query_get_single_result");
        LOAD(queryGetLastError, "container_query_get_last_error");
        LOAD(queryFree, "container_query_free");
        LOAD(objectGetPath, "container_object_get_path");
        LOAD(objectGetIdentifier, "container_object_get_identifier");
        LOAD(objectCopy, "container_object_copy");
        LOAD(objectCopyToken, "container_copy_sandbox_token");
        LOAD(objectActivate, "container_object_sandbox_extension_activate");
        LOAD(objectFree, "container_object_free");
        LOAD(errorGetPOSIX, "container_error_get_posix_errno");
        LOAD(errorGetMessage, "container_error_get_message");
#undef LOAD
    });
    return &api;
}

static BOOL MCMAvailable(void) {
    MCMAPI *api = MCMSharedAPI();
    return api->queryCreate && api->querySetClass && api->querySetIdentifiers &&
        api->querySetFlags && api->queryGetSingle && api->queryFree &&
        api->objectGetPath && api->objectGetIdentifier && api->objectCopy &&
        api->objectCopyToken && api->objectActivate && api->objectFree;
}

static BOOL IsPosterBoardRoot(NSString *path) {
    NSString *prefix = @"/private/var/mobile/Containers/Data/Application";
    if (![[path stringByDeletingLastPathComponent] isEqualToString:prefix]) return NO;
    return [[NSUUID alloc] initWithUUIDString:path.lastPathComponent] != nil;
}

// Query and activation must remain alive for the sandbox extension's lifetime.
@interface TendiesPosterBoardLease : NSObject {
    void *_query;
    void *_activation;
}
@property(nonatomic, copy) NSString *rootPath;
+ (nullable instancetype)leaseWithError:(NSString **)error;
@end

@implementation TendiesPosterBoardLease
+ (instancetype)leaseWithError:(NSString **)error {
    if (!MCMAvailable()) {
        if (error) *error = @"iOS does not expose the required container manager functions";
        return nil;
    }
    MCMAPI *api = MCMSharedAPI();
    void *query = api->queryCreate();
    if (!query) {
        if (error) *error = @"container query creation failed";
        return nil;
    }
    api->querySetClass(query, 2);
    xpc_object_t identifier = xpc_string_create("com.apple.PosterBoard");
    api->querySetIdentifiers(query, identifier);
#if !OS_OBJECT_USE_OBJC
    xpc_release(identifier);
#endif
    api->querySetFlags(query, 0x900000000ULL);
    if (api->querySetPart) api->querySetPart(query, 0);
    void *result = api->queryGetSingle(query);
    if (!result) {
        void *queryError = api->queryGetLastError ? api->queryGetLastError(query) : NULL;
        int posix = queryError && api->errorGetPOSIX ? api->errorGetPOSIX(queryError) : 0;
        const char *message = queryError && api->errorGetMessage ? api->errorGetMessage(queryError) : NULL;
        if (error) *error = [NSString stringWithFormat:@"PosterBoard lookup denied (%d): %s", posix, message ?: "unknown"];
        api->queryFree(query);
        return nil;
    }
    const char *rawIdentifier = api->objectGetIdentifier(result);
    const char *rawPath = api->objectGetPath(result);
    NSString *returnedIdentifier = rawIdentifier ? [NSString stringWithUTF8String:rawIdentifier] : nil;
    NSString *path = rawPath ? [NSString stringWithUTF8String:rawPath] : nil;
    if ([path hasPrefix:@"/var/"]) path = [@"/private" stringByAppendingString:path];
    path = path.stringByStandardizingPath;
    if (![returnedIdentifier isEqualToString:@"com.apple.PosterBoard"] || !IsPosterBoardRoot(path)) {
        if (error) *error = @"container manager returned an unexpected PosterBoard root";
        api->queryFree(query);
        return nil;
    }
    TendiesPosterBoardLease *lease = [TendiesPosterBoardLease new];
    lease->_query = query;
    lease.rootPath = path;
    lease->_activation = api->objectCopy(result);
    char *token = lease->_activation ? api->objectCopyToken(lease->_activation) : NULL;
    BOOL tokenPresent = token && token[0] != '\0';
    free(token);
    if (tokenPresent) api->objectActivate(lease->_activation, false);
    // Some iOS builds grant the extension during the query itself. Actual
    // directory access and the later write probe determine availability.
    int descriptor = open(path.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        if (error) *error = [NSString stringWithFormat:@"PosterBoard root access denied (%d)", errno];
        return nil;
    }
    close(descriptor);
    return lease;
}
- (void)dealloc {
    MCMAPI *api = MCMSharedAPI();
    if (_activation) api->objectFree(_activation);
    if (_query) api->queryFree(_query);
}
@end

NSString *TendiesPosterBoardContainerPath(NSString **error) {
    if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.mobile.MobileHouseArrest"]) {
        if (error) *error = @"the enterprise app must use the MobileHouseArrest bundle identifier";
        return nil;
    }
    static TendiesPosterBoardLease *retainedLease;
    @synchronized (TendiesPosterBoardLease.class) {
        if (retainedLease) return retainedLease.rootPath;
        retainedLease = [TendiesPosterBoardLease leaseWithError:error];
        return retainedLease.rootPath;
    }
}
