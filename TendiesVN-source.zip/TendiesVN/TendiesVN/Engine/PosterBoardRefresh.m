// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105, YangJiii and contributors, AppIconHelper.m at
// a72617ed4c764a65d8aac1e91aca95231e72a2cb. Restricted to PosterBoard.
#import "PosterBoardRefresh.h"
#import <dlfcn.h>
#import <objc/message.h>

BOOL TendiesOpenPosterBoard(void) {
    if (!NSThread.isMainThread) return NO;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!NSClassFromString(@"LSApplicationWorkspace")) {
            // Retain the framework handle for the classes' lifetime.
            dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",
                RTLD_LAZY | RTLD_LOCAL);
        }
    });
    @try {
        Class workspaceClass = NSClassFromString(@"LSApplicationWorkspace");
        SEL defaultWorkspace = NSSelectorFromString(@"defaultWorkspace");
        SEL openApplication = NSSelectorFromString(@"openApplicationWithBundleID:");
        if (!workspaceClass || ![workspaceClass respondsToSelector:defaultWorkspace]) return NO;
        id workspace = ((id (*)(id, SEL))objc_msgSend)(workspaceClass, defaultWorkspace);
        if (!workspace || ![workspace respondsToSelector:openApplication]) return NO;
        return ((BOOL (*)(id, SEL, id))objc_msgSend)(workspace, openApplication, @"com.apple.PosterBoard");
    } @catch (__unused NSException *exception) {
        return NO;
    }
}
