// SPDX-License-Identifier: GPL-3.0-only

import Foundation

enum WallpaperAssetKind: String, Codable {
    case image
    case video
}

/// An original media file inside an app-owned, validated wallpaper package.
/// Identity is its path relative to Extracted, rather than a temporary URL.
struct WallpaperAsset: Identifiable, Equatable {
    let id: String
    let fileURL: URL
    let displayName: String
    let kind: WallpaperAssetKind
    let byteCount: Int64
    let uniformTypeIdentifier: String?
}
