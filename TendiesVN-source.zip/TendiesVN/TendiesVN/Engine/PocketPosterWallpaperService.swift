// SPDX-License-Identifier: GPL-3.0-only
// Pocket-Poster-compatible legacy writer. See THIRD_PARTY_NOTICES.md.

import Foundation
import Darwin

/// Legacy PosterBoard writer used by Pocket-Poster on iOS 17–18.
///
/// The target container UUID is discovered on-device by the 3105 resolver;
/// a validated manually saved UUID is accepted only as a fallback. The writer
/// only ever targets generation 61 and the three known PosterBoard descriptor
/// extensions.
enum PocketPosterWallpaperService {
    private static let generation = "61"
    private static var ownedTrashTargetPath: String?

    static var supportsCurrentVersion: Bool {
        let version = DeviceCompatibility.currentVersion
        return !DeviceCompatibility.isSimulator
            && DeviceCompatibility.supportsPocketPoster(version)
    }

    static var shouldUse: Bool {
        supportsCurrentVersion
            && !DeviceCompatibility.directInstallationSupported
    }

    static func report(
        requiredExtensionIdentifiers: Set<String>? = nil
    ) throws -> WallpaperAccessReport {
        guard supportsCurrentVersion else {
            throw WallpaperLabError.pocketPosterHashRequired
        }
        // Preserve the native resolver diagnostic instead of collapsing a
        // failed discovery into the generic "hash required" message.
        let appHash = try PocketPosterConfiguration.discoverAppHashIfNeeded()
        let identifiers = try normalizedIdentifiers(requiredExtensionIdentifiers)
        let directories = Dictionary(uniqueKeysWithValues: identifiers.map { identifier in
            (
                identifier,
                PocketPosterConfiguration.descriptorTargetURL(
                    appHash: appHash,
                    extensionIdentifier: identifier
                )
            )
        })
        let root = URL(
            fileURLWithPath: "/var/mobile/Containers/Data/Application/\(appHash)",
            isDirectory: true
        )
        return WallpaperAccessReport(
            layout: WallpaperPosterLayout(
                generation: generation,
                storeURL: root,
                extensionDescriptorDirectories: directories
            ),
            descriptorCount: 0,
            customDescriptorCount: 0,
            canInstall: !identifiers.isEmpty,
            deniedExtensionIdentifiers: []
        )
    }

    static func install(_ package: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        guard supportsCurrentVersion else {
            throw WallpaperLabError.pocketPosterHashRequired
        }
        // The resolver may report a kernel, MCM, or generation-61 diagnostic;
        // keep that error visible so a device failure can be fixed from the
        // journal rather than appearing as an unrelated package error.
        let appHash = try PocketPosterConfiguration.discoverAppHashIfNeeded()
        let validated = try WallpaperPackageStore.validated(package)
        guard !validated.payload.descriptors.isEmpty else {
            throw WallpaperLabError.noDescriptors
        }

        let fileManager = FileManager.default
        let documentsURL = PocketPosterConfiguration.documentsURL
        let stagingURL = documentsURL.appendingPathComponent(
            ".1809-pocket-staging-\(UUID().uuidString)",
            isDirectory: true
        )
        try fileManager.createDirectory(
            at: stagingURL,
            withIntermediateDirectories: false,
            attributes: [.posixPermissions: 0o700]
        )
        defer {
            removeTrashLinkIfOwned()
            try? fileManager.removeItem(at: stagingURL)
        }

        for source in validated.payload.descriptors {
            guard let extensionIdentifier = PocketPosterConfiguration.legacyExtensionIdentifier(
                for: source.extensionIdentifier
            ) else {
                throw WallpaperLabError.unsupportedPosterLayout
            }
            let target = PocketPosterConfiguration.descriptorTargetURL(
                appHash: appHash,
                extensionIdentifier: extensionIdentifier
            )
            try installDescriptor(
                source,
                into: target,
                stagingRoot: stagingURL,
                fileManager: fileManager
            )
        }

        return try report(
            requiredExtensionIdentifiers: Set(
                validated.payload.descriptors.compactMap {
                    PocketPosterConfiguration.legacyExtensionIdentifier(
                        for: $0.extensionIdentifier
                    )
                }
            )
        )
    }

    private static func installDescriptor(
        _ source: WallpaperDescriptorSource,
        into target: URL,
        stagingRoot: URL,
        fileManager: FileManager
    ) throws {
        // Some clean iOS 17–18 installs have the generation-61 extension
        // registered but no descriptor directory until the first write. The
        // escaped process can create this fixed, validated target; without it
        // FileManager.trashItem cannot move the staged descriptor through the
        // .Trash transfer route.
        try fileManager.createDirectory(
            at: target,
            withIntermediateDirectories: true,
            attributes: [.posixPermissions: 0o755]
        )
        let staged = stagingRoot.appendingPathComponent(
            UUID().uuidString.uppercased(),
            isDirectory: true
        )
        try fileManager.copyItem(at: source.directoryURL, to: staged)
        defer { try? fileManager.removeItem(at: staged) }
        try WallpaperDescriptorRewriter.randomize(
            in: staged,
            identifier: nil,
            fileManager: fileManager
        )

        try replaceTrashLink(withTarget: target, fileManager: fileManager)
        do {
            try fileManager.trashItem(at: staged, resultingItemURL: nil)
        } catch {
            removeTrashLinkIfOwned()
            throw WallpaperLabError.pocketPosterTargetUnavailable
        }
        removeTrashLinkIfOwned()
    }

    private static func replaceTrashLink(
        withTarget target: URL,
        fileManager: FileManager
    ) throws {
        removeTrashLinkIfOwned()
        let trash = PocketPosterConfiguration.trashURL
        var info = stat()
        if lstat(trash.path, &info) == 0 {
            throw WallpaperLabError.symbolicLinkUnsupported
        }
        guard errno == ENOENT else {
            throw WallpaperLabError.pocketPosterTargetUnavailable
        }
        try fileManager.createSymbolicLink(at: trash, withDestinationURL: target)
        ownedTrashTargetPath = target.standardizedFileURL.path
    }

    private static func removeTrashLinkIfOwned() {
        guard let expectedTarget = ownedTrashTargetPath else { return }
        let trash = PocketPosterConfiguration.trashURL
        var info = stat()
        guard lstat(trash.path, &info) == 0 else {
            ownedTrashTargetPath = nil
            return
        }
        guard (info.st_mode & mode_t(S_IFMT)) == mode_t(S_IFLNK) else {
            ownedTrashTargetPath = nil
            return
        }
        let fileManager = FileManager.default
        let destination = try? fileManager.destinationOfSymbolicLink(atPath: trash.path)
        let resolved = destination.map {
            URL(fileURLWithPath: $0, relativeTo: trash.deletingLastPathComponent())
                .standardizedFileURL.path
        }
        if resolved == expectedTarget {
            _ = unlink(trash.path)
        }
        ownedTrashTargetPath = nil
    }

    private static func normalizedIdentifiers(
        _ input: Set<String>?
    ) throws -> [String] {
        let source = input ?? [WallpaperPosterLayout.collectionsExtension]
        let identifiers = source.compactMap {
            PocketPosterConfiguration.legacyExtensionIdentifier(for: $0)
        }
        guard identifiers.count == source.count else {
            throw WallpaperLabError.unsupportedPosterLayout
        }
        return Array(Set(identifiers)).sorted()
    }
}
