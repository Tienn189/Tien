// SPDX-License-Identifier: GPL-3.0-only
// Adapted from 3105, YangJiii and contributors, AppIconHelper.m.
#import <Foundation/Foundation.h>

/// Opens only PosterBoard after a committed wallpaper change. Main thread only.
/// The user closes its card in the app switcher to refresh the collection.
BOOL TendiesOpenPosterBoard(void);
