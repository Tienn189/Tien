import Foundation

enum PocketPosterConfigurationError: LocalizedError {
    case invalidAppHash

    var errorDescription: String? {
        "App Hash/UUID phải là UUID của container PosterBoard hợp lệ."
    }
}

/// Configuration for the Pocket-Poster-compatible iOS 17–18 writer.
///
/// Pocket-Poster obtains this UUID from Nugget on a computer because an app
/// cannot discover the PosterBoard application container from its own sandbox.
enum PocketPosterConfiguration {
    static let appHashKey = "1809.pocketPoster.appHash"

    static var appHash: String? {
        normalizedAppHash(UserDefaults.standard.string(forKey: appHashKey) ?? "")
    }

    static var isConfigured: Bool { appHash != nil }

    static func normalizedAppHash(_ rawValue: String) -> String? {
        let trimmed = rawValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.utf8.count == 36,
              let uuid = UUID(uuidString: trimmed) else { return nil }
        return uuid.uuidString.uppercased()
    }

    static func saveAppHash(_ rawValue: String) throws {
        guard let normalized = normalizedAppHash(rawValue) else {
            throw PocketPosterConfigurationError.invalidAppHash
        }
        UserDefaults.standard.set(normalized, forKey: appHashKey)
    }

    static func clearAppHash() {
        UserDefaults.standard.removeObject(forKey: appHashKey)
    }

    static var documentsURL: URL {
        if let liveContainerHome = ProcessInfo.processInfo.environment["LC_HOME_PATH"],
           !liveContainerHome.isEmpty {
            return URL(fileURLWithPath: liveContainerHome, isDirectory: true)
                .appendingPathComponent("Documents", isDirectory: true)
        }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static var trashURL: URL {
        documentsURL.appendingPathComponent(".Trash", isDirectory: true)
    }

    static func descriptorTargetURL(appHash: String, extensionIdentifier: String) -> URL {
        URL(fileURLWithPath: "/var/mobile/Containers/Data/Application", isDirectory: true)
            .appendingPathComponent(appHash, isDirectory: true)
            .appendingPathComponent("Library", isDirectory: true)
            .appendingPathComponent("Application Support", isDirectory: true)
            .appendingPathComponent("PRBPosterExtensionDataStore", isDirectory: true)
            .appendingPathComponent("61", isDirectory: true)
            .appendingPathComponent("Extensions", isDirectory: true)
            .appendingPathComponent(extensionIdentifier, isDirectory: true)
            .appendingPathComponent("descriptors", isDirectory: true)
    }

    /// Normalize identifiers used by newer package producers to the extension
    /// names present in the iOS 17–18 PosterBoard store.
    static func legacyExtensionIdentifier(for identifier: String) -> String? {
        switch identifier {
        case "com.apple.WallpaperKit.CollectionsPoster",
             "com.apple.Posters.CollectionsPoster":
            return "com.apple.WallpaperKit.CollectionsPoster"
        case "com.apple.PhotosUIPrivate.PhotosPosterProvider",
             "com.apple.Posters.PhotosPosterProvider":
            return "com.apple.PhotosUIPrivate.PhotosPosterProvider"
        case "com.apple.MercuryPoster",
             "com.apple.Posters.MercuryPosterApp":
            return "com.apple.MercuryPoster"
        default:
            return nil
        }
    }
}
