// SPDX-License-Identifier: GPL-3.0-only
// Public Photos APIs only. Saving a resource does not set the system wallpaper.

import Foundation
import Photos
import UniformTypeIdentifiers

enum WallpaperPhotoLibraryError: LocalizedError {
    case permissionDenied
    case permissionRestricted
    case simulatorUnavailable
    case unsupportedMedia
    case changedResource
    case saveFailed(String?)

    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return "Chưa được phép thêm vào Ảnh. Mở Cài đặt, tìm 1809 > Ảnh, cho phép thêm ảnh rồi thử lại."
        case .permissionRestricted:
            return "Thiết bị đang hạn chế quyền thêm vào Ảnh. Hãy kiểm tra Thời gian sử dụng hoặc cấu hình quản lý thiết bị."
        case .simulatorUnavailable:
            return "Hãy dùng iPhone hoặc iPad thật để kiểm tra lưu vào Ảnh. Bạn vẫn có thể xuất tệp bằng nút Chia sẻ."
        case .unsupportedMedia:
            return "Tệp này không phải ảnh hoặc video được nhận dạng để lưu vào Ảnh."
        case .changedResource:
            return "Tệp hình nền đã thay đổi hoặc không còn trong thư viện. Hãy nhập lại tệp."
        case .saveFailed(let detail):
            let message = "Ảnh chưa xác nhận lưu thành công. Hãy kiểm tra dung lượng trống rồi thử lại."
            guard let detail, !detail.isEmpty else { return message }
            return message + " " + String(detail.prefix(300))
        }
    }
}

enum WallpaperPhotoLibrary {
    private static let maximumResourceBytes: Int64 = 256 * 1_024 * 1_024

    /// Adds the original image or normal video resource. It never creates or
    /// claims a Live Photo and never changes the Lock Screen or Home Screen.
    static func save(
        _ asset: WallpaperAsset,
        packageID: UUID,
        packageName: String
    ) async throws -> WallpaperSaveReceipt {
        #if targetEnvironment(simulator)
        throw WallpaperPhotoLibraryError.simulatorUnavailable
        #else
        try Task.checkCancellation()
        let resource = try checkedResource(asset)
        try await authorizeAdding()
        try Task.checkCancellation()
        // Recheck after permission UI; a package may have been removed meanwhile.
        let current = try checkedResource(asset)
        guard resource.url == current.url, resource.bytes == current.bytes else {
            throw WallpaperPhotoLibraryError.changedResource
        }
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            PHPhotoLibrary.shared().performChanges {
                let request = PHAssetCreationRequest.forAsset()
                let options = PHAssetResourceCreationOptions()
                options.originalFilename = resource.filename
                options.uniformTypeIdentifier = resource.type.identifier
                options.shouldMoveFile = false
                request.addResource(
                    with: asset.kind == .image ? .photo : .video,
                    fileURL: resource.url,
                    options: options
                )
            } completionHandler: { success, error in
                if success {
                    continuation.resume()
                } else {
                    continuation.resume(throwing: WallpaperPhotoLibraryError.saveFailed(error?.localizedDescription))
                }
            }
        }
        // Do not check cancellation here: Photos has committed the asset, so the
        // caller needs a receipt even if cancellation arrived during the write.
        return WallpaperSaveReceipt(
            id: UUID(),
            packageID: packageID,
            packageName: boundedName(packageName, fallback: "Hình nền"),
            assetName: boundedName(asset.displayName, fallback: resource.filename),
            kind: asset.kind,
            savedAt: Date()
        )
        #endif
    }

    /// A copy owned by the app, suitable for a share sheet without Photos access.
    /// Call from a background worker. The caller removes the copy after sharing.
    static func shareCopy(_ asset: WallpaperAsset) throws -> URL {
        let resource = try checkedResource(asset)
        let directory = try WallpaperSandboxFiles.directory(
            .cachesDirectory,
            components: ["WallpaperExports", UUID().uuidString]
        )
        let destination = directory.appendingPathComponent(resource.filename)
        do {
            try FileManager.default.copyItem(at: resource.url, to: destination)
            let (_, bytes) = try WallpaperSandboxFiles.regularFile(destination, maximumBytes: maximumResourceBytes)
            guard bytes == resource.bytes else { throw WallpaperPhotoLibraryError.changedResource }
            return destination
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }

    /// Removes only a validated export snapshot produced by shareCopy(_:).
    static func removeShareCopy(_ url: URL) throws {
        let (snapshot, _) = try WallpaperSandboxFiles.regularFile(url, maximumBytes: maximumResourceBytes)
        let exports = try WallpaperSandboxFiles.directory(.cachesDirectory, components: ["WallpaperExports"])
        let directory = snapshot.deletingLastPathComponent()
        let directoryName = directory.lastPathComponent
        guard directory.deletingLastPathComponent() == exports,
              let identifier = UUID(uuidString: directoryName),
              identifier.uuidString == directoryName else {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        try FileManager.default.removeItem(at: snapshot)
        // Never recursively delete unexpected siblings, even in an export folder.
        if try FileManager.default.contentsOfDirectory(atPath: directory.path).isEmpty {
            try FileManager.default.removeItem(at: directory)
        }
    }

    private static func authorizeAdding() async throws {
        var status = PHPhotoLibrary.authorizationStatus(for: .addOnly)
        if status == .notDetermined {
            status = await withCheckedContinuation { continuation in
                PHPhotoLibrary.requestAuthorization(for: .addOnly) { continuation.resume(returning: $0) }
            }
        }
        switch status {
        case .authorized, .limited: return
        case .restricted: throw WallpaperPhotoLibraryError.permissionRestricted
        default: throw WallpaperPhotoLibraryError.permissionDenied
        }
    }

    private struct Resource {
        let url: URL
        let bytes: Int64
        let type: UTType
        let filename: String
    }

    private static func checkedResource(_ asset: WallpaperAsset) throws -> Resource {
        let (url, bytes) = try WallpaperSandboxFiles.regularFile(asset.fileURL, maximumBytes: maximumResourceBytes)
        guard bytes == asset.byteCount else { throw WallpaperPhotoLibraryError.changedResource }
        let declared = asset.uniformTypeIdentifier.flatMap { UTType($0) }
        let type = declared ?? UTType(filenameExtension: url.pathExtension)
        guard let type,
              asset.kind == .image ? type.conforms(to: .image) : type.conforms(to: .movie),
              let suffix = type.preferredFilenameExtension,
              !suffix.isEmpty else {
            throw WallpaperPhotoLibraryError.unsupportedMedia
        }
        let original = (asset.displayName as NSString).lastPathComponent
        // The catalog already supplies a filename stem. Preserve dots within it.
        let base = original
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: " -_()."))
        let clean = String(base.unicodeScalars.map { allowed.contains($0) ? Character(String($0)) : "_" })
            .trimmingCharacters(in: CharacterSet(charactersIn: " ."))
        let name = clean.isEmpty ? "Wallpaper" : String(clean.prefix(100))
        return Resource(url: url, bytes: bytes, type: type, filename: name + "." + suffix)
    }

    private static func boundedName(_ value: String, fallback: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let chosen = trimmed.isEmpty ? fallback : trimmed
        // A scalar bound keeps the encoded history safely below its byte budget.
        return String(String.UnicodeScalarView(chosen.unicodeScalars.prefix(200)))
    }
}
