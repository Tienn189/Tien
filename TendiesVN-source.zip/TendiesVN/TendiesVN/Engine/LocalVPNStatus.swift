import Foundation
import Darwin

struct LocalVPNSnapshot: Equatable {
    var hasTunnel = false
    var targetUsesTunnel = false
    var interfacesText = ""
}

enum LocalVPNStatus {
    private struct Interface {
        let name: String
        let address: String
    }

    static func normalizeHost(_ value: String) -> String {
        String(value.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: "/").first ?? "")
    }

    static func isValidHost(_ value: String) -> Bool {
        let host = normalizeHost(value)
        let parts = host.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4, parts.allSatisfy({
            !$0.isEmpty && $0.allSatisfy({ $0.isASCII && $0.isNumber }) && UInt8($0) != nil
        }) else { return false }
        let bytes = parts.compactMap { UInt8($0) }
        // Pairing credentials are used only on a local/private VPN endpoint.
        return bytes[0] == 10 || bytes[0] == 127 ||
            (bytes[0] == 172 && (16...31).contains(bytes[1])) ||
            (bytes[0] == 192 && bytes[1] == 168) ||
            (bytes[0] == 169 && bytes[1] == 254)
    }

    static func snapshot(host: String) -> LocalVPNSnapshot {
        var first: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&first) == 0, let first else { return LocalVPNSnapshot() }
        defer { freeifaddrs(first) }
        var interfaces: [Interface] = []
        var current: UnsafeMutablePointer<ifaddrs>? = first
        while let item = current {
            defer { current = item.pointee.ifa_next }
            guard let address = item.pointee.ifa_addr,
                  address.pointee.sa_family == sa_family_t(AF_INET),
                  item.pointee.ifa_flags & UInt32(IFF_UP) != 0,
                  let ip = numericHost(address) else { continue }
            interfaces.append(Interface(name: String(cString: item.pointee.ifa_name), address: ip))
        }
        let source = routeSource(to: normalizeHost(host))
        let routeInterface = interfaces.first { $0.address == source }
        return LocalVPNSnapshot(
            hasTunnel: interfaces.contains { isTunnel($0.name) },
            targetUsesTunnel: routeInterface.map { isTunnel($0.name) } ?? false,
            interfacesText: interfaces.map { "\($0.name)=\($0.address)" }.joined(separator: ", ")
        )
    }

    private static func isTunnel(_ name: String) -> Bool {
        ["utun", "ipsec", "ppp", "tap"].contains { name.hasPrefix($0) }
    }

    private static func numericHost(_ address: UnsafePointer<sockaddr>) -> String? {
        var result = [CChar](repeating: 0, count: Int(NI_MAXHOST))
        guard getnameinfo(address, socklen_t(MemoryLayout<sockaddr_in>.size), &result,
                          socklen_t(result.count), nil, 0, NI_NUMERICHOST) == 0 else { return nil }
        return String(cString: result)
    }

    private static func routeSource(to host: String) -> String? {
        var destination = sockaddr_in()
        destination.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        destination.sin_family = sa_family_t(AF_INET)
        destination.sin_port = UInt16(9).bigEndian
        guard host.withCString({ inet_pton(AF_INET, $0, &destination.sin_addr) }) == 1 else { return nil }
        let descriptor = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        guard descriptor >= 0 else { return nil }
        defer { close(descriptor) }
        // UDP connect selects a route without sending any payload.
        let connected = withUnsafePointer(to: &destination) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.connect(descriptor, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard connected == 0 else { return nil }
        var local = sockaddr_in()
        var length = socklen_t(MemoryLayout<sockaddr_in>.size)
        let status = withUnsafeMutablePointer(to: &local) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                getsockname(descriptor, $0, &length)
            }
        }
        guard status == 0 else { return nil }
        return withUnsafePointer(to: &local) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1, numericHost)
        }
    }
}
