import Foundation
import AirliftFFI

/// PosterBoard writer used for iOS 27.0.1 and 27.0 builds that are outside
/// the local BadQuery allowlist. Airlift requires an imported pairing record.
enum AirliftWallpaperService {
    private static func errorText(_ pointer: UnsafeMutablePointer<CChar>?) -> String? {
        guard let pointer else { return nil }
        let raw = String(cString: pointer)
        let lower = raw.lowercased()
        if lower.contains("channel closed") || lower.contains("read length") {
            return "Kênh Airlift bị đóng trong lúc kết nối. Mở LocalDevVPN, kiểm tra IP thiết bị, xác thực lại pairing rồi thử lại."
        }
        if lower.contains("timed out") || lower.contains("timeout") {
            return "Airlift hết thời gian chờ thiết bị. Mở khoá thiết bị, giữ LocalDevVPN đang chạy và thử lại."
        }
        return raw
    }

    static var supportsCurrentVersion: Bool {
        let version = DeviceCompatibility.currentVersion
        return !DeviceCompatibility.isSimulator
            && version.major == 27
            && version.minor == 0
            && version.patch <= 1
    }

    static var shouldUse: Bool {
        supportsCurrentVersion && !DeviceCompatibility.directInstallationSupported
    }

    static func install(_ package: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        guard supportsCurrentVersion else { throw WallpaperLabError.unsupportedPosterLayout }
        guard AirliftPairingStore.hasPairing,
              UserDefaults.standard.bool(forKey: "1809.pairing.verified") else {
            throw WallpaperLabError.accessDenied
        }

        configureTargetHost()
        let validated = try WallpaperPackageStore.validated(package)
        let container = try findPosterBoardContainer()
        let fileManager = FileManager.default
        let stagingRoot = fileManager.temporaryDirectory
            .appendingPathComponent("1809-airlift-\(UUID().uuidString)", isDirectory: true)
        try fileManager.createDirectory(at: stagingRoot, withIntermediateDirectories: false)
        defer { try? fileManager.removeItem(at: stagingRoot) }

        let generation = "61"
        for source in validated.payload.descriptors {
            let staged = stagingRoot.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try fileManager.copyItem(at: source.directoryURL, to: staged)
            try WallpaperDescriptorRewriter.randomize(
                in: staged,
                identifier: nil,
                fileManager: fileManager
            )

            let destinationName = UUID().uuidString.uppercased()
            let parent = "\(container)/Library/Application Support/PRBPosterExtensionDataStore/\(generation)/Extensions/\(source.extensionIdentifier)/descriptors"
            try inject(
                folder: staged,
                parent: parent,
                name: destinationName
            )

            // iOS 18+ also mirrors the two modern extension identifiers used by
            // PosterBoard's newer descriptor providers.
            if source.extensionIdentifier == WallpaperPosterLayout.collectionsExtension {
                let modernParent = "\(container)/Library/Application Support/PRBPosterExtensionDataStore/\(generation)/Extensions/com.apple.Posters.CollectionsPosterApp/descriptors"
                try? inject(folder: staged, parent: modernParent, name: destinationName)
            } else if source.extensionIdentifier == WallpaperPosterLayout.mercuryExtension {
                let modernParent = "\(container)/Library/Application Support/PRBPosterExtensionDataStore/\(generation)/Extensions/com.apple.Posters.MercuryPosterApp/descriptors"
                try? inject(folder: staged, parent: modernParent, name: destinationName)
            }
        }

        let layout = WallpaperPosterLayout(
            generation: generation,
            storeURL: URL(fileURLWithPath: container, isDirectory: true),
            extensionDescriptorDirectories: [:]
        )
        return WallpaperAccessReport(
            layout: layout,
            descriptorCount: validated.payload.descriptors.count,
            customDescriptorCount: validated.payload.descriptors.count,
            canInstall: true,
            deniedExtensionIdentifiers: []
        )
    }

    private static func findPosterBoardContainer() throws -> String {
        let pairingPath = AirliftPairingStore.pairingURL.path
        var containerPointer: UnsafeMutablePointer<CChar>?
        var errorPointer: UnsafeMutablePointer<CChar>?
        let status = pairingPath.withCString { pairing in
            "com.apple.PosterBoard".withCString { identifier in
                al_find_app_container(
                    pairing,
                    identifier,
                    nil,
                    nil,
                    &containerPointer,
                    &errorPointer
                )
            }
        }
        defer {
            if let containerPointer { al_string_free(containerPointer) }
            if let errorPointer { al_string_free(errorPointer) }
        }
        guard status == 0, let containerPointer else {
            throw NSError(
                domain: "AirliftWallpaperService",
                code: Int(status),
                userInfo: [NSLocalizedDescriptionKey: errorText(errorPointer) ?? "Không tìm thấy kho PosterBoard qua pairing."]
            )
        }
        return String(cString: containerPointer)
    }

    private static func configureTargetHost() {
        let host = UserDefaults.standard.string(forKey: "1809.pairing.deviceIP") ?? "10.7.0.1"
        let trimmed = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            al_clear_target_hosts()
            return
        }
        trimmed.withCString { _ = al_set_target_host($0) }
    }

    private static func inject(folder: URL, parent: String, name: String) throws {
        let pairingPath = AirliftPairingStore.pairingURL.path
        var errorPointer: UnsafeMutablePointer<CChar>?
        let status = pairingPath.withCString { pairing in
            folder.path.withCString { source in
                parent.withCString { target in
                    name.withCString { destination in
                        al_exploit_inject_folder(
                            pairing,
                            source,
                            target,
                            destination,
                            nil,
                            nil,
                            &errorPointer
                        )
                    }
                }
            }
        }
        defer {
            if let errorPointer { al_string_free(errorPointer) }
        }
        guard status == 0 else {
            throw NSError(
                domain: "AirliftWallpaperService",
                code: Int(status),
                userInfo: [NSLocalizedDescriptionKey: errorText(errorPointer) ?? "Airlift không ghi được descriptor."]
            )
        }
    }
}
