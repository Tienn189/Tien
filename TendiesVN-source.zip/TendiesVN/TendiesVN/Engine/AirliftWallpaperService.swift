import Foundation
import AirliftFFI

/// PosterBoard writer used for iOS 27.0.1 and 27.0 builds that are outside
/// the local BadQuery allowlist. Airlift requires an imported pairing record.
enum AirliftWallpaperService {
    private static func errorText(_ pointer: UnsafeMutablePointer<CChar>?) -> String? {
        guard let pointer else { return nil }
        return errorText(String(cString: pointer))
    }

    private static func errorText(_ raw: String?) -> String? {
        guard let raw, !raw.isEmpty else { return nil }
        let lower = raw.lowercased()
        if lower.contains("channel closed") || lower.contains("read length") {
            return "Kênh Airlift bị đóng: \(raw). Mở LocalDevVPN, kiểm tra IP thiết bị và xác thực lại pairing rồi thử lại."
        }
        if lower.contains("timed out") || lower.contains("timeout") {
            return "Airlift hết thời gian chờ: \(raw). Mở khoá thiết bị, giữ LocalDevVPN đang chạy và thử lại."
        }
        if lower.contains("pairverify") || lower.contains("pair verify") || lower.contains("pairing") {
            return "Pairing iOS 27 bị từ chối: \(raw). Xoá hồ sơ cũ, ghép đôi lại trong Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển, rồi xác thực lại trong 1809."
        }
        return raw
    }

    static var supportsCurrentVersion: Bool {
        let version = DeviceCompatibility.currentVersion
        return !DeviceCompatibility.isSimulator
            && version.major == 27
            && version.minor == 0
            && version.patch <= 1
    }

    static var shouldUse: Bool {
        supportsCurrentVersion && !DeviceCompatibility.directInstallationSupported
    }

    static func install(_ package: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        guard supportsCurrentVersion else { throw WallpaperLabError.unsupportedPosterLayout }
        guard AirliftPairingStore.hasPairing,
              UserDefaults.standard.bool(forKey: "1809.pairing.verified") else {
            throw WallpaperLabError.accessDenied
        }

        configureTargetHost()
        let validated = try WallpaperPackageStore.validated(package)
        let container = try findPosterBoardContainer()
        let fileManager = FileManager.default
        let stagingRoot = fileManager.temporaryDirectory
            .appendingPathComponent("1809-airlift-\(UUID().uuidString)", isDirectory: true)
        try fileManager.createDirectory(at: stagingRoot, withIntermediateDirectories: false)
        defer { try? fileManager.removeItem(at: stagingRoot) }

        let generation = "61"
        for source in validated.payload.descriptors {
            let staged = stagingRoot.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try fileManager.copyItem(at: source.directoryURL, to: staged)
            try WallpaperDescriptorRewriter.randomize(
                in: staged,
                identifier: nil,
                fileManager: fileManager
            )

            let destinationName = UUID().uuidString.uppercased()
            // Stable iOS 27 uses the `com.apple.Posters.*` providers. Older
            // packages still carry the legacy identifiers, so try the modern
            // provider first and fall back to the legacy path only when the
            // device rejects it. The old code required the legacy path and
            // silently ignored the modern write, which left iOS 27 with no
            // usable descriptor even though Airlift reported success.
            let extensionIdentifiers = targetExtensionIdentifiers(
                for: source.extensionIdentifier
            )
            try injectIntoFirstAvailable(
                folder: staged,
                container: container,
                generation: generation,
                extensionIdentifiers: extensionIdentifiers,
                name: destinationName
            )
        }

        let layout = WallpaperPosterLayout(
            generation: generation,
            storeURL: URL(fileURLWithPath: container, isDirectory: true),
            extensionDescriptorDirectories: [:]
        )
        return WallpaperAccessReport(
            layout: layout,
            descriptorCount: validated.payload.descriptors.count,
            customDescriptorCount: validated.payload.descriptors.count,
            canInstall: true,
            deniedExtensionIdentifiers: []
        )
    }

    private static func findPosterBoardContainer() throws -> String {
        let pairingPath = AirliftPairingStore.pairingURL.path
        var containerPointer: UnsafeMutablePointer<CChar>?
        var errorPointer: UnsafeMutablePointer<CChar>?
        let status = pairingPath.withCString { pairing in
            "com.apple.PosterBoard".withCString { identifier in
                al_find_app_container(
                    pairing,
                    identifier,
                    nil,
                    nil,
                    &containerPointer,
                    &errorPointer
                )
            }
        }
        defer {
            if let containerPointer { al_string_free(containerPointer) }
            if let errorPointer { al_string_free(errorPointer) }
        }
        guard status == 0, let containerPointer else {
            throw NSError(
                domain: "AirliftWallpaperService",
                code: Int(status),
                userInfo: [NSLocalizedDescriptionKey: errorText(errorPointer) ?? "Không tìm thấy kho PosterBoard qua pairing."]
            )
        }
        return String(cString: containerPointer)
    }

    private static func configureTargetHost() {
        let host = UserDefaults.standard.string(forKey: "1809.pairing.deviceIP") ?? "10.7.0.1"
        let trimmed = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            al_clear_target_hosts()
            return
        }
        trimmed.withCString { _ = al_set_target_host($0) }
    }

    private static func targetExtensionIdentifiers(for identifier: String) -> [String] {
        switch identifier {
        case WallpaperPosterLayout.collectionsExtension:
            return [
                "com.apple.Posters.CollectionsPosterApp",
                WallpaperPosterLayout.collectionsExtension
            ]
        case WallpaperPosterLayout.mercuryExtension:
            return [
                "com.apple.Posters.MercuryPosterApp",
                WallpaperPosterLayout.mercuryExtension
            ]
        case WallpaperPosterLayout.photosExtension:
            return [
                WallpaperPosterLayout.photosExtension,
                "com.apple.Posters.PhotosPosterProvider"
            ]
        default:
            return [identifier]
        }
    }

    private static func injectIntoFirstAvailable(
        folder: URL,
        container: String,
        generation: String,
        extensionIdentifiers: [String],
        name: String
    ) throws {
        var lastError: Error?
        for identifier in extensionIdentifiers {
            let parent = "\(container)/Library/Application Support/PRBPosterExtensionDataStore/\(generation)/Extensions/\(identifier)/descriptors"
            do {
                try inject(folder: folder, parent: parent, name: name)
                return
            } catch {
                lastError = error
            }
        }
        throw lastError ?? NSError(
            domain: "AirliftWallpaperService",
            code: 1,
            userInfo: [NSLocalizedDescriptionKey: "Không tìm thấy extension PosterBoard phù hợp để ghi."]
        )
    }

    private static func inject(folder: URL, parent: String, name: String) throws {
        let pairingPath = AirliftPairingStore.pairingURL.path
        var lastStatus = 1
        var lastMessage: String?

        // ATC can close an RSD channel while LocalDevVPN is renewing the
        // tunnel, or immediately after a previous sync session. Reconfigure
        // the target and retry a few times before surfacing the final error.
        // Each FFI call owns its staging/cleanup transaction, so a retry does
        // not reuse a half-written descriptor.
        for attempt in 0..<3 {
            var errorPointer: UnsafeMutablePointer<CChar>?
            let status = pairingPath.withCString { pairing in
                folder.path.withCString { source in
                    parent.withCString { target in
                        name.withCString { destination in
                            al_exploit_inject_folder(
                                pairing,
                                source,
                                target,
                                destination,
                                nil,
                                nil,
                                &errorPointer
                            )
                        }
                    }
                }
            }
            let rawMessage = errorPointer.map { String(cString: $0) }
            if let errorPointer { al_string_free(errorPointer) }
            if status == 0 { return }

            lastStatus = Int(status)
            lastMessage = rawMessage
            let lower = (rawMessage ?? "").lowercased()
            let transient = lower.contains("channel closed")
                || lower.contains("read length")
                || lower.contains("connection reset")
            if attempt < 2 && transient {
                configureTargetHost()
                Thread.sleep(forTimeInterval: 0.35 * Double(attempt + 1))
                continue
            }
            break
        }

        throw NSError(
            domain: "AirliftWallpaperService",
            code: lastStatus,
            userInfo: [NSLocalizedDescriptionKey: errorText(lastMessage).map { $0 } ?? "Airlift không ghi được descriptor."]
        )
    }
}
