// SPDX-License-Identifier: GPL-3.0-only

import AVFoundation
import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

/// Reads media from imported packages using public frameworks. It never changes
/// package contents or reads the system wallpaper store.
enum WallpaperAssetCatalog {
    static let maximumAssetCount = 512
    static let maximumImageDimension = 16_384
    static let maximumImagePixels: Int64 = 64_000_000
    static let maximumImageFrameCount = 512
    static let maximumThumbnailDimension = 2_048

    static func assets(in package: WallpaperStagedPackage) throws -> [WallpaperAsset] {
        // Ignore every caller-supplied file path except the validated identity.
        let validated = try WallpaperPackageStore.validated(package)
        let root = validated.extractedURL.standardizedFileURL
        let resolvedRoot = root.resolvingSymlinksInPath()
        let manager = FileManager.default
        let rootValues = try root.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard root.isFileURL, rootValues.isDirectory == true,
              rootValues.isSymbolicLink != true else {
            throw WallpaperLabError.unsafeArchive
        }

        let keys: Set<URLResourceKey> = [
            .isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey
        ]
        var enumerationError: Error?
        guard let enumerator = manager.enumerator(
            at: root,
            includingPropertiesForKeys: Array(keys),
            options: [],
            errorHandler: { _, error in
                enumerationError = error
                return false
            }
        ) else { throw WallpaperLabError.unsafeArchive }

        var result: [WallpaperAsset] = []
        var entryCount = 0
        var totalBytes: Int64 = 0
        for case let fileURL as URL in enumerator {
            entryCount += 1
            guard entryCount <= WallpaperLabLimits.maximumEntryCount else {
                throw WallpaperLabError.packageTooLarge
            }
            let normalized = fileURL.standardizedFileURL
            guard isDescendant(normalized, of: root),
                  isDescendant(normalized.resolvingSymlinksInPath(), of: resolvedRoot) else {
                throw WallpaperLabError.unsafeArchive
            }
            let relativePath = String(normalized.path.dropFirst(root.path.count + 1))
            guard relativePath.utf8.count <= WallpaperLabLimits.maximumPathBytes else {
                throw WallpaperLabError.unsafeArchive
            }
            let values = try normalized.resourceValues(forKeys: keys)
            guard values.isSymbolicLink != true else {
                throw WallpaperLabError.symbolicLinkUnsupported
            }
            if values.isDirectory == true { continue }
            guard values.isRegularFile == true, let size = values.fileSize, size >= 0 else {
                throw WallpaperLabError.unsafeArchive
            }
            let byteCount = Int64(size)
            guard byteCount <= WallpaperLabLimits.maximumEntryBytes,
                  byteCount <= WallpaperLabLimits.maximumExpandedBytes - totalBytes else {
                throw WallpaperLabError.packageTooLarge
            }
            totalBytes += byteCount
            guard byteCount > 0 else { continue }

            let kind: WallpaperAssetKind
            let typeIdentifier: String?
            if let source = imageSource(at: normalized) {
                kind = .image
                typeIdentifier = CGImageSourceGetType(source) as String?
            } else if let type = videoType(at: normalized) {
                kind = .video
                typeIdentifier = type.identifier
            } else {
                // Plists, private wallpaper descriptors, and unsupported media
                // stay in the package but are never presented as saveable media.
                continue
            }
            guard result.count < maximumAssetCount else {
                throw WallpaperLabError.packageTooLarge
            }
            result.append(WallpaperAsset(
                id: relativePath,
                fileURL: normalized,
                displayName: normalized.deletingPathExtension().lastPathComponent,
                kind: kind,
                byteCount: byteCount,
                uniformTypeIdentifier: typeIdentifier
            ))
        }
        if let enumerationError { throw enumerationError }
        return result.sorted {
            $0.id.compare($1.id, options: [.numeric, .literal]) == .orderedAscending
        }
    }

    /// ImageIO downsamples directly from the encoded source; it does not decode
    /// a full-size bitmap and then resize it. Video previews are handled by UI.
    static func thumbnail(
        for asset: WallpaperAsset,
        maxPixelSize: Int = 400
    ) -> CGImage? {
        guard asset.kind == .image, maxPixelSize > 0,
              let source = imageSource(at: asset.fileURL) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: min(maxPixelSize, maximumThumbnailDimension)
        ]
        return CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary)
    }

    private static func isDescendant(_ candidate: URL, of root: URL) -> Bool {
        candidate.path.hasPrefix(root.path + "/")
    }

    private static func imageSource(at url: URL) -> CGImageSource? {
        guard url.isFileURL,
              let values = try? url.resourceValues(forKeys: [
                .isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey
              ]),
              values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size > 0,
              Int64(size) <= WallpaperLabLimits.maximumEntryBytes else { return nil }
        let options = [kCGImageSourceShouldCache: false] as CFDictionary
        // Content sniffing deliberately permits JPEG/HEIC/PNG data named
        // asset.resource or without an extension in wallpaper archives.
        guard let source = CGImageSourceCreateWithURL(url as CFURL, options),
              let identifier = CGImageSourceGetType(source) as String?,
              let type = UTType(identifier), type.conforms(to: .image),
              CGImageSourceGetCount(source) > 0,
              CGImageSourceGetCount(source) <= maximumImageFrameCount,
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, options)
                as? [CFString: Any],
              let widthValue = properties[kCGImagePropertyPixelWidth] as? NSNumber,
              let heightValue = properties[kCGImagePropertyPixelHeight] as? NSNumber else {
            return nil
        }
        let width = widthValue.int64Value
        let height = heightValue.int64Value
        guard width > 0, height > 0,
              width <= Int64(maximumImageDimension), height <= Int64(maximumImageDimension),
              width <= maximumImagePixels / height else { return nil }
        return source
    }

    private static func videoType(at url: URL) -> UTType? {
        let extensionName = url.pathExtension.lowercased()
        guard ["mov", "mp4", "m4v"].contains(extensionName),
              let type = UTType(filenameExtension: extensionName),
              type.conforms(to: .movie) else { return nil }
        // A filename or generic movie UTI is insufficient: verify a real video
        // track. This public synchronous metadata API remains available on iOS
        // 17+; callers run catalog scanning away from the main thread.
        let video = AVURLAsset(url: url, options: [AVURLAssetPreferPreciseDurationAndTimingKey: false])
        guard !video.tracks(withMediaType: .video).isEmpty else { return nil }
        return type
    }
}
