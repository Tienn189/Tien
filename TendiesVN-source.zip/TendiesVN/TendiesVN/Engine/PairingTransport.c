// Standard developer pairing protocols via jkcoxson/idevice (MIT).
// This adapter reads device identity; it does not change device settings/files.
#include "PairingTransport.h"
#include "IDevice/idevice.h"
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#ifndef TD_PAIRING_TIMEOUT_MS
#define TD_PAIRING_TIMEOUT_MS 12000
#endif

// The upstream global timeout covers dialling, but not every protocol read.
// Cancel only new TCP sockets owned by this process to the selected device.
// shutdown wakes the library's reads; the library keeps ownership/cleanup.
typedef struct {
    pthread_mutex_t mutex;
    pthread_cond_t condition;
    pthread_t thread;
    struct in_addr target;
    uint32_t existing[4096];
    int limit;
    int done;
    int started;
} PairingDeadline;

static uint32_t device_connection(int fd, struct in_addr target) {
    struct sockaddr_in peer;
    struct sockaddr_in local;
    socklen_t size = sizeof(peer);
    socklen_t local_size = sizeof(local);
    int type = 0;
    socklen_t type_size = sizeof(type);
    if (getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &type_size) == 0 &&
        type == SOCK_STREAM && getpeername(fd, (struct sockaddr *)&peer, &size) == 0 &&
        peer.sin_family == AF_INET && peer.sin_addr.s_addr == target.s_addr &&
        getsockname(fd, (struct sockaddr *)&local, &local_size) == 0) {
        return ((uint32_t)peer.sin_port << 16) | local.sin_port;
    }
    return 0;
}

static struct timespec after_ms(long milliseconds) {
    struct timespec result;
    clock_gettime(CLOCK_REALTIME, &result);
    result.tv_sec += milliseconds / 1000;
    result.tv_nsec += (milliseconds % 1000) * 1000000;
    if (result.tv_nsec >= 1000000000) { result.tv_nsec -= 1000000000; result.tv_sec++; }
    return result;
}

static void *deadline_worker(void *context) {
    PairingDeadline *deadline = context;
    struct timespec end = after_ms(TD_PAIRING_TIMEOUT_MS);
    pthread_mutex_lock(&deadline->mutex);
    while (!deadline->done) {
        if (pthread_cond_timedwait(&deadline->condition, &deadline->mutex, &end) == 0) continue;
        if (deadline->done) break;
        for (int fd = 0; fd < deadline->limit; fd++) {
            uint32_t connection = device_connection(fd, deadline->target);
            if (connection && connection != deadline->existing[fd]) shutdown(fd, SHUT_RDWR);
        }
        end = after_ms(100);
    }
    pthread_mutex_unlock(&deadline->mutex);
    return NULL;
}

static void deadline_start(PairingDeadline *deadline, struct in_addr target) {
    memset(deadline, 0, sizeof(*deadline));
    deadline->target = target;
    long limit = sysconf(_SC_OPEN_MAX);
    deadline->limit = limit > 0 && limit < 4096 ? (int)limit : 4096;
    for (int fd = 0; fd < deadline->limit; fd++) deadline->existing[fd] = device_connection(fd, target);
    pthread_mutex_init(&deadline->mutex, NULL);
    pthread_cond_init(&deadline->condition, NULL);
    deadline->started = pthread_create(&deadline->thread, NULL, deadline_worker, deadline) == 0;
}

static void deadline_stop(PairingDeadline *deadline) {
    if (deadline->started) {
        pthread_mutex_lock(&deadline->mutex);
        deadline->done = 1;
        pthread_cond_signal(&deadline->condition);
        pthread_mutex_unlock(&deadline->mutex);
        pthread_join(deadline->thread, NULL);
    }
    pthread_cond_destroy(&deadline->condition);
    pthread_mutex_destroy(&deadline->mutex);
}

static char *copy_string(const char *value) {
    if (!value) return NULL;
    size_t size = strlen(value) + 1;
    char *result = malloc(size);
    if (result) memcpy(result, value, size);
    return result;
}

static int take_error(struct IdeviceFfiError *error, char **message) {
    if (!error) return 0;
    if (message) {
        char buffer[1536];
        snprintf(buffer, sizeof(buffer), "[%d:%d] %.1400s", error->code,
                 error->sub_code, error->message ? error->message : "Pairing failed");
        *message = copy_string(buffer);
    }
    idevice_error_free(error);
    return 1;
}

static void read_string(struct LockdowndClientHandle *client, const char *key,
                         char **destination) {
    plist_t value = NULL;
    struct IdeviceFfiError *error = lockdownd_get_value(client, key, NULL, &value);
    if (error) { idevice_error_free(error); return; }
    if (value) {
        char *text = NULL;
        plist_get_string_val(value, &text);
        if (text) {
            free(*destination);
            *destination = copy_string(text);
            plist_mem_free(text);
        }
        plist_free(value);
    }
}

static void read_identity(struct LockdowndClientHandle *client, TDPairingResult *out) {
    read_string(client, "UniqueDeviceID", &out->identifier);
    read_string(client, "DeviceName", &out->name);
    read_string(client, "ProductType", &out->model);
    read_string(client, "ProductVersion", &out->version);
}

void td_pairing_result_free(TDPairingResult *result) {
    if (!result) return;
    free(result->identifier); free(result->name); free(result->model);
    free(result->version); free(result->transport);
    if (result->updated_record) {
        volatile uint8_t *bytes = result->updated_record;
        for (size_t i = 0; i < result->updated_record_size; i++) bytes[i] = 0;
        free(result->updated_record);
    }
    memset(result, 0, sizeof(*result));
}

void td_pairing_string_free(char *value) { free(value); }

int td_pairing_verify(const uint8_t *record, size_t size, const char *host,
                      uint16_t remote_port, int is_remote,
                      TDPairingResult *out, char **message) {
    if (message) *message = NULL;
    if (!out || !record || !size || !host) return 1;
    memset(out, 0, sizeof(*out));
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
#ifdef __APPLE__
    address.sin_len = sizeof(address);
#endif
    address.sin_family = AF_INET;
    address.sin_port = htons(is_remote ? remote_port : 62078);
    if (inet_pton(AF_INET, host, &address.sin_addr) != 1) {
        if (message) *message = copy_string("Invalid device IPv4 address");
        return 1;
    }
    idevice_set_global_timeout(8);
    int failed = 1;
    struct LockdowndClientHandle *client = NULL;
    if (is_remote) {
        struct RpPairingFileHandle *pairing = NULL;
        struct AdapterHandle *adapter = NULL;
        struct RsdHandshakeHandle *handshake = NULL;
        struct IdeviceFfiError *error = rp_pairing_file_from_bytes(record, size, &pairing);
        if (take_error(error, message)) goto remote_cleanup;
        PairingDeadline deadline;
        deadline_start(&deadline, address.sin_addr);
        error = tunnel_create_remotexpc((const idevice_sockaddr *)&address,
                  sizeof(address), "1809", pairing, NULL, NULL, &adapter, &handshake);
        deadline_stop(&deadline);
        if (error) {
            idevice_error_free(error);
            if (handshake) { rsd_handshake_free(handshake); handshake = NULL; }
            if (adapter) { adapter_free(adapter); adapter = NULL; }
            deadline_start(&deadline, address.sin_addr);
            error = tunnel_create_rppairing((const idevice_sockaddr *)&address,
                      sizeof(address), "1809", pairing, NULL, NULL, &adapter, &handshake);
            deadline_stop(&deadline);
            if (take_error(error, message)) goto remote_cleanup;
            out->transport = copy_string("RSD · RPPairing");
        } else {
            out->transport = copy_string("RSD · RemoteXPC");
        }
        if (!adapter || !handshake) goto remote_cleanup;
        char *uuid = NULL;
        error = rsd_get_uuid(handshake, &uuid);
        if (take_error(error, message)) goto remote_cleanup;
        out->identifier = copy_string(uuid);
        rsd_free_string(uuid);
        // The authenticated RSD handshake is the proof of connectivity.
        // No extra service is required; devices need not expose lockdown here.
        failed = out->identifier && out->identifier[0] ? 0 : 1;
        if (!failed) {
            uint8_t *updated = NULL;
            uintptr_t count = 0;
            error = rp_pairing_file_to_bytes(pairing, &updated, &count);
            if (take_error(error, message)) { failed = 1; goto remote_cleanup; }
            if (!updated || !count || count > 1024 * 1024) {
                if (updated) idevice_data_free(updated, count);
                failed = 1; goto remote_cleanup;
            }
            out->updated_record = malloc(count);
            if (!out->updated_record) {
                idevice_data_free(updated, count);
                failed = 1; goto remote_cleanup;
            }
            memcpy(out->updated_record, updated, count);
            out->updated_record_size = count;
            idevice_data_free(updated, count);
        }
remote_cleanup:
        lockdownd_client_free(client);
        rsd_handshake_free(handshake);
        adapter_free(adapter);
        rp_pairing_file_free(pairing);
    } else {
        struct IdevicePairingFile *provider_pairing = NULL;
        struct IdevicePairingFile *session_pairing = NULL;
        struct IdeviceProviderHandle *provider = NULL;
        PairingDeadline deadline;
        deadline_start(&deadline, address.sin_addr);
        struct IdeviceFfiError *error = idevice_pairing_file_from_bytes(record, size, &provider_pairing);
        if (take_error(error, message)) goto classic_cleanup;
        error = idevice_pairing_file_from_bytes(record, size, &session_pairing);
        if (take_error(error, message)) goto classic_cleanup;
        error = idevice_tcp_provider_new((const idevice_sockaddr *)&address,
                                         provider_pairing, "1809", &provider);
        provider_pairing = NULL; // ownership transfers to the provider
        if (take_error(error, message)) goto classic_cleanup;
        error = lockdownd_connect(provider, &client);
        if (take_error(error, message)) goto classic_cleanup;
        error = lockdownd_start_session(client, session_pairing);
        if (take_error(error, message)) goto classic_cleanup;
        read_identity(client, out);
        out->transport = copy_string("Lockdown · TLS");
        failed = out->identifier && out->identifier[0] ? 0 : 1;
classic_cleanup:
        lockdownd_client_free(client);
        idevice_provider_free(provider);
        idevice_pairing_file_free(session_pairing);
        idevice_pairing_file_free(provider_pairing);
        deadline_stop(&deadline);
    }
    if (failed) {
        td_pairing_result_free(out);
        if (message && !*message) *message = copy_string("The device did not return an authenticated identity");
    }
    return failed;
}
