// SPDX-License-Identifier: GPL-3.0-only
// TendiesVN fixed PosterBoard path validation; added 2026-10-17.
#include "posterboard_path.h"

#include <string.h>

static const char PrivatePrefix[] = "/private/var/mobile/Containers/Data/Application/";
static const char AliasPrefix[] = "/var/mobile/Containers/Data/Application/";

static int reject_path(char *output, size_t capacity) {
    if (output && capacity > 0) output[0] = '\0';
    return 0;
}

static int is_hex(unsigned char character) {
    return (character >= '0' && character <= '9') ||
        (character >= 'A' && character <= 'F') ||
        (character >= 'a' && character <= 'f');
}

int tendies_canonical_posterboard_root_path(
    const char *input,
    size_t input_length,
    char *output,
    size_t output_capacity
) {
    if (!input || !output || output_capacity < TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE) {
        return reject_path(output, output_capacity);
    }
    const size_t private_length = sizeof(PrivatePrefix) - 1;
    const size_t alias_length = sizeof(AliasPrefix) - 1;
    size_t uuid_offset;
    if ((input_length == private_length + 36 || input_length == private_length + 37) &&
        memcmp(input, PrivatePrefix, private_length) == 0) {
        uuid_offset = private_length;
    } else if ((input_length == alias_length + 36 || input_length == alias_length + 37) &&
        memcmp(input, AliasPrefix, alias_length) == 0) {
        uuid_offset = alias_length;
    } else {
        return reject_path(output, output_capacity);
    }
    if (input_length == uuid_offset + 37 && input[input_length - 1] != '/') {
        return reject_path(output, output_capacity);
    }
    for (size_t index = 0; index < 36; index++) {
        unsigned char character = (unsigned char)input[uuid_offset + index];
        int hyphen = index == 8 || index == 13 || index == 18 || index == 23;
        if ((hyphen && character != '-') || (!hyphen && !is_hex(character))) {
            return reject_path(output, output_capacity);
        }
    }
    // A local buffer makes valid in-place canonicalization safe as well.
    char canonical[TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE];
    memcpy(canonical, PrivatePrefix, private_length);
    memcpy(canonical + private_length, input + uuid_offset, 36);
    canonical[private_length + 36] = '\0';
    memmove(output, canonical, sizeof(canonical));
    return 1;
}

int tendies_posterboard_candidate_root_path(
    const char *input,
    size_t input_length,
    char *output,
    size_t output_capacity
) {
    if (!input || !output || output_capacity < TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE ||
        input_length > 4096) {
        return reject_path(output, output_capacity);
    }
    const size_t private_length = sizeof(PrivatePrefix) - 1;
    const size_t alias_length = sizeof(AliasPrefix) - 1;
    size_t uuid_offset;
    if (input_length >= private_length + 36 &&
        memcmp(input, PrivatePrefix, private_length) == 0) {
        uuid_offset = private_length;
    } else if (input_length >= alias_length + 36 &&
        memcmp(input, AliasPrefix, alias_length) == 0) {
        uuid_offset = alias_length;
    } else {
        return reject_path(output, output_capacity);
    }
    const size_t root_end = uuid_offset + 36;
    char canonical[TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE];
    // Reuse the strict validator for the extracted root, never the reverse.
    if (!tendies_canonical_posterboard_root_path(input, root_end, canonical, sizeof(canonical))) {
        return reject_path(output, output_capacity);
    }
    size_t logical_length = input_length;
    if (logical_length > root_end && input[logical_length - 1] == '/') logical_length--;
    if (logical_length > root_end) {
        if (input[root_end] != '/') return reject_path(output, output_capacity);
        size_t component_start = root_end + 1;
        for (size_t index = component_start; index <= logical_length; index++) {
            if (index == logical_length || input[index] == '/') {
                size_t length = index - component_start;
                if (length == 0 ||
                    (length == 1 && input[component_start] == '.') ||
                    (length == 2 && input[component_start] == '.' && input[component_start + 1] == '.')) {
                    return reject_path(output, output_capacity);
                }
                component_start = index + 1;
            } else {
                unsigned char character = (unsigned char)input[index];
                if (character == '\0' || character < 0x20 || character == 0x7f || character == '\\') {
                    return reject_path(output, output_capacity);
                }
            }
        }
    } else if (logical_length != root_end) {
        return reject_path(output, output_capacity);
    }
    memmove(output, canonical, sizeof(canonical));
    return 1;
}
