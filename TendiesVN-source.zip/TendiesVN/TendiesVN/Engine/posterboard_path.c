// SPDX-License-Identifier: GPL-3.0-only
// TendiesVN fixed PosterBoard path validation; added 2026-10-17.
#include "posterboard_path.h"

#include <string.h>

static const char PrivatePrefix[] = "/private/var/mobile/Containers/Data/Application/";
static const char AliasPrefix[] = "/var/mobile/Containers/Data/Application/";

static int reject_path(char *output, size_t capacity) {
    if (output && capacity > 0) output[0] = '\0';
    return 0;
}

static int is_hex(unsigned char character) {
    return (character >= '0' && character <= '9') ||
        (character >= 'A' && character <= 'F') ||
        (character >= 'a' && character <= 'f');
}

int tendies_canonical_posterboard_root_path(
    const char *input,
    size_t input_length,
    char *output,
    size_t output_capacity
) {
    if (!input || !output || output_capacity < TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE) {
        return reject_path(output, output_capacity);
    }
    const size_t private_length = sizeof(PrivatePrefix) - 1;
    const size_t alias_length = sizeof(AliasPrefix) - 1;
    size_t uuid_offset;
    if ((input_length == private_length + 36 || input_length == private_length + 37) &&
        memcmp(input, PrivatePrefix, private_length) == 0) {
        uuid_offset = private_length;
    } else if ((input_length == alias_length + 36 || input_length == alias_length + 37) &&
        memcmp(input, AliasPrefix, alias_length) == 0) {
        uuid_offset = alias_length;
    } else {
        return reject_path(output, output_capacity);
    }
    if (input_length == uuid_offset + 37 && input[input_length - 1] != '/') {
        return reject_path(output, output_capacity);
    }
    for (size_t index = 0; index < 36; index++) {
        unsigned char character = (unsigned char)input[uuid_offset + index];
        int hyphen = index == 8 || index == 13 || index == 18 || index == 23;
        if ((hyphen && character != '-') || (!hyphen && !is_hex(character))) {
            return reject_path(output, output_capacity);
        }
    }
    // A local buffer makes valid in-place canonicalization safe as well.
    char canonical[TENDIES_POSTERBOARD_ROOT_BUFFER_SIZE];
    memcpy(canonical, PrivatePrefix, private_length);
    memcpy(canonical + private_length, input + uuid_offset, 36);
    canonical[private_length + 36] = '\0';
    memmove(output, canonical, sizeof(canonical));
    return 1;
}
