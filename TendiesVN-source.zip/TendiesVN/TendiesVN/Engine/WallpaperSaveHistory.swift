// SPDX-License-Identifier: GPL-3.0-only
// Records actions completed by this app. This is not a view of the Photos library.

import Foundation

struct WallpaperSaveReceipt: Identifiable, Codable, Equatable {
    let id: UUID
    let packageID: UUID
    let packageName: String
    let assetName: String
    let kind: WallpaperAssetKind
    let savedAt: Date
}

enum WallpaperSaveHistoryError: LocalizedError {
    case unsafeStorage
    case invalidHistory

    var errorDescription: String? {
        switch self {
        case .unsafeStorage:
            return "Không thể truy cập vùng lưu trữ an toàn của ứng dụng."
        case .invalidHistory:
            return "Không thể đọc lịch sử lưu hình nền. Dữ liệu lịch sử không hợp lệ."
        }
    }
}

enum WallpaperSaveHistory {
    private static let lock = NSLock()
    private static let maximumRecords = WallpaperHistoryCodec.maximumRecords
    private static let maximumHistoryBytes = WallpaperHistoryCodec.maximumBytes

    static func receipts() throws -> [WallpaperSaveReceipt] {
        lock.lock()
        defer { lock.unlock() }
        return try read(at: historyURL())
    }

    static func record(_ receipt: WallpaperSaveReceipt) throws {
        lock.lock()
        defer { lock.unlock() }
        guard WallpaperHistoryCodec.valid(receipt) else { throw WallpaperSaveHistoryError.invalidHistory }
        let url = try historyURL()
        var entries = try read(at: url).filter { $0.id != receipt.id }
        entries.insert(receipt, at: 0)
        entries.sort { $0.savedAt > $1.savedAt }
        try write(Array(entries.prefix(maximumRecords)), at: url)
    }

    /// Removes only the app's receipt. Never requests Photos access or deletes a photo.
    static func remove(_ receipt: WallpaperSaveReceipt) throws {
        lock.lock()
        defer { lock.unlock() }
        let url = try historyURL()
        let entries = try read(at: url)
        try write(entries.filter { $0.id != receipt.id }, at: url)
    }

    private static func historyURL() throws -> URL {
        let directory = try WallpaperSandboxFiles.directory(
            .applicationSupportDirectory,
            components: ["WallpaperHistory"]
        )
        let url = directory.appendingPathComponent("saved-wallpapers.json")
        if FileManager.default.fileExists(atPath: url.path) {
            _ = try WallpaperSandboxFiles.regularFile(url, maximumBytes: maximumHistoryBytes)
        } else if (try? url.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink) == true {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        return url
    }

    private static func read(at url: URL) throws -> [WallpaperSaveReceipt] {
        guard FileManager.default.fileExists(atPath: url.path) else { return [] }
        let (checkedURL, _) = try WallpaperSandboxFiles.regularFile(
            url,
            maximumBytes: maximumHistoryBytes
        )
        let data = try Data(contentsOf: checkedURL)
        return try WallpaperHistoryCodec.decode(data)
    }

    private static func write(_ entries: [WallpaperSaveReceipt], at url: URL) throws {
        let data = try WallpaperHistoryCodec.encode(entries)
        // Atomic replacement means an interrupted write cannot truncate the existing history.
        #if os(iOS)
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        #else
        // The standalone macOS codec harness never invokes this disk-writing method.
        try data.write(to: url, options: [.atomic])
        #endif
    }

}

/// The on-disk format can be checked without accessing Application Support or Photos.
/// Both reads and writes use these limits, including receipts made in this process.
enum WallpaperHistoryCodec {
    static let maximumRecords = 1_000
    static let maximumBytes: Int64 = 2 * 1_024 * 1_024

    static func decode(_ data: Data) throws -> [WallpaperSaveReceipt] {
        guard Int64(data.count) <= maximumBytes,
              let entries = try? JSONDecoder().decode([WallpaperSaveReceipt].self, from: data) else {
            throw WallpaperSaveHistoryError.invalidHistory
        }
        try validate(entries)
        return entries.sorted { $0.savedAt > $1.savedAt }
    }

    static func encode(_ entries: [WallpaperSaveReceipt]) throws -> Data {
        try validate(entries)
        let data = try JSONEncoder().encode(entries)
        guard Int64(data.count) <= maximumBytes else {
            throw WallpaperSaveHistoryError.invalidHistory
        }
        return data
    }

    static func valid(_ receipt: WallpaperSaveReceipt) -> Bool {
        !receipt.packageName.isEmpty && receipt.packageName.utf8.count <= 1_024
            && !receipt.assetName.isEmpty && receipt.assetName.utf8.count <= 1_024
            && receipt.savedAt.timeIntervalSince1970.isFinite
            && receipt.savedAt.timeIntervalSince1970 >= 0
    }

    private static func validate(_ entries: [WallpaperSaveReceipt]) throws {
        guard entries.count <= maximumRecords,
              entries.allSatisfy(valid),
              Set(entries.map(\.id)).count == entries.count else {
            throw WallpaperSaveHistoryError.invalidHistory
        }
    }
}

/// File operations stay inside this app's container. The system's /var alias is
/// canonicalized once; symlinks below the app container are never followed.
enum WallpaperSandboxFiles {
    static func directory(
        _ searchDirectory: FileManager.SearchPathDirectory,
        components: [String]
    ) throws -> URL {
        guard let base = FileManager.default.urls(for: searchDirectory, in: .userDomainMask).first else {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        let target = components.reduce(base) { $0.appendingPathComponent($1, isDirectory: true) }
        guard components.allSatisfy({ !$0.isEmpty && $0 != "." && $0 != ".." && !$0.contains("/") }) else {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        return try walk(target, createDirectories: true, finalIsDirectory: true)
    }

    static func regularFile(_ url: URL, maximumBytes: Int64) throws -> (URL, Int64) {
        let checkedURL = try walk(url, createDirectories: false, finalIsDirectory: false)
        let values = try checkedURL.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size > 0, Int64(size) <= maximumBytes else {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        return (checkedURL, Int64(size))
    }

    private static func walk(_ url: URL, createDirectories: Bool, finalIsDirectory: Bool) throws -> URL {
        guard url.isFileURL, url.query == nil, url.fragment == nil,
              url.path.utf8.count <= 4_096 else {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        let rawHome = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true).standardizedFileURL
        let home = rawHome.resolvingSymlinksInPath()
        let path = url.standardizedFileURL.path
        let relative: String
        if path.hasPrefix(rawHome.path + "/") {
            relative = String(path.dropFirst(rawHome.path.count + 1))
        } else if path.hasPrefix(home.path + "/") {
            relative = String(path.dropFirst(home.path.count + 1))
        } else {
            throw WallpaperSaveHistoryError.unsafeStorage
        }
        let components = relative.split(separator: "/").map(String.init)
        guard !components.isEmpty else { throw WallpaperSaveHistoryError.unsafeStorage }
        var cursor = home
        for (index, component) in components.enumerated() {
            cursor.appendPathComponent(component)
            let needsDirectory = index < components.count - 1 || finalIsDirectory
            let existing = try? cursor.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            if existing == nil && createDirectories && needsDirectory {
                try FileManager.default.createDirectory(at: cursor, withIntermediateDirectories: false)
            }
            let values = try cursor.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true, !needsDirectory || values.isDirectory == true else {
                throw WallpaperSaveHistoryError.unsafeStorage
            }
        }
        return cursor
    }
}
