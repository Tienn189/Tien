import Foundation
import Combine
import UIKit
import AVFoundation
import Darwin

struct PairingHostResult {
    let data: Data
    let deviceIdentifier: String?
    let deviceName: String?
}

private struct PairingHostFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

/// Owns listener resources across cancellation and the native handshake thread.
private final class PairingHostRun: @unchecked Sendable {
    private let lock = NSLock()
    private var stopped = false
    private var expired = false
    private var listener: Int32 = -1
    private var client: Int32 = -1

    var isCancelled: Bool {
        lock.lock(); defer { lock.unlock() }
        return stopped
    }

    var cancellationError: Error {
        lock.lock(); defer { lock.unlock() }
        if expired {
            return PairingHostFailure(message: "Hết thời gian chờ ghép đôi. Mở khoá máy, bật Chế độ nhà phát triển và thử lại.")
        }
        return CancellationError()
    }

    func setListener(_ descriptor: Int32) {
        lock.lock(); defer { lock.unlock() }
        listener = descriptor
        if stopped { shutdown(descriptor, SHUT_RDWR) }
    }

    func setClient(_ descriptor: Int32) {
        lock.lock(); defer { lock.unlock() }
        client = descriptor
        if stopped { shutdown(descriptor, SHUT_RDWR) }
    }

    func closeDescriptors() {
        lock.lock(); defer { lock.unlock() }
        if listener >= 0 { close(listener); listener = -1 }
        if client >= 0 { close(client); client = -1 }
    }

    func cancel(timedOut: Bool = false) {
        lock.lock(); defer { lock.unlock() }
        stopped = true
        expired = expired || timedOut
        if listener >= 0 { shutdown(listener, SHUT_RDWR) }
        if client >= 0 { shutdown(client, SHUT_RDWR) }
    }
}

private final class PairingPINCallback: @unchecked Sendable {
    let onPIN: (String) -> Void
    init(_ onPIN: @escaping (String) -> Void) { self.onPIN = onPIN }
}

@MainActor
final class PairingHost: NSObject, ObservableObject, NetServiceDelegate {
    static let shared = PairingHost()
    @Published private(set) var running = false
    @Published private(set) var statusText = ""
    @Published private(set) var pin: String?
    private var service: NetService?
    private var run: PairingHostRun?
    private var player: AVAudioPlayer?
    private var previousIdleTimerDisabled = false
    private var advertisingError: String?

    func cancel() {
        statusText = "Đang huỷ ghép đôi…"
        run?.cancel()
        service?.stop()
    }

    func start() async throws -> PairingHostResult {
        guard !running else { throw PairingHostFailure(message: "Đang có một phiên ghép đôi.") }
        running = true
        pin = nil
        advertisingError = nil
        statusText = "Đang tạo dịch vụ ghép đôi…"
        let operation = PairingHostRun()
        run = operation
        previousIdleTimerDisabled = UIApplication.shared.isIdleTimerDisabled
        UIApplication.shared.isIdleTimerDisabled = true
        defer { finish() }
        do {
            try startKeepAlive()
            DispatchQueue.global().asyncAfter(deadline: .now() + 180) { [weak operation] in
                operation?.cancel(timedOut: true)
            }
            return try await withTaskCancellationHandler {
                try await withCheckedThrowingContinuation { continuation in
                    let callback = PairingPINCallback { [weak self] value in
                        DispatchQueue.main.async {
                            guard let self, self.run === operation, !operation.isCancelled else { return }
                            self.pin = value
                            self.statusText = "Nhập mã này trong Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép đôi với 1809."
                        }
                    }
                    DispatchQueue.global(qos: .userInitiated).async {
                        let outcome = Result {
                            try Self.accept(operation: operation, callback: callback) { serviceID, port, txt in
                                DispatchQueue.main.async { [weak self] in
                                    guard let self, self.run === operation, !operation.isCancelled else { return }
                                    let service = NetService(domain: "local.", type: "_remotepairing-pairable-host._tcp.", name: serviceID, port: Int32(port))
                                    service.delegate = self
                                    service.includesPeerToPeer = true
                                    service.setTXTRecord(NetService.data(fromTXTRecord: txt))
                                    self.service = service
                                    service.publish()
                                    self.statusText = "Mở Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép đôi với 1809. Mã sẽ hiện khi thiết bị kết nối."
                                }
                            }
                        }
                        continuation.resume(with: outcome)
                    }
                }
            } onCancel: {
                operation.cancel()
            }
        } catch {
            let message = advertisingError
            if let message { throw PairingHostFailure(message: message) }
            throw error
        }
    }

    nonisolated private static func accept(
        operation: PairingHostRun, callback: PairingPINCallback,
        advertise: @escaping (String, UInt16, [String: Data]) -> Void
    ) throws -> PairingHostResult {
        defer { operation.closeDescriptors() }
        idevice_set_global_timeout(120)
        var handle: OpaquePointer?
        var serviceID: UnsafeMutablePointer<CChar>?
        var txtData: UnsafeMutablePointer<UInt8>?
        var txtLength: UInt = 0
        var hostIRK = [UInt8](repeating: 0, count: 16)
        let error = "1809".withCString { name in
            "Mac17,7".withCString { model in
                pairable_host_prepare(name, model, false, &handle, &serviceID, &txtData, &txtLength, &hostIRK)
            }
        }
        defer {
            pairable_host_free(handle)
            idevice_string_free(serviceID)
            if let txtData { idevice_data_free(txtData, txtLength) }
        }
        try check(error)
        guard let handle, let serviceID, let txtData else {
            throw PairingHostFailure(message: "Không tạo được dịch vụ ghép đôi.")
        }
        let plist = try PropertyListSerialization.propertyList(from: Data(bytes: txtData, count: Int(txtLength)), options: [], format: nil)
        guard let values = plist as? [String: Any] else {
            throw PairingHostFailure(message: "Dữ liệu Bonjour không hợp lệ.")
        }
        var txt: [String: Data] = [:]
        for (key, value) in values {
            if let data = value as? Data { txt[key] = data }
            else if let text = value as? String { txt[key] = Data(text.utf8) }
        }
        let listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)
        guard listener >= 0 else { throw PairingHostFailure(message: "Không mở được cổng ghép đôi.") }
        operation.setListener(listener)
        var reuse: Int32 = 1
        setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &reuse, socklen_t(MemoryLayout<Int32>.size))
        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        let bound = withUnsafePointer(to: &address) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                bind(listener, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bound == 0, listen(listener, 1) == 0 else {
            throw PairingHostFailure(message: "Không khởi động được dịch vụ ghép đôi.")
        }
        var length = socklen_t(MemoryLayout<sockaddr_in>.size)
        let named = withUnsafeMutablePointer(to: &address) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { getsockname(listener, $0, &length) }
        }
        guard named == 0 else { throw PairingHostFailure(message: "Không đọc được cổng ghép đôi.") }
        advertise(String(cString: serviceID), UInt16(bigEndian: address.sin_port), txt)
        let deadline = Date().addingTimeInterval(180)
        var client: Int32 = -1
        while client < 0 {
            if operation.isCancelled { throw operation.cancellationError }
            guard Date() < deadline else {
                throw PairingHostFailure(message: "Hết thời gian chờ ghép đôi. Mở khoá máy, bật Chế độ nhà phát triển và thử lại.")
            }
            var descriptor = pollfd(fd: listener, events: Int16(POLLIN), revents: 0)
            let polled = poll(&descriptor, 1, 250)
            if polled < 0 && errno != EINTR { throw PairingHostFailure(message: "Cổng ghép đôi đã đóng.") }
            if polled > 0 && descriptor.revents & Int16(POLLIN) != 0 {
                client = Darwin.accept(listener, nil, nil)
            }
        }
        operation.setClient(client)
        let context = Unmanaged.passRetained(callback).toOpaque()
        defer { Unmanaged<PairingPINCallback>.fromOpaque(context).release() }
        var peer: UnsafeMutablePointer<RpPairingPeerDeviceC>?
        var record: OpaquePointer?
        let failure = pairable_host_accept_fd(handle, client, { value, context in
            guard let value, let context else { return }
            Unmanaged<PairingPINCallback>.fromOpaque(context).takeUnretainedValue().onPIN(String(cString: value))
        }, context, &peer, &record)
        defer { rppairing_peer_device_free(peer); rp_pairing_file_free(record) }
        if operation.isCancelled { if let failure { idevice_error_free(failure) }; throw operation.cancellationError }
        try check(failure)
        var bytes: UnsafeMutablePointer<UInt8>?
        var count: UInt = 0
        try check(rp_pairing_file_to_bytes(record, &bytes, &count))
        defer { if let bytes { idevice_data_free(bytes, count) } }
        guard let bytes, count > 0, count <= 1_024 * 1_024 else {
            throw PairingHostFailure(message: "Thiết bị chưa trả về hồ sơ ghép đôi hợp lệ.")
        }
        return PairingHostResult(
            data: Data(bytes: bytes, count: Int(count)),
            deviceIdentifier: peer?.pointee.udid.map { String(cString: $0) },
            deviceName: peer?.pointee.name.map { String(cString: $0) }
        )
    }

    nonisolated private static func check(_ error: UnsafeMutablePointer<IdeviceFfiError>?) throws {
        guard let error else { return }
        defer { idevice_error_free(error) }
        let description = error.pointee.message.map { String(cString: $0) } ?? "Pairing failed"
        throw PairingHostFailure(message: "Ghép đôi không hoàn tất: \(description)")
    }

    private func finish() {
        service?.stop(); service = nil
        run = nil
        player?.stop(); player = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        UIApplication.shared.isIdleTimerDisabled = previousIdleTimerDisabled
        running = false
        pin = nil
    }

    private func startKeepAlive() throws {
        // Keep the user-initiated handshake alive while its PIN is approved in
        // Settings. Stop the silent audio as soon as pairing ends or is cancelled.
        let audio = AVAudioSession.sharedInstance()
        try audio.setCategory(.playback, mode: .default, options: .mixWithOthers)
        try audio.setActive(true)
        var wave = Data("RIFF".utf8)
        func number<T: FixedWidthInteger>(_ value: T) {
            var encoded = value.littleEndian
            withUnsafeBytes(of: &encoded) { wave.append(contentsOf: $0) }
        }
        let size: UInt32 = 16_000
        number(UInt32(36) + size); wave.append(Data("WAVEfmt ".utf8))
        number(UInt32(16)); number(UInt16(1)); number(UInt16(1))
        number(UInt32(8_000)); number(UInt32(16_000)); number(UInt16(2)); number(UInt16(16))
        wave.append(Data("data".utf8)); number(size)
        wave.append(Data(repeating: 0, count: Int(size)))
        let player = try AVAudioPlayer(data: wave)
        player.numberOfLoops = -1
        player.volume = 0.001
        guard player.play() else { throw PairingHostFailure(message: "Không thể giữ phiên ghép đôi khi chuyển sang Cài đặt.") }
        self.player = player
    }

    nonisolated func netService(_ sender: NetService, didNotPublish errorDict: [String: NSNumber]) {
        Task { @MainActor [weak self] in
            self?.advertisingError = "Không phát được dịch vụ Bonjour. Bật quyền Mạng cục bộ cho 1809 trong Cài đặt rồi thử lại."
            self?.cancel()
        }
    }
}
