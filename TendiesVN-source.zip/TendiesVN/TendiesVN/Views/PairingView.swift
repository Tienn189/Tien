import SwiftUI
import UIKit

struct PairingView: View {
    @EnvironmentObject private var model: WallpaperModel
    @ObservedObject private var pairing = PairingStore.shared
    @ObservedObject private var host = PairingHost.shared
    @State private var importing = false
    @State private var pendingURL: URL?
    @State private var confirmingRemoval = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                introduction
                section("Mạng", content: networkCard)
                section("Hồ sơ pairing", content: credentialCard)
                section("Ghép đôi trên thiết bị", content: hostCard)
                NavigationLink {
                    PairingGuideView()
                } label: {
                    HStack {
                        Label("Hướng dẫn LocalDevVPN và pairing", systemImage: "questionmark.circle")
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                    }
                    .font(.subheadline)
                    .padding(20)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 22))
                }
                .buttonStyle(.plain)
                Button {
                    model.selectedTab = 0
                } label: {
                    Label("Mở Wallpapers", systemImage: "photo.on.rectangle")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.plain)
            }
            .padding(20)
            .padding(.bottom, 16)
        }
        .background(Color.appBackground)
        .navigationTitle("Pairing")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { model.selectedTab = 2 } label: { Image(systemName: "gearshape") }
                    .accessibilityLabel("Cài đặt 1809")
            }
        }
        .sheet(isPresented: $importing, onDismiss: importPendingFile) {
            PairingFilePicker(onPick: { url in
                pendingURL = url
                importing = false
            }, onCancel: { importing = false })
        }
        .alert("Không hoàn tất pairing", isPresented: Binding(
            get: { model.selectedTab == 3 && !importing && pairing.errorMessage != nil },
            set: { if !$0 { pairing.errorMessage = nil } }
        )) {
            Button("Đã hiểu", role: .cancel) { pairing.errorMessage = nil }
        } message: { Text(pairing.errorMessage ?? "") }
        .confirmationDialog("Xoá hồ sơ pairing đã lưu?", isPresented: $confirmingRemoval, titleVisibility: .visible) {
            Button("Xoá hồ sơ", role: .destructive) { Task { await pairing.removeRecord() } }
        } message: {
            Text("Bạn có thể nhập lại tệp hoặc ghép đôi lại trên iOS 27. Thao tác này xoá hồ sơ khỏi Keychain của 1809.")
        }
        .task {
            await pairing.refresh()
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 15_000_000_000) } catch { break }
                pairing.refreshNetwork()
            }
        }
        .refreshable {
            await pairing.refresh()
            await pairing.verifyConnection()
        }
    }

    private var introduction: some View {
        HStack(alignment: .top, spacing: 14) {
            Image("AppMark").resizable().frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 12)).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 6) {
                Text("1809").font(.title2.weight(.semibold))
                Text("Kết nối thiết bị qua LocalDevVPN.\nNhập hồ sơ có sẵn hoặc ghép đôi trực tiếp.")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 26))
    }

    private var networkCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: "network")
                    .font(.title3)
                VStack(alignment: .leading, spacing: 5) {
                    Text(pairing.network.targetUsesTunnel ? "Đã phát hiện đường hầm VPN" : pairing.network.hasTunnel ? "Đã phát hiện VPN" : "Chưa phát hiện VPN")
                        .font(.headline)
                    Text(pairing.network.targetUsesTunnel ? "IP thiết bị được định tuyến qua VPN. Hãy xác thực hồ sơ để kiểm tra kết nối." : "Bật LocalDevVPN và dùng IP thiết bị hiển thị trong ứng dụng đó.")
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            HStack(spacing: 10) {
                Text("IP thiết bị").font(.subheadline).foregroundStyle(.secondary)
                TextField("10.7.0.1", text: $pairing.deviceIP)
                    .font(.subheadline.monospaced())
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.numbersAndPunctuation)
                    .padding(10)
                    .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 10))
                    .disabled(pairing.isBusy)
                Button {
                    pairing.refreshNetwork()
                } label: { Image(systemName: "arrow.clockwise").frame(width: 44, height: 44) }
                    .buttonStyle(.plain).disabled(pairing.isBusy)
                    .accessibilityLabel("Kiểm tra lại mạng")
            }
            DisclosureGroup("Tuỳ chọn kết nối") {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Cổng RSD").font(.subheadline)
                        Spacer()
                        TextField("49152", text: $pairing.remotePort)
                            .keyboardType(.numberPad).font(.subheadline.monospaced())
                            .multilineTextAlignment(.trailing).frame(maxWidth: 110)
                            .disabled(pairing.isBusy)
                    }
                    Text("Mặc định RPPairing dùng cổng 49152; hồ sơ Lockdown dùng cổng 62078. Chỉ đổi khi cấu hình LocalDevVPN của bạn yêu cầu.")
                        .font(.caption).foregroundStyle(.secondary)
                    if !pairing.network.interfacesText.isEmpty {
                        Text(pairing.network.interfacesText).font(.caption2.monospaced())
                            .foregroundStyle(.tertiary).textSelection(.enabled)
                    }
                }.padding(.top, 10)
            }.font(.subheadline)
            Link("LocalDevVPN · hướng dẫn và tải ứng dụng", destination: URL(string: "https://github.com/jkcoxson/LocalDevVPN")!)
                .font(.caption)
            if let url = URL(string: "localdevvpn://"), UIApplication.shared.canOpenURL(url) {
                Button("Mở LocalDevVPN", systemImage: "arrow.up.forward.app") {
                    UIApplication.shared.open(url)
                }.font(.subheadline)
            }
        }
        .padding(22)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 26))
    }

    private var credentialCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(alignment: .top, spacing: 12) {
                Image(systemName: pairing.connection == nil ? "doc.badge.gearshape" : "checkmark.seal.fill")
                    .font(.title3)
                VStack(alignment: .leading, spacing: 6) {
                    Text(pairing.statusText).font(.headline)
                    if let record = pairing.record {
                        Text(record.fileName).font(.caption.monospaced()).foregroundStyle(.secondary)
                            .lineLimit(2)
                        Text("\(record.kind?.rawValue ?? "Pairing") · \(ByteCountFormatter.string(fromByteCount: Int64(record.byteCount ?? 0), countStyle: .file))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 0)
                if pairing.record != nil {
                    Button(role: .destructive) { confirmingRemoval = true } label: {
                        Image(systemName: "trash").frame(width: 44, height: 44)
                    }.buttonStyle(.plain).disabled(pairing.isBusy)
                        .accessibilityLabel("Xoá hồ sơ pairing")
                }
            }
            if let info = pairing.connection {
                VStack(alignment: .leading, spacing: 5) {
                    if !info.deviceName.isEmpty { Text(info.deviceName).font(.subheadline.weight(.semibold)) }
                    if !info.model.isEmpty { Text("\(info.model) · iOS \(info.version)").font(.caption).foregroundStyle(.secondary) }
                }
            }
            Text(pairing.detailText).font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            if pairing.isImporting || pairing.isConnecting {
                ProgressView(pairing.isImporting ? "Đang đọc hồ sơ…" : "Đang xác thực với thiết bị…")
                    .font(.subheadline).tint(.primary)
            }
            Button { importing = true } label: {
                Label(pairing.record == nil ? "Nhập tệp pairing" : "Thay tệp pairing", systemImage: "square.and.arrow.down")
                    .frame(maxWidth: .infinity, minHeight: 48)
                    .font(.subheadline.weight(.semibold))
                    .background(Color(uiColor: .tertiarySystemFill), in: Capsule())
            }
            .buttonStyle(.plain).disabled(pairing.isBusy)
            if pairing.record != nil {
                action("Kiểm tra kết nối", icon: "checkmark.shield") {
                    Task { await pairing.verifyConnection() }
                }.disabled(pairing.isBusy)
            }
        }
        .padding(22)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 26))
    }

    private var hostCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            if DeviceCompatibility.requiresPairing {
                Text("Ghép đôi với 1809 trong Cài đặt của iPhone hoặc iPad. Không cần xuất hồ sơ bằng máy tính.")
                    .font(.subheadline).foregroundStyle(.secondary)
                if let pin = host.pin {
                    Text(pin).font(.system(size: 40, weight: .semibold, design: .monospaced))
                        .frame(maxWidth: .infinity).textSelection(.enabled)
                    Button("Sao chép mã") { UIPasteboard.general.string = pin }
                        .font(.subheadline).frame(maxWidth: .infinity)
                }
                if pairing.isPairing {
                    ProgressView().tint(.primary).frame(maxWidth: .infinity)
                    Text(host.statusText).font(.subheadline).foregroundStyle(.secondary)
                    Button("Huỷ ghép đôi", role: .cancel) { pairing.cancelPairing() }
                        .font(.subheadline.weight(.semibold)).frame(maxWidth: .infinity, minHeight: 44)
                } else {
                    action(pairing.record == nil ? "Ghép đôi trên thiết bị này" : "Ghép đôi lại thiết bị này", icon: "antenna.radiowaves.left.and.right") {
                        Task { await pairing.pairOnDevice() }
                    }.disabled(pairing.isBusy)
                }
            } else {
                Text("Ghép đôi trực tiếp trong Cài đặt cần iOS 27 trở lên. Trên phiên bản này, nhập hồ sơ từ SideStore, iLoader hoặc máy tính ở mục phía trên.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 26))
    }

    private func section<Content: View>(_ title: String, content: Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.subheadline.weight(.medium)).foregroundStyle(.secondary).padding(.horizontal, 18)
            content
        }
    }

    private func action(_ title: String, icon: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            Label(title, systemImage: icon).font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity, minHeight: 52)
                .foregroundStyle(Color(uiColor: .systemBackground))
                .background(Color.primary, in: Capsule())
        }.buttonStyle(.plain)
    }

    private func importPendingFile() {
        guard let url = pendingURL else { return }
        pendingURL = nil
        Task { await pairing.importRecord(from: url) }
    }
}
