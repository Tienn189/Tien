import SwiftUI

enum AppAppearance: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject private var model: WallpaperModel
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue

    var body: some View {
        List {
            Section {
                HStack(spacing: 16) {
                    Image("AppMark").resizable().frame(width: 64, height: 64)
                        .clipShape(RoundedRectangle(cornerRadius: 15)).accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("1809").font(.title2.bold())
                        Text("Một nơi cho hình nền của bạn.").font(.subheadline).foregroundStyle(.secondary)
                    }
                }.padding(.vertical, 8)
            }
            Section("Giao diện") {
                Picker("Chế độ hiển thị", selection: $appearance) {
                    ForEach(AppAppearance.allCases) { Text($0.title).tag($0.rawValue) }
                }.pickerStyle(.navigationLink)
            }
            Section {
                LabeledContent("Phiên bản ứng dụng", value: DeviceCompatibility.appVersionText)
                LabeledContent("Bản dựng", value: DeviceCompatibility.buildNumber)
                LabeledContent("Phiên bản hiện tại", value: DeviceCompatibility.installationSupported ? "Được hỗ trợ cài" : "Không hỗ trợ cài")
                LabeledContent("Model phần cứng", value: DeviceCompatibility.hardwareModel)
                LabeledContent("Phiên bản iOS", value: DeviceCompatibility.osVersionText)
            } header: {
                Text("Thông tin ứng dụng và thiết bị")
            } footer: {
                Text(DeviceCompatibility.explanation)
            }
            Section {
                ForEach(DeviceCompatibility.supportedRanges) { Text($0.title) }
            } header: {
                Text("Phạm vi hỗ trợ iOS dự kiến")
            } footer: {
                Text("Bộ cài hình nền hiện có hỗ trợ iOS 26.0–26.6.1. Xác thực pairing là kiểm tra kết nối với thiết bị; chưa mở rộng bộ cài hình nền sang các phiên bản khác.")
            }
            Section("Pairing và LocalDevVPN") {
                Button { model.selectedTab = 3 } label: {
                    Label("Quản lý và xác thực pairing", systemImage: "antenna.radiowaves.left.and.right")
                }
                NavigationLink { PairingGuideView() } label: {
                    Label("Hướng dẫn pairing", systemImage: "questionmark.circle")
                }
            }
            Section("Nguồn") {
                Link("Pocket-Poster · leminlimez", destination: URL(string: "https://github.com/leminlimez/Pocket-Poster")!)
                Link("Thư viện kết nối idevice · jkcoxson", destination: URL(string: "https://github.com/jkcoxson/idevice")!)
                Text("Thông tin nguồn gốc và giấy phép nằm trong LICENSE, ThirdParty và THIRD_PARTY_NOTICES.md của gói mã nguồn.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .listStyle(.insetGrouped).scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài đặt")
    }
}

