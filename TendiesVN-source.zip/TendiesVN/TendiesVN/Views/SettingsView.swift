import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var model: WallpaperModel
    @ObservedObject private var pairing = PairingStore.shared
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex

    private var accent: Color { AppTheme.accentColor(hex: accentHex) }

    var body: some View {
        List {
            Section {
                HStack(spacing: 14) {
                    Image("AppMark").resizable().frame(width: 52, height: 52)
                        .clipShape(RoundedRectangle(cornerRadius: 13)).accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 5) {
                        Text("1809").font(.title3.bold())
                        Text("Thiết lập theo cách của bạn.").font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    Text(DeviceCompatibility.osVersionText)
                        .font(.caption.monospaced().weight(.semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 24))
                .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                .listRowBackground(Color.clear)
            }
            Section("Cá nhân hóa") {
                NavigationLink { AppearanceView() } label: {
                    HStack(spacing: 13) {
                        settingsIcon("paintbrush.pointed", color: accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Giao diện").foregroundStyle(.primary)
                            Text((AppAppearance(rawValue: appearance) ?? .system).title)
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Circle().fill(accent).frame(width: 18, height: 18)
                            .accessibilityHidden(true)
                    }
                    .padding(.vertical, 3)
                }
            }
            Section("Nhật ký") {
                NavigationLink { JournalView() } label: {
                    HStack(spacing: 13) {
                        settingsIcon("text.book.closed", color: accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Nhật ký hoạt động")
                            Text("Các thao tác của ứng dụng và kết quả")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            Section {
                informationRow("Phiên bản ứng dụng", value: DeviceCompatibility.appVersionText)
                informationRow("Bản dựng", value: DeviceCompatibility.buildNumber)
                let capability = DeviceCompatibility.currentCapability
                statusRow("Khả năng trên thiết bị", value: capability.title,
                          systemImage: capability.systemImage, tone: capability.tone)
                informationRow("Model phần cứng", value: DeviceCompatibility.hardwareModel)
                informationRow("Phiên bản iOS", value: DeviceCompatibility.osVersionText)
                if let build = DeviceCompatibility.systemBuild {
                    informationRow("Bản dựng iOS", value: build)
                }
            } header: {
                Text("Thông tin ứng dụng và thiết bị")
            } footer: {
                Text(DeviceCompatibility.explanation)
            }
            Section {
                ForEach(DeviceCompatibility.supportedSystemDescriptions, id: \.self) { description in
                    Text(description).font(.subheadline).padding(.vertical, 3)
                }
                DisclosureGroup("Chi tiết iOS 27 beta") {
                    ForEach(DeviceCompatibility.referenceIOS27BetaRows) { beta in
                        VStack(alignment: .leading, spacing: 5) {
                            Text(beta.title).font(.subheadline)
                            Text(beta.build).font(.caption.monospaced()).foregroundStyle(.secondary)
                        }.padding(.vertical, 4)
                    }
                    Text("Các build beta được hiển thị riêng theo từng tên và build.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            } header: {
                Text("Phạm vi bộ cài hiện có")
            } footer: {
                Text("Ứng dụng chạy từ iOS 17. Các phiên bản trong danh sách được hỗ trợ theo build tương ứng.")
            }
            Section {
                statusRow("Kết nối thiết bị", value: pairing.statusText,
                          systemImage: pairing.statusSystemImage, tone: pairing.statusTone)
                Button { model.selectedTab = 3 } label: {
                    HStack(spacing: 13) {
                        settingsIcon("antenna.radiowaves.left.and.right", color: accent)
                        Text("Quản lý và xác thực pairing")
                    }
                }
                NavigationLink { PairingGuideView() } label: {
                    HStack(spacing: 13) {
                        settingsIcon("questionmark.circle", color: accent)
                        Text("Hướng dẫn pairing")
                    }
                }
            } header: {
                Text("Pairing · tùy chọn")
            } footer: {
                Text("Giữ công cụ kết nối và nhập hồ sơ qua LocalDevVPN. Các build 27.0 beta được liệt kê dùng bộ cài cục bộ, không bắt buộc pairing cho luồng này. Kết nối pairing không tự cấp quyền ghi hình nền.")
            }
            Section("Ghi công") {
                attributionLink(
                    title: "Denrindz",
                    subtitle: "Nhà phát triển & thiết kế",
                    url: "https://github.com/Denrindz"
                )
                attributionRow(title: "1809", subtitle: "Ứng dụng TendiesVN")
                attributionLink(
                    title: "LeminLimez",
                    subtitle: "Pocket Poster, Nugget và định dạng .tendies",
                    url: "https://github.com/leminlimez/Pocket-Poster"
                )
                attributionLink(
                    title: "YangJiii",
                    subtitle: "Nhà phát triển & thiết kế",
                    url: "https://github.com/YangJiiii"
                )
                attributionLink(
                    title: "jkcoxson",
                    subtitle: "Thư viện pairing idevice",
                    url: "https://github.com/jkcoxson/idevice"
                )
                attributionLink(
                    title: "frs0n",
                    subtitle: "Đối chiếu tương thích iOS",
                    url: "https://github.com/frs0n/placard"
                )
            }
        }
        .listStyle(.insetGrouped).scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài đặt")
    }

    private func informationRow(_ title: String, value: String) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                Text(title).fixedSize()
                Spacer(minLength: 12)
                Text(value).foregroundStyle(.secondary).fixedSize()
            }
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                Text(value).foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .fixedSize(horizontal: false, vertical: true)
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }

    private func statusRow(_ title: String, value: String,
                           systemImage: String, tone: AppStatusTone) -> some View {
        ViewThatFits(in: .horizontal) {
            HStack(alignment: .center, spacing: 12) {
                Text(title).fixedSize()
                Spacer(minLength: 12)
                StatusBadge(title: value, systemImage: systemImage, tone: tone)
                    .fixedSize()
            }
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                StatusBadge(title: value, systemImage: systemImage, tone: tone)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .fixedSize(horizontal: false, vertical: true)
        .padding(.vertical, 3)
        .accessibilityElement(children: .combine)
    }

    private func settingsIcon(_ systemImage: String, color: Color) -> some View {
        Image(systemName: systemImage)
            .font(.system(size: 18, weight: .medium))
            .foregroundStyle(color)
            .frame(width: 34, height: 34)
            .background(color.opacity(0.10), in: RoundedRectangle(cornerRadius: 10))
            .accessibilityHidden(true)
    }

    private func attributionRow(title: String, subtitle: String) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundStyle(accent)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
        }
        .padding(.vertical, 5)
    }

    private func attributionLink(title: String, subtitle: String, url: String) -> some View {
        Link(destination: URL(string: url)!) {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.headline)
                        .foregroundStyle(accent)
                    Text(subtitle)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 8)
                Image(systemName: "arrow.up.right")
                    .font(.title3.weight(.medium))
                    .foregroundStyle(.orange)
            }
            .padding(.vertical, 5)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

