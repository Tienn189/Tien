import SwiftUI
import UniformTypeIdentifiers

enum AppAppearance: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

struct SettingsView: View {
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue
    @ObservedObject private var pairing = PairingStore.shared
    @State private var importingPairing = false
    @State private var confirmingRemoval = false

    var body: some View {
        List {
            Section {
                HStack(spacing: 16) {
                    Image("AppMark")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 64, height: 64)
                        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                        .accessibilityHidden(true)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("1809").font(.title2.bold())
                        Text("Một nơi cho hình nền của bạn.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 8)
            }

            Section("Giao diện") {
                Picker("Chế độ hiển thị", selection: $appearance) {
                    ForEach(AppAppearance.allCases) { mode in
                        Text(mode.title).tag(mode.rawValue)
                    }
                }
                .pickerStyle(.navigationLink)
            }

            Section {
                LabeledContent("Phiên bản ứng dụng", value: DeviceCompatibility.appVersionText)
                LabeledContent("Bản dựng", value: DeviceCompatibility.buildNumber)
                LabeledContent("Phiên bản hiện tại") {
                    Label(
                        DeviceCompatibility.installationSupported ? "Được hỗ trợ" : "Không hỗ trợ cài",
                        systemImage: DeviceCompatibility.installationSupported ? "checkmark.circle" : "xmark.circle"
                    )
                    .font(.subheadline)
                    .multilineTextAlignment(.trailing)
                }
                LabeledContent("Model phần cứng", value: DeviceCompatibility.hardwareModel)
                LabeledContent("Phiên bản iOS", value: DeviceCompatibility.osVersionText)
            } header: {
                Text("Thông tin ứng dụng và thiết bị")
            } footer: {
                Text(DeviceCompatibility.explanation)
            }

            Section {
                ForEach(DeviceCompatibility.supportedRanges) { range in
                    Text(range.title)
                }
            } header: {
                Text("Phạm vi hỗ trợ iOS dự kiến")
            } footer: {
                Text("Cài hình nền hiện khả dụng trên iOS 26.0–26.6.1 sau khi kiểm tra quyền. Các phiên bản còn lại chưa hỗ trợ cài trong bản này. iOS 27 trở lên yêu cầu pairing.")
            }

            Section {
                NavigationLink {
                    PairingGuideView()
                } label: {
                    Label("Hướng dẫn pairing", systemImage: "questionmark.circle")
                }
                LabeledContent("Yêu cầu trên thiết bị này", value: DeviceCompatibility.requiresPairing ? "Bắt buộc" : "Không bắt buộc")
                LabeledContent("Trạng thái", value: pairing.statusText)
                if let record = pairing.record {
                    LabeledContent("Tệp đã lưu", value: record.fileName)
                        .font(.subheadline)
                    LabeledContent("Ngày nhập", value: record.importedAt.formatted(date: .abbreviated, time: .shortened))
                        .font(.subheadline)
                    if let identifier = record.maskedDeviceIdentifier {
                        LabeledContent("Mã trong hồ sơ", value: identifier)
                            .font(.subheadline.monospaced())
                    }
                    Text(pairing.detailText)
                        .font(.footnote).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Button {
                    importingPairing = true
                } label: {
                    Label(pairing.record == nil ? "Nhập tệp pairing" : "Thay tệp pairing", systemImage: "doc.badge.plus")
                }
                .disabled(pairing.isImporting)
                if pairing.isImporting {
                    ProgressView("Đang kiểm tra tệp…")
                }
                if pairing.record != nil {
                    Button(role: .destructive) {
                        confirmingRemoval = true
                    } label: {
                        Label("Xoá tệp pairing đã lưu", systemImage: "trash")
                    }
                    .disabled(pairing.isImporting)
                }
            } header: {
                Text("Pairing")
            } footer: {
                Text("Hồ sơ được lưu trong Keychain trên thiết bị. Nhập tệp chưa xác nhận kết nối hoặc quyền cài. Bản này chưa tích hợp kết nối pairing để cài hình nền trên iOS 27.")
            }

            Section("Nguồn") {
                Link(destination: URL(string: "https://github.com/leminlimez/Pocket-Poster")!) {
                    HStack {
                        Label("Pocket-Poster", systemImage: "chevron.left.forwardslash.chevron.right")
                        Spacer()
                        Text("leminlimez").foregroundStyle(.secondary)
                        Image(systemName: "arrow.up.right")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Text("Tham khảo dự án Pocket-Poster của leminlimez. Thông tin giấy phép và các thành phần mã nguồn nằm trong LICENSE và THIRD_PARTY_NOTICES.md.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài đặt")
        .fileImporter(isPresented: $importingPairing, allowedContentTypes: [.item]) { result in
            switch result {
            case .success(let url):
                Task { await pairing.importRecord(from: url) }
            case .failure(let error):
                pairing.errorMessage = error.localizedDescription
            }
        }
        .alert("Không thể cập nhật pairing", isPresented: Binding(
            get: { pairing.errorMessage != nil },
            set: { if !$0 { pairing.errorMessage = nil } }
        )) {
            Button("Đã hiểu", role: .cancel) { pairing.errorMessage = nil }
        } message: {
            Text(pairing.errorMessage ?? "")
        }
        .confirmationDialog("Xoá hồ sơ pairing khỏi thiết bị?", isPresented: $confirmingRemoval, titleVisibility: .visible) {
            Button("Xoá hồ sơ", role: .destructive) { Task { await pairing.removeRecord() } }
        } message: {
            Text("Bạn có thể nhập lại tệp từ Cài đặt khi cần.")
        }
        .task { await pairing.refresh() }
    }
}

private struct PairingGuideView: View {
    var body: some View {
        List {
            Section {
                Text("iOS 27 trở lên yêu cầu hồ sơ pairing của chính thiết bị. Các bước dưới đây giúp tạo và lưu hồ sơ; kết nối để cài hình nền trên iOS 27 chưa có trong bản này.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Section("Chuẩn bị trên máy tính") {
                step("1", "Kết nối thiết bị", "Dùng cáp nối iPhone hoặc iPad với máy tính. Mở khoá máy, chọn Tin cậy và nhập mật mã khi được hỏi.")
                Text("Máy cần có mật mã và luôn mở khoá khi tạo hồ sơ. Trên Windows, cài iTunes và trình điều khiển thiết bị Apple; trên Linux, cài usbmuxd trước khi chạy công cụ.")
                    .font(.footnote).foregroundStyle(.secondary)
                step("2", "Tạo hồ sơ pairing", "Tải công cụ JitterbugPair từ trang phát hành chính thức của Jitterbug. Giải nén và chạy bản dành cho hệ điều hành máy tính của bạn. Công cụ tạo tệp .mobiledevicepairing cho thiết bị đã kết nối.")
                Link("Tải JitterbugPair · osy/Jitterbug", destination: URL(string: "https://github.com/osy/Jitterbug/releases")!)
                step("3", "Chuyển tệp vào Tệp", "Chuyển tệp .mobiledevicepairing vừa tạo sang ứng dụng Tệp trên đúng iPhone hoặc iPad đó, chẳng hạn qua AirDrop hoặc iCloud Drive.")
            }
            Section("Trong 1809") {
                step("4", "Nhập hồ sơ", "Mở Cài đặt → Pairing → Nhập tệp pairing và chọn tệp vừa chuyển. 1809 kiểm tra cấu trúc hồ sơ trước khi lưu vào Keychain.")
                step("5", "Đọc trạng thái", "Đã lưu hồ sơ nghĩa là tệp đã được kiểm tra và lưu cục bộ. Trạng thái này chưa xác minh hồ sơ thuộc thiết bị hiện tại, chưa xác nhận kết nối và chưa mở quyền cài hình nền.")
            }
            Section("Lưu ý về hồ sơ") {
                Text("Hồ sơ chứa khoá ghép đôi với thiết bị. Giữ tệp riêng tư và chỉ nhập hồ sơ của máy bạn đang dùng. Bạn có thể xoá hồ sơ trong Cài đặt → Pairing.")
                Text("Nếu tệp bị từ chối, hãy mở khoá máy, kết nối lại với máy tính và tạo hồ sơ mới. Đổi đuôi một tệp khác thành .mobiledevicepairing không tạo ra hồ sơ hợp lệ.")
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Hướng dẫn pairing")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func step(_ number: String, _ title: String, _ detail: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Text(number)
                .font(.subheadline.weight(.semibold).monospacedDigit())
                .frame(width: 28, height: 28)
                .background(Color(uiColor: .tertiarySystemFill), in: Circle())
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.headline)
                Text(detail).font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 6)
    }
}
