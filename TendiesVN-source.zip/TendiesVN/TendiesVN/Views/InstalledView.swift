import SwiftUI

/// This is the app's save history, not a list of the device's active wallpapers.
struct InstalledView: View {
    @EnvironmentObject private var model: WallpaperModel
    @State private var removing: WallpaperSaveReceipt?

    var body: some View {
        List {
            Section {
                Text("Những ảnh và video đã được ứng dụng lưu thành công vào Ảnh. Đây là lịch sử lưu, không phải danh sách hình nền đang dùng trên thiết bị.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            if model.exportHistory.isEmpty {
                ContentUnavailableView("Chưa lưu hình nền nào", systemImage: "photo.badge.checkmark", description: Text("Mở một gói trong tab Hình nền, chọn ảnh và nhấn Lưu vào Ảnh."))
                    .listRowBackground(Color.clear)
            } else {
                Section("Lịch sử lưu") {
                    ForEach(model.exportHistory) { receipt in
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Đã lưu vào Ảnh", systemImage: "checkmark.circle.fill")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(AppStatusTone.success.color)
                            Text(receipt.assetName).font(.headline).lineLimit(3)
                            Text(receipt.packageName).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                            Text(receipt.savedAt.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 6)
                        .swipeActions {
                            Button(role: .destructive) { removing = receipt } label: {
                                Label("Xoá bản ghi", systemImage: "trash")
                            }.disabled(model.isBusy)
                        }
                        .contextMenu {
                            Button(role: .destructive) { removing = receipt } label: {
                                Label("Xoá bản ghi", systemImage: "trash")
                            }.disabled(model.isBusy)
                        }
                    }
                }
            }
            Section {
                NavigationLink {
                    WallpaperGuideView()
                } label: {
                    Label("Hướng dẫn đặt hình nền", systemImage: "questionmark.circle")
                }
            } footer: {
                Text("Xoá bản ghi chỉ dọn lịch sử trong ứng dụng. Ảnh trong thư viện Ảnh được giữ nguyên.")
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Đã lưu")
        .refreshable { await model.load() }
        .confirmationDialog("Xoá bản ghi khỏi lịch sử?", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }), titleVisibility: .visible) {
            if let receipt = removing {
                Button("Xoá bản ghi", role: .destructive) {
                    removing = nil
                    Task { await model.removeSaveReceipt(receipt) }
                }
            }
        } message: {
            Text("Thao tác này không xoá ảnh hoặc video trong thư viện Ảnh.")
        }
    }
}
