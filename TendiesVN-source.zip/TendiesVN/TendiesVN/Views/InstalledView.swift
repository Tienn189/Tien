import SwiftUI

struct InstalledView: View {
    @EnvironmentObject private var model: WallpaperModel
    @State private var removing: WallpaperInstallReceipt?

    var body: some View {
        List {
            Section {
                Text("Mỗi lần cài có một bản ghi để bạn có thể gỡ đúng các hình nền đã thêm.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            if model.activeReceipts.isEmpty {
                ContentUnavailableView("Chưa có lần cài nào", systemImage: "checkmark.seal", description: Text("Nhập một gói .tendies trong tab Hình nền để bắt đầu."))
                    .listRowBackground(Color.clear)
            }
            ForEach(model.activeReceipts) { receipt in
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label(receipt.status == .preparing ? "Cần dọn lần cài gián đoạn" : "Đã thêm \(receipt.installedDescriptors.count) hình nền", systemImage: receipt.status == .preparing ? "exclamationmark.circle" : "checkmark.circle")
                            .font(.headline).foregroundStyle(receipt.status == .preparing ? .orange : .mint)
                        Text(receipt.createdAt.formatted(date: .abbreviated, time: .shortened))
                            .font(.subheadline).foregroundStyle(.secondary)
                        Text("Mã lần cài: \(receipt.id.uuidString.prefix(8))").font(.caption.monospaced()).foregroundStyle(.secondary)
                    }.padding(.vertical, 5)
                    Button("Gỡ hình nền của lần cài này", role: .destructive) { removing = receipt }
                        .disabled(model.isBusy || !DeviceCompatibility.supported)
                }
            }
        }
        .navigationTitle("Đã cài")
        .refreshable { await model.load() }
        .confirmationDialog("Gỡ hình nền của lần cài này?", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }), titleVisibility: .visible) {
            if let receipt = removing {
                Button("Gỡ hình nền", role: .destructive) { model.restore(receipt); removing = nil }
            }
        } message: {
            Text("Hãy chuyển sang một hình nền Apple khác trước khi gỡ. Gỡ xong sẽ mở PosterBoard; mở đa nhiệm và vuốt đóng thẻ đó để cập nhật Bộ sưu tập.")
        }
    }
}
