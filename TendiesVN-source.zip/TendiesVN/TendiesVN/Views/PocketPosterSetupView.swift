import SwiftUI

/// Recovery App Hash/UUID setup for the Pocket-Poster-compatible iOS 17–18
/// installer. 1809 first discovers the container locally; this screen is only
/// needed when that device-side lookup fails.
struct PocketPosterSetupView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage(PocketPosterConfiguration.appHashKey) private var savedAppHash = ""
    @State private var draftAppHash = ""
    @State private var errorText: String?
    @State private var isDiscovering = false

    private var normalizedDraft: String? {
        PocketPosterConfiguration.normalizedAppHash(draftAppHash)
    }

    var body: some View {
        List {
            Section {
                Text("1809 sẽ tự tìm container PosterBoard khi bắt đầu cài trên iOS 17–18. Nếu bản ký hoặc thiết bị không cho phép dò tự động, bạn có thể nhập UUID dự phòng ở đây.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Link("Mở hướng dẫn Nugget", destination: URL(string: "https://github.com/leminlimez/Nugget")!)
                    .font(.subheadline)
            } header: {
                Text("Cách chuẩn bị")
            }

            Section {
                Button {
                    autoDiscover()
                } label: {
                    Label("Tự tìm container PosterBoard", systemImage: "wand.and.stars")
                }
                .disabled(isDiscovering)
                TextField("Ví dụ: 00112233-4455-6677-8899-AABBCCDDEEFF", text: $draftAppHash)
                    .font(.caption.monospaced())
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .textContentType(.none)
                Button("Lưu App Hash/UUID") {
                    save()
                }
                .disabled(normalizedDraft == nil)
                Button("Đọc NuggetPosterBoardHash") {
                    detectNuggetHash()
                }
                if !savedAppHash.isEmpty {
                    Button("Xoá mã đã lưu", role: .destructive) {
                        PocketPosterConfiguration.clearAppHash()
                        savedAppHash = ""
                        draftAppHash = ""
                    }
                }
            } header: {
                Text("Dò tự động hoặc nhập dự phòng")
            } footer: {
                Text(savedAppHash.isEmpty
                     ? "Chưa có mã lưu. Nút Cài hình nền sẽ tự chạy bộ dò trước; chỉ cần nhập UUID nếu bộ dò thất bại."
                     : "Đã lưu UUID (savedAppHash). Nếu ghi thất bại, lấy lại mã bằng Nugget sau khi tạo một hình nền Bộ sưu tập của Apple.")
            }

            Section("Luồng cài") {
                instruction(1, "Nhấn Cài hình nền; 1809 sẽ tự dò UUID trên thiết bị.")
                instruction(2, "Nếu dò thất bại, dán UUID của com.apple.PosterBoard rồi lưu.")
                instruction(3, "Sau khi cài, đóng thẻ PosterBoard trong đa nhiệm để làm mới Bộ sưu tập.")
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài wallpaper iOS 17–18")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { draftAppHash = savedAppHash }
        .alert("App Hash không hợp lệ", isPresented: Binding(
            get: { errorText != nil },
            set: { if !$0 { errorText = nil } }
        )) {
            Button("Đã hiểu", role: .cancel) { errorText = nil }
        } message: {
            Text(errorText ?? "")
        }
    }

    private func save() {
        do {
            try PocketPosterConfiguration.saveAppHash(draftAppHash)
            savedAppHash = PocketPosterConfiguration.appHash ?? ""
            draftAppHash = savedAppHash
            dismiss()
        } catch {
            errorText = error.localizedDescription
        }
    }

    private func autoDiscover() {
        guard !isDiscovering else { return }
        isDiscovering = true
        Task { @MainActor in
            do {
                let hash = try await Task.detached(priority: .userInitiated) {
                    try PocketPosterConfiguration.discoverAppHashIfNeeded()
                }.value
                savedAppHash = hash
                draftAppHash = hash
                errorText = nil
            } catch {
                errorText = error.localizedDescription
            }
            isDiscovering = false
        }
    }

    private func detectNuggetHash() {
        let helperURL = PocketPosterConfiguration.documentsURL
            .appendingPathComponent("NuggetPosterBoardHash")
        guard let raw = try? String(contentsOf: helperURL, encoding: .utf8),
              PocketPosterConfiguration.normalizedAppHash(raw) != nil else {
            errorText = "Không tìm thấy NuggetPosterBoardHash hợp lệ trong Documents. Hãy dùng Nugget gửi mã vào ứng dụng hoặc dán UUID thủ công."
            return
        }
        draftAppHash = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        save()
        try? FileManager.default.removeItem(at: helperURL)
    }

    private func instruction(_ number: Int, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(number)")
                .font(.subheadline.weight(.semibold))
                .frame(width: 26, height: 26)
                .background(Color.accentColor.opacity(0.12), in: Circle())
            Text(text)
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 4)
    }
}
