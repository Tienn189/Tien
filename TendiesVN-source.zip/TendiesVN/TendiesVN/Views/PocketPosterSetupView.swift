import SwiftUI

/// Manual App Hash/UUID setup for the Pocket-Poster-compatible iOS 17–18
/// installer. The UUID is normally obtained with Nugget on a computer.
struct PocketPosterSetupView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage(PocketPosterConfiguration.appHashKey) private var savedAppHash = ""
    @State private var draftAppHash = ""
    @State private var errorText: String?

    private var normalizedDraft: String? {
        PocketPosterConfiguration.normalizedAppHash(draftAppHash)
    }

    var body: some View {
        List {
            Section {
                Text("Pocket-Poster dùng App Hash/UUID của container PosterBoard để cài hình nền trên iOS 17–18. Ứng dụng không thể tự đọc mã này trong sandbox.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Link("Mở hướng dẫn Nugget", destination: URL(string: "https://github.com/leminlimez/Nugget")!)
                    .font(.subheadline)
            } header: {
                Text("Cách chuẩn bị")
            }

            Section {
                TextField("Ví dụ: 00112233-4455-6677-8899-AABBCCDDEEFF", text: $draftAppHash)
                    .font(.caption.monospaced())
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .textContentType(.none)
                Button("Lưu App Hash/UUID") {
                    save()
                }
                .disabled(normalizedDraft == nil)
                Button("Đọc NuggetPosterBoardHash") {
                    detectNuggetHash()
                }
                if !savedAppHash.isEmpty {
                    Button("Xoá mã đã lưu", role: .destructive) {
                        PocketPosterConfiguration.clearAppHash()
                        savedAppHash = ""
                        draftAppHash = ""
                    }
                }
            } header: {
                Text("App Hash / UUID PosterBoard")
            } footer: {
                Text(savedAppHash.isEmpty
                     ? "Chưa có mã. Cài wallpaper iOS 17–18 sẽ bị khóa cho đến khi nhập UUID hợp lệ."
                     : "Đã lưu UUID (savedAppHash). Nếu ghi thất bại, lấy lại mã bằng Nugget sau khi tạo một hình nền Bộ sưu tập của Apple.")
            }

            Section("Luồng cài") {
                instruction(1, "Dùng Nugget trên máy tính để lấy UUID của com.apple.PosterBoard.")
                instruction(2, "Dán UUID vào đây rồi lưu.")
                instruction(3, "Nhập gói trong 1809, nhấn Cài hình nền, sau đó đóng thẻ PosterBoard trong đa nhiệm để làm mới Bộ sưu tập.")
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài wallpaper iOS 17–18")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { draftAppHash = savedAppHash }
        .alert("App Hash không hợp lệ", isPresented: Binding(
            get: { errorText != nil },
            set: { if !$0 { errorText = nil } }
        )) {
            Button("Đã hiểu", role: .cancel) { errorText = nil }
        } message: {
            Text(errorText ?? "")
        }
    }

    private func save() {
        do {
            try PocketPosterConfiguration.saveAppHash(draftAppHash)
            savedAppHash = PocketPosterConfiguration.appHash ?? ""
            draftAppHash = savedAppHash
            dismiss()
        } catch {
            errorText = error.localizedDescription
        }
    }

    private func detectNuggetHash() {
        let helperURL = PocketPosterConfiguration.documentsURL
            .appendingPathComponent("NuggetPosterBoardHash")
        guard let raw = try? String(contentsOf: helperURL, encoding: .utf8),
              PocketPosterConfiguration.normalizedAppHash(raw) != nil else {
            errorText = "Không tìm thấy NuggetPosterBoardHash hợp lệ trong Documents. Hãy dùng Nugget gửi mã vào ứng dụng hoặc dán UUID thủ công."
            return
        }
        draftAppHash = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        save()
        try? FileManager.default.removeItem(at: helperURL)
    }

    private func instruction(_ number: Int, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(number)")
                .font(.subheadline.weight(.semibold))
                .frame(width: 26, height: 26)
                .background(Color.accentColor.opacity(0.12), in: Circle())
            Text(text)
                .font(.subheadline)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 4)
    }
}
