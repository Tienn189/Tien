import SwiftUI
import UIKit

/// Displays the app-wide activity journal and exposes copy/share and clear actions.
@MainActor
struct JournalView: View {
    @ObservedObject private var journal = JournalStore.shared
    @State private var confirmingClear = false
    @State private var copied = false

    var body: some View {
        Group {
            if journal.entries.isEmpty {
                ContentUnavailableView(
                    "Chưa có nhật ký",
                    systemImage: "doc.text.magnifyingglass",
                    description: Text("Các thao tác nhập, cài, gỡ và lỗi sẽ xuất hiện ở đây.")
                )
            } else {
                List {
                    Section {
                        ForEach(journal.entries) { entry in
                            Text(entry.line)
                                .font(.caption.monospaced())
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.vertical, 6)
                        }
                    } footer: {
                        Text("Nhật ký lưu tối đa 500 mục trên thiết bị này.")
                    }
                }
                .listStyle(.insetGrouped)
            }
        }
        .background(Color.appBackground)
        .navigationTitle("Nhật ký")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                if !journal.entries.isEmpty {
                    Button {
                        UIPasteboard.general.string = journal.shareText
                        copied = true
                    } label: {
                        Image(systemName: copied ? "checkmark" : "doc.on.doc")
                    }
                    .accessibilityLabel(copied ? "Đã sao chép nhật ký" : "Sao chép nhật ký")
                    ShareLink(item: journal.shareText) {
                        Image(systemName: "square.and.arrow.up")
                    }
                    .accessibilityLabel("Chia sẻ nhật ký")
                    Button { confirmingClear = true } label: {
                        Image(systemName: "trash")
                    }
                    .accessibilityLabel("Xoá nhật ký")
                }
            }
        }
        .confirmationDialog(
            "Xoá toàn bộ nhật ký?",
            isPresented: $confirmingClear,
            titleVisibility: .visible
        ) {
            Button("Xoá nhật ký", role: .destructive) { journal.clear() }
            Button("Huỷ", role: .cancel) {}
        }
    }
}
