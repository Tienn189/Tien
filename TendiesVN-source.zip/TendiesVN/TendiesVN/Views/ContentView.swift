import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var model: WallpaperModel
    @State private var importing = false
    @State private var pendingImportURL: URL?

    var body: some View {
        TabView(selection: $model.selectedTab) {
            NavigationStack { PairingView() }
                .tabItem { Label("Pairing", systemImage: "antenna.radiowaves.left.and.right") }
                .tag(3)
            NavigationStack { library }
                .tabItem { Label("Wallpapers", systemImage: "photo.on.rectangle") }
                .tag(0)
            NavigationStack { InstalledView() }
                .tabItem { Label("Đã cài", systemImage: "checkmark.seal") }
                .tag(1)
            NavigationStack { SettingsView() }
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
                .tag(2)
        }
        .tint(.primary)
        .task { await model.load() }
        .sheet(item: $model.selectedPackage, onDismiss: model.sheetDismissed) { package in
            NavigationStack { PackageDetailView(package: package) }
                .presentationDetents([.medium, .large])
                .interactiveDismissDisabled(model.isBusy)
        }
        .sheet(isPresented: $importing, onDismiss: importPickedFile) {
            WallpaperFilePicker(onPick: { url in
                pendingImportURL = url
                importing = false
            }, onCancel: { importing = false })
        }
        .alert(item: Binding(get: { model.selectedPackage == nil && !importing ? model.message : nil }, set: { model.message = $0 })) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
        .overlay(alignment: .bottom) {
            if model.selectedPackage == nil, let status = model.operationStatus {
                OperationStatusView(status: status)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 88)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                hero
                if let notice = model.successNotice {
                    OperationStatusView(
                        status: notice,
                        actionTitle: "Mở lại PosterBoard",
                        onAction: { model.openPosterBoardForRefresh() },
                        onDismiss: { model.dismissSuccessNotice() }
                    )
                }
                DeviceCard()
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Thư viện").font(.title2.bold())
                        Spacer()
                        Text("\(model.packages.count) gói")
                            .font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                    }
                    if model.packages.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "rectangle.stack.badge.plus")
                                .font(.system(size: 32, weight: .light))
                                .padding(.bottom, 4)
                            Text("Thư viện của bạn").font(.headline)
                            Text("Nhập gói .tendies hoặc .zip để cài hình nền.")
                                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 36)
                        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 24))
                    } else {
                        ForEach(model.packages) { package in
                            Button { model.selectedPackage = package } label: { PackageRow(package: package) }
                                .buttonStyle(.plain)
                                .disabled(model.isBusy)
                                .contextMenu {
                                    ShareLink(item: package.archiveURL) {
                                        Label("Xuất .tendies", systemImage: "square.and.arrow.up")
                                    }
                                }
                        }
                    }
                }
                Label("Gói được kiểm tra trên thiết bị trước khi cài.", systemImage: "checkmark.shield")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(20)
            .padding(.bottom, 12)
        }
        .background(Color.appBackground)
        .navigationTitle("Hình nền")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { importing = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Nhập gói hình nền")
                    .disabled(model.isBusy)
            }
        }
        .refreshable { await model.load() }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("1809")
                        .font(.system(size: 64, weight: .semibold))
                        .tracking(-3)
                        .minimumScaleFactor(0.7)
                        .lineLimit(1)
                    Text("Hình nền. Theo cách của bạn.")
                        .font(.headline)
                }
                Spacer(minLength: 8)
                Image(systemName: "rectangle.portrait.on.rectangle.portrait")
                    .font(.system(size: 27, weight: .light))
                    .foregroundStyle(.secondary)
                    .padding(.top, 12)
                    .accessibilityHidden(true)
            }
            Text("Nhập, cài đặt và quản lý bộ sưu tập hình nền trong một nơi.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Button { importing = true } label: {
                Label("Nhập hình nền", systemImage: "plus")
                    .font(.headline)
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundStyle(Color(uiColor: .systemBackground))
                    .background(Color.primary, in: RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            .disabled(model.isBusy)
            .opacity(model.isBusy ? 0.5 : 1)
        }
        .padding(24)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 28))
    }

    private func importPickedFile() {
        // Wait for the document picker to close before presenting details or errors.
        guard let url = pendingImportURL else { return }
        pendingImportURL = nil
        model.importFile(url)
    }
}

struct DeviceCard: View {
    @EnvironmentObject private var model: WallpaperModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "iphone")
                    .font(.title3)
                    .accessibilityHidden(true)
                Text("iOS/iPadOS \(UIDevice.current.systemVersion)")
                    .font(.subheadline.weight(.semibold))
                Spacer(minLength: 8)
                if model.report?.canInstall == true {
                    Image(systemName: "checkmark.circle.fill")
                        .accessibilityLabel("Có quyền cài")
                }
            }
            Text(DeviceCompatibility.explanation)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Button("Kiểm tra quyền cài", systemImage: "checkmark.shield") { model.checkAccess() }
                .font(.subheadline.weight(.semibold))
                .padding(.vertical, 4)
                .disabled(model.isBusy || !DeviceCompatibility.installationSupported)
        }
        .padding(20)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 22))
    }
}

struct PackageRow: View {
    let package: WallpaperStagedPackage

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "rectangle.portrait")
                .font(.system(size: 28, weight: .light))
                .frame(width: 52, height: 62)
                .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(package.displayName).font(.headline).lineLimit(2)
                Text("\(package.payload.descriptors.count) hình nền · \(package.payload.totalBytes.fileSize)")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                .accessibilityHidden(true)
        }
        .padding(16)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 22))
        .contentShape(RoundedRectangle(cornerRadius: 22))
    }
}

extension Int64 {
    var fileSize: String { ByteCountFormatter.string(fromByteCount: self, countStyle: .file) }
}

extension Color {
    static let appBackground = Color(uiColor: .systemGroupedBackground)
    static let appSurface = Color(uiColor: .secondarySystemGroupedBackground)
}
