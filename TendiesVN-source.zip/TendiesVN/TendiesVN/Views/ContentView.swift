import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var model: WallpaperModel
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @State private var importing = false
    @State private var pendingImportURL: URL?

    var body: some View {
        TabView(selection: $model.selectedTab) {
            NavigationStack { library }
                .tabItem { Label("Hình nền", systemImage: "photo.on.rectangle") }
                .tag(0)
            NavigationStack { InstalledView() }
                .tabItem { Label("Đã lưu", systemImage: "photo.badge.checkmark") }
                .tag(1)
            NavigationStack { PairingView() }
                .tabItem { Label("Pairing", systemImage: "antenna.radiowaves.left.and.right") }
                .tag(3)
            NavigationStack { SettingsView() }
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
                .tag(2)
        }
        .task { await model.load() }
        .sheet(item: $model.selectedPackage) { package in
            NavigationStack { PackageDetailView(package: package) }
                .presentationDetents([.large])
                .interactiveDismissDisabled(model.isBusy)
        }
        .sheet(isPresented: $importing, onDismiss: importPickedFile) {
            WallpaperFilePicker(onPick: { url in
                pendingImportURL = url
                importing = false
            }, onCancel: { importing = false })
        }
        .alert(item: Binding(get: { model.selectedPackage == nil && !importing ? model.message : nil }, set: { model.message = $0 })) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
        .overlay(alignment: .bottom) {
            if model.selectedPackage == nil, let status = model.operationStatus {
                OperationStatusView(status: status)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 88)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if let notice = model.successNotice {
                    OperationStatusView(status: notice, onDismiss: { model.dismissSuccessNotice() })
                }
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Thư viện của bạn").font(.headline)
                        Spacer()
                        Text("\(model.packages.count) gói")
                            .font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                    }
                    if model.packages.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "photo.stack")
                                .font(.system(size: 44, weight: .ultraLight))
                                .foregroundStyle(Color.accentColor)
                            Text("Chưa có hình nền").font(.title3.weight(.semibold))
                            Text("Thêm gói .tendies hoặc .zip, chọn ảnh và lưu vào thư viện Ảnh.")
                                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                            Button { importing = true } label: {
                                Label("Thêm gói hình nền", systemImage: "plus")
                                    .font(.subheadline.weight(.semibold))
                                    .padding(.horizontal, 8).padding(.vertical, 5)
                            }
                            .buttonStyle(.borderedProminent).buttonBorderShape(.capsule)
                            .foregroundStyle(AppTheme.foregroundColor(hex: accentHex))
                            .disabled(model.isBusy)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 44)
                    } else {
                        VStack(spacing: 0) {
                            ForEach(Array(model.packages.enumerated()), id: \.element.id) { index, package in
                                Button { model.selectedPackage = package } label: { PackageRow(package: package) }
                                    .buttonStyle(.plain)
                                    .disabled(model.isBusy)
                                    .contextMenu {
                                        ShareLink(item: package.archiveURL) {
                                            Label("Xuất .tendies", systemImage: "square.and.arrow.up")
                                        }
                                    }
                                if index < model.packages.count - 1 {
                                    Divider().padding(.leading, 82)
                                }
                            }
                        }
                        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                    }
                }
                DeviceCard()
                NavigationLink {
                    WallpaperGuideView()
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "questionmark.circle")
                            .font(.title3).foregroundStyle(Color.accentColor)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Cách đặt hình nền").font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                            Text("Lưu ảnh, sau đó chọn trong Cài đặt.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                    }
                    .padding(18)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                }
                .buttonStyle(.plain)
            }
            .padding(20)
            .padding(.bottom, 12)
        }
        .background(Color.appBackground)
        .navigationTitle("Hình nền")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { importing = true } label: {
                    Image(systemName: "plus").font(.body.weight(.semibold))
                        .frame(width: 34, height: 34)
                        .background(Color.accentColor.opacity(0.10), in: Circle())
                }
                .accessibilityLabel("Nhập gói hình nền")
                .disabled(model.isBusy)
            }
        }
        .refreshable { await model.load() }
    }

    private func importPickedFile() {
        guard let url = pendingImportURL else { return }
        pendingImportURL = nil
        model.importFile(url)
    }
}

struct DeviceCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label(DeviceCompatibility.osVersionText, systemImage: "iphone")
                .font(.subheadline.weight(.semibold))
            VStack(alignment: .leading, spacing: 10) {
                StatusBadge(title: DeviceCompatibility.mediaSavingSupported ? "Có thể lưu vào Ảnh" : "Không hỗ trợ lưu vào Ảnh",
                            systemImage: DeviceCompatibility.mediaSavingSupported ? "checkmark.circle.fill" : "xmark.circle.fill",
                            tone: DeviceCompatibility.mediaSavingSupported ? .success : .failure)
                StatusBadge(title: "iOS không cho đặt hình nền trực tiếp",
                            systemImage: "xmark.circle.fill", tone: .failure)
            }
            Text(DeviceCompatibility.explanation)
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(18)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
    }
}

struct PackageRow: View {
    let package: WallpaperStagedPackage

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "photo")
                .font(.system(size: 24, weight: .light))
                .foregroundStyle(Color.accentColor)
                .frame(width: 48, height: 58)
                .background(Color.accentColor.opacity(0.08), in: RoundedRectangle(cornerRadius: 11))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(package.displayName).font(.subheadline.weight(.semibold)).lineLimit(2)
                Text("\(package.payload.descriptors.count) mục · \(package.payload.totalBytes.fileSize)")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.medium)).foregroundStyle(.tertiary)
                .accessibilityHidden(true)
        }
        .padding(16)
        .contentShape(Rectangle())
    }
}

extension Int64 {
    var fileSize: String { ByteCountFormatter.string(fromByteCount: self, countStyle: .file) }
}

extension Color {
    static let appBackground = Color(uiColor: .systemGroupedBackground)
    static let appSurface = Color(uiColor: .secondarySystemGroupedBackground)
}
