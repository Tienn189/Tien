import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var model: WallpaperModel
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @State private var importing = false
    @State private var pendingImportURL: URL?

    private var accent: Color { AppTheme.accentColor(hex: accentHex) }

    var body: some View {
        TabView(selection: $model.selectedTab) {
            NavigationStack { library }
                .tabItem { Label("Hình nền", systemImage: "photo.on.rectangle") }
                .tag(0)
            NavigationStack { InstalledView() }
                .tabItem { Label("Đã cài", systemImage: "checkmark.seal") }
                .tag(1)
            NavigationStack { PairingView() }
                .tabItem { Label("Pairing", systemImage: "antenna.radiowaves.left.and.right") }
                .tag(3)
            NavigationStack { SettingsView() }
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
                .tag(2)
        }
        .task { await model.load() }
        .sheet(item: $model.selectedPackage, onDismiss: model.sheetDismissed) { package in
            NavigationStack { WallpaperActionsView(package: package) }
                .presentationDetents([.large])
                .interactiveDismissDisabled(model.isBusy)
        }
        .sheet(isPresented: $importing, onDismiss: importPickedFile) {
            WallpaperFilePicker(onPick: { url in
                pendingImportURL = url
                importing = false
            }, onCancel: { importing = false })
        }
        .alert(item: Binding(get: { model.selectedPackage == nil && !importing ? model.message : nil }, set: { model.message = $0 })) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
        .overlay(alignment: .bottom) {
            if model.selectedPackage == nil, let status = model.operationStatus {
                OperationStatusView(status: status)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 88)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if let notice = model.successNotice {
                    OperationStatusView(status: notice,
                                        actionTitle: notice.kind == .success && model.refreshInstructions != nil ? "Mở PosterBoard" : nil,
                                        onAction: { model.openPosterBoardForRefresh() },
                                        onDismiss: { model.dismissSuccessNotice() })
                }
                libraryHero
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Text("Thư viện của bạn").font(.title3.weight(.bold))
                        Spacer()
                        Text("\(model.packages.count) gói")
                            .font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                    }
                    if model.packages.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "photo.stack.fill")
                                .font(.system(size: 34, weight: .medium))
                                .foregroundStyle(accent)
                                .frame(width: 74, height: 74)
                                .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 24))
                            Text("Chưa có hình nền").font(.title3.weight(.semibold))
                            Text("Thêm gói .tendies hoặc .zip để cài vào Bộ sưu tập hình nền.")
                                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 38)
                        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 24))
                    } else {
                        VStack(spacing: 0) {
                            ForEach(Array(model.packages.enumerated()), id: \.element.id) { index, package in
                                Button { model.selectedPackage = package } label: { PackageRow(package: package) }
                                    .buttonStyle(.plain)
                                    .disabled(model.isBusy)
                                    .accessibilityHint("Mở thao tác cài hình nền")
                                    .contextMenu {
                                        ShareLink(item: package.archiveURL) {
                                            Label("Xuất .tendies", systemImage: "square.and.arrow.up")
                                        }
                                    }
                                if index < model.packages.count - 1 {
                                    Divider().padding(.leading, 82)
                                }
                            }
                        }
                        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                    }
                    Button { importing = true } label: {
                        Label("Nhập file Tendies", systemImage: "arrow.down.doc.fill")
                            .font(.body.weight(.bold))
                            .foregroundStyle(AppTheme.foregroundColor(hex: accentHex))
                            .frame(maxWidth: .infinity, minHeight: 54)
                            .background(
                                LinearGradient(
                                    colors: [accent, accent.opacity(0.78)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                in: RoundedRectangle(cornerRadius: 18)
                            )
                    }
                    .buttonStyle(.plain)
                    .disabled(model.isBusy)
                }
                DeviceCard()
                NavigationLink {
                    WallpaperGuideView()
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "questionmark.circle")
                            .font(.title3).foregroundStyle(Color.accentColor)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Cài và làm mới hình nền").font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                            Text("PosterBoard và thao tác trong đa nhiệm.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                    }
                    .padding(18)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                }
                .buttonStyle(.plain)
            }
            .padding(20)
            .padding(.bottom, 12)
        }
        .background(Color.appBackground)
        .navigationTitle("Hình nền")
        .refreshable { await model.load() }
    }

    private var libraryHero: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("KHÔNG GIAN CỦA BẠN", systemImage: "sparkles")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.86))
            Text("Một chút mới mẻ\ncho màn hình của bạn")
                .font(.title2.weight(.bold))
                .foregroundStyle(.white)
                .fixedSize(horizontal: false, vertical: true)
            Text("Lưu những gói hình nền yêu thích và khám phá diện mạo mới.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.9))
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(24)
        .background {
            ZStack(alignment: .topTrailing) {
                LinearGradient(colors: [Color(red: 0.18, green: 0.19, blue: 0.62),
                                        Color(red: 0.48, green: 0.20, blue: 0.65),
                                        Color(red: 0.72, green: 0.24, blue: 0.48)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                Circle()
                    .fill(.white.opacity(0.1))
                    .frame(width: 150, height: 150)
                    .offset(x: 55, y: -55)
                    .accessibilityHidden(true)
            }
            .clipShape(RoundedRectangle(cornerRadius: 26))
        }
    }

    private func importPickedFile() {
        guard let url = pendingImportURL else { return }
        pendingImportURL = nil
        model.importFile(url)
    }
}

struct DeviceCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 10) {
                Image(systemName: "iphone.gen3")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(Color.accentColor)
                    .frame(width: 40, height: 40)
                    .background(Color.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 13))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Thiết bị của bạn").font(.subheadline.weight(.bold))
                    Text(DeviceCompatibility.osVersionText).font(.caption).foregroundStyle(.secondary)
                }
            }
            let capability = DeviceCompatibility.currentCapability
            StatusBadge(title: capability.title,
                        systemImage: capability.systemImage,
                        tone: capability.tone)
            Text(DeviceCompatibility.explanation)
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(18)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
    }
}

struct PackageRow: View {
    let package: WallpaperStagedPackage

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "photo.stack.fill")
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: 52, height: 62)
                .background(
                    LinearGradient(colors: [Color(red: 0.38, green: 0.36, blue: 0.84),
                                            Color(red: 0.82, green: 0.35, blue: 0.59)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 15)
                )
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(package.displayName).font(.subheadline.weight(.semibold)).lineLimit(2)
                Text("\(package.payload.descriptors.count) hình nền · \(package.statistics.expandedBytes.fileSize)")
                    .font(.caption).foregroundStyle(.secondary)
                Text("Cài hình nền")
                    .font(.caption.weight(.semibold)).foregroundStyle(Color.accentColor)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.medium)).foregroundStyle(.tertiary)
                .accessibilityHidden(true)
        }
        .padding(16)
        .contentShape(Rectangle())
    }
}

extension Int64 {
    var fileSize: String { ByteCountFormatter.string(fromByteCount: self, countStyle: .file) }
}

extension Color {
    static let appBackground = Color(uiColor: UIColor { traits in
        if traits.userInterfaceStyle == .dark {
            return UIColor(red: 0.045, green: 0.04, blue: 0.085, alpha: 1)
        }
        return UIColor(red: 0.955, green: 0.965, blue: 0.995, alpha: 1)
    })
    static let appSurface = Color(uiColor: UIColor { traits in
        if traits.userInterfaceStyle == .dark {
            return UIColor(red: 0.105, green: 0.095, blue: 0.15, alpha: 1)
        }
        return UIColor.white
    })
}
