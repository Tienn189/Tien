import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var model: WallpaperModel
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @State private var importing = false
    @State private var pendingImportURL: URL?

    private var accent: Color { AppTheme.accentColor(hex: accentHex) }

    var body: some View {
        TabView(selection: $model.selectedTab) {
            NavigationStack { library }
                .tabItem { Label("Hình nền", systemImage: "photo.on.rectangle") }
                .tag(0)
            NavigationStack { InstalledView() }
                .tabItem { Label("Đã cài", systemImage: "checkmark.seal") }
                .tag(1)
            NavigationStack { PairingView() }
                .tabItem { Label("Pairing", systemImage: "antenna.radiowaves.left.and.right") }
                .tag(3)
            NavigationStack { SettingsView() }
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
                .tag(2)
        }
        .task { await model.load() }
        .sheet(item: $model.selectedPackage, onDismiss: model.sheetDismissed) { package in
            NavigationStack { WallpaperActionsView(package: package) }
                .presentationDetents([.large])
                .interactiveDismissDisabled(model.isBusy)
        }
        .sheet(isPresented: $importing, onDismiss: importPickedFile) {
            WallpaperFilePicker(onPick: { url in
                pendingImportURL = url
                importing = false
            }, onCancel: { importing = false })
        }
        .alert(item: Binding(get: { model.selectedPackage == nil && !importing ? model.message : nil }, set: { model.message = $0 })) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
        .overlay(alignment: .bottom) {
            if model.selectedPackage == nil, let status = model.operationStatus {
                OperationStatusView(status: status)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 88)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                if let notice = model.successNotice {
                    OperationStatusView(status: notice,
                                        actionTitle: notice.kind == .success && model.refreshInstructions != nil ? "Mở PosterBoard" : nil,
                                        onAction: { model.openPosterBoardForRefresh() },
                                        onDismiss: { model.dismissSuccessNotice() })
                }
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Text("Thư viện của bạn").font(.headline)
                        Spacer()
                        Text("\(model.packages.count) gói")
                            .font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                    }
                    if model.packages.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "photo.stack")
                                .font(.system(size: 44, weight: .ultraLight))
                                .foregroundStyle(Color.accentColor)
                            Text("Chưa có hình nền").font(.title3.weight(.semibold))
                            Text("Thêm gói .tendies hoặc .zip để cài vào Bộ sưu tập hình nền.")
                                .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 44)
                    } else {
                        VStack(spacing: 0) {
                            ForEach(Array(model.packages.enumerated()), id: \.element.id) { index, package in
                                Button { model.selectedPackage = package } label: { PackageRow(package: package) }
                                    .buttonStyle(.plain)
                                    .disabled(model.isBusy)
                                    .accessibilityHint("Mở thao tác cài hình nền")
                                    .contextMenu {
                                        ShareLink(item: package.archiveURL) {
                                            Label("Xuất .tendies", systemImage: "square.and.arrow.up")
                                        }
                                    }
                                if index < model.packages.count - 1 {
                                    Divider().padding(.leading, 82)
                                }
                            }
                        }
                        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                    }
                    Button { importing = true } label: {
                        Label("Nhập file Tendies", systemImage: "arrow.down.doc.fill")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(AppTheme.foregroundColor(hex: accentHex))
                            .frame(maxWidth: .infinity, minHeight: 46)
                            .background(
                                LinearGradient(
                                    colors: [accent, accent.opacity(0.78)],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                ),
                                in: RoundedRectangle(cornerRadius: 15)
                            )
                    }
                    .buttonStyle(.plain)
                    .disabled(model.isBusy)
                }
                DeviceCard()
                NavigationLink {
                    WallpaperGuideView()
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "questionmark.circle")
                            .font(.title3).foregroundStyle(Color.accentColor)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Cài và làm mới hình nền").font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                            Text("PosterBoard và thao tác trong đa nhiệm.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 8)
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                    }
                    .padding(18)
                    .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
                }
                .buttonStyle(.plain)
            }
            .padding(20)
            .padding(.bottom, 12)
        }
        .background(Color.appBackground)
        .navigationTitle("Hình nền")
        .refreshable { await model.load() }
    }

    private func importPickedFile() {
        guard let url = pendingImportURL else { return }
        pendingImportURL = nil
        model.importFile(url)
    }
}

struct DeviceCard: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label(DeviceCompatibility.osVersionText, systemImage: "iphone")
                .font(.subheadline.weight(.semibold))
            let capability = DeviceCompatibility.currentCapability
            StatusBadge(title: capability.title,
                        systemImage: capability.systemImage,
                        tone: capability.tone)
            Text(DeviceCompatibility.explanation)
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(18)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
    }
}

struct PackageRow: View {
    let package: WallpaperStagedPackage

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "photo")
                .font(.system(size: 24, weight: .light))
                .foregroundStyle(Color.accentColor)
                .frame(width: 48, height: 58)
                .background(Color.accentColor.opacity(0.08), in: RoundedRectangle(cornerRadius: 11))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(package.displayName).font(.subheadline.weight(.semibold)).lineLimit(2)
                Text("\(package.payload.descriptors.count) hình nền · \(package.statistics.expandedBytes.fileSize)")
                    .font(.caption).foregroundStyle(.secondary)
                Text("Cài hình nền")
                    .font(.caption.weight(.semibold)).foregroundStyle(Color.accentColor)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.medium)).foregroundStyle(.tertiary)
                .accessibilityHidden(true)
        }
        .padding(16)
        .contentShape(Rectangle())
    }
}

extension Int64 {
    var fileSize: String { ByteCountFormatter.string(fromByteCount: self, countStyle: .file) }
}

extension Color {
    static let appBackground = Color(uiColor: UIColor { traits in
        if traits.userInterfaceStyle == .dark {
            return UIColor(red: 0.055, green: 0.065, blue: 0.105, alpha: 1)
        }
        return UIColor(red: 0.955, green: 0.965, blue: 0.995, alpha: 1)
    })
    static let appSurface = Color(uiColor: UIColor { traits in
        if traits.userInterfaceStyle == .dark {
            return UIColor(red: 0.115, green: 0.13, blue: 0.19, alpha: 1)
        }
        return UIColor.white
    })
}
