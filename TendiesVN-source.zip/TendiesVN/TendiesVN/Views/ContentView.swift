import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct ContentView: View {
    @EnvironmentObject private var model: WallpaperModel
    @State private var importing = false
    @State private var pendingImportURL: URL?
    @State private var studioRequest: StudioOpenRequest?
    @State private var studioAfterDetail: WallpaperStagedPackage?

    var body: some View {
        ZStack {
            // Keep the canvas mounted when changing sections so its draft and
            // native bridge remain alive until the user explicitly opens a file.
            StudioEditorView(
                package: nil,
                openRequest: studioRequest,
                onSaved: { _ in Task { await model.load() } },
                onOpenPackage: { package in
                    model.selectedTab = 0
                    model.selectedPackage = package
                },
                onNavigate: { model.selectedTab = $0 }
            )
            .opacity(model.selectedTab == 3 ? 1 : 0)
            .allowsHitTesting(model.selectedTab == 3)
            .accessibilityHidden(model.selectedTab != 3)

            TabView(selection: $model.selectedTab) {
                Tab("Chỉnh sửa", systemImage: "paintbrush.pointed", value: 3) {
                    Color.clear.accessibilityHidden(true)
                }
                Tab("Hình nền", systemImage: "rectangle.portrait.on.rectangle.portrait", value: 0) {
                    NavigationStack { library }
                }
                Tab("Đã cài", systemImage: "checkmark.seal", value: 1) {
                    NavigationStack { InstalledView() }
                }
                Tab("Hướng dẫn", systemImage: "info.circle", value: 2) {
                    NavigationStack { GuideView() }
                }
            }
            .toolbar(model.selectedTab == 3 ? .hidden : .visible, for: .tabBar)
            .opacity(model.selectedTab == 3 ? 0 : 1)
            .allowsHitTesting(model.selectedTab != 3)
            .accessibilityHidden(model.selectedTab == 3)
        }
        .tint(.mint)
        .preferredColorScheme(.dark)
        .task { await model.load() }
        .sheet(item: $model.selectedPackage, onDismiss: {
            model.sheetDismissed()
            if let package = studioAfterDetail {
                studioAfterDetail = nil
                openEditor(package)
            }
        }) { package in
            NavigationStack {
                PackageDetailView(package: package, onEdit: {
                    studioAfterDetail = package
                    model.selectedPackage = nil
                })
            }
                .presentationDetents([.medium, .large])
                .interactiveDismissDisabled(model.isBusy)
        }
        .sheet(isPresented: $importing, onDismiss: importPickedFile) {
            WallpaperFilePicker(onPick: { url in
                pendingImportURL = url
                importing = false
            }, onCancel: { importing = false })
        }
        .alert(item: Binding(get: { model.selectedPackage == nil && !importing ? model.message : nil }, set: { model.message = $0 })) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
        .overlay(alignment: .bottom) {
            if model.selectedPackage == nil, model.selectedTab != 3, let status = model.operationStatus {
                OperationStatusView(status: status)
                .padding(.horizontal, 18)
                .padding(.bottom, 88)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                hero
                if let notice = model.successNotice {
                    OperationStatusView(
                        status: notice,
                        actionTitle: "Mở lại PosterBoard",
                        onAction: { model.openPosterBoardForRefresh() },
                        onDismiss: { model.dismissSuccessNotice() }
                    )
                }
                DeviceCard()
                HStack {
                    Text("Gói của bạn").font(.title2.bold())
                    Spacer()
                    Text("\(model.packages.count)").font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                }
                if model.packages.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "square.and.arrow.down").font(.largeTitle).foregroundStyle(.mint)
                        Text("Bắt đầu với một gói hình nền").font(.headline)
                        Text("Nhập .tendies từ CAPlayground, hoặc bản sao .zip của cùng gói hình nền.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity).padding(28).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 24))
                } else {
                    ForEach(model.packages) { package in
                        Button { model.selectedPackage = package } label: { PackageRow(package: package) }
                            .buttonStyle(.plain).disabled(model.isBusy)
                            .contextMenu {
                                Button("Chỉnh sửa", systemImage: "slider.horizontal.3") {
                                    openEditor(package)
                                }
                                ShareLink(item: package.archiveURL) { Label("Xuất .tendies", systemImage: "square.and.arrow.up") }
                            }
                    }
                }
                Label("Gói được kiểm tra trên thiết bị trước khi cài.", systemImage: "checkmark.shield")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }
        .background(Color.appBackground)
        .navigationTitle("TendiesVN")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { importing = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Nhập gói hình nền").disabled(model.isBusy)
            }
        }
        .refreshable { await model.load() }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label("TendiesVN", systemImage: "sparkles").font(.caption.weight(.semibold)).foregroundStyle(.mint)
                Spacer()
                Image(systemName: "waveform.path").font(.title2).foregroundStyle(.mint.opacity(0.7))
            }
            Text("Một màn hình khoá.\nMột chất riêng.")
                .font(.system(.largeTitle, design: .rounded, weight: .bold)).fixedSize(horizontal: false, vertical: true)
            Text("Tạo, chỉnh sửa và cài hình nền của bạn.\nẢnh, chữ và chuyển động theo cách riêng.")
                .font(.subheadline).foregroundStyle(.white.opacity(0.7))
            Button { model.selectedTab = 3 } label: {
                Label("Chỉnh sửa hình nền", systemImage: "paintbrush.pointed.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 7)
            }
            .buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black).disabled(model.isBusy)
            Button { importing = true } label: {
                Label("Nhập .tendies hoặc .zip", systemImage: "plus.circle.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 7)
            }
            .buttonStyle(.bordered).tint(.mint).disabled(model.isBusy)
        }
        .padding(24)
        .background(LinearGradient(colors: [Color(red: 0.10, green: 0.23, blue: 0.23), Color(red: 0.08, green: 0.11, blue: 0.16)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(.mint.opacity(0.15), lineWidth: 1))
    }

    private func openEditor(_ package: WallpaperStagedPackage) {
        studioRequest = StudioOpenRequest(package: package)
        model.selectedTab = 3
    }

    private func importPickedFile() {
        // Present package details/errors only after the document picker closes.
        guard let url = pendingImportURL else { return }
        pendingImportURL = nil
        model.importFile(url)
    }
}

struct StudioOpenRequest: Identifiable {
    let id = UUID()
    let package: WallpaperStagedPackage
}

struct DeviceCard: View {
    @EnvironmentObject private var model: WallpaperModel
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("iOS/iPadOS \(UIDevice.current.systemVersion)", systemImage: "iphone")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                if model.report?.canInstall == true {
                    Label("Có quyền cài", systemImage: "checkmark.circle.fill").foregroundStyle(.mint).font(.caption)
                }
            }
            Text(DeviceCompatibility.explanation).font(.caption).foregroundStyle(.secondary)
            Button("Kiểm tra quyền cài") { model.checkAccess() }
                .font(.subheadline.weight(.semibold)).disabled(model.isBusy || !DeviceCompatibility.supported)
        }
        .padding(18).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20))
    }
}

struct PackageRow: View {
    let package: WallpaperStagedPackage
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "rectangle.portrait.fill")
                .font(.title).foregroundStyle(.mint)
                .frame(width: 54, height: 66)
                .background(LinearGradient(colors: [.mint.opacity(0.2), .blue.opacity(0.15)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 5) {
                Text(package.displayName).font(.headline).lineLimit(2)
                Text("\(package.payload.descriptors.count) hình nền · \(package.payload.totalBytes.fileSize)")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.secondary)
        }
        .padding(14).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20))
    }
}

extension Int64 {
    var fileSize: String { ByteCountFormatter.string(fromByteCount: self, countStyle: .file) }
}

extension Color {
    static let appBackground = Color(red: 0.035, green: 0.045, blue: 0.065)
}
