import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct ContentView: View {
    @EnvironmentObject private var model: WallpaperModel
    @State private var importing = false

    var body: some View {
        TabView(selection: $model.selectedTab) {
            Tab("Hình nền", systemImage: "rectangle.portrait.on.rectangle.portrait", value: 0) {
                NavigationStack { library }
            }
            Tab("Đã cài", systemImage: "checkmark.seal", value: 1) {
                NavigationStack { InstalledView() }
            }
            Tab("Hướng dẫn", systemImage: "info.circle", value: 2) {
                NavigationStack { GuideView() }
            }
        }
        .tint(.mint)
        .preferredColorScheme(.dark)
        .task { await model.load() }
        .sheet(item: $model.selectedPackage, onDismiss: { model.sheetDismissed() }) { package in
            NavigationStack { PackageDetailView(package: package) }
                .presentationDetents([.medium, .large])
                .interactiveDismissDisabled(model.isBusy)
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.tendiesPackage, .data], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first { model.importFile(url) }
            case .failure(let error):
                if (error as NSError).code != NSUserCancelledError {
                    model.message = AppMessage(title: "Không mở được tệp", text: error.localizedDescription)
                }
            }
        }
        .alert(item: Binding(get: { model.selectedPackage == nil ? model.message : nil }, set: { model.message = $0 })) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
        .overlay(alignment: .bottom) {
            if let busy = model.busy {
                HStack(spacing: 12) {
                    ProgressView()
                    Text(busy).font(.subheadline.weight(.medium))
                }
                .padding().background(.regularMaterial, in: Capsule())
                .padding(.bottom, 88)
                .accessibilityAddTraits(.updatesFrequently)
            }
        }
    }

    private var library: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                hero
                DeviceCard()
                HStack {
                    Text("Gói của bạn").font(.title2.bold())
                    Spacer()
                    Text("\(model.packages.count)").font(.subheadline.monospacedDigit()).foregroundStyle(.secondary)
                }
                if model.packages.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "square.and.arrow.down").font(.largeTitle).foregroundStyle(.mint)
                        Text("Bắt đầu với một file .tendies").font(.headline)
                        Text("Xuất gói từ CAPlayground, lưu vào Tệp rồi nhập tại đây.")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity).padding(28).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 24))
                } else {
                    ForEach(model.packages) { package in
                        Button { model.selectedPackage = package } label: { PackageRow(package: package) }
                            .buttonStyle(.plain).disabled(model.isBusy)
                    }
                }
                Label("Gói được kiểm tra trên thiết bị trước khi cài.", systemImage: "checkmark.shield")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }
        .background(Color.appBackground)
        .navigationTitle("TendiesVN")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { importing = true } label: { Image(systemName: "plus") }
                    .accessibilityLabel("Nhập file tendies").disabled(model.isBusy)
            }
        }
        .refreshable { await model.load() }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label("CAPlayground → iPhone", systemImage: "sparkles").font(.caption.weight(.semibold)).foregroundStyle(.mint)
                Spacer()
                Image(systemName: "waveform.path").font(.title2).foregroundStyle(.mint.opacity(0.7))
            }
            Text("Một màn hình khoá.\nMột chất riêng.")
                .font(.system(.largeTitle, design: .rounded, weight: .bold)).fixedSize(horizontal: false, vertical: true)
            Text("Nhập hình nền .tendies của bạn\nvà thêm vào Bộ sưu tập trên iOS.")
                .font(.subheadline).foregroundStyle(.white.opacity(0.7))
            Button { importing = true } label: {
                Label("Nhập file .tendies", systemImage: "plus.circle.fill")
                    .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 7)
            }
            .buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black).disabled(model.isBusy)
        }
        .padding(24)
        .background(LinearGradient(colors: [Color(red: 0.10, green: 0.23, blue: 0.23), Color(red: 0.08, green: 0.11, blue: 0.16)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(.mint.opacity(0.15), lineWidth: 1))
    }
}

struct DeviceCard: View {
    @EnvironmentObject private var model: WallpaperModel
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("iOS/iPadOS \(UIDevice.current.systemVersion)", systemImage: "iphone")
                    .font(.subheadline.weight(.semibold))
                Spacer()
                if model.report?.canInstall == true {
                    Label("Có quyền cài", systemImage: "checkmark.circle.fill").foregroundStyle(.mint).font(.caption)
                }
            }
            Text(DeviceCompatibility.explanation).font(.caption).foregroundStyle(.secondary)
            Button("Kiểm tra quyền cài") { model.checkAccess() }
                .font(.subheadline.weight(.semibold)).disabled(model.isBusy || !DeviceCompatibility.supported)
        }
        .padding(18).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20))
    }
}

struct PackageRow: View {
    let package: WallpaperStagedPackage
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "rectangle.portrait.fill")
                .font(.title).foregroundStyle(.mint)
                .frame(width: 54, height: 66)
                .background(LinearGradient(colors: [.mint.opacity(0.2), .blue.opacity(0.15)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 5) {
                Text(package.displayName).font(.headline).lineLimit(2)
                Text("\(package.payload.descriptors.count) hình nền · \(package.payload.totalBytes.fileSize)")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.secondary)
        }
        .padding(14).background(.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 20))
    }
}

extension Int64 {
    var fileSize: String { ByteCountFormatter.string(fromByteCount: self, countStyle: .file) }
}

extension Color {
    static let appBackground = Color(red: 0.035, green: 0.045, blue: 0.065)
}
