import SwiftUI

struct WallpaperOperationStatus: Identifiable, Equatable {
    enum Kind: Equatable {
        case working
        case success
        case failure
    }

    let id: UUID
    let kind: Kind
    let title: String
    let detail: String
    let phases: [String]
    let activePhase: Int?

    init(
        id: UUID = UUID(),
        kind: Kind,
        title: String,
        detail: String,
        phases: [String] = [],
        activePhase: Int? = nil
    ) {
        self.id = id
        self.kind = kind
        self.title = title
        self.detail = detail
        self.phases = phases
        self.activePhase = activePhase
    }
}

/// The same card can present an indeterminate operation or a lasting result.
/// Phase changes come from completed operations, never elapsed-time estimates.
struct OperationStatusView: View {
    let status: WallpaperOperationStatus
    var actionTitle: String? = nil
    var onAction: (() -> Void)? = nil
    var onDismiss: (() -> Void)? = nil

    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    private var accent: Color {
        status.kind == .failure ? .orange : .mint
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 12) {
                statusIcon
                VStack(alignment: .leading, spacing: 5) {
                    Text(status.title)
                        .font(.system(.subheadline, design: .rounded, weight: .bold))
                        .foregroundStyle(.white)
                    Text(status.detail)
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.72))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                if status.kind != .working, let onDismiss {
                    Button(action: onDismiss) {
                        Image(systemName: "xmark")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white.opacity(0.65))
                            .frame(width: 32, height: 32)
                            .background(.white.opacity(0.06), in: Circle())
                            .frame(minWidth: 44, minHeight: 44)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Đóng thông báo")
                }
            }

            if status.kind == .working,
               let activePhase = status.activePhase,
               status.phases.indices.contains(activePhase) {
                phaseList(activePhase: activePhase)
                    .padding(.top, 1)
                    .accessibilityLabel("Bước \(activePhase + 1): \(status.phases[activePhase])")
            }

            if let actionTitle, let onAction {
                Button(action: onAction) {
                    Label(actionTitle, systemImage: "arrow.up.forward.app")
                        .font(.footnote.weight(.semibold))
                }
                .buttonStyle(.bordered)
                .tint(accent)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 22)
                .fill(Color(red: 0.055, green: 0.095, blue: 0.105))
                .overlay {
                    RoundedRectangle(cornerRadius: 22)
                        .fill(LinearGradient(
                            colors: [accent.opacity(0.09), .clear],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                }
        }
        .overlay {
            RoundedRectangle(cornerRadius: 22)
                .stroke(accent.opacity(0.2), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.16), radius: 14, y: 6)
        .accessibilityElement(children: .contain)
        .accessibilityAddTraits(status.kind == .working ? .updatesFrequently : [])
    }

    private var statusIcon: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 13)
                .fill(accent.opacity(0.13))
            if status.kind == .working {
                ProgressView()
                    .tint(accent)
                    .accessibilityLabel("Đang xử lý")
            } else {
                Image(systemName: status.kind == .success ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(accent)
            }
        }
        .frame(width: 44, height: 44)
        .accessibilityHidden(true)
    }

    @ViewBuilder
    private func phaseList(activePhase: Int) -> some View {
        if dynamicTypeSize.isAccessibilitySize {
            VStack(alignment: .leading, spacing: 9) {
                phases(activePhase: activePhase)
            }
        } else {
            HStack(alignment: .top, spacing: 10) {
                phases(activePhase: activePhase)
            }
        }
    }

    private func phases(activePhase: Int) -> some View {
        ForEach(Array(status.phases.enumerated()), id: \.offset) { index, title in
            HStack(alignment: .firstTextBaseline, spacing: 5) {
                if index < activePhase {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(accent)
                } else {
                    Text("\(index + 1)")
                        .font(.system(.caption2, design: .rounded, weight: .bold))
                        .foregroundStyle(index == activePhase ? Color.black : Color.white.opacity(0.45))
                        .frame(width: 17, height: 17)
                        .background(index == activePhase ? accent : Color.white.opacity(0.07), in: Circle())
                }
                Text(title)
                    .foregroundStyle(index <= activePhase ? Color.white.opacity(0.9) : Color.white.opacity(0.4))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .font(.caption2.weight(index == activePhase ? .semibold : .regular))
            .frame(maxWidth: dynamicTypeSize.isAccessibilitySize ? nil : .infinity, alignment: .leading)
        }
    }
}
