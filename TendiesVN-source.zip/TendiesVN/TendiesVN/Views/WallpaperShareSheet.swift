import SwiftUI
import UIKit

/// Standard iOS share sheet; Save to Files is supplied by the system.
struct WallpaperShareSheet: UIViewControllerRepresentable {
    let fileURL: URL
    let onFinish: () -> Void

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
        controller.completionWithItemsHandler = { _, _, _, _ in
            DispatchQueue.main.async { onFinish() }
        }
        return controller
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
