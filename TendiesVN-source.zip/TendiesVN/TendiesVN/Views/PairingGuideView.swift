import SwiftUI

struct PairingGuideView: View {
    var body: some View {
        List {
            Section("1. Bật LocalDevVPN") {
                Text("Mở LocalDevVPN, cài cấu hình VPN nếu được hỏi rồi bật kết nối. Trở lại 1809 → Pairing, nhập IP thiết bị hiển thị trong LocalDevVPN; mặc định thường là 10.7.0.1.")
                Text("Nếu LocalDevVPN của bạn dùng IP khác, nhập đúng địa chỉ đó. Biểu tượng VPN chỉ cho biết có đường hầm; kết nối được xác thực ở bước kiểm tra hồ sơ.")
                    .font(.footnote).foregroundStyle(.secondary)
                Link("LocalDevVPN chính thức", destination: URL(string: "https://github.com/jkcoxson/LocalDevVPN")!)
            }
            Section("2. Nhập hồ sơ có sẵn") {
                Text("Chọn Nhập tệp pairing và mở hồ sơ .mobiledevicepairing, .mobilepair hoặc .plist từ ứng dụng Tệp. 1809 nhận cả hồ sơ Lockdown và RPPairing, kiểm tra khoá rồi lưu vào Keychain.")
                Text("Bạn có thể dùng hồ sơ đã xuất từ SideStore, iLoader hoặc máy tính. Tệp phải thuộc đúng thiết bị và được tải xong từ iCloud trước khi nhập.")
                Link("Công cụ tạo hồ sơ idevice", destination: URL(string: "https://github.com/jkcoxson/idevice/releases")!)
            }
            Section("Hoặc: ghép đôi trực tiếp trên iOS 27") {
                Text("Trong 1809 → Pairing, chọn Ghép đôi trên thiết bị này. Cho phép Mạng cục bộ khi iOS hỏi.")
                Text("Giữ phiên ghép đôi đang chạy, mở Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép đôi với 1809. Khi thiết bị bắt đầu kết nối, mã PIN sẽ xuất hiện trong 1809; nhập mã đó để chấp thuận.")
                Text("Quay lại 1809 sau khi ghép đôi hoàn tất. Hồ sơ mới được kiểm tra và lưu tự động. Nếu cần làm lại, chọn Ghép đôi lại thiết bị này.")
                Text("Nếu không thấy 1809, kiểm tra Chế độ nhà phát triển và quyền Mạng cục bộ trong Cài đặt của 1809. Trên iOS cũ hơn, nhập hồ sơ từ máy tính hoặc ứng dụng đã ghép đôi.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("3. Xác thực kết nối") {
                Text("Bật LocalDevVPN, mở khoá máy và chọn Kiểm tra kết nối. 1809 mở kết nối tới thiết bị bằng khoá trong hồ sơ và chỉ hiện Kết nối đã xác thực sau khi nhận được phản hồi xác thực.")
                Text("Kết quả hiển thị loại kết nối và thời điểm kiểm tra. Sau khi đổi IP, thay hồ sơ hoặc rời ứng dụng, kiểm tra lại kết nối trước khi tiếp tục.")
                Text("Pairing là công cụ kết nối riêng, không cần để xem hoặc lưu hình nền. 1809 lưu ảnh bằng quyền Thêm vào Ảnh; bạn tự đặt hình nền trong Cài đặt iOS.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Nếu không kết nối được") {
                Text("Kiểm tra LocalDevVPN đang bật, IP đúng và quyền Mạng cục bộ được cho phép. Tắt VPN khác đang chiếm đường hầm, mở khoá thiết bị rồi thử lại.")
                Text("Nếu thiết bị từ chối khoá, ghép đôi lại hoặc tạo và nhập hồ sơ mới của đúng thiết bị. Không đổi đuôi một tệp khác thành tệp pairing.")
                Text("Hồ sơ chứa khoá ghép đôi. Giữ riêng tư; nút thùng rác trong Pairing xoá hồ sơ khỏi Keychain của 1809.")
            }
        }
        .listStyle(.insetGrouped).scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Hướng dẫn pairing").navigationBarTitleDisplayMode(.inline)
    }
}
