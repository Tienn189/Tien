import SwiftUI
import AVKit

struct WallpaperAssetThumbnail: View {
    let asset: WallpaperAsset
    @State private var thumbnail: CGImage?
    @State private var loading = true

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Color(uiColor: .tertiarySystemFill)
            if let thumbnail {
                Image(decorative: thumbnail, scale: 1)
                    .resizable().scaledToFill()
                    .accessibilityHidden(true)
            } else if loading {
                ProgressView().frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                Image(systemName: asset.kind == .image ? "photo.badge.exclamationmark" : "video")
                    .font(.title2).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            if asset.kind == .video {
                Image(systemName: "play.fill")
                    .font(.caption.bold()).foregroundStyle(.white)
                    .padding(8).background(.black.opacity(0.55), in: Circle())
                    .padding(8)
                    .accessibilityHidden(true)
            }
        }
        .task(id: asset.fileURL) {
            thumbnail = nil
            loading = true
            let selectedAsset = asset
            let loaded = await Task.detached(priority: .utility) {
                WallpaperAssetCatalog.thumbnail(for: selectedAsset, maxPixelSize: 480)
            }.value
            guard !Task.isCancelled else { return }
            thumbnail = loaded
            loading = false
        }
        .onDisappear {
            thumbnail = nil
            loading = true
        }
    }
}

struct WallpaperAssetPreview: View {
    let asset: WallpaperAsset
    @State private var image: CGImage?
    @State private var player: AVPlayer?
    @State private var videoObservation: NSKeyValueObservation?
    @State private var videoUnavailable = false
    @State private var loading = true

    var body: some View {
        Group {
            if asset.kind == .video {
                if videoUnavailable {
                    ContentUnavailableView("Không phát được video", systemImage: "video.slash", description: Text("Định dạng video này chưa phát được trên thiết bị. Bạn vẫn có thể thử lưu hoặc chia sẻ tệp gốc."))
                } else if let player {
                    VideoPlayer(player: player)
                        .frame(height: 320)
                        .accessibilityLabel("Xem trước video: \(asset.displayName)")
                } else {
                    ProgressView("Đang mở video…").frame(maxWidth: .infinity, minHeight: 240)
                }
            } else if let image {
                Image(decorative: image, scale: 1)
                    .resizable().scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 400)
                    .accessibilityLabel("Xem trước ảnh: \(asset.displayName)")
            } else if loading {
                ProgressView("Đang mở ảnh…").frame(maxWidth: .infinity, minHeight: 240)
            } else {
                ContentUnavailableView("Không xem trước được ảnh", systemImage: "photo.badge.exclamationmark", description: Text("Bạn vẫn có thể thử lưu hoặc chia sẻ tệp gốc."))
            }
        }
        .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 18))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .task(id: asset.fileURL) {
            player?.pause()
            videoObservation?.invalidate()
            videoObservation = nil
            player = nil
            image = nil
            videoUnavailable = false
            loading = true
            if asset.kind == .video {
                let item = AVPlayerItem(url: asset.fileURL)
                player = AVPlayer(playerItem: item)
                videoObservation = item.observe(\.status, options: [.initial, .new]) { item, _ in
                    guard item.status == .failed else { return }
                    DispatchQueue.main.async {
                        guard player?.currentItem === item else { return }
                        videoUnavailable = true
                    }
                }
            } else {
                let selectedAsset = asset
                let loaded = await Task.detached(priority: .utility) {
                    WallpaperAssetCatalog.thumbnail(for: selectedAsset, maxPixelSize: 1600)
                }.value
                guard !Task.isCancelled else { return }
                image = loaded
            }
            loading = false
        }
        .onDisappear {
            player?.pause()
            videoObservation?.invalidate()
            videoObservation = nil
            image = nil
        }
    }
}
