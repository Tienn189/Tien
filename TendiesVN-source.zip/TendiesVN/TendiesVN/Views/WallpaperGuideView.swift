import SwiftUI

struct WallpaperGuideView: View {
    var body: some View {
        List {
            Section {
                Label("Cài gói qua PosterBoard", systemImage: "photo.on.rectangle")
                    .font(.headline)
                Text("Dùng bộ cài cũ để thêm gói .tendies vào Bộ sưu tập. Sau khi ghi thành công, app mở PosterBoard để bạn làm mới trong đa nhiệm.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Section("Thực hiện") {
                instruction(1, title: "Chuẩn bị Bộ sưu tập", detail: "Trong Cài đặt → Hình nền, thêm và dùng một hình nền Bộ sưu tập của Apple để iOS tạo kho dữ liệu cần thiết.")
                instruction(2, title: "Nhập và cài gói", detail: "Quay lại 1809, nhấn + để nhập gói .tendies hoặc .zip. Mở gói rồi nhấn Cài hình nền. Giữ app mở trong lúc kiểm tra và ghi dữ liệu.")
                instruction(3, title: "Đóng thẻ PosterBoard", detail: "Cài xong, app sẽ mở PosterBoard. Mở đa nhiệm bằng cách vuốt từ cạnh dưới lên và giữ, hoặc nhấn đúp nút Home. Vuốt thẻ PosterBoard lên để đóng; không phải thẻ 1809.")
                instruction(4, title: "Chọn hình nền vừa thêm", detail: "Mở Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập, rồi chọn hình nền mới. Nếu chưa cập nhật, quay lại 1809 nhấn Mở PosterBoard và làm lại bước đóng thẻ.")
            }
            Section {
                Text(DeviceCompatibility.explanation)
                    .font(.subheadline).foregroundStyle(.secondary)
            } header: {
                Text("Tương thích")
            } footer: {
                Text("Bộ cài dùng cho iOS 26.0–26.6.1, các build 27.0 beta được liệt kê và iOS 27.0–27.0.1 qua Airlift với pairing. iOS 18 vẫn hỗ trợ app và thư viện nhưng chưa có backend cài wallpaper. Nếu iOS không mở được PosterBoard, app sẽ báo riêng, không yêu cầu cài lại gói đã ghi xong.")
            }
            Section("Gỡ hình nền đã thêm") {
                Text("Chuyển sang một hình nền Apple khác trước. Trong tab Đã cài, chọn đúng lần cài để gỡ, rồi đóng thẻ PosterBoard trong đa nhiệm lần nữa. Xoá gói nhập trong thư viện không gỡ hình nền đã cài.")
                    .font(.subheadline)
            }
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Cài qua PosterBoard")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func instruction(_ number: Int, title: String, detail: String) -> some View {
        HStack(alignment: .top, spacing: 13) {
            Text("\(number)")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.accentColor)
                .frame(width: 28, height: 28)
                .background(Color.accentColor.opacity(0.10), in: Circle())
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(detail).font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 5)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Bước \(number). \(title). \(detail)")
    }
}
