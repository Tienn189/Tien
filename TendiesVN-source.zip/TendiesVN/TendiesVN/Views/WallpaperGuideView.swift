import SwiftUI
import UIKit

struct WallpaperGuideView: View {
    var body: some View {
        List {
            Section {
                Label("Tự đặt hình nền trong iOS", systemImage: "photo.on.rectangle")
                    .font(.headline)
                Text("Ứng dụng có thể lưu ảnh bạn chọn vào Ảnh. iOS không cung cấp API công khai để ứng dụng tự đổi hình nền; bạn hoàn tất bước này trong Cài đặt.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Section("Thực hiện") {
                instruction(1, title: "Lưu ảnh", detail: "Trong chi tiết gói, chọn đúng ảnh rồi nhấn Lưu vào Ảnh. Chờ thông báo đã lưu thành công.")
                instruction(2, title: "Mở phần Hình nền", detail: "Mở ứng dụng Cài đặt của iPhone → Hình nền → Thêm hình nền mới.")
                instruction(3, title: "Chọn ảnh vừa lưu", detail: "Chọn Ảnh, tìm ảnh vừa lưu, sau đó điều chỉnh vị trí và cách hiển thị theo ý bạn.")
                instruction(4, title: "Hoàn tất", detail: "Nhấn Thêm, rồi chọn Đặt làm cặp hình nền hoặc Tùy chỉnh Màn hình chính. Tên nút có thể khác đôi chút theo phiên bản iOS.")
            }
            Section("Quyền truy cập Ảnh") {
                Text("Khi được hỏi, hãy cho phép ứng dụng thêm ảnh vào thư viện. Nếu đã từ chối, mở cài đặt của ứng dụng để cấp lại quyền Ảnh, rồi thử lưu lại.")
                    .font(.subheadline).foregroundStyle(.secondary)
                Button("Mở cài đặt ứng dụng", systemImage: "gearshape") {
                    guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
                    UIApplication.shared.open(url)
                }
            } footer: {
                Text("Nút này mở thẳng cài đặt của ứng dụng. Nếu tự tìm: trên iOS 17, mở Cài đặt → 1809; trên iOS mới hơn, mục này thường nằm trong Cài đặt → Ứng dụng → 1809. Để đặt hình nền, quay về Cài đặt → Hình nền.")
            }
            Section("Gói hình nền và video") {
                Text("Không phải gói .tendies nào cũng chứa ảnh thông thường có thể dùng riêng. Những hiệu ứng, cấu hình và hình nền hệ thống trong gói không thể áp dụng qua API công khai.")
                Text("Video có thể được lưu và chia sẻ, nhưng iOS không cho đặt mọi video làm hình nền động. Hãy dùng một ảnh tĩnh phù hợp nếu video không xuất hiện khi chọn hình nền.")
            }
            .font(.subheadline)
        }
        .listStyle(.insetGrouped)
        .scrollContentBackground(.hidden)
        .background(Color.appBackground)
        .navigationTitle("Đặt hình nền")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func instruction(_ number: Int, title: String, detail: String) -> some View {
        HStack(alignment: .top, spacing: 13) {
            Text("\(number)")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(Color.accentColor)
                .frame(width: 28, height: 28)
                .background(Color.accentColor.opacity(0.10), in: Circle())
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(detail).font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 5)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Bước \(number). \(title). \(detail)")
    }
}
