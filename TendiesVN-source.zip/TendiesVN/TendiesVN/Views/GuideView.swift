import SwiftUI

struct GuideView: View {
    var body: some View {
        List {
            Section("Lần đầu sử dụng") {
                step("1", "Chuẩn bị Bộ sưu tập", "Vào Cài đặt → Hình nền → Thêm hình nền mới. Chọn một hình nền có sẵn thuộc Bộ sưu tập của Apple, thêm và dùng hình nền đó trước khi cài gói.")
                step("2", "Xuất từ CAPlayground", "Chọn Export → Tendies trong CAPlayground. Lưu tệp .tendies vào ứng dụng Tệp và chờ tải xong nếu đang dùng iCloud.")
                step("3", "Nhập và cài", "Trong TendiesVN, chọn Nhập file .tendies. Xem thông tin gói rồi chọn Cài vào Bộ sưu tập.")
                step("4", "Chọn hình nền mới", "Khởi động lại iPhone/iPad. Mở Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập và chọn hình nền vừa cài.")
            }
            Section("Nếu không cài được") {
                Text("Bản này dùng cơ chế bad_query để truy cập PosterBoard với Bundle ID riêng. Dự án bad_query công bố hỗ trợ iOS/iPadOS 26.0–26.6.1; quyền đọc và ghi vẫn được kiểm tra thực tế trên máy.")
                Text("Khi ký doanh nghiệp, chọn chứng chỉ và provisioning profile cho phép Bundle ID của app. Bundle ID và định danh trong chữ ký phải khớp nhau. Bạn có thể dùng ID riêng; tránh chọn ID đã được một ứng dụng khác sử dụng.")
                Text("Nếu không tìm thấy Bộ sưu tập, hãy hoàn thành bước 1 rồi kiểm tra quyền cài lại. Không tiếp tục thử trên một phiên bản iOS ngoài phạm vi hỗ trợ.")
            }
            Section("Phiên bản và định danh") {
                LabeledContent("Phiên bản", value: "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—") (\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"))")
                VStack(alignment: .leading, spacing: 6) {
                    Text("Bundle ID").font(.subheadline.weight(.semibold))
                    Text(Bundle.main.bundleIdentifier ?? "Không xác định")
                        .font(.caption.monospaced()).textSelection(.enabled)
                }
                Text("ID mặc định vn.tendies.wallpaper khác với 3105, cho phép cài song song. Dữ liệu gói và bản ghi của bản cũ dùng ID MobileHouseArrest không tự chuyển sang app này.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Dữ liệu và gỡ cài đặt") {
                Text("Gói được giải nén và kiểm tra ngay trên thiết bị. App không cần tài khoản hay tải gói lên máy chủ.")
                Text("Tab Đã cài chỉ gỡ các hình nền có trong bản ghi của TendiesVN. Chuyển sang hình nền khác trước khi gỡ. Hãy gỡ hình nền trước khi xoá app để giữ khả năng dọn các gói đã thêm.")
                Text("Thay đổi dữ liệu PosterBoard dùng cơ chế ngoài API công khai của Apple. Hãy sao lưu thiết bị trước khi dùng; khả năng hoạt động có thể thay đổi sau khi cập nhật iOS.")
            }
            Section("Mã nguồn") {
                Link("3105 · YangJiiii · GPL-3.0", destination: URL(string: "https://github.com/YangJiiii/3105")!)
                Link("bad_query · forcequitOS", destination: URL(string: "https://github.com/forcequitOS/bad_query")!)
                Link("CAPlayground", destination: URL(string: "https://github.com/CAPlayground/CAPlayground")!)
                Text("TendiesVN · Bản chuyên cài .tendies với định danh riêng. Xem LICENSE và THIRD_PARTY_NOTICES.md trong gói mã nguồn để biết nguồn gốc các thành phần.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Hướng dẫn")
    }

    private func step(_ number: String, _ title: String, _ body: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Text(number).font(.headline).foregroundStyle(.mint)
                .frame(width: 30, height: 30).background(.mint.opacity(0.12), in: Circle())
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.headline)
                Text(body).font(.subheadline).foregroundStyle(.secondary)
            }.fixedSize(horizontal: false, vertical: true)
        }.padding(.vertical, 8)
    }
}
