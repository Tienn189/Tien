import SwiftUI

struct GuideView: View {
    var body: some View {
        List {
            Section("Tạo và chỉnh sửa trong Studio") {
                step("1", "Tạo mới hoặc mở gói", "Chọn tab Studio để tạo hình nền mới. Muốn sửa gói có sẵn, chọn gói trong danh sách hoặc bấm Chỉnh sửa trong Studio ở màn chi tiết.")
                step("2", "Thiết kế hình nền", "Thêm ảnh, chữ hoặc khối màu. Chạm vào lớp trên khung xem trước để chọn, kéo để di chuyển; dùng bảng thuộc tính để chỉnh kích thước, màu, độ trong suốt và thứ tự lớp.")
                step("3", "Thử chuyển động", "Chọn hiệu ứng động cho từng lớp, chỉnh thời gian và cường độ, rồi bấm Phát để xem thử.")
                step("4", "Xuất .tendies", "Bấm Xuất. Gói được kiểm tra và thêm vào thư viện; chọn lưu vào Tệp, chia sẻ hoặc mở gói để cài. Gói đã nhập ban đầu được giữ lại.")
                Text("Một số hiệu ứng đặc biệt của gói nhập có thể chưa mô phỏng đầy đủ trong khung xem trước. Studio giữ các dữ liệu không chỉnh sửa khi xuất lại và hiển thị cảnh báo nếu có.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Lần đầu sử dụng") {
                step("1", "Chuẩn bị Bộ sưu tập", "Vào Cài đặt → Hình nền → Thêm hình nền mới. Chọn một hình nền có sẵn thuộc Bộ sưu tập của Apple, thêm và dùng hình nền đó trước khi cài gói.")
                step("2", "Xuất từ CAPlayground", "Chọn Export → Tendies trong CAPlayground. Lưu tệp .tendies vào ứng dụng Tệp và chờ tải xong nếu đang dùng iCloud.")
                step("3", "Nhập và cài", "Trong TendiesVN, chọn Nhập .tendies hoặc .zip. Mở gói rồi chọn Cài và mở PosterBoard. App tự tìm và xác minh thư mục hình nền trên máy.")
                step("4", "Đóng thẻ PosterBoard", "Sau khi ghi hình nền thành công, app mở PosterBoard. Vuốt lên từ cạnh dưới và giữ để mở đa nhiệm, rồi vuốt thẻ PosterBoard lên để đóng. Máy có nút Home thì nhấn Home hai lần để mở đa nhiệm.")
                step("5", "Chọn hình nền mới", "Vào Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập và chọn hình nền vừa thêm.")
            }
            Section("Nếu file .tendies không chọn được") {
                Text("Trong ứng dụng Tệp, nhấn giữ file .tendies và chọn Nhân bản để giữ lại bản gốc. Đổi tên bản sao, ví dụ Family.tendies.zip, và xác nhận dùng đuôi .zip. Sau đó chọn bản sao ZIP trong TendiesVN.")
                Text("Chỉ đổi đuôi bản sao, không nén lại file .tendies vào một ZIP khác. App vẫn kiểm tra nội dung gói và chỉ chấp nhận ZIP có cấu trúc hình nền hợp lệ.")
            }
            Section("Nếu không cài được") {
                Text("App tự tìm PosterBoard trên thiết bị và kiểm tra quyền ghi trước khi cài hình nền.")
                Text("Bản này dùng cơ chế bad_query để truy cập PosterBoard với Bundle ID riêng. Dự án bad_query công bố hỗ trợ iOS/iPadOS 26.0–26.6.1; quyền đọc và ghi vẫn được kiểm tra thực tế trên máy.")
                Text("Khi ký doanh nghiệp, chọn chứng chỉ và provisioning profile cho phép Bundle ID của app. Bundle ID và định danh trong chữ ký phải khớp nhau. Bạn có thể dùng ID riêng; tránh chọn ID đã được một ứng dụng khác sử dụng.")
                Text("Nếu không tìm thấy Bộ sưu tập, hãy hoàn thành bước 1 rồi kiểm tra quyền cài lại. Nếu app báo lỗi, hình nền chưa được xác nhận cài thành công; mở thẻ đa nhiệm không thay thế được quyền ghi.")
            }
            Section("Nếu PosterBoard không mở hoặc chưa cập nhật") {
                Text("Sau khi ghi thành công, thẻ hướng dẫn trong tab Hình nền có nút Mở lại PosterBoard. Nếu iOS từ chối mở tự động, vào Cài đặt → Hình nền → Thêm hình nền mới, đóng thẻ PosterBoard trong đa nhiệm nếu có rồi mở lại Bộ sưu tập. Nếu vẫn chưa cập nhật, khởi động lại thiết bị.")
                Text("App mở PosterBoard; bạn tự mở đa nhiệm và vuốt đóng thẻ. App không tự vuốt thẻ hay tự chọn hình nền đang dùng.")
            }
            Section("Phiên bản và định danh") {
                LabeledContent("Phiên bản", value: "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—") (\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"))")
                VStack(alignment: .leading, spacing: 6) {
                    Text("Bundle ID").font(.subheadline.weight(.semibold))
                    Text(Bundle.main.bundleIdentifier ?? "Không xác định")
                        .font(.caption.monospaced()).textSelection(.enabled)
                }
                Text("Giữ nguyên Bundle ID khi cập nhật để giữ thư viện hình nền và các bản ghi cài đặt của bạn.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Dữ liệu và gỡ cài đặt") {
                Text("Gói được giải nén và kiểm tra ngay trên thiết bị. App không cần tài khoản hay tải gói lên máy chủ.")
                Text("Tab Đã cài chỉ gỡ các hình nền có trong bản ghi của TendiesVN. Chuyển sang hình nền khác trước khi gỡ. Hãy gỡ hình nền trước khi xoá app để giữ khả năng dọn các gói đã thêm.")
                Text("Thay đổi dữ liệu PosterBoard dùng cơ chế ngoài API công khai của Apple. Hãy sao lưu thiết bị trước khi dùng; khả năng hoạt động có thể thay đổi sau khi cập nhật iOS.")
            }
            Section("Mã nguồn") {
                Link("bad_query · forcequitOS", destination: URL(string: "https://github.com/forcequitOS/bad_query")!)
                Link("CAPlayground", destination: URL(string: "https://github.com/CAPlayground/CAPlayground")!)
                Text("TendiesVN · Bản chuyên cài .tendies với định danh riêng. Xem LICENSE và THIRD_PARTY_NOTICES.md trong gói mã nguồn để biết nguồn gốc các thành phần.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Hướng dẫn")
    }

    private func step(_ number: String, _ title: String, _ body: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Text(number).font(.headline).foregroundStyle(.mint)
                .frame(width: 30, height: 30).background(.mint.opacity(0.12), in: Circle())
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.headline)
                Text(body).font(.subheadline).foregroundStyle(.secondary)
            }.fixedSize(horizontal: false, vertical: true)
        }.padding(.vertical, 8)
    }
}
