import SwiftUI

struct GuideView: View {
    var body: some View {
        List {
            Section("Lần đầu sử dụng") {
                step("1", "Chuẩn bị Bộ sưu tập", "Vào Cài đặt → Hình nền → Thêm hình nền mới. Chọn một hình nền có sẵn thuộc Bộ sưu tập của Apple, thêm và dùng hình nền đó trước khi cài gói.")
                step("2", "Xuất từ CAPlayground", "Chọn Export → Tendies trong CAPlayground. Lưu tệp .tendies vào ứng dụng Tệp và chờ tải xong nếu đang dùng iCloud.")
                step("3", "Nhập và cài", "Trong TendiesVN, chọn Nhập file .tendies. Xem thông tin gói rồi chọn Cài vào Bộ sưu tập.")
                step("4", "Chọn hình nền mới", "Khởi động lại iPhone/iPad. Mở Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập và chọn hình nền vừa cài.")
            }
            Section("Nếu không cài được") {
                Text("Bản này dùng cơ chế của 3105 dành cho iOS/iPadOS 26.0–26.6.1. Phạm vi tương thích do dự án gốc công bố; quyền truy cập vẫn được kiểm tra trên máy.")
                Text("App cần được ký bằng chứng chỉ doanh nghiệp và giữ nguyên định danh com.apple.mobile.MobileHouseArrest cả trong app lẫn chữ ký. Nếu đổi định danh hoặc ký bằng tài khoản cá nhân, cơ chế này có thể không hoạt động.")
                Text("Nếu đã có 3105 dùng cùng định danh, cài app này có thể thay thế 3105. Hãy lưu dữ liệu cần giữ trước khi cài IPA.")
                Text("Nếu không tìm thấy Bộ sưu tập, hãy hoàn thành bước 1 rồi kiểm tra quyền cài lại. Không tiếp tục thử trên một phiên bản iOS ngoài phạm vi hỗ trợ.")
            }
            Section("Dữ liệu và gỡ cài đặt") {
                Text("Gói được giải nén và kiểm tra ngay trên thiết bị. App không cần tài khoản hay tải gói lên máy chủ.")
                Text("Tab Đã cài chỉ gỡ các hình nền có trong bản ghi của TendiesVN. Chuyển sang hình nền khác trước khi gỡ. Hãy gỡ hình nền trước khi xoá app để giữ khả năng dọn các gói đã thêm.")
                Text("Thay đổi dữ liệu PosterBoard dùng cơ chế ngoài API công khai của Apple. Hãy sao lưu thiết bị trước khi dùng; khả năng hoạt động có thể thay đổi sau khi cập nhật iOS.")
            }
            Section("Mã nguồn") {
                Link("3105 · YangJiiii · GPL-3.0", destination: URL(string: "https://github.com/YangJiiii/3105")!)
                Link("CAPlayground", destination: URL(string: "https://github.com/CAPlayground/CAPlayground")!)
                Text("TendiesVN 1.0 · Bản chuyên cài .tendies. Xem LICENSE và THIRD_PARTY_NOTICES.md trong gói mã nguồn để biết nguồn gốc các thành phần.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("Hướng dẫn")
    }

    private func step(_ number: String, _ title: String, _ body: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Text(number).font(.headline).foregroundStyle(.mint)
                .frame(width: 30, height: 30).background(.mint.opacity(0.12), in: Circle())
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.headline)
                Text(body).font(.subheadline).foregroundStyle(.secondary)
            }.fixedSize(horizontal: false, vertical: true)
        }.padding(.vertical, 8)
    }
}
