import SwiftUI
import WebKit
import UIKit
import CoreFoundation

struct StudioEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model: StudioEditorModel
    @State private var confirmingClose = false
    private let onOpenPackage: (WallpaperStagedPackage) -> Void

    init(
        package: WallpaperStagedPackage?,
        onSaved: @escaping (WallpaperStagedPackage) -> Void,
        onOpenPackage: @escaping (WallpaperStagedPackage) -> Void
    ) {
        _model = StateObject(wrappedValue: StudioEditorModel(package: package, onSaved: onSaved))
        self.onOpenPackage = onOpenPackage
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.appBackground.ignoresSafeArea()
                if let location = model.location {
                    StudioWebContainer(model: model, location: location)
                        .allowsHitTesting(!model.isBusy)
                        .opacity(model.isReady ? 1 : 0)
                }
                if let failure = model.loadFailure {
                    VStack(spacing: 14) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.largeTitle).foregroundStyle(.orange)
                        Text("Chưa mở được trình soạn thảo").font(.headline)
                        Text(failure).font(.subheadline).foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                        Button("Đóng") { requestClose() }.buttonStyle(.bordered)
                    }
                    .padding(28).frame(maxWidth: 420)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 24))
                    .padding(20)
                } else if let busy = model.statusText {
                    VStack(spacing: 12) {
                        ProgressView().tint(.mint)
                        Text(busy).font(.subheadline.weight(.semibold))
                            .multilineTextAlignment(.center)
                    }
                    .padding(24)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
                    .padding(20)
                    .accessibilityAddTraits(.updatesFrequently)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Đóng") { requestClose() }
                }
                ToolbarItem(placement: .principal) {
                    VStack(spacing: 2) {
                        Text("Studio").font(.headline)
                        Text(model.documentTitle).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button("Mở") { model.requestOpen() }
                        .disabled(!model.isReady || model.isBusy)
                    Button { model.requestExport() } label: {
                        Label("Xuất", systemImage: "square.and.arrow.up")
                    }
                    .buttonStyle(.borderedProminent).tint(.mint).foregroundStyle(.black)
                    .disabled(!model.isReady || model.isBusy)
                }
            }
        }
        .tint(.mint)
        .preferredColorScheme(.dark)
        .interactiveDismissDisabled()
        .task { model.start() }
        .sheet(isPresented: $model.showingPicker, onDismiss: { model.pickerDismissed() }) {
            WallpaperFilePicker(onPick: { model.pickedFile($0) }, onCancel: { model.showingPicker = false })
                .ignoresSafeArea()
        }
        .sheet(item: $model.exportResult, onDismiss: resultDismissed) { result in
            StudioExportResultView(result: result, onOpen: { model.openSavedPackage(result.package) })
        }
        .confirmationDialog("Đóng trình soạn thảo?", isPresented: $confirmingClose, titleVisibility: .visible) {
            Button("Đóng, bỏ thay đổi chưa xuất", role: .destructive) { closeEditor() }
            Button("Tiếp tục chỉnh sửa", role: .cancel) {}
        } message: {
            Text("Thay đổi chưa xuất và thao tác đang chạy sẽ dừng. Các gói đã lưu trong thư viện vẫn được giữ lại.")
        }
        .confirmationDialog("Mở gói khác?", isPresented: $model.confirmingOpen, titleVisibility: .visible) {
            Button("Chọn gói khác", role: .destructive) { model.openPickerAfterConfirmation() }
            Button("Tiếp tục chỉnh sửa", role: .cancel) {}
        } message: {
            Text("Hãy xuất trước nếu muốn giữ thay đổi hiện tại. Gói gốc trong thư viện luôn được giữ nguyên.")
        }
        .alert(item: $model.dialog) { dialog in
            if dialog.isConfirmation {
                return Alert(
                    title: Text(dialog.title), message: Text(dialog.message),
                    primaryButton: .default(Text("Tiếp tục"), action: { dialog.resolve(true) }),
                    secondaryButton: .cancel(Text("Hủy"), action: { dialog.resolve(false) })
                )
            }
            return Alert(
                title: Text(dialog.title), message: Text(dialog.message),
                dismissButton: .default(Text("Đã hiểu"), action: { dialog.resolve(true) })
            )
        }
    }

    private func requestClose() {
        if model.isDirty || model.isBusy { confirmingClose = true }
        else { closeEditor() }
    }

    private func closeEditor() {
        Task {
            await model.shutdown()
            dismiss()
        }
    }

    private func resultDismissed() {
        guard let package = model.resultDismissed() else { return }
        Task {
            await model.shutdown()
            onOpenPackage(package)
        }
    }
}

private struct StudioExportResult: Identifiable {
    let id = UUID()
    let package: WallpaperStagedPackage
    let shareURL: URL?
}

private struct StudioExportResultView: View {
    let result: StudioExportResult
    let onOpen: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 12) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.largeTitle).foregroundStyle(.mint)
                        Text("Đã xuất và lưu vào thư viện").font(.title3.bold())
                        Text(result.package.displayName).font(.subheadline).foregroundStyle(.secondary)
                        Text("Bản xuất là một gói mới. Gói gốc của bạn được giữ nguyên.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }.padding(.vertical, 10)
                }
                Section {
                    if let url = result.shareURL {
                        ShareLink(item: url) { Label("Chia sẻ / Lưu vào Tệp", systemImage: "square.and.arrow.up") }
                    } else {
                        Text("Gói đã nằm trong thư viện. Có thể chia sẻ từ trang chi tiết gói.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Button(action: onOpen) {
                        Label("Xem gói và cài", systemImage: "rectangle.portrait.on.rectangle.portrait")
                            .fontWeight(.semibold)
                    }
                    Button("Tiếp tục chỉnh sửa") { dismiss() }
                }
            }
            .navigationTitle("Xuất hình nền").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Đóng") { dismiss() } } }
        }
        .tint(.mint).preferredColorScheme(.dark)
        .presentationDetents([.medium, .large])
    }
}

private final class StudioDialog: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    let isConfirmation: Bool
    private var reply: ((Bool) -> Void)?

    init(title: String, message: String, isConfirmation: Bool = false, reply: ((Bool) -> Void)? = nil) {
        self.title = title
        self.message = String(message.prefix(4_000))
        self.isConfirmation = isConfirmation
        self.reply = reply
    }

    func resolve(_ accepted: Bool) {
        let callback = reply
        reply = nil
        callback?(accepted)
    }
}

@MainActor
private final class StudioEditorModel: ObservableObject {
    @Published private(set) var location: StudioWebLocation?
    @Published private(set) var statusText: String? = "Đang mở trình soạn thảo…"
    @Published private(set) var loadFailure: String?
    @Published private(set) var isReady = false
    @Published private(set) var isDirty = false
    @Published private(set) var webBusy = false
    @Published private(set) var documentTitle = "Hình nền mới"
    @Published var showingPicker = false
    @Published var confirmingOpen = false
    @Published var exportResult: StudioExportResult?
    @Published var dialog: StudioDialog?

    private let initialPackage: WallpaperStagedPackage?
    private let onSaved: (WallpaperStagedPackage) -> Void
    private let assets = StudioAssets.shared
    private let transfers = EditorTransferStore()
    private weak var webView: WKWebView?
    private var operation: Task<Void, Never>?
    private var activeReadID: String?
    private var activeTransferID: String?
    private var pendingPickerURL: URL?
    private var pendingOpenPackage: WallpaperStagedPackage?
    private var shareCopyURL: URL?
    private var started = false
    private var closed = false

    var isBusy: Bool { statusText != nil || webBusy }
    var isClosed: Bool { closed }

    init(package: WallpaperStagedPackage?, onSaved: @escaping (WallpaperStagedPackage) -> Void) {
        initialPackage = package
        self.onSaved = onSaved
        if let package { documentTitle = package.displayName }
    }

    func start() {
        guard !started, !closed else { return }
        started = true
        operation = Task {
            do {
                let prepared = try await assets.prepare()
                try Task.checkCancellation()
                guard !closed else { return }
                location = prepared
            } catch {
                if !closed { failedToLoad(error.localizedDescription) }
            }
        }
    }

    func attach(_ webView: WKWebView) { self.webView = webView }

    func allowedLocalURL(_ url: URL?) -> Bool {
        guard let url, url.isFileURL, let root = location?.rootURL.standardizedFileURL else { return false }
        let path = url.standardizedFileURL.path
        return path.hasPrefix(root.path + "/")
    }

    func becameReady() {
        guard !isReady, !closed else { return }
        isReady = true
        loadFailure = nil
        if let initialPackage {
            loadPackage(initialPackage)
        } else {
            operation = Task {
                do {
                    try await call("return await window.TendiesStudio.startNew();")
                    guard !closed else { return }
                    statusText = nil
                } catch {
                    if !closed { failedToLoad("Không khởi tạo được trang mới. Hãy đóng rồi mở lại Studio.") }
                }
            }
        }
    }

    func failedToLoad(_ message: String) {
        guard !closed else { return }
        statusText = nil
        loadFailure = message
    }

    func requestOpen() {
        guard isReady, !isBusy, !closed else { return }
        if isDirty { confirmingOpen = true }
        else { showingPicker = true }
    }

    func openPickerAfterConfirmation() { showingPicker = true }
    func pickedFile(_ url: URL) { pendingPickerURL = url; showingPicker = false }

    func pickerDismissed() {
        guard let url = pendingPickerURL, !closed else { return }
        pendingPickerURL = nil
        statusText = "Đang kiểm tra gói đã chọn…"
        operation = Task {
            do {
                let package = try await assets.importPackage(from: url)
                try Task.checkCancellation()
                guard !closed else { return }
                onSaved(package)
                await streamPackage(package)
            } catch {
                if !closed { statusText = nil; showError(error) }
            }
        }
    }

    private func loadPackage(_ package: WallpaperStagedPackage) {
        statusText = "Đang mở gói hình nền…"
        operation = Task { await streamPackage(package) }
    }

    private func streamPackage(_ package: WallpaperStagedPackage) async {
        var readID: String?
        do {
            let source = try await assets.beginRead(package)
            readID = source.sessionID
            activeReadID = source.sessionID
            try Task.checkCancellation()
            try await call("return await window.TendiesStudio.beginImport(name, expectedBytes);", arguments: [
                "name": source.filename, "expectedBytes": NSNumber(value: source.expectedBytes)
            ])
            while let chunk = try await assets.nextChunk(sessionID: source.sessionID) {
                try Task.checkCancellation()
                try await call("return await window.TendiesStudio.appendImport(base64, index);", arguments: [
                    "base64": chunk.base64, "index": chunk.index
                ])
            }
            try Task.checkCancellation()
            statusText = "Đang dựng bản xem trước…"
            try await call("return await window.TendiesStudio.finishImport();")
            guard !closed else { return }
            documentTitle = package.displayName
            isDirty = false
            statusText = nil
        } catch {
            if let readID { await assets.cancelRead(sessionID: readID) }
            if !closed { statusText = nil; showError(error) }
        }
        activeReadID = nil
    }

    func requestExport() {
        guard isReady, !isBusy, !closed else { return }
        statusText = "Đang chuẩn bị tệp xuất…"
        operation = Task {
            do {
                try await call("return await window.TendiesStudio.requestExport();")
                if !closed, activeTransferID == nil { statusText = nil }
            } catch {
                if let id = activeTransferID { await transfers.cancel(sessionID: id) }
                activeTransferID = nil
                if !closed { statusText = nil; showError(error) }
            }
        }
    }

    func receive(_ body: [String: Any]) async throws -> [String: Any] {
        guard !closed, let type = body["type"] as? String else { throw StudioBridgeFailure.invalidMessage }
        switch type {
        case "ready":
            becameReady()
        case "state":
            guard let dirty = body["dirty"] as? Bool else { throw StudioBridgeFailure.invalidMessage }
            isDirty = dirty
            if let busy = body["busy"] as? Bool { webBusy = busy }
            if let title = body["title"] as? String {
                documentTitle = String(title.components(separatedBy: .controlCharacters).joined().prefix(80))
            }
        case "openRequest":
            requestOpen()
        case "begin":
            guard activeReadID == nil, activeTransferID == nil,
                  let filename = body["filename"] as? String else { throw StudioBridgeFailure.unavailable }
            let expected = try integer(body["expectedBytes"], maximum: WallpaperLabLimits.maximumArchiveBytes)
            let id = try await transfers.begin(filename: filename, expectedBytes: expected)
            guard !closed else { await transfers.cancel(sessionID: id); throw StudioBridgeFailure.closed }
            activeTransferID = id
            statusText = "Đang nhận và lưu tệp xuất…"
            return ["success": true, "sessionID": id]
        case "append":
            let id = try transferID(body)
            do {
                guard let chunk = body["base64Chunk"] as? String else { throw StudioBridgeFailure.invalidMessage }
                let index = try integer(body["index"], maximum: 1_000_000_000)
                try await transfers.append(sessionID: id, index: Int(index), base64Chunk: chunk)
            } catch {
                await transfers.cancel(sessionID: id)
                activeTransferID = nil
                statusText = nil
                throw error
            }
        case "finish":
            let id = try transferID(body)
            do {
                let package = try await transfers.finish(sessionID: id)
                activeTransferID = nil
                onSaved(package)
                guard !closed else { throw StudioBridgeFailure.closed }
                let share = try? await assets.shareCopy(of: package)
                guard !closed else {
                    if let share { await assets.removeShareCopy(share) }
                    throw StudioBridgeFailure.closed
                }
                shareCopyURL = share
                exportResult = StudioExportResult(package: package, shareURL: share)
                isDirty = false
                statusText = nil
            } catch {
                await transfers.cancel(sessionID: id)
                activeTransferID = nil
                statusText = nil
                throw error
            }
        case "cancel":
            guard let id = body["sessionID"] as? String else { throw StudioBridgeFailure.invalidMessage }
            await transfers.cancel(sessionID: id)
            if activeTransferID == id { activeTransferID = nil; statusText = nil }
        default:
            throw StudioBridgeFailure.invalidMessage
        }
        return ["success": true]
    }

    func openSavedPackage(_ package: WallpaperStagedPackage) {
        pendingOpenPackage = package
        exportResult = nil
    }

    func resultDismissed() -> WallpaperStagedPackage? {
        let package = pendingOpenPackage
        pendingOpenPackage = nil
        if let url = shareCopyURL { Task { await assets.removeShareCopy(url) } }
        shareCopyURL = nil
        return package
    }

    func showDialog(_ next: StudioDialog) {
        if let current = dialog { current.resolve(false) }
        guard !closed else { next.resolve(false); return }
        dialog = next
    }

    func shutdown() async {
        guard !closed else { return }
        closed = true
        operation?.cancel()
        operation = nil
        dialog?.resolve(false)
        dialog = nil
        webView?.stopLoading()
        if let id = activeReadID { await assets.cancelRead(sessionID: id) }
        if let id = activeTransferID { await transfers.cancel(sessionID: id) }
        if let url = shareCopyURL { await assets.removeShareCopy(url) }
        activeReadID = nil
        activeTransferID = nil
        shareCopyURL = nil
    }

    private func call(_ script: String, arguments: [String: Any] = [:]) async throws {
        guard !closed, let webView else { throw StudioBridgeFailure.closed }
        _ = try await webView.callAsyncJavaScript(script, arguments: arguments, in: nil, contentWorld: .page)
    }

    private func transferID(_ body: [String: Any]) throws -> String {
        guard let id = body["sessionID"] as? String, id == activeTransferID else {
            throw StudioBridgeFailure.invalidSession
        }
        return id
    }

    private func integer(_ raw: Any?, maximum: Int64) throws -> Int64 {
        guard let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID(),
              number.doubleValue.isFinite, number.doubleValue.rounded(.towardZero) == number.doubleValue,
              number.doubleValue >= 0, number.doubleValue <= Double(maximum) else {
            throw StudioBridgeFailure.invalidMessage
        }
        return number.int64Value
    }

    private func showError(_ error: Error) {
        showDialog(StudioDialog(title: "Không hoàn tất được", message: error.localizedDescription))
    }
}

private enum StudioBridgeFailure: LocalizedError {
    case invalidMessage, unavailable, invalidSession, closed
    var errorDescription: String? {
        switch self {
        case .invalidMessage: return "Dữ liệu từ trình soạn thảo chưa hợp lệ. Hãy thử lại thao tác."
        case .unavailable: return "Một thao tác khác đang chạy. Hãy chờ thao tác đó hoàn tất."
        case .invalidSession: return "Phiên xuất không còn hợp lệ. Hãy xuất lại hình nền."
        case .closed: return "Trình soạn thảo đã đóng. Gói đã lưu vẫn có trong thư viện."
        }
    }
}

private struct StudioWebContainer: UIViewRepresentable {
    let model: StudioEditorModel
    let location: StudioWebLocation

    func makeCoordinator() -> Coordinator { Coordinator(model: model, location: location) }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        configuration.allowsInlineMediaPlayback = true
        configuration.userContentController.addScriptMessageHandler(
            context.coordinator, contentWorld: .page, name: "tendiesStudio"
        )
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = .clear
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = false
        model.attach(webView)
        context.coordinator.load(webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.stopLoading()
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "tendiesStudio", contentWorld: .page)
        Task { await coordinator.model.shutdown() }
    }

    @MainActor
    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandlerWithReply {
        let model: StudioEditorModel
        private let location: StudioWebLocation

        init(model: StudioEditorModel, location: StudioWebLocation) {
            self.model = model
            self.location = location
        }

        func load(_ webView: WKWebView) {
            Task {
                do {
                    let rules: WKContentRuleList = try await withCheckedThrowingContinuation { continuation in
                        let encoded = """
                        [{"trigger":{"url-filter":"^https?://"},"action":{"type":"block"}},
                         {"trigger":{"url-filter":"^wss?://"},"action":{"type":"block"}}]
                        """
                        WKContentRuleListStore.default().compileContentRuleList(
                            forIdentifier: "TendiesStudioOffline-v1", encodedContentRuleList: encoded
                        ) { list, error in
                            if let list { continuation.resume(returning: list) }
                            else { continuation.resume(throwing: error ?? StudioBridgeFailure.unavailable) }
                        }
                    }
                    guard !model.isClosed else { return }
                    webView.configuration.userContentController.add(rules)
                    webView.loadFileURL(location.indexURL, allowingReadAccessTo: location.rootURL)
                } catch {
                    model.failedToLoad("Không chuẩn bị được chế độ ngoại tuyến. Hãy đóng rồi mở lại Studio.")
                }
            }
        }

        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage,
            replyHandler: @escaping (Any?, String?) -> Void
        ) {
            guard message.frameInfo.isMainFrame,
                  model.allowedLocalURL(message.frameInfo.request.url),
                  let body = message.body as? [String: Any] else {
                replyHandler(nil, "Chỉ trang Studio ngoại tuyến được phép dùng thao tác này.")
                return
            }
            Task {
                do { replyHandler(try await model.receive(body), nil) }
                catch { replyHandler(nil, error.localizedDescription) }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if model.allowedLocalURL(action.request.url) {
                decisionHandler(.allow)
            } else {
                openUserLink(action)
                decisionHandler(.cancel)
            }
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            openUserLink(action)
            return nil
        }

        private func openUserLink(_ action: WKNavigationAction) {
            guard action.navigationType == .linkActivated, action.sourceFrame.isMainFrame,
                  model.allowedLocalURL(action.sourceFrame.request.url), let url = action.request.url,
                  ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { return }
            UIApplication.shared.open(url)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { handleLoadError(error) }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { handleLoadError(error) }

        private func handleLoadError(_ error: Error) {
            guard (error as NSError).code != NSURLErrorCancelled else { return }
            model.failedToLoad("Không tải được bộ soạn thảo ngoại tuyến. Hãy đóng rồi mở lại Studio.")
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            model.failedToLoad("Trình soạn thảo đã dừng do thiếu tài nguyên. Các gói đã xuất vẫn ở thư viện; hãy đóng rồi mở lại Studio.")
        }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
            guard frame.isMainFrame, model.allowedLocalURL(frame.request.url) else { completionHandler(); return }
            model.showDialog(StudioDialog(title: "Studio", message: message, reply: { _ in completionHandler() }))
        }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
            guard frame.isMainFrame, model.allowedLocalURL(frame.request.url) else { completionHandler(false); return }
            model.showDialog(StudioDialog(title: "Xác nhận", message: message, isConfirmation: true, reply: completionHandler))
        }
    }
}
