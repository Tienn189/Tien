import SwiftUI

struct PackageDetailView: View {
    let package: WallpaperStagedPackage
    @EnvironmentObject private var model: WallpaperModel
    @Environment(\.dismiss) private var dismiss
    @State private var confirmingDelete = false

    var body: some View {
        List {
            Section {
                Label(package.displayName, systemImage: "rectangle.portrait.on.rectangle.portrait.fill")
                    .font(.title2.bold()).padding(.vertical, 12)
                LabeledContent("Hình nền", value: "\(package.payload.descriptors.count)")
                LabeledContent("Dung lượng giải nén", value: package.payload.totalBytes.fileSize)
                LabeledContent("Số tệp", value: "\(package.payload.fileCount)")
                LabeledContent("Ngày nhập", value: package.importedAt.formatted(date: .abbreviated, time: .shortened))
            }
            Section {
                Button { model.install(package) } label: {
                    Label("Cài vào Bộ sưu tập", systemImage: "arrow.down.circle.fill")
                        .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 8)
                }
                .disabled(model.isBusy || !DeviceCompatibility.supported)
            } footer: {
                Text("Trước lần cài đầu, hãy tạo và dùng một hình nền thuộc Bộ sưu tập của Apple. Sau khi cài, cần khởi động lại thiết bị và chọn hình nền mới trong Cài đặt. Hãy sao lưu thiết bị trước khi thử.")
            }
            Section {
                ShareLink(item: package.archiveURL) { Label("Chia sẻ gói gốc", systemImage: "square.and.arrow.up") }
                    .disabled(model.isBusy)
                Button(role: .destructive) { confirmingDelete = true } label: {
                    Label("Xoá gói đã nhập", systemImage: "trash")
                }.disabled(model.isBusy)
            } footer: {
                Text("Xoá gói chỉ giải phóng bản nhập trong app. Để gỡ hình nền đã cài, dùng tab Đã cài.")
            }
        }
        .navigationTitle("Chi tiết gói").navigationBarTitleDisplayMode(.inline)
        .safeAreaInset(edge: .bottom) {
            if let busy = model.busy {
                HStack(spacing: 12) {
                    ProgressView()
                    Text(busy).font(.subheadline.weight(.medium))
                }
                .frame(maxWidth: .infinity).padding()
                .background(.regularMaterial)
                .accessibilityAddTraits(.updatesFrequently)
            }
        }
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Đóng") { dismiss() }.disabled(model.isBusy) } }
        .confirmationDialog("Xoá bản nhập trong app?", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("Xoá gói", role: .destructive) { model.delete(package) }
        }
        .alert(item: $model.message) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
    }
}
