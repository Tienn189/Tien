import SwiftUI

struct PackageDetailView: View {
    let package: WallpaperStagedPackage
    @EnvironmentObject private var model: WallpaperModel
    @Environment(\.dismiss) private var dismiss
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @State private var confirmingDelete = false
    @State private var selectedAssetID: String?

    private var selectedAsset: WallpaperAsset? {
        model.assets.first { $0.id == selectedAssetID } ?? model.assets.first
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 8) {
                    Text(package.displayName).font(.title2.bold())
                    Text("\(package.payload.totalBytes.fileSize) · Nhập \(package.importedAt.formatted(date: .abbreviated, time: .omitted))")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if model.isLoadingAssets {
                    ProgressView("Đang tìm ảnh trong gói…")
                        .frame(maxWidth: .infinity).padding(.vertical, 32)
                } else if let error = model.assetsError {
                    ContentUnavailableView("Chưa đọc được nội dung", systemImage: "exclamationmark.triangle", description: Text(error))
                    Button("Thử lại", systemImage: "arrow.clockwise") {
                        Task { await model.loadAssets(for: package) }
                    }.disabled(model.isBusy)
                } else if let asset = selectedAsset {
                    WallpaperAssetPreview(asset: asset)
                    selectedAssetActions(asset)
                    assetLibrary
                } else {
                    ContentUnavailableView("Không tìm thấy ảnh có thể lưu", systemImage: "photo.badge.exclamationmark", description: Text("Gói này không có ảnh hoặc video mà ứng dụng đọc được. Bạn vẫn có thể xuất nguyên gói bên dưới."))
                }
                NavigationLink {
                    WallpaperGuideView()
                } label: {
                    Label("Hướng dẫn đặt hình nền", systemImage: "questionmark.circle")
                        .font(.subheadline.weight(.medium))
                }
                .padding(.horizontal, 2)
                packageActions
                if let notice = model.successNotice {
                    OperationStatusView(status: notice, onDismiss: { model.dismissSuccessNotice() })
                }
            }
            .padding(20)
        }
        .background(Color.appBackground)
        .navigationTitle("Chi tiết gói")
        .navigationBarTitleDisplayMode(.inline)
        .task(id: package.id) { await model.loadAssets(for: package) }
        .safeAreaInset(edge: .bottom) {
            if let status = model.operationStatus {
                OperationStatusView(status: status)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(Color.appBackground.opacity(0.96))
            }
        }
        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Đóng") { dismiss() }.disabled(model.isBusy) } }
        .confirmationDialog("Xoá bản nhập trong app?", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("Xoá gói", role: .destructive) { model.delete(package) }
        } message: {
            Text("Ảnh bạn đã lưu vào thư viện Ảnh và các tệp đã xuất sẽ được giữ nguyên.")
        }
        .sheet(item: $model.sharing, onDismiss: model.sharingFinished) { item in
            WallpaperShareSheet(fileURL: item.fileURL, onFinish: model.sharingFinished)
        }
        .alert(item: $model.message) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Đã hiểu")))
        }
    }

    private func selectedAssetActions(_ asset: WallpaperAsset) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(asset.displayName).font(.headline).lineLimit(3)
            Text("\(asset.kind == .image ? "Ảnh" : "Video") · \(asset.byteCount.fileSize)")
                .font(.caption).foregroundStyle(.secondary)
            Button {
                Task { await model.saveToPhotos(asset, from: package) }
            } label: {
                Label("Lưu vào Ảnh", systemImage: "square.and.arrow.down")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .foregroundStyle(AppTheme.foregroundColor(hex: accentHex))
            .disabled(model.isBusy || !DeviceCompatibility.mediaSavingSupported)
            Button {
                Task { await model.prepareShare(asset, from: package) }
            } label: {
                Label("Lưu vào Tệp / Chia sẻ", systemImage: "square.and.arrow.up")
                    .font(.subheadline.weight(.medium))
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.bordered)
            .disabled(model.isBusy)
            Text(asset.kind == .image
                 ? "Sau khi lưu, mở Cài đặt → Hình nền để tự chọn ảnh. Ứng dụng không tự thay đổi hình nền của thiết bị."
                 : "Video có thể lưu hoặc chia sẻ. iOS không cho dùng mọi video làm hình nền động.")
                .font(.caption).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var assetLibrary: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Nội dung trong gói").font(.headline)
                Spacer()
                Text("\(model.assets.count) tệp").font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 130), spacing: 12)], spacing: 12) {
                ForEach(model.assets) { asset in
                    Button { selectedAssetID = asset.id } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            WallpaperAssetThumbnail(asset: asset)
                                .frame(height: 160)
                                .frame(maxWidth: .infinity)
                                .clipped()
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                            HStack(alignment: .top, spacing: 5) {
                                Text(asset.displayName)
                                    .font(.caption.weight(.medium)).foregroundStyle(.primary)
                                    .lineLimit(2)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                if selectedAsset?.id == asset.id {
                                    Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.accentColor)
                                }
                            }
                        }
                        .padding(9)
                        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 18))
                        .overlay {
                            RoundedRectangle(cornerRadius: 18)
                                .strokeBorder(selectedAsset?.id == asset.id ? Color.accentColor : .clear, lineWidth: 1.5)
                        }
                        .contentShape(RoundedRectangle(cornerRadius: 18))
                    }
                    .buttonStyle(.plain)
                    .disabled(model.isBusy)
                    .accessibilityLabel("\(asset.kind == .image ? "Ảnh" : "Video"): \(asset.displayName)")
                    .accessibilityAddTraits(selectedAsset?.id == asset.id ? [.isSelected] : [])
                }
            }
        }
    }

    private var packageActions: some View {
        VStack(alignment: .leading, spacing: 16) {
            ShareLink(item: package.archiveURL) {
                Label("Xuất gói .tendies", systemImage: "shippingbox")
            }.disabled(model.isBusy)
            Divider()
            Button(role: .destructive) { confirmingDelete = true } label: {
                Label("Xoá gói khỏi thư viện", systemImage: "trash")
            }.disabled(model.isBusy)
        }
        .font(.subheadline)
        .padding(18)
        .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 20))
    }
}
