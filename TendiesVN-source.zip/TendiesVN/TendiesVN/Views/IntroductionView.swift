import SwiftUI

/// A short, optional first-run introduction. Device compatibility is checked
/// by the existing installation flow, not by this screen.
struct IntroductionView: View {
    let onFinish: () -> Void
    @State private var page = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private let ink = Color(red: 0.10, green: 0.14, blue: 0.24)
    private let violet = Color(red: 0.43, green: 0.32, blue: 0.70)
    private let teal = Color(red: 0.09, green: 0.48, blue: 0.47)

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                HStack {
                    Text("1809 / HÌNH NỀN")
                        .font(.caption.weight(.heavy))
                        .tracking(1.4)
                    Spacer()
                    Text(page == 0 ? "01 / 02" : "02 / 02")
                        .font(.caption.monospacedDigit().weight(.semibold))
                        .accessibilityLabel(page == 0 ? "Trang 1 trên 2" : "Trang 2 trên 2")
                }
                .foregroundStyle(ink.opacity(0.65))

                if page == 0 {
                    welcome
                } else {
                    features
                }
            }
            .frame(maxWidth: 520, alignment: .leading)
            .padding(.horizontal, 26)
            .padding(.top, 28)
            .padding(.bottom, 24)
            .frame(maxWidth: .infinity)
        }
        .background(Color(red: 0.96, green: 0.96, blue: 0.98).ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(spacing: 12) {
                Button {
                    if page == 0 {
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) { page = 1 }
                    } else {
                        onFinish()
                    }
                } label: {
                    HStack {
                        Text(page == 0 ? "Khám phá 1809" : "Bắt đầu")
                        Spacer()
                        Image(systemName: "arrow.right")
                    }
                    .font(.body.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 22)
                    .frame(maxWidth: .infinity, minHeight: 58)
                    .background(ink, in: RoundedRectangle(cornerRadius: 18))
                }
                .buttonStyle(.plain)
                if page == 0 {
                    Button("Bỏ qua giới thiệu", action: onFinish)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(ink.opacity(0.7))
                        .frame(minHeight: 44)
                } else {
                    Button("Quay lại") {
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) { page = 0 }
                    }
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(ink.opacity(0.7))
                    .frame(minHeight: 44)
                }
            }
            .frame(maxWidth: 520)
            .padding(.horizontal, 26)
            .padding(.top, 14)
            .padding(.bottom, 8)
            .frame(maxWidth: .infinity)
            .background(Color(red: 0.96, green: 0.96, blue: 0.98))
        }
        .preferredColorScheme(.light)
    }

    private var welcome: some View {
        VStack(alignment: .leading, spacing: 24) {
            ZStack {
                RoundedRectangle(cornerRadius: 32)
                    .fill(Color(red: 0.87, green: 0.90, blue: 0.96))
                Circle()
                    .stroke(violet.opacity(0.3), lineWidth: 1)
                    .frame(width: 190, height: 190)
                Circle()
                    .stroke(teal.opacity(0.24), lineWidth: 1)
                    .frame(width: 250, height: 250)
                Image("AppMark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 112, height: 112)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .shadow(color: ink.opacity(0.18), radius: 20, y: 10)
            }
            .frame(height: 245)
            .clipped()
            .accessibilityHidden(true)

            VStack(alignment: .leading, spacing: 12) {
                Text("CHÀO MỪNG BẠN")
                    .font(.caption.weight(.heavy))
                    .tracking(1.3)
                    .foregroundStyle(teal)
                Text("Màn hình của bạn,\ncâu chuyện của bạn.")
                    .font(.system(.largeTitle, design: .rounded).weight(.bold))
                    .foregroundStyle(ink)
                    .fixedSize(horizontal: false, vertical: true)
                Text("1809 giúp bạn mang những bộ hình nền yêu thích vào Bộ sưu tập trên thiết bị.")
                    .font(.body)
                    .foregroundStyle(ink.opacity(0.75))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var features: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 10) {
                Text("SẴN SÀNG KHÁM PHÁ")
                    .font(.caption.weight(.heavy))
                    .tracking(1.3)
                    .foregroundStyle(teal)
                Text("Ba bước để bắt đầu")
                    .font(.system(.largeTitle, design: .rounded).weight(.bold))
                    .foregroundStyle(ink)
                Text("Mọi thứ bạn cần để đưa một gói hình nền vào 1809.")
                    .foregroundStyle(ink.opacity(0.75))
                    .fixedSize(horizontal: false, vertical: true)
            }
            feature(number: "01", icon: "square.and.arrow.down", title: "Nhập gói hình nền", detail: "Chọn tệp .tendies hoặc .zip tương thích từ ứng dụng Tệp.", color: violet)
            feature(number: "02", icon: "iphone", title: "Kiểm tra thiết bị", detail: "Xem trạng thái hỗ trợ và hoàn tất pairing nếu phiên bản iOS yêu cầu.", color: teal)
            feature(number: "03", icon: "sparkles", title: "Cài và khám phá", detail: "Làm theo hướng dẫn trong ứng dụng rồi kiểm tra hình nền trong Bộ sưu tập.", color: Color(red: 0.70, green: 0.35, blue: 0.35))
        }
    }

    private func feature(number: String, icon: String, title: String, detail: String, color: Color) -> some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.title3.weight(.semibold))
                .foregroundStyle(color)
                .frame(width: 46, height: 46)
                .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.headline).foregroundStyle(ink)
                Text(detail).font(.subheadline).foregroundStyle(ink.opacity(0.75))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            Text(number).font(.caption.monospacedDigit().weight(.bold)).foregroundStyle(color)
                .accessibilityHidden(true)
        }
        .padding(17)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.white, in: RoundedRectangle(cornerRadius: 20))
    }
}
