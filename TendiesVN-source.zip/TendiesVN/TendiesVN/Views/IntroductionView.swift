import SwiftUI
import UIKit

/// First-run introduction; installation support still depends on the device and its setup.
struct IntroductionView: View {
    let onFinish: () -> Void

    @State private var phase = 0
    @State private var showWelcome = false
    @Namespace private var brandMotion
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme
    @ScaledMetric(relativeTo: .largeTitle) private var headingSize: CGFloat = 44
    @ScaledMetric(relativeTo: .largeTitle) private var markSize: CGFloat = 52

    private let accent = Color(red: 0.59, green: 0.45, blue: 0.76)
    private var background: Color { colorScheme == .dark ? .black : .white }
    private var skipMotion: Bool { reduceMotion || UIAccessibility.isVoiceOverRunning }

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                background.ignoresSafeArea()

                if phase == 0 {
                    Text("1809")
                        .font(.system(size: markSize, weight: .bold, design: .rounded))
                        .tracking(-1.5)
                        .foregroundStyle(.primary)
                        .matchedGeometryEffect(id: "brand", in: brandMotion)
                        .transition(.identity)
                        .accessibilityHidden(true)
                }

                if phase == 1 || phase == 2 {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 0) {
                            // Keep the icon in the same layout as the heading so
                            // it travels upward with the words while fading away.
                            Image("AppMark")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 78, height: 78)
                                .clipShape(RoundedRectangle(cornerRadius: 19))
                                .opacity(showWelcome && phase == 1 ? 1 : 0)
                                .frame(height: phase == 1 ? 96 : 0, alignment: .top)
                                .accessibilityHidden(true)
                            heading
                            features
                                .padding(.top, 42)
                                .accessibilityHidden(phase != 2)
                        }
                        .frame(maxWidth: 450, alignment: .leading)
                        .padding(.horizontal, 30)
                        .padding(.top, phase == 1 ? max(40, geometry.size.height * 0.20) : 34)
                        .padding(.bottom, 28)
                        .frame(maxWidth: .infinity, alignment: .top)
                    }
                    .scrollDisabled(phase != 2)
                    .transition(.identity)
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        // Reserve the button's space throughout the transition;
                        // this avoids a sudden layout jump when it appears.
                        bottomButton("Tiếp tục") {
                            if skipMotion { phase = 3 }
                            else { withAnimation(.easeInOut(duration: 0.45)) { phase = 3 } }
                        }
                        .opacity(phase == 2 ? 1 : 0)
                        .offset(y: phase == 2 ? 0 : 12)
                        .animation(skipMotion ? nil : .easeOut(duration: 0.45).delay(0.8), value: phase)
                        .allowsHitTesting(phase == 2)
                        .accessibilityHidden(phase != 2)
                    }
                }

                if phase == 3 {
                    DeviceIntroductionView(onFinish: onFinish)
                        .transition(skipMotion ? .opacity : .opacity.combined(with: .offset(y: 25)))
                }
            }
        }
        .task {
            if skipMotion {
                showWelcome = true
                phase = 2
                return
            }
            do {
                try await Task.sleep(nanoseconds: 650_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.9)) { phase = 1 }
                try await Task.sleep(nanoseconds: 50_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.7)) { showWelcome = true }
                try await Task.sleep(nanoseconds: 1_650_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.85)) { phase = 2 }
            } catch {
                // The view may disappear when a file is opened or the app exits.
            }
        }
    }

    private var heading: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Welcome to")
                .foregroundStyle(.primary)
                .opacity(showWelcome ? 1 : 0)
                .offset(y: showWelcome ? 0 : 16)
            Text("1809")
                .foregroundStyle(accent)
                .matchedGeometryEffect(id: "brand", in: brandMotion)
        }
        .font(.system(size: headingSize, weight: .bold, design: .rounded))
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }

    private var features: some View {
        VStack(alignment: .leading, spacing: 28) {
            feature(icon: "square.and.arrow.down", color: .blue,
                    title: "Nhập hình nền", index: 0,
                    detail: "Chọn gói .tendies hoặc .zip tương thích từ ứng dụng Tệp.")
            feature(icon: "iphone", color: accent,
                    title: "Kiểm tra thiết bị", index: 1,
                    detail: "Xem trạng thái hỗ trợ và kết nối pairing nếu phiên bản iOS yêu cầu.")
            feature(icon: "sparkles", color: .mint,
                    title: "Cài và khám phá", index: 2,
                    detail: "Làm theo hướng dẫn trong ứng dụng và kiểm tra hình nền trong Bộ sưu tập.")
        }
    }

    private func feature(icon: String, color: Color, title: String, index: Int, detail: String) -> some View {
        HStack(alignment: .top, spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 27, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: 40, alignment: .center)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(detail)
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .opacity(phase == 2 ? 1 : 0)
        .offset(y: phase == 2 ? 0 : 20)
        .animation(skipMotion ? nil : .easeOut(duration: 0.6).delay(0.8 + 0.12 * Double(index)), value: phase)
    }

    private func bottomButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.headline.weight(.bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, minHeight: 54)
                .background(Color(red: 0.43, green: 0.29, blue: 0.63), in: Capsule())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: 450)
        .padding(.horizontal, 30)
        .padding(.top, 14)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(background)
    }
}

private struct DeviceIntroductionView: View {
    let onFinish: () -> Void
    @State private var showStatus = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme

    private var background: Color { colorScheme == .dark ? .black : .white }
    private var capability: DeviceCapability { DeviceCompatibility.currentCapability }
    private var supported: Bool { capability == .localInstallation }
    private var statusColor: Color { capability.tone.color }
    private var device: UIDevice { UIDevice.current }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 26) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Thiết bị của bạn")
                        .font(.largeTitle.weight(.bold))
                        .accessibilityAddTraits(.isHeader)
                    Text("Kiểm tra nhanh trước khi bắt đầu.")
                        .font(.body).foregroundStyle(.secondary)
                }
                VStack(spacing: 0) {
                    informationRow("Tên thiết bị", value: device.name, icon: "person.crop.circle")
                    Divider().padding(.leading, 50)
                    informationRow("Thiết bị", value: device.model, icon: "iphone")
                    Divider().padding(.leading, 50)
                    informationRow("Phiên bản iOS", value: DeviceCompatibility.osVersionText, icon: "gearshape")
                }
                .padding(18)
                .background(Color.appSurface, in: RoundedRectangle(cornerRadius: 22))

                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        Image(systemName: capability.systemImage)
                            .font(.title2.weight(.semibold))
                            .foregroundStyle(statusColor)
                            .scaleEffect(showStatus ? 1 : 0.55)
                            .rotationEffect(.degrees(showStatus ? 0 : (supported ? -18 : 18)))
                            .opacity(showStatus ? 1 : 0)
                            .accessibilityHidden(true)
                        Text(capability.title)
                            .font(.title3.weight(.bold))
                            .foregroundStyle(statusColor)
                    }
                    Text(DeviceCompatibility.explanation)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    if supported {
                        Text("Khả năng cài thực tế còn phụ thuộc vào thiết bị và cấu hình.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(statusColor.opacity(0.1), in: RoundedRectangle(cornerRadius: 22))
            }
            .frame(maxWidth: 450, alignment: .leading)
            .padding(.horizontal, 30)
            .padding(.top, 34)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .background(background.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) {
            Button(action: onFinish) {
                Text("Bắt đầu")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 54)
                    .background(Color(red: 0.43, green: 0.29, blue: 0.63), in: Capsule())
            }
            .buttonStyle(.plain)
            .frame(maxWidth: 450)
            .padding(.horizontal, 30)
            .padding(.top, 14)
            .padding(.bottom, 12)
            .frame(maxWidth: .infinity)
            .background(background)
        }
        .task {
            if reduceMotion || UIAccessibility.isVoiceOverRunning {
                showStatus = true
            } else {
                withAnimation(.spring(response: 0.55, dampingFraction: 0.7).delay(0.2)) {
                    showStatus = true
                }
            }
        }
    }

    private func informationRow(_ title: String, value: String, icon: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: icon)
                .foregroundStyle(.secondary)
                .frame(width: 30)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.body.weight(.semibold))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 10)
        .accessibilityElement(children: .combine)
    }
}
