import SwiftUI

/// First-run introduction. The installation flow performs its own compatibility checks.
struct IntroductionView: View {
    let onFinish: () -> Void

    @State private var phase = 0
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme
    @ScaledMetric(relativeTo: .largeTitle) private var headingSize: CGFloat = 44
    @ScaledMetric(relativeTo: .largeTitle) private var markSize: CGFloat = 52

    private let accent = Color(red: 0.59, green: 0.45, blue: 0.76)
    private var background: Color { colorScheme == .dark ? .black : .white }

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                background.ignoresSafeArea()

                if phase == 0 {
                    Text("1809")
                        .font(.system(size: markSize, weight: .bold, design: .rounded))
                        .tracking(-1.5)
                        .foregroundStyle(.primary)
                        .transition(.opacity)
                        .accessibilityHidden(true)
                }

                if phase > 0 {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 0) {
                            if phase == 1 {
                                Image("AppMark")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 78, height: 78)
                                    .clipShape(RoundedRectangle(cornerRadius: 19))
                                    .padding(.bottom, 18)
                                    .accessibilityHidden(true)
                                    .transition(.opacity)
                            }
                            heading
                            if phase == 2 {
                                features
                                    .padding(.top, 42)
                                    .transition(.opacity.combined(with: .offset(y: 16)))
                            }
                        }
                        .frame(maxWidth: 450, alignment: .leading)
                        .padding(.horizontal, 30)
                        .padding(.top, phase == 1 ? max(40, geometry.size.height * 0.20) : 34)
                        .padding(.bottom, 28)
                        .frame(maxWidth: .infinity, alignment: .top)
                    }
                    .transition(.opacity)
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        if phase == 2 {
                            Button(action: onFinish) {
                                Text("Tiếp tục")
                                    .font(.headline.weight(.bold))
                                    .foregroundStyle(.white)
                                    .frame(maxWidth: .infinity, minHeight: 54)
                                    .background(Color(red: 0.43, green: 0.29, blue: 0.63), in: Capsule())
                            }
                            .buttonStyle(.plain)
                            .frame(maxWidth: 450)
                            .padding(.horizontal, 30)
                            .padding(.top, 14)
                            .padding(.bottom, 12)
                            .frame(maxWidth: .infinity)
                            .background(background)
                            .transition(.opacity)
                        }
                    }
                }
            }
        }
        .task {
            if reduceMotion {
                phase = 2
                return
            }
            do {
                try await Task.sleep(nanoseconds: 1_000_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.55)) { phase = 1 }
                try await Task.sleep(nanoseconds: 1_500_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.65)) { phase = 2 }
            } catch {
                // The view may disappear when a file is opened or the app exits.
            }
        }
    }

    private var heading: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Welcome to")
                .foregroundStyle(.primary)
            Text("1809")
                .foregroundStyle(accent)
        }
        .font(.system(size: headingSize, weight: .bold, design: .rounded))
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }

    private var features: some View {
        VStack(alignment: .leading, spacing: 28) {
            feature(icon: "square.and.arrow.down", color: .blue,
                    title: "Nhập hình nền",
                    detail: "Chọn gói .tendies hoặc .zip tương thích từ ứng dụng Tệp.")
            feature(icon: "iphone", color: accent,
                    title: "Kiểm tra thiết bị",
                    detail: "Xem trạng thái hỗ trợ và kết nối pairing nếu phiên bản iOS yêu cầu.")
            feature(icon: "sparkles", color: .mint,
                    title: "Cài và khám phá",
                    detail: "Làm theo hướng dẫn trong ứng dụng và kiểm tra hình nền trong Bộ sưu tập.")
        }
    }

    private func feature(icon: String, color: Color, title: String, detail: String) -> some View {
        HStack(alignment: .top, spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 27, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: 40, alignment: .center)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(detail)
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}
