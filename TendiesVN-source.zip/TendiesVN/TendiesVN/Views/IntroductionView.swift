import SwiftUI
import UIKit

/// First-run introduction; installation support still depends on the device and its setup.
struct IntroductionView: View {
    let onFinish: () -> Void

    @State private var phase = 0
    @State private var showWelcome = false
    @Namespace private var brandMotion
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme
    @ScaledMetric(relativeTo: .largeTitle) private var headingSize: CGFloat = 44
    @ScaledMetric(relativeTo: .largeTitle) private var markSize: CGFloat = 52

    private let accent = AppTheme.accentColor(hex: AppTheme.defaultAccentHex)
    private var background: Color { colorScheme == .dark ? .black : .white }
    private var skipMotion: Bool { reduceMotion || UIAccessibility.isVoiceOverRunning }

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                background.ignoresSafeArea()

                if phase == 0 {
                    Text("1809")
                        .font(.system(size: markSize, weight: .bold, design: .rounded))
                        .tracking(-1.5)
                        .foregroundStyle(.primary)
                        .matchedGeometryEffect(id: "brand", in: brandMotion)
                        .transition(.identity)
                        .accessibilityHidden(true)
                }

                if phase == 1 || phase == 2 {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 0) {
                            heading
                                // The mark stays at a fixed distance above the
                                // heading. Only the shared top position changes,
                                // so the two travel at exactly the same speed.
                                .overlay(alignment: .topLeading) {
                                    Image("AppMark")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 78, height: 78)
                                        .clipShape(RoundedRectangle(cornerRadius: 19))
                                        .offset(y: -96)
                                        .opacity(showWelcome && phase == 1 ? 1 : 0)
                                        .animation(skipMotion ? nil : .easeInOut(duration: 0.35), value: phase)
                                        .accessibilityHidden(true)
                                }
                            features
                                .padding(.top, 42)
                                .accessibilityHidden(phase != 2)
                        }
                        .frame(maxWidth: 450, alignment: .leading)
                        .padding(.horizontal, 30)
                        .padding(.top, phase == 1 ? max(40, geometry.size.height * 0.20) + 96 : 34)
                        .padding(.bottom, 28)
                        .frame(maxWidth: .infinity, alignment: .top)
                    }
                    .scrollDisabled(phase != 2)
                    .transition(.identity)
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        // Reserve the button's space throughout the transition;
                        // this avoids a sudden layout jump when it appears.
                        bottomButton("Tiếp tục") {
                            if skipMotion { phase = 3 }
                            else { withAnimation(.easeInOut(duration: 0.45)) { phase = 3 } }
                        }
                        .opacity(phase == 2 ? 1 : 0)
                        .offset(y: phase == 2 ? 0 : 12)
                        .animation(skipMotion ? nil : .easeOut(duration: 0.45).delay(0.8), value: phase)
                        .allowsHitTesting(phase == 2)
                        .accessibilityHidden(phase != 2)
                    }
                }

                if phase == 3 {
                    DeviceIntroductionView(onFinish: onFinish)
                        .transition(skipMotion ? .opacity : .opacity.combined(with: .offset(y: 25)))
                }
            }
        }
        .task {
            if skipMotion {
                showWelcome = true
                phase = 2
                return
            }
            do {
                try await Task.sleep(nanoseconds: 650_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.9)) { phase = 1 }
                try await Task.sleep(nanoseconds: 50_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.7)) { showWelcome = true }
                try await Task.sleep(nanoseconds: 1_650_000_000)
                try Task.checkCancellation()
                withAnimation(.easeInOut(duration: 0.85)) { phase = 2 }
            } catch {
                // The view may disappear when a file is opened or the app exits.
            }
        }
    }

    private var heading: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Welcome to")
                .foregroundStyle(.primary)
                .opacity(showWelcome ? 1 : 0)
                .offset(y: showWelcome ? 0 : 16)
            Text("1809")
                .foregroundStyle(accent)
                .matchedGeometryEffect(id: "brand", in: brandMotion)
        }
        .font(.system(size: headingSize, weight: .bold, design: .rounded))
        .fixedSize(horizontal: false, vertical: true)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isHeader)
    }

    private var features: some View {
        VStack(alignment: .leading, spacing: 28) {
            feature(icon: "square.and.arrow.down", color: accent,
                    title: "Nhập hình nền", index: 0,
                    detail: "Chọn gói .tendies hoặc .zip tương thích từ ứng dụng Tệp.")
            feature(icon: "iphone", color: accent,
                    title: "Kiểm tra thiết bị", index: 1,
                    detail: "Xem trạng thái hỗ trợ và kết nối pairing nếu phiên bản iOS yêu cầu.")
            feature(icon: "sparkles", color: accent,
                    title: "Cài và khám phá", index: 2,
                    detail: "Làm theo hướng dẫn trong ứng dụng và kiểm tra hình nền trong Bộ sưu tập.")
        }
    }

    private func feature(icon: String, color: Color, title: String, index: Int, detail: String) -> some View {
        HStack(alignment: .top, spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 27, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: 40, alignment: .center)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(detail)
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .opacity(phase == 2 ? 1 : 0)
        .offset(y: phase == 2 ? 0 : 20)
        .animation(skipMotion ? nil : .easeOut(duration: 0.6).delay(0.8 + 0.12 * Double(index)), value: phase)
    }

    private func bottomButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.headline.weight(.bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, minHeight: 54)
                .background(accent, in: Capsule())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: 450)
        .padding(.horizontal, 30)
        .padding(.top, 14)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(background)
    }
}

private struct DeviceIntroductionView: View {
    let onFinish: () -> Void
    @State private var showStatus = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorScheme) private var colorScheme

    private var background: Color { colorScheme == .dark ? .black : .white }
    private var capability: DeviceCapability { DeviceCompatibility.currentCapability }
    private var supported: Bool { capability == .localInstallation }
    private var statusColor: Color { capability.tone.color }
    private var accent: Color { AppTheme.accentColor(hex: AppTheme.defaultAccentHex) }

    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                VStack(spacing: 14) {
                    Image(systemName: "iphone")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundStyle(accent)
                        .frame(width: 72, height: 72)
                        .background(accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 22))
                        .accessibilityHidden(true)
                    Text("Thiết bị của bạn")
                        .font(.title.weight(.bold))
                        .multilineTextAlignment(.center)
                        .accessibilityAddTraits(.isHeader)
                }
                VStack(spacing: 12) {
                    HStack(alignment: .center, spacing: 14) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Phiên bản iOS")
                                .font(.caption.weight(.medium))
                                .foregroundStyle(.secondary)
                            Text(DeviceCompatibility.osVersionText)
                                .font(.headline)
                                .fixedSize(horizontal: false, vertical: true)
                            Text(capability.title)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(statusColor)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: capability.systemImage)
                            .font(.title2.weight(.semibold))
                            .foregroundStyle(statusColor)
                            .scaleEffect(showStatus ? 1 : 0.55)
                            .rotationEffect(.degrees(showStatus ? 0 : (supported ? -18 : 18)))
                            .opacity(showStatus ? 1 : 0)
                            .accessibilityHidden(true)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20))
                    .accessibilityElement(children: .combine)

                    HStack(spacing: 14) {
                        Image(systemName: "cpu")
                            .font(.title3.weight(.medium))
                            .foregroundStyle(accent)
                            .frame(width: 40, height: 40)
                            .background(accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                            .accessibilityHidden(true)
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Model phần cứng")
                                .font(.caption.weight(.medium))
                                .foregroundStyle(.secondary)
                            Text(DeviceCompatibility.hardwareModel)
                                .font(.headline.monospaced())
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20))
                    .accessibilityElement(children: .combine)
                }
            }
            .frame(maxWidth: 450)
            .padding(.horizontal, 30)
            .padding(.top, 60)
            .padding(.bottom, 28)
            .frame(maxWidth: .infinity)
        }
        .background(background.ignoresSafeArea())
        .safeAreaInset(edge: .bottom, spacing: 0) {
            Button(action: onFinish) {
                Text("Bắt đầu")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 54)
                    .background(AppTheme.accentColor(hex: AppTheme.defaultAccentHex), in: Capsule())
            }
            .buttonStyle(.plain)
            .frame(maxWidth: 450)
            .padding(.horizontal, 30)
            .padding(.top, 14)
            .padding(.bottom, 12)
            .frame(maxWidth: .infinity)
            .background(background)
        }
        .task {
            if reduceMotion || UIAccessibility.isVoiceOverRunning {
                showStatus = true
            } else {
                withAnimation(.spring(response: 0.55, dampingFraction: 0.7).delay(0.2)) {
                    showStatus = true
                }
            }
        }
    }

}
