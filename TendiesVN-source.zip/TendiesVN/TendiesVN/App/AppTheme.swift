import SwiftUI
import UIKit

enum AppAppearance: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
    var subtitle: String {
        switch self {
        case .system: return "Tự đổi theo cài đặt của iPhone"
        case .light: return "Nền sáng, nội dung rõ ràng"
        case .dark: return "Nền tối, dịu mắt hơn"
        }
    }
    var systemImage: String {
        switch self {
        case .system: return "circle.lefthalf.filled"
        case .light: return "sun.max.fill"
        case .dark: return "moon.stars.fill"
        }
    }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

struct AppAccentPreset: Identifiable {
    let title: String
    let hex: String
    var id: String { hex }
}

enum AppTheme {
    static let defaultAccentHex = "2673E8"
    static let presets = [
        AppAccentPreset(title: "Đại dương", hex: defaultAccentHex),
        AppAccentPreset(title: "Lá xanh", hex: "17845B"),
        AppAccentPreset(title: "Tím khói", hex: "8062CD"),
        AppAccentPreset(title: "Đỏ đào", hex: "C34865"),
        AppAccentPreset(title: "Hổ phách", hex: "A96B14")
    ]

    static func accentColor(hex: String) -> Color {
        let rgb = components(hex: hex)
        return Color(red: rgb.red, green: rgb.green, blue: rgb.blue)
    }

    static func foregroundColor(hex: String) -> Color {
        let rgb = components(hex: hex)
        return (0.2126 * rgb.red + 0.7152 * rgb.green + 0.0722 * rgb.blue) > 0.6 ? .black : .white
    }

    static func hex(from color: Color) -> String {
        let resolved = UIColor(color).resolvedColor(with: UITraitCollection(userInterfaceStyle: .light))
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        guard resolved.getRed(&red, green: &green, blue: &blue, alpha: &alpha) else {
            return defaultAccentHex
        }
        func byte(_ value: CGFloat) -> Int { Int((min(1, max(0, value)) * 255).rounded()) }
        return String(format: "%02X%02X%02X", byte(red), byte(green), byte(blue))
    }

    private static func components(hex: String) -> (red: Double, green: Double, blue: Double) {
        let value = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let rgb = value.count == 6 ? UInt32(value, radix: 16) : nil
        let resolved = rgb ?? UInt32(defaultAccentHex, radix: 16)!
        return (Double((resolved >> 16) & 0xFF) / 255,
                Double((resolved >> 8) & 0xFF) / 255,
                Double(resolved & 0xFF) / 255)
    }
}
