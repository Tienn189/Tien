import Foundation

/// Accept a UUID, an exact container-root path, or the read-only 3105 import log.
/// Only the UUID reaches the bridge; the bridge independently verifies identity.
enum PosterBoardUUIDInput {
    static func uuid(from input: String) -> String? {
        guard input.utf8.count <= 2 * 1024 * 1024 else { return nil }
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)
        if let uuid = strictUUID(trimmed) { return uuid }
        if let uuid = uuidFromRoot(trimmed) { return uuid }
        let marker = "filebrowser: import requested destination="
        for line in trimmed.split(whereSeparator: \.isNewline).reversed() {
            guard let range = line.range(of: marker) else { continue }
            let path = String(line[range.upperBound...])
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if let uuid = uuidFromRoot(path) { return uuid }
        }
        return nil
    }

    private static func uuidFromRoot(_ path: String) -> String? {
        for prefix in [
            "/private/var/mobile/Containers/Data/Application/",
            "/var/mobile/Containers/Data/Application/"
        ] where path.hasPrefix(prefix) {
            var component = String(path.dropFirst(prefix.count))
            if component.hasSuffix("/") { component.removeLast() }
            return strictUUID(component)
        }
        return nil
    }

    private static func strictUUID(_ string: String) -> String? {
        guard string.utf8.count == 36, let uuid = UUID(uuidString: string) else { return nil }
        return uuid.uuidString
    }
}
