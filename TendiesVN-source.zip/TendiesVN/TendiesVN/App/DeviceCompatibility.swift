import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// Numeric comparison avoids treating 18.7.10 as older than 18.7.9.
struct SystemVersion: Comparable, Equatable, CustomStringConvertible {
    let major: Int
    let minor: Int
    let patch: Int

    init(_ major: Int, _ minor: Int = 0, _ patch: Int = 0) {
        self.major = major
        self.minor = minor
        self.patch = patch
    }

    init(_ version: OperatingSystemVersion) {
        self.init(version.majorVersion, version.minorVersion, version.patchVersion)
    }

    /// Compare the OS version, never beta labels or kernel build suffixes.
    init?(versionString: String) {
        let prefix = versionString.trimmingCharacters(in: .whitespacesAndNewlines)
            .prefix { $0.isASCII && ($0.isNumber || $0 == ".") }
        let parts = prefix.split(separator: ".", omittingEmptySubsequences: false)
        guard (1...3).contains(parts.count),
              parts.allSatisfy({ !$0.isEmpty && $0.allSatisfy({ $0.isNumber }) }) else { return nil }
        let values = parts.compactMap { Int($0) }
        guard values.count == parts.count else { return nil }
        self.init(values[0], values.count > 1 ? values[1] : 0, values.count > 2 ? values[2] : 0)
    }

    static func < (lhs: Self, rhs: Self) -> Bool {
        if lhs.major != rhs.major { return lhs.major < rhs.major }
        if lhs.minor != rhs.minor { return lhs.minor < rhs.minor }
        return lhs.patch < rhs.patch
    }

    var description: String { "\(major).\(minor).\(patch)" }
}

enum DeviceCapability: Equatable {
    case localInstallation, libraryOnly, unsupported, simulator

    var title: String {
        switch self {
        case .localInstallation: return "Có bộ cài PosterBoard"
        case .libraryOnly: return "Chưa hỗ trợ cài trên iOS này"
        case .unsupported: return "Không hỗ trợ"
        case .simulator: return "Simulator · quản lý thư viện"
        }
    }
}

/// Build labels published by 3105, not proof of installation support in 1809.
struct IOS27BetaRelease: Identifiable {
    let developerBeta: Int
    let publicBeta: Int?
    let build: String

    var id: String { build }
    var title: String {
        let developer = "Developer Beta \(developerBeta)"
        return publicBeta.map { developer + " · Public Beta \($0)" } ?? developer
    }
}

enum DeviceCompatibility {
    // Attribution: 3105 SupportPolicy.swift, commit
    // a72617ed4c764a65d8aac1e91aca95231e72a2cb (GPL-3.0).
    static let referenceIOS27Betas = [
        IOS27BetaRelease(developerBeta: 1, publicBeta: nil, build: "24A5355q"),
        IOS27BetaRelease(developerBeta: 2, publicBeta: nil, build: "24A5370h"),
        IOS27BetaRelease(developerBeta: 3, publicBeta: 1, build: "24A5380h"),
        IOS27BetaRelease(developerBeta: 4, publicBeta: 2, build: "24A5390f")
    ]

    static func betaRelease(for build: String) -> IOS27BetaRelease? {
        referenceIOS27Betas.first { $0.build == build }
    }
    /// Describe the bundled backend, not device test results.
    static let supportedSystemDescriptions = [
        "iOS 26.0 – 26.6.1: có bộ cài PosterBoard cũ",
        "iOS 17 và 18: nhập/xuất gói, chưa có bộ cài",
        "iOS 26.6.2 trở lên: chưa có backend cài tương ứng",
        "iOS 27, gồm Developer Beta 1–4/Public Beta 1–2: có pairing, chưa có bộ cài"
    ]

    static let currentVersion: SystemVersion = {
        if let raw = systemValue("kern.osproductversion"), let version = SystemVersion(versionString: raw) {
            return version
        }
        return SystemVersion(ProcessInfo.processInfo.operatingSystemVersion)
    }()

    static let systemBuild: String? = systemValue("kern.osversion")

    private static func systemValue(_ name: String) -> String? {
        #if canImport(Darwin)
        var size = 0
        guard sysctlbyname(name, nil, &size, nil, 0) == 0, size > 0, size <= 256 else { return nil }
        var bytes = [CChar](repeating: 0, count: size)
        guard sysctlbyname(name, &bytes, &size, nil, 0) == 0 else { return nil }
        return String(cString: bytes)
        #else
        return nil
        #endif
    }

    static func isSupported(_ version: SystemVersion) -> Bool {
        version.major >= 17 && version.minor >= 0 && version.patch >= 0
    }

    static func needsPairing(_ version: SystemVersion) -> Bool {
        version.major >= 27
    }

    /// Match the native bridge's existing gate. Do not expand without a backend.
    static func hasLocalBackend(_ version: SystemVersion) -> Bool {
        guard version.minor >= 0, version.patch >= 0 else { return false }
        return version >= SystemVersion(26) && version <= SystemVersion(26, 6, 1)
    }

    static func capability(for version: SystemVersion, simulator: Bool = false) -> DeviceCapability {
        guard isSupported(version) else { return .unsupported }
        if simulator { return .simulator }
        return hasLocalBackend(version) ? .localInstallation : .libraryOnly
    }

    static var isSimulator: Bool {
        #if targetEnvironment(simulator)
        return true
        #else
        return false
        #endif
    }

    static var versionIsSupported: Bool { isSupported(currentVersion) }
    static var supported: Bool { installationSupported }
    static var directInstallationSupported: Bool { hasLocalBackend(currentVersion) && !isSimulator }
    static var installationSupported: Bool { directInstallationSupported }
    /// Pairing remains independent of the restored local installer.
    static var requiresPairing: Bool { needsPairing(currentVersion) }
    static var currentCapability: DeviceCapability { capability(for: currentVersion, simulator: isSimulator) }
    static var currentBetaRelease: IOS27BetaRelease? {
        guard currentVersion == SystemVersion(27), let systemBuild else { return nil }
        return betaRelease(for: systemBuild)
    }
    static var osVersionText: String {
        let version = "iOS \(currentVersion)"
        return currentBetaRelease.map { version + " · " + $0.title } ?? version
    }

    static var hardwareModel: String {
        var system = utsname()
        guard uname(&system) == 0 else { return "Không xác định" }
        let capacity = MemoryLayout.size(ofValue: system.machine)
        return withUnsafePointer(to: &system.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: capacity) {
                String(cString: $0)
            }
        }
    }

    static var appVersionText: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
    }

    static var buildNumber: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
    }

    static var explanation: String {
        guard versionIsSupported else {
            return "Ứng dụng yêu cầu iOS 17 trở lên."
        }
        if isSimulator {
            return "Simulator dùng quản lý thư viện và xuất gói. Cài hình nền và mở PosterBoard cần thiết bị thật."
        }
        if installationSupported {
            return "Có bộ cài PosterBoard cũ cho phiên bản này. App phải kiểm tra quyền ghi thực tế trước khi cài. Cài xong sẽ mở PosterBoard; mở đa nhiệm và vuốt đóng thẻ đó để làm mới Bộ sưu tập."
        }
        if requiresPairing {
            return "Có công cụ pairing qua LocalDevVPN nhưng chưa có backend cài hình nền cho iOS 27. Pairing thành công không đồng nghĩa với quyền ghi PosterBoard. Bạn vẫn có thể nhập và xuất gói."
        }
        return "Chưa có bộ cài PosterBoard cho phiên bản này. Mã cũ chỉ có backend cho iOS 26.0–26.6.1; bạn vẫn có thể nhập và xuất gói."
    }
}
