import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// Numeric comparison avoids treating 18.7.10 as older than 18.7.9.
struct SystemVersion: Comparable, Equatable, CustomStringConvertible {
    let major: Int
    let minor: Int
    let patch: Int

    init(_ major: Int, _ minor: Int = 0, _ patch: Int = 0) {
        self.major = major
        self.minor = minor
        self.patch = patch
    }

    init(_ version: OperatingSystemVersion) {
        self.init(version.majorVersion, version.minorVersion, version.patchVersion)
    }

    /// Compare the OS version, never beta labels or kernel build suffixes.
    init?(versionString: String) {
        let prefix = versionString.trimmingCharacters(in: .whitespacesAndNewlines)
            .prefix { $0.isASCII && ($0.isNumber || $0 == ".") }
        let parts = prefix.split(separator: ".", omittingEmptySubsequences: false)
        guard (1...3).contains(parts.count),
              parts.allSatisfy({ !$0.isEmpty && $0.allSatisfy({ $0.isNumber }) }) else { return nil }
        let values = parts.compactMap { Int($0) }
        guard values.count == parts.count else { return nil }
        self.init(values[0], values.count > 1 ? values[1] : 0, values.count > 2 ? values[2] : 0)
    }

    static func < (lhs: Self, rhs: Self) -> Bool {
        if lhs.major != rhs.major { return lhs.major < rhs.major }
        if lhs.minor != rhs.minor { return lhs.minor < rhs.minor }
        return lhs.patch < rhs.patch
    }

    var description: String { "\(major).\(minor).\(patch)" }
}

enum DeviceCapability: Equatable {
    case localInstallation, libraryOnly, unsupported, simulator

    var title: String {
        switch self {
        case .localInstallation: return "Được hỗ trợ"
        case .libraryOnly: return "Được hỗ trợ · chỉ thư viện"
        case .unsupported: return "Không hỗ trợ"
        case .simulator: return "Không hỗ trợ"
        }
    }
}

/// Build labels referenced by 3105/Placard, not device test results in 1809.
struct IOS27BetaRelease: Identifiable {
    let developerBeta: Int
    let publicBeta: Int?
    let build: String

    var id: String { build }
    var title: String {
        let developer = "Developer Beta \(developerBeta)"
        return publicBeta.map { developer + " · Public Beta \($0)" } ?? developer
    }
}

enum DeviceCompatibility {
    // Attribution: 3105 SupportPolicy.swift, commit
    // a72617ed4c764a65d8aac1e91aca95231e72a2cb (GPL-3.0).
    static let referenceIOS27Betas = [
        IOS27BetaRelease(developerBeta: 1, publicBeta: nil, build: "24A5355q"),
        IOS27BetaRelease(developerBeta: 2, publicBeta: nil, build: "24A5370h"),
        IOS27BetaRelease(developerBeta: 3, publicBeta: 1, build: "24A5380h"),
        IOS27BetaRelease(developerBeta: 3, publicBeta: nil, build: "24A5380l"),
        IOS27BetaRelease(developerBeta: 4, publicBeta: 2, build: "24A5390f")
    ]

    static func betaRelease(for build: String) -> IOS27BetaRelease? {
        referenceIOS27Betas.first { $0.build == build }
    }
    /// Describe the bundled backend, not device test results.
    static let supportedSystemDescriptions = [
        "iOS 26.0 – 26.6.1: có bộ cài BadQuery",
        "iOS 17.0 – 18.x: cài qua backend Pocket-Poster khi đã nhập App Hash/UUID",
        "iOS 27.0 – 27.0.1: Airlift với pairing; 27.0 beta allowlist vẫn dùng BadQuery",
        "iOS 27.0 Developer Beta 1–4/Public Beta 1–2: BadQuery theo đúng build được liệt kê"
    ]

    static let currentVersion: SystemVersion = {
        if let raw = systemValue("kern.osproductversion"), let version = SystemVersion(versionString: raw) {
            return version
        }
        return SystemVersion(ProcessInfo.processInfo.operatingSystemVersion)
    }()

    static let systemBuild: String? = systemValue("kern.osversion")

    private static func systemValue(_ name: String) -> String? {
        #if canImport(Darwin)
        var size = 0
        guard sysctlbyname(name, nil, &size, nil, 0) == 0, size > 0, size <= 256 else { return nil }
        var bytes = [CChar](repeating: 0, count: size)
        guard sysctlbyname(name, &bytes, &size, nil, 0) == 0 else { return nil }
        return String(cString: bytes)
        #else
        return nil
        #endif
    }

    static func isSupported(_ version: SystemVersion) -> Bool {
        version.major >= 17 && version.minor >= 0 && version.patch >= 0
    }

    static func needsPairing(_ version: SystemVersion) -> Bool {
        version.major >= 27
    }

    /// Pocket-Poster uses the generation-61 descriptor store on iOS 17–18.
    /// It needs a PosterBoard container UUID supplied by Nugget or pasted by
    /// the user; the version range alone does not grant write access.
    static func supportsPocketPoster(_ version: SystemVersion) -> Bool {
        version >= SystemVersion(17) && version < SystemVersion(19)
    }

    /// AirCard's Airlift route supports stable 27.0 and 27.0.1 through an
    /// imported pairing record. The actual writer is selected separately.
    static func hasAirliftBackend(_ version: SystemVersion) -> Bool {
        version.major == 27 && version.minor == 0 && (0...1).contains(version.patch)
    }

    /// Shared with the native bridge, including the exact 27.0 build allowlist.
    static func hasLocalBackend(_ version: SystemVersion, build: String? = nil) -> Bool {
        guard let major = Int32(exactly: version.major),
              let minor = Int32(exactly: version.minor),
              let patch = Int32(exactly: version.patch) else { return false }
        if let build {
            guard !build.utf8.contains(0) else { return false }
            return build.withCString { tendies_posterboard_backend_supports(major, minor, patch, $0) }
        }
        return tendies_posterboard_backend_supports(major, minor, patch, nil)
    }

    static func capability(for version: SystemVersion, build: String? = nil, simulator: Bool = false) -> DeviceCapability {
        guard isSupported(version) else { return .unsupported }
        if simulator { return .simulator }
        return hasLocalBackend(version, build: build) || hasAirliftBackend(version)
            ? .localInstallation : .libraryOnly
    }

    static func capability(
        for version: SystemVersion,
        build: String? = nil,
        simulator: Bool = false,
        pocketPosterConfigured: Bool
    ) -> DeviceCapability {
        guard isSupported(version) else { return .unsupported }
        if simulator { return .simulator }
        if hasLocalBackend(version, build: build) || hasAirliftBackend(version) {
            return .localInstallation
        }
        return supportsPocketPoster(version) && pocketPosterConfigured
            ? .localInstallation : .libraryOnly
    }

    static var isSimulator: Bool {
        #if targetEnvironment(simulator)
        return true
        #else
        return false
        #endif
    }

    static var versionIsSupported: Bool { isSupported(currentVersion) }
    static var supported: Bool { installationSupported }
    static var directInstallationSupported: Bool { hasLocalBackend(currentVersion, build: systemBuild) && !isSimulator }
    static var hasConfiguredPocketPosterHash: Bool {
        let raw = UserDefaults.standard.string(forKey: "1809.pocketPoster.appHash") ?? ""
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.utf8.count == 36 && UUID(uuidString: trimmed) != nil
    }
    static var pocketPosterInstallationSupported: Bool {
        supportsPocketPoster(currentVersion)
            && hasConfiguredPocketPosterHash
            && !isSimulator
            && !directInstallationSupported
    }
    static var installationSupported: Bool {
        directInstallationSupported
            || (hasAirliftBackend(currentVersion) && !isSimulator)
            || pocketPosterInstallationSupported
    }
    /// Backend availability and current readiness are separate. Airlift needs
    /// a pairing record that has actually completed verification before a
    /// blocking FFI container lookup is allowed to start.
    static var installationReady: Bool {
        if directInstallationSupported || pocketPosterInstallationSupported {
            return true
        }
        if hasAirliftBackend(currentVersion) && !isSimulator {
            return UserDefaults.standard.bool(forKey: "1809.pairing.verified")
        }
        return false
    }
    /// Pairing remains independent of the restored local installer.
    static var requiresPairing: Bool { needsPairing(currentVersion) }
    static var currentCapability: DeviceCapability {
        capability(
            for: currentVersion,
            build: systemBuild,
            simulator: isSimulator,
            pocketPosterConfigured: hasConfiguredPocketPosterHash
        )
    }
    static var currentBetaRelease: IOS27BetaRelease? {
        guard currentVersion == SystemVersion(27), let systemBuild else { return nil }
        return betaRelease(for: systemBuild)
    }
    static var osVersionText: String {
        let version = "iOS \(currentVersion)"
        return currentBetaRelease.map { version + " · " + $0.title } ?? version
    }

    static var hardwareModel: String {
        var system = utsname()
        guard uname(&system) == 0 else { return "Không xác định" }
        let capacity = MemoryLayout.size(ofValue: system.machine)
        return withUnsafePointer(to: &system.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: capacity) {
                String(cString: $0)
            }
        }
    }

    static var appVersionText: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
    }

    static var buildNumber: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
    }

    static var explanation: String {
        guard versionIsSupported else {
            return "Ứng dụng yêu cầu iOS 17 trở lên."
        }
        if isSimulator {
            return "Simulator dùng quản lý thư viện và xuất gói. Cài hình nền và mở PosterBoard cần thiết bị thật."
        }
        if hasAirliftBackend(currentVersion) && !directInstallationSupported {
            if installationReady {
                return "iOS 27.0–27.0.1 dùng backend Airlift với pairing đã xác thực. Cài xong sẽ mở PosterBoard để làm mới Bộ sưu tập."
            }
            return "iOS 27.0–27.0.1 được hỗ trợ bằng Airlift nhưng cần nhập và xác thực pairing trong tab Pairing trước khi cài."
        }
        if supportsPocketPoster(currentVersion) && !directInstallationSupported {
            if hasConfiguredPocketPosterHash {
                return "iOS 17–18 dùng backend Pocket-Poster với App Hash/UUID đã nhập. Cài xong sẽ mở PosterBoard; hãy đóng thẻ PosterBoard trong đa nhiệm để làm mới Bộ sưu tập."
            }
            return "iOS 17–18 cần App Hash/UUID của container PosterBoard để cài wallpaper. Lấy mã bằng Nugget trên máy tính rồi nhập trong Cài đặt → Cài wallpaper iOS 17–18."
        }
        if installationSupported {
            return "Có bộ cài BadQuery cho phiên bản/build này. App kiểm tra quyền ghi thực tế trước khi cài. Cài xong sẽ mở PosterBoard; mở đa nhiệm và vuốt đóng thẻ đó để làm mới Bộ sưu tập."
        }
        if requiresPairing {
            return "Build iOS 27 này chưa có trong phạm vi BadQuery đã đối chiếu. Chỉ hỗ trợ các build beta cụ thể trong Cài đặt, không phải mọi bản 27.0/27.0.1. Pairing thành công không tự cấp quyền ghi PosterBoard."
        }
        return "Chưa có bộ cài PosterBoard cho phiên bản này. Bạn vẫn có thể nhập và xuất gói."
    }
}
