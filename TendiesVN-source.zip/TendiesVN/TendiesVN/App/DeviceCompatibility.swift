import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// Numeric comparison avoids treating 18.7.10 as older than 18.7.9.
struct SystemVersion: Comparable, Equatable, CustomStringConvertible {
    let major: Int
    let minor: Int
    let patch: Int

    init(_ major: Int, _ minor: Int = 0, _ patch: Int = 0) {
        self.major = major
        self.minor = minor
        self.patch = patch
    }

    init(_ version: OperatingSystemVersion) {
        self.init(version.majorVersion, version.minorVersion, version.patchVersion)
    }

    static func < (lhs: Self, rhs: Self) -> Bool {
        if lhs.major != rhs.major { return lhs.major < rhs.major }
        if lhs.minor != rhs.minor { return lhs.minor < rhs.minor }
        return lhs.patch < rhs.patch
    }

    var description: String { "\(major).\(minor).\(patch)" }
}

struct SupportedSystemRange: Identifiable {
    let minimum: SystemVersion
    let maximum: SystemVersion
    let title: String

    var id: Int { minimum.major }

    func contains(_ version: SystemVersion) -> Bool {
        version >= minimum && version <= maximum
    }
}

enum DeviceCompatibility {
    /// Product support policy requested for 1809. This is separate from whether
    /// a working device-access transport is included in this source release.
    static let supportedRanges = [
        SupportedSystemRange(minimum: SystemVersion(17), maximum: SystemVersion(17, 7), title: "iOS 17.0 – 17.7"),
        SupportedSystemRange(minimum: SystemVersion(18), maximum: SystemVersion(18, 7, 10), title: "iOS 18.0 – 18.7.10"),
        SupportedSystemRange(minimum: SystemVersion(26), maximum: SystemVersion(26, 7), title: "iOS 26.0 – 26.7.0"),
        SupportedSystemRange(minimum: SystemVersion(27), maximum: SystemVersion(27, 0, 1), title: "iOS 27.0 – 27.0.1")
    ]

    static var currentVersion: SystemVersion {
        SystemVersion(ProcessInfo.processInfo.operatingSystemVersion)
    }

    static func isSupported(_ version: SystemVersion) -> Bool {
        guard version.major >= 0, version.minor >= 0, version.patch >= 0 else { return false }
        return supportedRanges.contains { $0.contains(version) }
    }

    static func needsPairing(_ version: SystemVersion) -> Bool {
        version.major >= 27
    }

    /// The bundled bad_query implementation has a narrower verified range.
    /// Do not widen this predicate without adding and validating a transport.
    static func hasLocalBackend(_ version: SystemVersion) -> Bool {
        guard version.major >= 0, version.minor >= 0, version.patch >= 0 else { return false }
        return version >= SystemVersion(26) && version <= SystemVersion(26, 6, 1)
    }

    static var isSimulator: Bool {
        #if targetEnvironment(simulator)
        return true
        #else
        return false
        #endif
    }

    static var versionIsSupported: Bool { isSupported(currentVersion) }
    static var supported: Bool { versionIsSupported && !isSimulator }
    static var installationSupported: Bool { hasLocalBackend(currentVersion) && !isSimulator }
    static var requiresPairing: Bool { needsPairing(currentVersion) }
    static var osVersionText: String { "iOS \(currentVersion)" }

    static var hardwareModel: String {
        var system = utsname()
        guard uname(&system) == 0 else { return "Không xác định" }
        let capacity = MemoryLayout.size(ofValue: system.machine)
        return withUnsafePointer(to: &system.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: capacity) {
                String(cString: $0)
            }
        }
    }

    static var appVersionText: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
    }

    static var buildNumber: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
    }

    static var explanation: String {
        if isSimulator {
            return "Simulator chỉ dùng để xem giao diện và nhập gói. Cài hình nền cần thiết bị thật."
        }
        guard versionIsSupported else {
            return "Phiên bản iOS này không nằm trong danh sách hỗ trợ của 1809. Bạn vẫn có thể nhập và kiểm tra gói."
        }
        if installationSupported {
            return "1809 hỗ trợ cài hình nền trên phiên bản này. Cần kiểm tra quyền truy cập trên thiết bị trước khi cài."
        }
        if requiresPairing {
            return "iOS 27 yêu cầu pairing. 1809 hiện cho phép lưu hồ sơ ghép đôi; kết nối để cài hình nền trên phiên bản này chưa sẵn sàng."
        }
        return "1809 chưa hỗ trợ cài hình nền trên phiên bản này. Bạn vẫn có thể nhập, xem thông tin và xuất gói."
    }
}
