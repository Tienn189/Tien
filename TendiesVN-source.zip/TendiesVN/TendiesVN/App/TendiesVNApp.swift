import SwiftUI

@main
struct TendiesVNApp: App {
    @StateObject private var model = WallpaperModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .environment(\.locale, Locale(identifier: "vi"))
                .onOpenURL { model.importFile($0) }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active { model.sceneBecameActive() }
                }
        }
    }
}
