import SwiftUI

@main
struct TendiesVNApp: App {
    @StateObject private var model = WallpaperModel()
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @AppStorage("1809.hasSeenHardwareIntroduction") private var hasSeenIntroduction = false
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some Scene {
        WindowGroup {
            ZStack {
                if hasSeenIntroduction {
                    ContentView()
                        .transition(reduceMotion ? .identity : .opacity.combined(with: .offset(y: 12)))
                        .zIndex(1)
                } else {
                    IntroductionView {
                        if reduceMotion {
                            hasSeenIntroduction = true
                        } else {
                            withAnimation(.easeOut(duration: 0.45)) {
                                hasSeenIntroduction = true
                            }
                        }
                    }
                    .transition(reduceMotion ? .identity : .opacity)
                    .zIndex(0)
                }
            }
                .preferredColorScheme((AppAppearance(rawValue: appearance) ?? .system).colorScheme)
                .tint(AppTheme.accentColor(hex: accentHex))
                .accentColor(AppTheme.accentColor(hex: accentHex))
                .environmentObject(model)
                .environment(\.locale, Locale(identifier: "vi"))
                .onOpenURL { url in
                    hasSeenIntroduction = true
                    if PairingFileType.supports(url) {
                        model.selectedTab = 3
                        Task { await PairingStore.shared.importRecord(from: url) }
                    } else {
                        model.importFile(url)
                    }
                }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active {
                        Task { await PairingStore.shared.refreshAndVerify() }
                        model.sceneBecameActive()
                    } else if phase == .background {
                        PairingStore.shared.invalidateConnection()
                    }
                }
        }
    }
}
