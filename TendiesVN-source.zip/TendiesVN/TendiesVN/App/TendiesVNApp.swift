import SwiftUI
import UIKit

@main
struct TendiesVNApp: App {
    @StateObject private var model = WallpaperModel()
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue
    @AppStorage("1809.accentHex") private var accentHex = AppTheme.defaultAccentHex
    @AppStorage("1809.hasSeenRefinedIntroduction") private var hasSeenIntroduction = false
    // Animate a direct SwiftUI state change; UserDefaults notifications can
    // otherwise update @AppStorage outside the animation transaction.
    @State private var showMainContent = UserDefaults.standard.bool(forKey: "1809.hasSeenRefinedIntroduction")
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some Scene {
        WindowGroup {
            ZStack {
                if showMainContent {
                    ContentView()
                        .transition(reduceMotion ? .identity : .opacity.combined(with: .offset(y: 12)))
                        .zIndex(1)
                } else {
                    IntroductionView {
                        if reduceMotion || UIAccessibility.isVoiceOverRunning {
                            showMainContent = true
                        } else {
                            withAnimation(.easeInOut(duration: 0.65)) {
                                showMainContent = true
                            }
                        }
                        hasSeenIntroduction = true
                    }
                    .transition(reduceMotion ? .identity : .opacity)
                    .zIndex(0)
                }
            }
                .preferredColorScheme((AppAppearance(rawValue: appearance) ?? .system).colorScheme)
                .tint(AppTheme.accentColor(hex: accentHex))
                .accentColor(AppTheme.accentColor(hex: accentHex))
                .environmentObject(model)
                .environment(\.locale, Locale(identifier: "vi"))
                .onOpenURL { url in
                    hasSeenIntroduction = true
                    showMainContent = true
                    if PairingFileType.supports(url) {
                        model.selectedTab = 3
                        Task { await PairingStore.shared.importRecord(from: url) }
                    } else {
                        model.importFile(url)
                    }
                }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active {
                        Task { await PairingStore.shared.refreshAndVerify() }
                        model.sceneBecameActive()
                    } else if phase == .background {
                        PairingStore.shared.invalidateConnection()
                    }
                }
        }
    }
}
