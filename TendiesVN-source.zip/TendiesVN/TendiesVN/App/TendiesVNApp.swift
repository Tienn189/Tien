import SwiftUI

@main
struct TendiesVNApp: App {
    @StateObject private var model = WallpaperModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(model)
                .environment(\.locale, Locale(identifier: "vi"))
                .onOpenURL { model.importFile($0) }
        }
    }
}
