import SwiftUI

@main
struct TendiesVNApp: App {
    @StateObject private var model = WallpaperModel()
    @AppStorage("1809.appearance") private var appearance = AppAppearance.system.rawValue
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme((AppAppearance(rawValue: appearance) ?? .system).colorScheme)
                .environmentObject(model)
                .environment(\.locale, Locale(identifier: "vi"))
                .onOpenURL { url in
                    if PairingFileType.supports(url) {
                        model.selectedTab = 3
                        Task { await PairingStore.shared.importRecord(from: url) }
                    } else {
                        model.importFile(url)
                    }
                }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active {
                        model.sceneBecameActive()
                        PairingStore.shared.refreshNetwork()
                    } else if phase == .background {
                        PairingStore.shared.invalidateConnection()
                    }
                }
        }
    }
}
