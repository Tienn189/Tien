import SwiftUI
import UIKit
import UniformTypeIdentifiers

extension UTType {
    static let tendiesPackage = UTType(importedAs: "vn.tendies.wallpaper", conformingTo: .zip)
}

struct AppMessage: Identifiable {
    let id = UUID()
    let title: String
    let text: String
}

enum DeviceCompatibility {
    static var supported: Bool {
        #if targetEnvironment(simulator)
        return false
        #else
        let version = ProcessInfo.processInfo.operatingSystemVersion
        return version.majorVersion == 26 &&
            (version.minorVersion < 6 || (version.minorVersion == 6 && version.patchVersion <= 1))
        #endif
    }

    static var explanation: String {
        #if targetEnvironment(simulator)
        return "Simulator chỉ dùng để xem giao diện và nhập gói. Cài hình nền cần thiết bị thật."
        #else
        return supported
            ? "Phiên bản nằm trong phạm vi 26.0–26.6.1 được backend hỗ trợ. Cần kiểm tra quyền cài trên máy."
            : "Cơ chế cài của bản này chỉ dành cho iOS/iPadOS 26.0–26.6.1. Bạn vẫn có thể nhập và kiểm tra gói."
        #endif
    }
}

// All file I/O and system operations share one serial executor, away from the UI.
private actor WallpaperWorker {
    func library() -> [WallpaperStagedPackage] { WallpaperPackageStore.packages() }
    func receipts() -> [WallpaperInstallReceipt] { WallpaperDeviceAccessService.receipts() }
    func importFile(_ url: URL) throws -> WallpaperStagedPackage {
        try WallpaperPackageStore.importPackage(from: url)
    }
    func delete(_ package: WallpaperStagedPackage) throws {
        try WallpaperPackageStore.delete(package)
    }
    func probe() throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.report()
    }
    func install(_ package: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.install(package).1
    }
    func restore(_ receipt: WallpaperInstallReceipt) throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.restore(receipt: receipt)
    }
}

@MainActor
final class WallpaperModel: ObservableObject {
    @Published private(set) var packages: [WallpaperStagedPackage] = []
    @Published private(set) var receipts: [WallpaperInstallReceipt] = []
    @Published private(set) var report: WallpaperAccessReport?
    @Published private(set) var busy: String?
    @Published var message: AppMessage?
    @Published var selectedPackage: WallpaperStagedPackage?
    @Published var selectedTab = 0

    private let worker = WallpaperWorker()
    private var messageAfterDismiss: AppMessage?

    var isBusy: Bool { busy != nil }
    var activeReceipts: [WallpaperInstallReceipt] {
        receipts.filter { $0.status == .installed || $0.status == .preparing }
    }

    func load() async {
        guard !isBusy else { return }
        packages = await worker.library()
        receipts = await worker.receipts()
    }

    func importFile(_ url: URL) {
        perform("Đang kiểm tra gói…") { [self] in
            let package = try await worker.importFile(url)
            packages = await worker.library()
            selectedTab = 0
            selectedPackage = package
        }
    }

    func checkAccess() {
        guard requireSupportedDevice() else { return }
        perform("Đang kiểm tra quyền cài…") { [self] in
            report = try await worker.probe()
            if report?.canInstall == false {
                message = AppMessage(title: "Chưa thể cài", text: "Chưa có quyền ghi vào Bộ sưu tập. Hãy tạo và dùng sẵn một hình nền Bộ sưu tập của Apple, rồi kiểm tra quyền cài lại. Xem tab Hướng dẫn nếu lỗi vẫn xuất hiện.")
            }
        }
    }

    func install(_ package: WallpaperStagedPackage) {
        guard requireSupportedDevice() else { return }
        perform("Đang cài hình nền…") { [self] in
            report = try await worker.install(package)
            receipts = await worker.receipts()
            messageAfterDismiss = AppMessage(title: "Đã thêm vào PosterBoard", text: "Khởi động lại thiết bị, sau đó vào Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập để chọn hình nền vừa thêm. App không tự đổi hình nền đang dùng.")
            selectedPackage = nil
        }
    }

    func delete(_ package: WallpaperStagedPackage) {
        perform("Đang xoá gói đã nhập…") { [self] in
            try await worker.delete(package)
            packages = await worker.library()
            selectedPackage = nil
        }
    }

    func restore(_ receipt: WallpaperInstallReceipt) {
        guard requireSupportedDevice() else { return }
        perform("Đang gỡ hình nền…") { [self] in
            report = try await worker.restore(receipt)
            receipts = await worker.receipts()
            message = AppMessage(title: "Đã gỡ", text: "Hình nền thuộc lần cài này đã được gỡ. Hãy khởi động lại thiết bị để cập nhật Bộ sưu tập.")
        }
    }

    func sheetDismissed() {
        if let next = messageAfterDismiss {
            messageAfterDismiss = nil
            message = next
        }
    }

    private func requireSupportedDevice() -> Bool {
        guard DeviceCompatibility.supported else {
            message = AppMessage(title: "Chưa hỗ trợ cài trên thiết bị này", text: DeviceCompatibility.explanation)
            return false
        }
        return true
    }

    private func perform(_ label: String, operation: @escaping @MainActor () async throws -> Void) {
        guard !isBusy else { return }
        busy = label
        Task {
            defer { busy = nil }
            do {
                try await operation()
            } catch {
                // A failed write can leave a recovery receipt; always reload it.
                receipts = await worker.receipts()
                message = AppMessage(title: "Không hoàn tất được", text: error.localizedDescription)
            }
        }
    }
}
