import SwiftUI
import UniformTypeIdentifiers

extension UTType {
    static let tendiesPackage = UTType(importedAs: "vn.tendies.wallpaper", conformingTo: .zip)
}

struct AppMessage: Identifiable {
    let id = UUID()
    let title: String
    let text: String
}

struct WallpaperShareItem: Identifiable {
    let id = UUID()
    let fileURL: URL
}

private struct WallpaperSelectionError: LocalizedError {
    var errorDescription: String? {
        "Tệp đã thay đổi hoặc không còn trong gói. Mở lại gói rồi chọn ảnh hoặc video một lần nữa."
    }
}

/// Serializes sandbox file operations. No system wallpaper containers are accessed.
private actor WallpaperWorker {
    func library() -> [WallpaperStagedPackage] { WallpaperPackageStore.packages() }
    func history() throws -> [WallpaperSaveReceipt] { try WallpaperSaveHistory.receipts() }
    func importFile(_ url: URL) throws -> WallpaperStagedPackage {
        try WallpaperPackageStore.importPackage(from: url)
    }
    func delete(_ package: WallpaperStagedPackage) throws {
        try WallpaperPackageStore.delete(package)
    }
    func assets(for package: WallpaperStagedPackage) throws -> [WallpaperAsset] {
        try WallpaperAssetCatalog.assets(in: package)
    }
    func validatedAsset(_ asset: WallpaperAsset, from package: WallpaperStagedPackage) throws -> WallpaperAsset {
        guard let current = try assets(for: package).first(where: { $0.id == asset.id }),
              current.fileURL.standardizedFileURL == asset.fileURL.standardizedFileURL,
              current.kind == asset.kind else { throw WallpaperSelectionError() }
        return current
    }
    func save(_ asset: WallpaperAsset, from package: WallpaperStagedPackage) async throws -> WallpaperSaveReceipt {
        let current = try validatedAsset(asset, from: package)
        return try await WallpaperPhotoLibrary.save(current, packageID: package.id, packageName: package.displayName)
    }
    func record(_ receipt: WallpaperSaveReceipt) throws { try WallpaperSaveHistory.record(receipt) }
    func remove(_ receipt: WallpaperSaveReceipt) throws { try WallpaperSaveHistory.remove(receipt) }
    func share(_ asset: WallpaperAsset, from package: WallpaperStagedPackage) throws -> URL {
        try WallpaperPhotoLibrary.shareCopy(validatedAsset(asset, from: package))
    }
    func removeShare(_ url: URL) throws { try WallpaperPhotoLibrary.removeShareCopy(url) }
}

@MainActor
final class WallpaperModel: ObservableObject {
    @Published private(set) var packages: [WallpaperStagedPackage] = []
    @Published private(set) var exportHistory: [WallpaperSaveReceipt] = []
    @Published private(set) var assets: [WallpaperAsset] = []
    @Published private(set) var isLoadingAssets = false
    @Published private(set) var assetsError: String?
    @Published private(set) var operationStatus: WallpaperOperationStatus?
    @Published private(set) var successNotice: WallpaperOperationStatus?
    @Published private(set) var busy: String?
    @Published var message: AppMessage?
    @Published var selectedPackage: WallpaperStagedPackage?
    @Published var selectedTab = 0
    @Published var sharing: WallpaperShareItem?

    private let worker = WallpaperWorker()
    private var assetsRequest = UUID()
    private var sharedFileURL: URL?

    var isBusy: Bool { busy != nil }

    func load() async {
        guard !isBusy else { return }
        packages = await worker.library()
        do { exportHistory = try await worker.history() }
        catch {
            message = AppMessage(title: "Không đọc được lịch sử lưu", text: error.localizedDescription)
        }
    }

    func importFile(_ url: URL) {
        Task {
            await perform("Đang nhập gói", detail: "Kiểm tra tệp và giải nén vào thư viện của ứng dụng.") { [self] in
                let package = try await worker.importFile(url)
                packages = await worker.library()
                selectedTab = 0
                selectedPackage = package
            }
        }
    }

    func loadAssets(for package: WallpaperStagedPackage) async {
        let request = UUID()
        assetsRequest = request
        assets = []
        assetsError = nil
        isLoadingAssets = true
        do {
            let found = try await worker.assets(for: package)
            guard request == assetsRequest else { return }
            isLoadingAssets = false
            guard !Task.isCancelled else { return }
            assets = found
        } catch {
            guard request == assetsRequest else { return }
            isLoadingAssets = false
            guard !Task.isCancelled else { return }
            assetsError = error.localizedDescription
        }
    }

    func saveToPhotos(_ asset: WallpaperAsset, from package: WallpaperStagedPackage) async {
        guard DeviceCompatibility.mediaSavingSupported else {
            fail(title: "Chưa thể lưu trên thiết bị này", detail: DeviceCompatibility.explanation)
            return
        }
        await perform("Đang lưu vào Ảnh", detail: "iOS chỉ thêm tệp bạn chọn; ứng dụng không đọc thư viện Ảnh.") { [self] in
            let receipt = try await worker.save(asset, from: package)
            var historyWarning = ""
            do {
                try await worker.record(receipt)
                exportHistory = try await worker.history()
            } catch {
                // Photos already committed successfully. Do not imply that a
                // failed local history write means the photo must be saved again.
                exportHistory.insert(receipt, at: 0)
                historyWarning = " Lịch sử chưa lưu được bền vững trong ứng dụng: " + error.localizedDescription
            }
            let instructions = asset.kind == .image
                ? "Mở Cài đặt → Hình nền → Thêm hình nền mới → Ảnh để tự đặt hình nền."
                : "Video được lưu như video thông thường, không tự chuyển thành Live Photo hoặc đặt làm hình nền."
            successNotice = WallpaperOperationStatus(kind: .success, title: "Đã lưu vào Ảnh", detail: instructions + historyWarning)
        }
    }

    func prepareShare(_ asset: WallpaperAsset, from package: WallpaperStagedPackage) async {
        await perform("Đang chuẩn bị tệp", detail: "Tạo bản sao để bạn chọn Lưu vào Tệp hoặc chia sẻ.") { [self] in
            let copy = try await worker.share(asset, from: package)
            if let previous = sharedFileURL { try? await worker.removeShare(previous) }
            sharedFileURL = copy
            sharing = WallpaperShareItem(fileURL: copy)
        }
    }

    func sharingFinished() {
        sharing = nil
        guard let copy = sharedFileURL else { return }
        sharedFileURL = nil
        Task { try? await worker.removeShare(copy) }
    }

    func delete(_ package: WallpaperStagedPackage) {
        Task {
            await perform("Đang xoá gói", detail: "Chỉ xoá bản nhập trong ứng dụng; ảnh đã lưu vẫn ở trong Ảnh.") { [self] in
                try await worker.delete(package)
                packages = await worker.library()
                assetsRequest = UUID()
                assets = []
                isLoadingAssets = false
                selectedPackage = nil
            }
        }
    }

    func removeSaveReceipt(_ receipt: WallpaperSaveReceipt) async {
        await perform("Đang xoá bản ghi", detail: "Chỉ xoá lịch sử trong 1809, không xoá ảnh hoặc video trong Ảnh.") { [self] in
            try await worker.remove(receipt)
            exportHistory = try await worker.history()
        }
    }

    func dismissSuccessNotice() { successNotice = nil }

    private func fail(title: String, detail: String) {
        successNotice = WallpaperOperationStatus(kind: .failure, title: title, detail: detail)
        message = AppMessage(title: title, text: detail)
    }

    private func perform(
        _ title: String,
        detail: String,
        operation: @escaping @MainActor () async throws -> Void
    ) async {
        guard !isBusy else { return }
        busy = title
        message = nil
        successNotice = nil
        operationStatus = WallpaperOperationStatus(kind: .working, title: title, detail: detail)
        defer {
            busy = nil
            operationStatus = nil
        }
        do { try await operation() }
        catch is CancellationError { }
        catch { fail(title: "Không hoàn tất được", detail: error.localizedDescription) }
    }
}
