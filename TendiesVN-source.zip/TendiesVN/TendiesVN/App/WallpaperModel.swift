import SwiftUI
import UIKit
import UniformTypeIdentifiers

extension UTType {
    static let tendiesPackage = UTType(importedAs: "vn.tendies.wallpaper", conformingTo: .zip)
}

struct AppMessage: Identifiable {
    let id = UUID()
    let title: String
    let text: String
}

enum DeviceCompatibility {
    static var supported: Bool {
        #if targetEnvironment(simulator)
        return false
        #else
        let version = ProcessInfo.processInfo.operatingSystemVersion
        return version.majorVersion == 26 &&
            (version.minorVersion < 6 || (version.minorVersion == 6 && version.patchVersion <= 1))
        #endif
    }

    static var explanation: String {
        #if targetEnvironment(simulator)
        return "Simulator chỉ dùng để xem giao diện và nhập gói. Cài hình nền cần thiết bị thật."
        #else
        return supported
            ? "Phiên bản nằm trong phạm vi 26.0–26.6.1 được backend hỗ trợ. Cần kiểm tra quyền cài trên máy."
            : "Cơ chế cài của bản này chỉ dành cho iOS/iPadOS 26.0–26.6.1. Bạn vẫn có thể nhập và kiểm tra gói."
        #endif
    }
}

// All file I/O and system operations share one serial executor, away from the UI.
private actor WallpaperWorker {
    func library() -> [WallpaperStagedPackage] { WallpaperPackageStore.packages() }
    func receipts() -> [WallpaperInstallReceipt] { WallpaperDeviceAccessService.receipts() }
    func importFile(_ url: URL) throws -> WallpaperStagedPackage {
        try WallpaperPackageStore.importPackage(from: url)
    }
    func delete(_ package: WallpaperStagedPackage) throws {
        try WallpaperPackageStore.delete(package)
    }
    func probe() throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.report()
    }
    func install(_ package: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.install(package).1
    }
    func restore(_ receipt: WallpaperInstallReceipt) throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.restore(receipt: receipt)
    }
}

@MainActor
final class WallpaperModel: ObservableObject {
    @Published private(set) var packages: [WallpaperStagedPackage] = []
    @Published private(set) var receipts: [WallpaperInstallReceipt] = []
    @Published private(set) var report: WallpaperAccessReport?
    @Published private(set) var refreshInstructions: String?
    @Published private(set) var busy: String?
    @Published var message: AppMessage?
    @Published var selectedPackage: WallpaperStagedPackage?
    @Published var selectedTab = 0

    private let worker = WallpaperWorker()
    private var refreshAfterDismiss = false
    private var hasCommittedWallpaperChange = false

    var isBusy: Bool { busy != nil }
    var activeReceipts: [WallpaperInstallReceipt] {
        receipts.filter { $0.status == .installed || $0.status == .preparing }
    }

    func load() async {
        guard !isBusy else { return }
        packages = await worker.library()
        receipts = await worker.receipts()
    }

    func importFile(_ url: URL) {
        perform("Đang kiểm tra gói…") { [self] in
            let package = try await worker.importFile(url)
            packages = await worker.library()
            selectedTab = 0
            selectedPackage = package
        }
    }

    func checkAccess() {
        guard requireSupportedDevice() else { return }
        perform("Đang kiểm tra quyền cài…") { [self] in
            report = nil
            report = try await worker.probe()
            if report?.canInstall == false {
                message = AppMessage(title: "Chưa thể cài", text: "Chưa có quyền ghi vào Bộ sưu tập. Hãy tạo và dùng sẵn một hình nền Bộ sưu tập của Apple, rồi kiểm tra quyền cài lại. Xem tab Hướng dẫn nếu lỗi vẫn xuất hiện.")
            }
        }
    }

    func install(_ package: WallpaperStagedPackage) {
        guard requireSupportedDevice() else { return }
        perform("Đang cài hình nền…") { [self] in
            refreshInstructions = nil
            refreshAfterDismiss = false
            hasCommittedWallpaperChange = false
            report = nil
            report = try await worker.install(package)
            receipts = await worker.receipts()
            hasCommittedWallpaperChange = true
            refreshInstructions = "Đã ghi hình nền. App sẽ mở PosterBoard; mở đa nhiệm và vuốt đóng thẻ PosterBoard, rồi vào Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập."
            refreshAfterDismiss = true
            selectedPackage = nil
        }
    }

    func delete(_ package: WallpaperStagedPackage) {
        perform("Đang xoá gói đã nhập…") { [self] in
            try await worker.delete(package)
            packages = await worker.library()
            selectedPackage = nil
        }
    }

    func restore(_ receipt: WallpaperInstallReceipt) {
        guard requireSupportedDevice() else { return }
        perform("Đang gỡ hình nền…", afterSuccess: { [self] in openPosterBoardForRefresh() }) { [self] in
            refreshInstructions = nil
            hasCommittedWallpaperChange = false
            report = nil
            report = try await worker.restore(receipt)
            receipts = await worker.receipts()
            hasCommittedWallpaperChange = true
            refreshInstructions = "Đã gỡ hình nền. Mở đa nhiệm và vuốt đóng thẻ PosterBoard để cập nhật Bộ sưu tập."
        }
    }

    func sheetDismissed() {
        guard refreshAfterDismiss else { return }
        refreshAfterDismiss = false
        openPosterBoardForRefresh()
    }

    func openPosterBoardForRefresh() {
        guard hasCommittedWallpaperChange, !isBusy else { return }
        let opened = TendiesOpenPosterBoard()
        if opened {
            refreshInstructions = "Đã lưu thay đổi và mở PosterBoard. Mở đa nhiệm, vuốt đóng thẻ PosterBoard rồi vào Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập để kiểm tra."
        } else {
            let instructions = "Đã lưu thay đổi, nhưng iOS chưa mở được PosterBoard tự động. Mở Cài đặt → Hình nền → Thêm hình nền mới, sau đó mở đa nhiệm và vuốt đóng thẻ PosterBoard nếu có. Quay lại Bộ sưu tập để kiểm tra; nếu chưa cập nhật, khởi động lại thiết bị."
            refreshInstructions = instructions
            message = AppMessage(title: "Đã lưu, cần làm mới hình nền", text: instructions)
        }
    }

    private func requireSupportedDevice() -> Bool {
        guard DeviceCompatibility.supported else {
            message = AppMessage(title: "Chưa hỗ trợ cài trên thiết bị này", text: DeviceCompatibility.explanation)
            return false
        }
        return true
    }

    private func perform(
        _ label: String,
        afterSuccess: (@MainActor () -> Void)? = nil,
        operation: @escaping @MainActor () async throws -> Void
    ) {
        guard !isBusy else { return }
        busy = label
        Task {
            do {
                try await operation()
            } catch {
                // A failed write can leave a recovery receipt; always reload it.
                receipts = await worker.receipts()
                message = AppMessage(title: "Không hoàn tất được", text: error.localizedDescription)
                busy = nil
                return
            }
            busy = nil
            afterSuccess?()
        }
    }
}
