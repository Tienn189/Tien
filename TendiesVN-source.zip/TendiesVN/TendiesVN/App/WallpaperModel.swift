import SwiftUI
import UIKit
import UniformTypeIdentifiers

extension UTType {
    static let tendiesPackage = UTType(importedAs: "vn.tendies.wallpaper", conformingTo: .zip)
}

struct AppMessage: Identifiable {
    let id = UUID()
    let title: String
    let text: String
}

enum DeviceCompatibility {
    static var supported: Bool {
        #if targetEnvironment(simulator)
        return false
        #else
        let version = ProcessInfo.processInfo.operatingSystemVersion
        return version.majorVersion == 26 &&
            (version.minorVersion < 6 || (version.minorVersion == 6 && version.patchVersion <= 1))
        #endif
    }

    static var explanation: String {
        #if targetEnvironment(simulator)
        return "Simulator chỉ dùng để xem giao diện và nhập gói. Cài hình nền cần thiết bị thật."
        #else
        return supported
            ? "Phiên bản nằm trong phạm vi 26.0–26.6.1 được backend hỗ trợ. Cần kiểm tra quyền cài trên máy."
            : "Cơ chế cài của bản này chỉ dành cho iOS/iPadOS 26.0–26.6.1. Bạn vẫn có thể nhập và kiểm tra gói."
        #endif
    }
}

// All file I/O and system operations share one serial executor, away from the UI.
private actor WallpaperWorker {
    func library() -> [WallpaperStagedPackage] { WallpaperPackageStore.packages() }
    func receipts() -> [WallpaperInstallReceipt] { WallpaperDeviceAccessService.receipts() }
    func importFile(_ url: URL) throws -> WallpaperStagedPackage {
        try WallpaperPackageStore.importPackage(from: url)
    }
    func delete(_ package: WallpaperStagedPackage) throws {
        try WallpaperPackageStore.delete(package)
    }
    func probe() throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.report()
    }
    func install(_ package: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.install(package).1
    }
    func restore(_ receipt: WallpaperInstallReceipt) throws -> WallpaperAccessReport {
        try WallpaperDeviceAccessService.restore(receipt: receipt)
    }
}

@MainActor
final class WallpaperModel: ObservableObject {
    @Published private(set) var packages: [WallpaperStagedPackage] = []
    @Published private(set) var receipts: [WallpaperInstallReceipt] = []
    @Published private(set) var report: WallpaperAccessReport?
    @Published private(set) var refreshInstructions: String?
    @Published private(set) var operationStatus: WallpaperOperationStatus?
    @Published private(set) var successNotice: WallpaperOperationStatus?
    @Published private(set) var busy: String?
    @Published var message: AppMessage?
    @Published var selectedPackage: WallpaperStagedPackage?
    @Published var selectedTab = 0

    private let worker = WallpaperWorker()
    private var refreshAfterDismiss = false
    private var hasCommittedWallpaperChange = false
    private var shouldAnnounceCommittedChange = false
    private var announceWhenActive = false
    private var committedChangeSummary: String?

    var isBusy: Bool { busy != nil }
    var activeReceipts: [WallpaperInstallReceipt] {
        receipts.filter { $0.status == .installed || $0.status == .preparing }
    }

    func load() async {
        guard !isBusy else { return }
        packages = await worker.library()
        receipts = await worker.receipts()
    }

    func importFile(_ url: URL) {
        perform("Đang nhập hình nền", detail: "Đang đọc tệp và kiểm tra nội dung gói.") { [self] in
            let package = try await worker.importFile(url)
            packages = await worker.library()
            selectedTab = 0
            selectedPackage = package
        }
    }

    func checkAccess() {
        guard requireSupportedDevice() else { return }
        perform("Đang kiểm tra quyền cài", detail: "Đang tìm Bộ sưu tập và kiểm tra khả năng cài trên thiết bị.") { [self] in
            report = nil
            report = try await worker.probe()
            if report?.canInstall == false {
                message = AppMessage(title: "Chưa thể cài", text: "Chưa có quyền ghi vào Bộ sưu tập. Hãy tạo và dùng sẵn một hình nền Bộ sưu tập của Apple, rồi kiểm tra quyền cài lại. Xem tab Hướng dẫn nếu lỗi vẫn xuất hiện.")
            }
        }
    }

    func install(_ package: WallpaperStagedPackage) {
        guard requireSupportedDevice() else { return }
        perform(
            "Đang cài hình nền",
            detail: "Đang kiểm tra gói và thêm vào Bộ sưu tập. Giữ ứng dụng mở.",
            phases: ["Cài hình nền", "Cập nhật", "Hoàn tất"]
        ) { [self] in
            resetWallpaperCompletion()
            report = nil
            report = try await worker.install(package)
            updateOperationPhase(1, detail: "Đã ghi hình nền. Đang cập nhật danh sách các lần cài.")
            receipts = await worker.receipts()
            updateOperationPhase(2, detail: "Đã hoàn tất. Đang chuẩn bị mở PosterBoard để làm mới Bộ sưu tập.")
            hasCommittedWallpaperChange = true
            publishSuccess(
                title: "Cài hình nền thành công",
                summary: "Đã thêm \(package.payload.descriptors.count) hình nền vào Bộ sưu tập.",
                instructions: "App sẽ mở PosterBoard. Mở đa nhiệm, vuốt đóng thẻ PosterBoard rồi chọn hình nền mới trong Cài đặt → Hình nền."
            )
            refreshAfterDismiss = true
            selectedPackage = nil
        }
    }

    func delete(_ package: WallpaperStagedPackage) {
        perform("Đang xoá gói đã nhập", detail: "Đang dọn bản nhập khỏi thư viện của bạn.") { [self] in
            try await worker.delete(package)
            packages = await worker.library()
            selectedPackage = nil
        }
    }

    func restore(_ receipt: WallpaperInstallReceipt) {
        guard requireSupportedDevice() else { return }
        perform(
            "Đang gỡ hình nền",
            detail: "Đang gỡ những hình nền thuộc lần cài đã chọn.",
            afterSuccess: { [self] in openPosterBoardForRefresh() }
        ) { [self] in
            resetWallpaperCompletion()
            report = nil
            report = try await worker.restore(receipt)
            receipts = await worker.receipts()
            hasCommittedWallpaperChange = true
            publishSuccess(
                title: "Đã gỡ hình nền",
                summary: "Đã gỡ hình nền của lần cài này.",
                instructions: "Mở đa nhiệm và vuốt đóng thẻ PosterBoard để cập nhật Bộ sưu tập."
            )
        }
    }

    func sheetDismissed() {
        guard refreshAfterDismiss else { return }
        refreshAfterDismiss = false
        openPosterBoardForRefresh()
    }

    func openPosterBoardForRefresh() {
        guard hasCommittedWallpaperChange, !isBusy else { return }
        let opened = TendiesOpenPosterBoard()
        if opened {
            updateSuccessInstructions("Mở đa nhiệm, vuốt đóng thẻ PosterBoard rồi vào Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập để chọn hình nền.")
            // Present the completion alert after the user returns, rather than
            // covering the launch with a modal. The result card stays visible.
            if shouldAnnounceCommittedChange {
                announceWhenActive = true
                shouldAnnounceCommittedChange = false
            }
        } else {
            updateSuccessInstructions("iOS chưa mở được PosterBoard tự động. Mở Cài đặt → Hình nền → Thêm hình nền mới, rồi mở đa nhiệm và vuốt đóng thẻ PosterBoard nếu có. Nếu Bộ sưu tập chưa cập nhật, khởi động lại thiết bị.")
            announceWhenActive = false
            shouldAnnounceCommittedChange = false
            if let notice = successNotice {
                message = AppMessage(title: notice.title, text: notice.detail)
            }
        }
    }

    /// Call when the app's scene becomes active after visiting PosterBoard.
    func sceneBecameActive() {
        guard announceWhenActive, !isBusy, selectedPackage == nil,
              let notice = successNotice else { return }
        announceWhenActive = false
        message = AppMessage(title: notice.title, text: notice.detail)
    }

    func dismissSuccessNotice() {
        successNotice = nil
        refreshInstructions = nil
        announceWhenActive = false
        shouldAnnounceCommittedChange = false
    }

    private func resetWallpaperCompletion() {
        successNotice = nil
        refreshInstructions = nil
        refreshAfterDismiss = false
        hasCommittedWallpaperChange = false
        committedChangeSummary = nil
        shouldAnnounceCommittedChange = false
        announceWhenActive = false
    }

    private func publishSuccess(title: String, summary: String, instructions: String) {
        committedChangeSummary = summary
        refreshInstructions = instructions
        successNotice = WallpaperOperationStatus(
            kind: .success,
            title: title,
            detail: summary + " " + instructions
        )
        shouldAnnounceCommittedChange = true
    }

    private func updateSuccessInstructions(_ instructions: String) {
        refreshInstructions = instructions
        guard let previous = successNotice else { return }
        successNotice = WallpaperOperationStatus(
            id: previous.id,
            kind: .success,
            title: previous.title,
            detail: [committedChangeSummary, instructions].compactMap { $0 }.joined(separator: " ")
        )
    }

    private func updateOperationPhase(_ index: Int, detail: String) {
        guard let previous = operationStatus,
              previous.kind == .working,
              previous.phases.indices.contains(index) else { return }
        operationStatus = WallpaperOperationStatus(
            id: previous.id,
            kind: .working,
            title: previous.title,
            detail: detail,
            phases: previous.phases,
            activePhase: index
        )
    }

    private func requireSupportedDevice() -> Bool {
        guard DeviceCompatibility.supported else {
            message = AppMessage(title: "Chưa hỗ trợ cài trên thiết bị này", text: DeviceCompatibility.explanation)
            return false
        }
        return true
    }

    private func perform(
        _ label: String,
        detail: String,
        phases: [String] = [],
        afterSuccess: (@MainActor () -> Void)? = nil,
        operation: @escaping @MainActor () async throws -> Void
    ) {
        guard !isBusy else { return }
        busy = label
        operationStatus = WallpaperOperationStatus(
            kind: .working,
            title: label,
            detail: detail,
            phases: phases,
            activePhase: phases.isEmpty ? nil : 0
        )
        Task {
            do {
                try await operation()
            } catch {
                // A failed write can leave a recovery receipt; always reload it.
                receipts = await worker.receipts()
                message = AppMessage(title: "Không hoàn tất được", text: error.localizedDescription)
                busy = nil
                operationStatus = nil
                return
            }
            busy = nil
            operationStatus = nil
            afterSuccess?()
        }
    }
}
