# Cập nhật giao diện và kiểm tra Airlift

- Làm mới màn thư viện, thẻ thiết bị, nút nhập và màu nền sáng/tối.
- Trên iOS 27.0–27.0.1, kiểm tra kết nối sử dụng Airlift: xác thực pairing và tìm container PosterBoard. Việc tìm thấy container không chứng minh ghi thành công; quyền ghi chỉ được kiểm tra khi cài.
- Giữ các backend iOS 17–18 và iOS 27 hiện có. Chưa xác nhận cài đặt trên thiết bị thực tế; không thể bảo đảm hỗ trợ mọi thiết bị hoặc bản build.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA, kiểm tra SwiftUI hoặc thử trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP này bằng GitHub Actions, sau đó ký IPA và thử trên thiết bị phù hợp. Nội dung VALIDATION.md mô tả bản trước, không phải xác nhận kiểm thử thiết bị cho thay đổi này.
