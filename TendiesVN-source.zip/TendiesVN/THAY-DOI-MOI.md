# Cập nhật 1809

- Giới thiệu: chữ 1809 chuyển động liền mạch vào tiêu đề; tiếp theo là thông tin thiết bị và trạng thái bộ cài với hiệu ứng tương ứng. Giảm chuyển động và VoiceOver hiện nội dung ngay. Màn này xuất hiện một lần sau khi cài mới hoặc cập nhật.
- Tên và loại thiết bị do iOS cung cấp; có thể là tên chung. Trạng thái hỗ trợ cho biết có backend theo phiên bản/build, không chứng minh cài thành công.
- Giữ nền tối đen thuần và các thay đổi Airlift đã thực hiện trước đó.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc kiểm tra hoạt ảnh trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
