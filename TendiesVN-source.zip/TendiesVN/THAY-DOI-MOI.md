# Cập nhật 1809

- Bỏ màn số 1809 xuất hiện riêng; giữ lời chào và biểu tượng. Ba mục giới thiệu có đường kẻ ngăn cách.
- Sau Bắt đầu, màn kiểm tra thiết bị trượt lên và mờ dần, màn chính hiện ra bên dưới. Giảm chuyển động và VoiceOver vào ngay. Màn giới thiệu xuất hiện một lần sau cập nhật hoặc cài mới.
- Giữ các thay đổi iOS 17–18 và danh sách beta trước đó. Khả năng cài hình nền chưa được xác nhận trên thiết bị thật.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc kiểm tra hoạt ảnh trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
