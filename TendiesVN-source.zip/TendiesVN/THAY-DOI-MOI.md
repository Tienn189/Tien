# Cập nhật kiểm tra Airlift

- Khôi phục giao diện thư viện của bản nguồn gốc.
- Trên iOS 27.0–27.0.1, kiểm tra kết nối sử dụng Airlift để xác thực pairing và tìm container PosterBoard. Việc tìm thấy container không chứng minh ghi thành công.
- Ghi vào extension của descriptor theo nhánh chính của Placard, không tự thử lại hay chuyển extension khi gặp lỗi; trạng thái lần ghi trước có thể chưa rõ. Airlift vẫn có thể mất vài phút mỗi lần chờ AirTraffic.
- Bước build luôn dựng lại Airlift từ mã nguồn thay vì âm thầm dùng framework cũ khi script thiếu quyền thực thi.
- Giao diện báo lệnh gửi gói hoàn tất nhưng chưa xác nhận được hình nền đã xuất hiện; nếu AirTraffic chưa sẵn sàng, thông báo hướng dẫn kiểm tra ứng dụng Sách.
- Nguồn 3105 giới hạn iOS 27 ở một số bản beta; không coi 3105 là bằng chứng hỗ trợ iOS 27 chính thức. Chưa xác nhận việc cài trên thiết bị thực tế.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA, kiểm tra SwiftUI hoặc thử trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP này bằng GitHub Actions, sau đó ký IPA và thử trên thiết bị phù hợp. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
