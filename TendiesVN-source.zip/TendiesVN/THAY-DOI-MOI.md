# Cập nhật 1809

- Sửa chuyển động số 1809 và hiệu ứng vào màn chính; danh sách iOS 27 beta gộp 4 dòng theo yêu cầu. Màn giới thiệu xuất hiện một lần sau khi cập nhật hoặc cài mới.
- Đối chiếu 3105 commit a72617e: giữ backend iOS 17.0–17.7.x và 18.0–18.7.1; bổ sung giữ thứ tự descriptor cho gói ordered-descriptors. Kiểm tra container không còn báo đã xác minh quyền ghi.
- 3105 ghi điều kiện ký enterprise và bundle ID riêng. 1809 hiện dùng bundle ID khác; chưa xác nhận thực tế rằng có thể cài hình nền trên mọi máy iOS 17–18.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc kiểm tra hoạt ảnh, ký và cài hình nền trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
