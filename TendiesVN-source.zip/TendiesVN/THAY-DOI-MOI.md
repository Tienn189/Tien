# Cập nhật 1809

- Chuyển động giới thiệu theo video tham khảo: cụm biểu tượng và lời chào trượt lên cùng nhau, biểu tượng mờ dần rồi các dòng thông tin xuất hiện lần lượt. Màn thông tin thiết bị vẫn mở sau Tiếp tục. Màn giới thiệu xuất hiện một lần sau khi cài mới hoặc cập nhật.
- Giữ nền tối đen thuần và các thay đổi Airlift trước đó. Trạng thái hỗ trợ là thông tin backend theo phiên bản/build, không chứng minh cài thành công.
- `python3 scripts/run-checks.py`: các bộ kiểm tra chạy được đã hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc kiểm tra hoạt ảnh trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
