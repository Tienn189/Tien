# Cập nhật 1809

- Màn kiểm tra thiết bị hiển thị phiên bản iOS, trạng thái hỗ trợ và model phần cứng; bỏ tên/loại thiết bị và đoạn giải thích dưới trạng thái. Model là mã phần cứng do hệ điều hành cung cấp. Màn này hiện một lần sau khi cài mới hoặc cập nhật.
- Giữ hiệu ứng giới thiệu, chuyển cảnh vào màn chính, màu xanh mặc định, nền tối đen và các thay đổi Airlift trước đó. Trạng thái hỗ trợ cho biết bộ cài theo phiên bản/build, không chứng minh cài thành công.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc kiểm tra giao diện trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
