# Cập nhật AirTraffic · iOS 27.0

- Nhật ký được cung cấp cho thấy pairing xác thực, nhưng AirTraffic đóng kênh khi chờ ReadyForSync; chưa xác định nguyên nhân kết nối đóng.
- Bộ đọc ATC giữ lại dữ liệu đang nhận khi hết thời gian chờ, tránh mất byte của thông điệp chưa hoàn chỉnh. Không thay đổi quy tắc đóng khung dữ liệu hoặc tự thử lại thao tác ghi không rõ kết quả.
- Khi lỗi, thông báo và nhật ký ghi giai đoạn gần nhất bằng nhãn cố định, không ghi token, địa chỉ IP hay nội dung pairing.
- Kiểm thử Rust `cargo test atc_read_tests --lib`: 3/3 đạt trên Linux; `python3 scripts/run-checks.py`: 15 bộ hoàn tất, các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc thử cài trên thiết bị iOS.
- Cần build lại IPA từ ZIP này: `scripts/build-unsigned.sh` chạy `scripts/build-airlift.sh` để dựng lại AirliftFFI từ mã Rust đã sửa. IPA hoặc framework cũ không chứa thay đổi mới.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
