# Cập nhật 1809

- Thêm giới thiệu hai bước với thiết kế riêng, hiển thị lần đầu, có thể bỏ qua và ghi nhớ khi đã hoàn tất. Mở tệp từ bên ngoài đưa thẳng vào ứng dụng.
- Xoá khối màu chuyển sắc phía trên thư viện hình nền.
- Giữ các thay đổi Airlift đã thực hiện trước đó: giới hạn thao tác lặp, dùng extension của gói, thông báo chưa xác nhận hình nền xuất hiện và build lại Airlift từ mã nguồn.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA, kiểm tra giao diện hoặc thử cài trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
