# Cập nhật 1809

- Giới thiệu có hiệu ứng: 1809 ở giữa mờ sang lời chào, tiêu đề chuyển lên và thông tin xuất hiện; người dùng bật Giảm chuyển động sẽ thấy ngay nội dung. Màn này xuất hiện một lần sau khi cập nhật hoặc cài mới.
- Nền chế độ tối của các màn chính và giới thiệu là đen thuần; thẻ dùng xám trung tính.
- Giữ thay đổi Airlift trước đó: giới hạn thao tác lặp, dùng extension của gói, thông báo chưa xác nhận hình nền xuất hiện và build lại Airlift từ mã nguồn.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA, kiểm tra hoạt ảnh hoặc thử cài trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
