# Cập nhật luồng cài hình nền iOS 27

- Với hồ sơ RPPairing đã lưu, cài trực tiếp qua kết nối Airlift, không mở thêm phiên xác thực riêng trước khi cài. Bỏ xác thực tự động khi mở app hoặc tab Pairing. Vẫn cần LocalDevVPN và hồ sơ pairing; hồ sơ Lockdown được xác thực khi cần.
- Trong kết nối Airlift, kiểm tra ProductType nếu thiết bị cung cấp và từ chối model khác. Thiếu dữ liệu hoặc hai máy cùng model không chứng minh đúng máy đích.
- Giữ bản sửa buffer AirTraffic và nhật ký giai đoạn. Lỗi AirTraffic đóng kênh trong nhật ký trước chưa được xác nhận đã khắc phục trên iOS 27.0.
- `cargo test atc_read_tests --lib`: 5/5 đạt trên Linux; `python3 scripts/run-checks.py`: 15 bộ hoàn tất, các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc thử cài trên iPhone.
- Build lại IPA từ ZIP này: scripts/build-unsigned.sh dựng lại AirliftFFI từ mã Rust. Xem BUILD-KHONG-CAN-MAC.md; VALIDATION.md mô tả bản cũ.
