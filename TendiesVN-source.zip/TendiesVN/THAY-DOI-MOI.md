# Cập nhật 1809

- Khi nhấn Bắt đầu, màn giới thiệu mờ dần và màn chính xuất hiện phía sau theo video mẫu. Giảm chuyển động và VoiceOver vào ngay. Màn giới thiệu xuất hiện một lần sau cập nhật hoặc cài mới.
- Giữ bố cục giới thiệu, nền tối và các thay đổi iOS 17–18 trước đó. Khả năng cài hình nền chưa được xác nhận trên thiết bị thật.
- `python3 scripts/run-checks.py`: 15 bộ kiểm tra hoàn tất trên Linux; các bài cần Swift/Apple SDK bị bỏ qua. Chưa build IPA hoặc kiểm tra hoạt ảnh trên thiết bị.

Xem BUILD-KHONG-CAN-MAC.md để build ZIP bằng GitHub Actions. VALIDATION.md mô tả bản cũ, không phải kết quả kiểm thử cho thay đổi này.
