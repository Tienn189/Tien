# Build 1809 · 3.5.0 · bản dựng 19 bằng GitHub Actions

Bản này khôi phục bộ cài PosterBoard từ build 14 và bỏ lưu vào Ảnh. Backend Pocket-Poster generation 61 nhận iOS 17–18 sau khi nhập App Hash/UUID; BadQuery nhận iOS 26.0–26.6.1 và các build iOS 27.0 beta được liệt kê; Airlift nhận iOS 27.0–27.0.1 khi đã nhập pairing. Cần kiểm tra quyền ghi trên thiết bị thật.

## Repository build từ ZIP

1. Thay **`TendiesVN-source.zip`** ở thư mục gốc repository bằng ZIP mới rồi commit. ZIP có thư mục gốc `TendiesVN/`, gồm project, Config, scripts và nguồn.
2. Giữ workflow cũ hoặc dùng [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml).
3. Chạy **Actions → Build IPA from ZIP → Run workflow** trên commit mới. Re-run lượt cũ vẫn lấy mã ở commit cũ.
4. Tải artifact **1809-unsigned**, giải nén lấy `1809-unsigned.ipa`.

Script còn tạo `build/TendiesVN-unsigned.ipa` giống hệt để workflow cũ upload được. ZIP này là mã nguồn, không thể cài trực tiếp như IPA.

## Repository đã giải nén nguồn

Đưa toàn bộ nguồn, gồm thư mục ẩn `.github`, vào repo. Chạy workflow **Build unsigned iOS IPA**. Runner `macos-26` phải chọn Xcode 26 trở lên. Workflow chạy `scripts/run-checks.py` rồi build arm64.

Các bài test yêu cầu Apple SDK/Swift báo skip khi thiếu công cụ. Skip không chứng minh tính năng đã hoạt động. `idevice v0.1.68` được tải khoảng 204 MB và kiểm SHA256 khi build; không nằm trong ZIP nguồn.

## Ký và kiểm tra bản mới

Ký IPA với chứng chỉ và profile Apple phù hợp. Bundle ID mặc định `vn.tendies.wallpaper`; giữ ID để giữ dữ liệu qua cập nhật. Trong Cài đặt của app phải hiện **3.5.0 / bản dựng 19**.

Trên iPhone/iPad:

- Nhập gói từ Tệp; kiểm tra dung lượng giải nén, số tệp và ngày nhập trên màn cài. Không có ảnh xem trước và không hỏi quyền Photos.
- iOS 26.0–26.6.1 hoặc build beta 27 được liệt kê: tạo sẵn hình nền Bộ sưu tập của Apple, kiểm tra quyền cài rồi cài gói. Màn cài phải đóng trước khi mở PosterBoard.
- Mở đa nhiệm, vuốt đóng thẻ PosterBoard rồi kiểm tra Bộ sưu tập. Quay lại 1809, xác nhận bản ghi trong Đã cài.
- Gói lỗi hoặc quyền bị từ chối: không được báo thành công hay mở PosterBoard. Nếu mở PosterBoard thất bại sau khi ghi thành công, phải giữ kết quả ghi và báo lỗi mở riêng.
- Chuyển sang hình nền Apple khác rồi gỡ đúng một lần cài. Kiểm tra hình nền gốc và những lần cài khác được giữ.
- iOS 17–18 dùng Pocket-Poster generation 61 sau khi nhập App Hash/UUID; iOS 26 dùng BadQuery; iOS 27.0–27.0.1 dùng Airlift và cần pairing đã nhập. Vẫn phải kiểm tra kết quả cài thực tế trên thiết bị.

## Khi build thất bại

Cuối bước build có **First compiler errors** với các lỗi đầu tiên. Workflow mẫu tải artifact **1809-build-log**, chứa `xcodebuild.log`. Nếu chỉ thay ZIP trong workflow cũ, script mới vẫn in tóm tắt lỗi.

Xem [VALIDATION.md](VALIDATION.md) về kiểm tra đã thực thi. Chưa có kết quả native hoặc máy thật kèm bản nguồn này.
