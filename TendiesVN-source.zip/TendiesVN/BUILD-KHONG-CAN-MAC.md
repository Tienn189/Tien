# Build 1809 · 3.3.0 · bản dựng 15 bằng GitHub Actions

Bản này dùng API công khai để xem, lưu và chia sẻ ảnh/video. Người dùng tự đặt hình nền trong Cài đặt iOS. Không có đường cài wallpaper bằng vượt sandbox.

## Repository build từ ZIP

1. Thay file **`TendiesVN-source.zip`** ở thư mục gốc repository bằng ZIP mới và commit. Bên trong ZIP có thư mục gốc `TendiesVN`, chứa project, Config, scripts và mã ứng dụng.
2. Giữ workflow cũ hoặc dùng [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml). Tên ZIP cũ được giữ để tương thích.
3. Chọn **Actions → Build IPA from ZIP → Run workflow** trên commit mới. **Re-run jobs** của lượt cũ vẫn lấy mã ở commit cũ.
4. Tải artifact **1809-unsigned**, giải nén để lấy `1809-unsigned.ipa`.

Script vẫn tạo bản sao giống hệt tại **`build/TendiesVN-unsigned.ipa`**, nên workflow cũ upload tên đó vẫn hoạt động. Workflow mẫu báo lỗi nếu không tìm thấy IPA, tránh báo thành công giả.

## Repository đã giải nén nguồn

Đưa toàn bộ mã nguồn, gồm thư mục ẩn `.github`, vào repository. Chạy workflow **Build unsigned iOS IPA**. Runner `macos-26` phải chọn Xcode 26 trở lên; script kiểm tra phiên bản trước build.

Các workflow chạy `python3 scripts/run-checks.py` rồi build arm64 với Xcode. Bộ kiểm tra tự phát hiện `tests/test_*.py`, gồm archive, phiên bản, pairing, catalog media, codec lịch sử và giới hạn API công khai. Các bài cần SDK Apple/Swift báo skip nếu môi trường thiếu công cụ; skip không chứng minh tính năng đã chạy.

## Ký và xác nhận bản mới

IPA từ Actions chưa có chữ ký. Ký với chứng chỉ/profile Apple hợp lệ cho Bundle ID đang dùng. Bundle ID mặc định **`vn.tendies.wallpaper`** để giữ dữ liệu khi cập nhật. Sau khi cài, vào Cài đặt trong app kiểm tra **3.3.0 / bản dựng 15**.

Deployment target là iOS 17.0. Bản API công khai không yêu cầu Bundle ID đặc biệt của 3105 hoặc enterprise signing để lưu hình nền; các phương thức cài/ký riêng vẫn phải đáp ứng quy định của Apple. Script `export-enterprise.sh` chỉ dành cho người đã có chứng chỉ và profile enterprise phù hợp.

Công cụ pairing dùng `idevice v0.1.68`, script tải khoảng 204 MB và kiểm SHA256 khi build; không thêm thư viện vào ZIP nguồn. Pairing không cần cho thao tác lưu hình nền.

## Kiểm thử trên iPhone/iPad sau build

- Nhập gói từ Tệp, chọn một ảnh thật và kiểm tra xem trước.
- Lần đầu lưu, cho phép thêm vào Ảnh rồi kiểm tra ảnh xuất hiện và lịch sử có đúng một bản ghi.
- Thử từ chối quyền Photos: app phải báo lỗi, không báo đã lưu. Có thể chia sẻ tệp mà không cần quyền Photos.
- Huỷ share sheet không tạo bản ghi lưu thành công. Xoá lịch sử không xoá ảnh.
- Đặt ảnh bằng Cài đặt → Hình nền; kiểm tra sáng/tối và màu nhấn được giữ qua lần mở app.

Xem [VALIDATION.md](VALIDATION.md) để biết những kiểm tra đã chạy trong môi trường sửa mã. Chưa có IPA build/native-device result kèm gói nguồn này.
