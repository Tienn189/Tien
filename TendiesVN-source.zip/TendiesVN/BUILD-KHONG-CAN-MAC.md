# Build 1809 · 3.1.0 · bản dựng 13 bằng GitHub Actions

Tên app mới là **1809**. Bản này bỏ hoàn toàn trình chỉnh sửa hình nền, thay bằng giao diện trắng đen có chế độ sáng/tối, mục Cài đặt và quản lý pairing. Bundle ID mặc định vẫn là `vn.tendies.wallpaper` để cập nhật app cũ và giữ dữ liệu.

## Nếu repository đang build từ ZIP

1. Tải ZIP nguồn mới và đặt tên là **`TendiesVN-source.zip`** trước khi tải lên repository. Tên ZIP này được giữ để tương thích workflow cũ.
2. Thay ZIP cùng tên ở thư mục gốc rồi commit.
3. Giữ workflow cũ hoặc dùng mẫu [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml). ZIP mới tạo cả **`build/1809-unsigned.ipa`** và bản sao giống hệt **`build/TendiesVN-unsigned.ipa`**, nên đường dẫn upload cũ vẫn hoạt động.
4. Chạy **Actions → Build IPA from ZIP → Run workflow** để tạo lượt chạy mới trên commit vừa cập nhật. Không chọn **Re-run jobs** của lượt cũ vì lượt đó vẫn dùng ZIP ở commit cũ.
5. Khi build thành công, tải artifact rồi giải nén để lấy IPA. Workflow mẫu mới tạo artifact **1809-unsigned** chứa **`1809-unsigned.ipa`**; workflow cũ có thể giữ tên **TendiesVN-unsigned** và **`TendiesVN-unsigned.ipa`**.

Trong ZIP, thư mục gốc phải là `TendiesVN`; bên trong có `TendiesVN.xcodeproj`, `Config`, `scripts` và mã ứng dụng. Nếu ZIP được tải xuống với tên `1809-source.zip`, đổi tên thành `TendiesVN-source.zip` để khớp workflow.

## Nếu đã giải nén mã nguồn vào repository

Tải toàn bộ mã nguồn và thư mục ẩn `.github` lên repository. Workflow `.github/workflows/unsigned-ios.yml` chạy trực tiếp `scripts/build-unsigned.sh` trên runner `macos-26`. Chạy **Build unsigned iOS IPA** trong Actions để lấy cùng artifact **1809-unsigned**.

## Ký và kiểm tra bản mới

IPA từ Actions chưa có chữ ký. Dùng công cụ ký của bạn với chứng chỉ và profile hợp lệ, cùng Bundle ID mà profile cho phép. Giữ `vn.tendies.wallpaper` khi cập nhật app hiện tại để giữ thư viện và biên nhận. Sau khi cập nhật, mở **Cài đặt** trong 1809 để kiểm tra **Phiên bản ứng dụng: 3.1.0** và **Bản dựng: 13**.

Runner GitHub cần Xcode 26 trở lên; deployment target của app là iOS 17.0. Cả hai workflow chạy kiểm tra giải nén, đường dẫn, chữ ký, tương thích, hồ sơ pairing và adapter kết nối trước khi build Xcode. Script build tự tải idevice v0.1.68 (~204 MB), xác minh SHA256 và chỉ lấy slice iOS cần dùng; không cần đưa thư viện vào ZIP tải lên GitHub. Không có bước npm hoặc dựng trình chỉnh sửa web.

## Trạng thái hỗ trợ và pairing

Mục Cài đặt liệt kê phạm vi được yêu cầu: iOS 17.0–17.7, 18.0–18.7.10, 26.0–26.7.0 và 27.0–27.0.1. **Backend hiện tại chỉ hỗ trợ cài hình nền trên iOS/iPadOS 26.0–26.6.1.** iOS 17, iOS 18, iOS 26.6.2–26.7.0 và iOS 27 chưa có backend cài đặt trong bản này; vẫn có thể nhập và xem thông tin gói. Trạng thái **Phiên bản hiện tại** dùng `installationSupported` để phản ánh hỗ trợ cài đặt thực tế, nên các phiên bản chưa có backend hiển thị **Không hỗ trợ**. Ngay trong phạm vi được backend hỗ trợ, quyền truy cập PosterBoard vẫn cần được kiểm tra trên máy thực tế.

Tab **Pairing** hỗ trợ nhập/xoá hồ sơ `.mobiledevicepairing`, `.mobilepair`, `.plist`, hiển thị mạng/IP và **Kiểm tra kết nối** thật qua LocalDevVPN. Bật LocalDevVPN, nhập đúng IP thiết bị rồi xác thực hồ sơ. RPPairing và Lockdown dùng hai cơ chế bắt tay riêng; chỉ hiện xác thực sau khi nhận phản hồi của thiết bị.

Trên iOS 27 có thêm **Ghép đôi trên thiết bị này**. Cho phép Mạng cục bộ, mở Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép đôi với 1809, nhập PIN và quay lại app.

Kết nối pairing chưa mở rộng bộ cài wallpaper sang iOS 27. Tab **Wallpapers** giữ cơ chế cài đã có và báo rõ phạm vi cài thực tế.

Nguồn tham khảo: [Pocket-Poster của leminlimez](https://github.com/leminlimez/Pocket-Poster). Các nguồn backend và giấy phép được giữ trong [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
