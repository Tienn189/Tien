# Build và cài TendiesVN khi không có Mac

Bạn có thể dùng **GitHub Actions để build trên macOS qua mạng**, sau đó ký IPA ngay trên iPhone bằng công cụ ký đã có, chẳng hạn ESign. Bạn không cần sở hữu Mac.

**Trạng thái:** workflow đã có trong mã nguồn nhưng chưa được chạy trong lần bàn giao này. Chưa có IPA đã build, chưa thử ký/cài hoặc kiểm chứng hoạt động trên iOS 26.6.

## 1. Chỉ tải một file ZIP lên GitHub

1. Giữ tệp `TendiesVN-source.zip` nguyên dạng ZIP. Nếu đã giải nén, quay lại thư mục Downloads để chọn tệp ZIP gốc, không chọn các thư mục con trong TendiesVN. Nếu Safari tự giải nén khi tải, nén lại **cả thư mục TendiesVN** trong ứng dụng Tệp rồi đổi tên tệp ZIP thành `TendiesVN-source.zip`.
2. Đăng nhập [GitHub](https://github.com) bằng Safari. Nếu thiếu nút thao tác, bật **Yêu cầu trang web cho máy tính** trong menu trang của Safari.
3. Tạo repository mới trong tài khoản của bạn. Chọn **Private** để giữ riêng; chỉ chọn **Public** khi bạn muốn công khai mã nguồn. Hướng dẫn này không tự tạo repository hoặc đăng mã lên tài khoản của bạn.
4. Dùng **Add file → Upload files** để chọn duy nhất tệp `TendiesVN-source.zip`, rồi **Commit changes**. Tệp phải có tên đúng như vậy ở thư mục gốc repository. Không cần chọn từng thư mục hoặc từng tệp mã nguồn.

GitHub không tự giải nén ZIP khi upload. Workflow ở bước tiếp theo sẽ giải nén ZIP trên runner macOS rồi chạy script build bên trong. Cách này dùng được với trình chọn tệp trên iPhone, kể cả khi không chọn được cây thư mục hoặc không thấy thư mục ẩn `.github`.

Trên GitHub chọn **Add file → Create new file**, đặt tên chính xác `.github/workflows/build.yml`, rồi dán nội dung dưới đây và lưu bằng **Commit changes** vào nhánh mặc định (thường là `main`). Cũng có bản để sao chép tại [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml).

```yaml
name: Build IPA from ZIP
on: workflow_dispatch
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-26
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - name: Extract source and build
        run: |
          ditto -x -k TendiesVN-source.zip "$RUNNER_TEMP/tendiesvn"
          bash "$RUNNER_TEMP/tendiesvn/TendiesVN/scripts/build-unsigned.sh"
      - uses: actions/upload-artifact@v4
        with:
          name: TendiesVN-unsigned
          path: ${{ runner.temp }}/tendiesvn/TendiesVN/build/TendiesVN-unsigned.ipa
          if-no-files-found: error
```

## 2. Build và tải IPA

1. Mở tab **Actions** của repository; bật Actions nếu GitHub yêu cầu.
2. Chọn **Build IPA from ZIP → Run workflow**, giữ nhánh chứa file ZIP và workflow rồi chạy.
3. Đợi lượt chạy báo thành công. Workflow dùng runner **macos-26**; khả năng chạy và chi phí phụ thuộc hạn mức/phương thức thanh toán GitHub của tài khoản, nhất là repository Private. Nếu bị chặn do hạn mức, cần xử lý trong phần thanh toán GitHub trước.
4. Mở lượt chạy thành công, tới **Artifacts**, tải **TendiesVN-unsigned**. Trong ứng dụng **Tệp**, giải nén ZIP tải về để lấy `TendiesVN-unsigned.ipa`.

Nếu lượt chạy thất bại, mở bước màu đỏ để xem lỗi; chưa có IPA sử dụng được chỉ vì workflow đã bắt đầu.

## 3. Ký IPA và cài trên iPhone

IPA tải về **chưa ký**, nên chưa cài trực tiếp được. Bạn cần công cụ ký đã cài trên iPhone, chứng chỉ doanh nghiệp `.p12` kèm mật khẩu và **provisioning profile `.mobileprovision` phù hợp**. Riêng file `.p12` chưa đủ.

1. Nhập chứng chỉ và profile vào công cụ ký trên iPhone, rồi nhập `TendiesVN-unsigned.ipa`.
2. Tắt tùy chọn tự đổi Bundle ID. Khi ký, công cụ phải giữ cả **Bundle ID** và **CodeDirectory identifier** là `com.apple.mobile.MobileHouseArrest`. Nếu công cụ không hỗ trợ giữ identifier này, cần dùng công cụ ký có hỗ trợ. Profile cũng phải cho phép identity đó.
3. Ký rồi cài bằng công cụ đó. Vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển; làm theo yêu cầu khởi động lại nếu xuất hiện.

Không cần đưa chứng chỉ, mật khẩu, khóa riêng hay profile lên GitHub để build IPA chưa ký; giữ chúng trên thiết bị của bạn. Chứng chỉ doanh nghiệp không tự cấp quyền truy cập PosterBoard. App dùng identity trên cũng có thể thay thế app 3105/FilzaSlop đã cài với cùng Bundle ID.

Khi app mở được, làm theo mục **Cài hình nền CAPlayground** trong [README](README.md). Chỉ tiếp tục khi app kiểm tra được quyền truy cập PosterBoard trên máy của bạn.
