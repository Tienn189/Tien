# Build và cài TendiesVN 1.1 khi không có Mac

Dùng GitHub Actions để build trên runner macOS, rồi ký IPA ngay trên iPhone bằng công cụ bạn đang dùng, chẳng hạn ESign. Bundle ID mặc định mới là **`vn.tendies.wallpaper`** để app có thể tồn tại riêng với 3105.

**Trạng thái:** bản cũ đã được người dùng build và cài thành công. Backend độc lập của 1.1.0 (build 3) chưa được thử bằng Xcode hoặc trên iPhone trong môi trường làm việc này; cần xác nhận lại quyền truy cập và cài hình nền trên thiết bị.

## Đã có workflow chạy được: chỉ thay ZIP

1. Tải `TendiesVN-source.zip` bản mới, giữ nguyên dạng ZIP và đúng tên đó.
2. Trong repository GitHub đang dùng, chọn **Add file → Upload files**, tải tệp ZIP mới lên thư mục gốc để thay bản cũ, rồi **Commit changes**.
3. Vào **Actions → Build IPA from ZIP → Run workflow**, chọn nhánh vừa cập nhật và chạy.
4. Trong lượt chạy mới thành công, tải artifact **TendiesVN-unsigned**. Giải nén trong ứng dụng **Tệp** để lấy `TendiesVN-unsigned.ipa`.
5. Ký IPA mới theo phần bên dưới. Không dùng lại artifact của lượt build cũ.

Workflow cũ có các dòng sửa `lipo` và bộ chọn tệp vẫn được giữ tương thích với ZIP mới. Không cần sửa lại YAML chỉ để nhận bản 1.1. Nếu dùng workflow mới bên dưới, có thể nhập Bundle ID riêng ở ô `bundle_id`; để mặc định nếu không cần đổi.

## Chưa có repository/workflow

1. Đăng nhập [GitHub](https://github.com) bằng Safari. Nếu thiếu nút, bật **Yêu cầu trang web cho máy tính**.
2. Tạo repository của bạn; chọn Private nếu muốn giữ riêng. Dùng **Add file → Upload files** để tải duy nhất `TendiesVN-source.zip` nguyên dạng ZIP vào thư mục gốc, rồi commit.
3. Chọn **Add file → Create new file**, đặt tên `.github/workflows/build.yml`, dán YAML dưới đây và commit vào nhánh mặc định.

GitHub không tự giải nén ZIP khi upload. Workflow sẽ giải nén trên runner macOS, nên không cần chọn từng tệp mã nguồn hoặc thư mục ẩn trên iPhone. Nếu Safari đã tự giải nén, nén lại cả thư mục `TendiesVN` trong ứng dụng Tệp và đặt tên ZIP đúng như trên.

Có bản YAML để sao chép tại [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml):

```yaml
name: Build IPA from ZIP
on:
  workflow_dispatch:
    inputs:
      bundle_id:
        description: Bundle ID used for this build
        required: false
        default: vn.tendies.wallpaper
        type: string
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-26
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - name: Extract source and build
        env:
          BUNDLE_ID: ${{ inputs.bundle_id || 'vn.tendies.wallpaper' }}
        run: |
          ditto -x -k TendiesVN-source.zip "$RUNNER_TEMP/tendiesvn"
          bash "$RUNNER_TEMP/tendiesvn/TendiesVN/scripts/build-unsigned.sh" --bundle-id "$BUNDLE_ID"
      - uses: actions/upload-artifact@v4
        with:
          name: TendiesVN-unsigned
          path: ${{ runner.temp }}/tendiesvn/TendiesVN/build/TendiesVN-unsigned.ipa
          if-no-files-found: error
```

Mở **Actions**, bật Actions nếu GitHub yêu cầu, rồi chạy **Build IPA from ZIP → Run workflow**. Runner `macos-26` sử dụng hạn mức GitHub của tài khoản; nếu lượt chạy bị chặn do hạn mức, xem thông báo GitHub trước. Chỉ khi lượt chạy thành công mới có IPA trong **Artifacts → TendiesVN-unsigned**.

## Ký và cài trên iPhone

IPA tải về chưa ký. Bạn cần công cụ ký, chứng chỉ `.p12` kèm mật khẩu và profile `.mobileprovision` phù hợp; riêng `.p12` chưa đủ.

1. Nhập chứng chỉ/profile và IPA vào công cụ ký trên iPhone.
2. Giữ ID mặc định **`vn.tendies.wallpaper`**, hoặc chọn ID riêng mà profile cho phép. Công cụ ký phải đặt **Bundle ID và CodeDirectory identifier cùng bằng ID thực tế đó**.
3. Ký rồi cài. Vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển và làm theo yêu cầu khởi động lại nếu xuất hiện.
4. Mở TendiesVN 1.1, kiểm tra quyền truy cập rồi nhập/cài `.tendies` theo [README](README.md).

Bản mới dùng backend `bad_query`, nên không cần giữ ID `com.apple.mobile.MobileHouseArrest` như hướng dẫn của bản cũ. Không đưa chứng chỉ, mật khẩu, khóa riêng hoặc profile lên GitHub; workflow chỉ build IPA chưa ký.

Nếu đổi ID khi ký, profile và chữ ký phải cùng phù hợp với ID mới. Một ID khác nữa sẽ tạo một app/sandbox khác nữa; giữ cùng ID qua các lần cập nhật nếu muốn giữ thư viện và biên nhận trong app đó.

## Giữ dữ liệu và cài song song với 3105

ID mới cho phép cài app riêng mà không thay app 3105 dùng ID MobileHouseArrest. Sandbox của hai app tách biệt, nên gói đã nhập và biên nhận cũ không tự chuyển sang bản mới. Giữ app cũ nếu còn cần dữ liệu hoặc cần gỡ những hình nền mà nó từng cài.

PosterBoard vẫn là dữ liệu chung của thiết bị. TendiesVN chỉ gỡ các descriptor thuộc biên nhận của chính nó; bản mới không tự có biên nhận của 3105 hoặc bản TendiesVN cũ. Việc cài app mở được chưa xác nhận backend có quyền ghi; cần kiểm tra quyền và thử cài/gỡ trên máy.
