# Build và cài TendiesVN 1.3.1 · build 7 khi không có Mac

Dùng GitHub Actions để build trên runner macOS, rồi ký IPA ngay trên iPhone bằng công cụ bạn đang dùng, chẳng hạn ESign. Bundle ID mặc định mới là **`vn.tendies.wallpaper`** để app có thể tồn tại riêng với 3105.

**Trạng thái:** bản 1.3 đã được người dùng thử và vẫn báo TP03: không tìm được ứng viên container dù kernel trả về nhiều đường dẫn. Bản 1.3.1 (build 7) mở rộng cách suy ra thư mục gốc từ đường dẫn tệp con, kiểm tra cặp filesystem bằng sandbox của chính app và bổ sung chẩn đoán. Chưa xác nhận bản này cài được trên iPhone của người dùng; môi trường làm việc này không trực tiếp chạy Xcode hoặc thử thiết bị.

## Đã có workflow: thay ZIP rồi chạy lại

1. Tải **`TendiesVN-source.zip`** bản 1.3.1 (build 7), giữ nguyên dạng ZIP và tên tệp.
2. Trong repository đang dùng, chọn **Add file → Upload files**, tải ZIP mới lên thư mục gốc để thay `TendiesVN-source.zip` cũ, rồi **Commit changes**. Workflow hiện tại đã đọc đúng tên này, không cần sửa YAML.
3. Vào **Actions → Build IPA from ZIP → Run workflow**, chọn nhánh vừa cập nhật và chạy.
4. Trong lượt chạy mới thành công, tải artifact **TendiesVN-unsigned**. Giải nén trong ứng dụng **Tệp** để lấy `TendiesVN-unsigned.ipa`.
5. Ký IPA mới theo phần bên dưới. Không dùng lại artifact của lượt build cũ.

Nếu tải bản có tên **`TendiesVN-1.3.1-build7-source.zip`**, đổi tên thành **`TendiesVN-source.zip`** trước khi tải lên. Hai tên chứa cùng mã nguồn 1.3.1 (7); tên trong lệnh `ditto` phải khớp tên ZIP trong repository. Các dòng sửa `lipo` và bộ chọn tệp trong workflow cũ được giữ tương thích với ZIP mới. Nếu dùng workflow mẫu bên dưới, có thể nhập Bundle ID riêng ở ô `bundle_id`; để mặc định nếu không cần đổi.

## Chưa có repository/workflow

1. Đăng nhập [GitHub](https://github.com) bằng Safari. Nếu thiếu nút, bật **Yêu cầu trang web cho máy tính**.
2. Tạo repository của bạn; chọn Private nếu muốn giữ riêng. Dùng **Add file → Upload files** để tải **`TendiesVN-source.zip`** vào thư mục gốc, rồi commit. Nếu tải bản có tên phiên bản, đổi tên thành `TendiesVN-source.zip` cho khớp mẫu YAML dưới đây.
3. Chọn **Add file → Create new file**, đặt tên `.github/workflows/build.yml`, dán YAML dưới đây và commit vào nhánh mặc định.

GitHub không tự giải nén ZIP khi upload. Workflow sẽ giải nén trên runner macOS, nên không cần chọn từng tệp mã nguồn hoặc thư mục ẩn trên iPhone. Nếu Safari đã tự giải nén, nén lại cả thư mục `TendiesVN` trong ứng dụng Tệp và đặt tên ZIP đúng như trên.

Có bản YAML để sao chép tại [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml):

```yaml
name: Build IPA from ZIP
on:
  workflow_dispatch:
    inputs:
      bundle_id:
        description: Bundle ID used for this build
        required: false
        default: vn.tendies.wallpaper
        type: string
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-26
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - name: Extract source and build
        env:
          BUNDLE_ID: ${{ inputs.bundle_id || 'vn.tendies.wallpaper' }}
        run: |
          ditto -x -k TendiesVN-source.zip "$RUNNER_TEMP/tendiesvn"
          bash "$RUNNER_TEMP/tendiesvn/TendiesVN/scripts/build-unsigned.sh" --bundle-id "$BUNDLE_ID"
      - uses: actions/upload-artifact@v4
        with:
          name: TendiesVN-unsigned
          path: ${{ runner.temp }}/tendiesvn/TendiesVN/build/TendiesVN-unsigned.ipa
          if-no-files-found: error
```

Mở **Actions**, bật Actions nếu GitHub yêu cầu, rồi chạy **Build IPA from ZIP → Run workflow**. Runner `macos-26` sử dụng hạn mức GitHub của tài khoản; nếu lượt chạy bị chặn do hạn mức, xem thông báo GitHub trước. Chỉ khi lượt chạy thành công mới có IPA trong **Artifacts → TendiesVN-unsigned**.

## Ký và cài trên iPhone

IPA tải về chưa ký. Bạn cần công cụ ký, chứng chỉ `.p12` kèm mật khẩu và profile `.mobileprovision` phù hợp; riêng `.p12` chưa đủ.

1. Nhập chứng chỉ/profile và IPA vào công cụ ký trên iPhone.
2. Giữ ID mặc định **`vn.tendies.wallpaper`**, hoặc chọn ID riêng mà profile cho phép. Công cụ ký phải đặt **Bundle ID và CodeDirectory identifier cùng bằng ID thực tế đó**.
3. Ký rồi cài. Vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển và làm theo yêu cầu khởi động lại nếu xuất hiện.
4. Mở TendiesVN, vào Hướng dẫn để kiểm tra phiên bản **1.3.1 (7)**. Nút nhập phải hiện **Nhập .tendies hoặc .zip**. Nếu vẫn hiện bản cũ, kiểm tra ZIP đã thay và artifact vừa tải.

Nếu file `.tendies` vẫn không chọn được, nhấn giữ file trong ứng dụng Tệp → **Nhân bản**, đổi đuôi bản sao thành `.zip` (ví dụ `Family.tendies.zip`) rồi chọn bản sao ZIP trong app. Chỉ đổi đuôi, không nén file gốc vào một ZIP khác.

Bản mới dùng backend `bad_query`, nên không cần giữ ID `com.apple.mobile.MobileHouseArrest` như hướng dẫn của bản cũ. Không đưa chứng chỉ, mật khẩu, khóa riêng hoặc profile lên GitHub; workflow chỉ build IPA chưa ký.

Nếu đổi ID khi ký, profile và chữ ký phải cùng phù hợp với ID mới. Một ID khác nữa sẽ tạo một app/sandbox khác nữa; giữ cùng ID qua các lần cập nhật nếu muốn giữ thư viện và biên nhận trong app đó.

## Nhập gói, cài và cập nhật Bộ sưu tập

1. Trước lần đầu, thêm và dùng một hình nền **Bộ sưu tập** của Apple trong **Cài đặt → Hình nền → Thêm hình nền mới**.
2. Trong TendiesVN, chọn **Nhập .tendies hoặc .zip**, mở gói và bấm **Cài và mở PosterBoard**. App tự tìm PosterBoard và kiểm tra quyền ghi.
3. Sau khi ghi xong, màn chi tiết đóng và app thử mở **PosterBoard**.
4. Tự mở trình đa nhiệm rồi **vuốt đóng thẻ PosterBoard**.
5. Vào **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập** và chọn hình nền mới.

iOS có thể từ chối yêu cầu mở PosterBoard qua API riêng. App không tự mở đa nhiệm hay tự vuốt đóng thẻ. Nếu mở tự động thất bại, đọc hướng dẫn dự phòng trong app: mở phần thêm hình nền của Cài đặt, đóng thẻ PosterBoard trong đa nhiệm nếu có rồi kiểm tra Bộ sưu tập. Nếu chưa cập nhật, khởi động lại thiết bị.

Nếu quyền truy cập hoặc ghi vẫn bị từ chối, đọc thông báo và thử lại **Kiểm tra quyền cài** sau bước khởi tạo hình nền Apple. Mở rộng cách tìm ứng viên chưa bảo đảm có quyền ghi; bản 1.3.1 chưa được xác nhận cài thành công trên iPhone của người dùng.

## Giữ dữ liệu và cài song song với 3105

ID mới cho phép cài app riêng mà không thay app 3105 dùng ID MobileHouseArrest. Sandbox của hai app tách biệt, nên gói đã nhập và biên nhận cũ không tự chuyển sang bản mới. Giữ app cũ nếu còn cần dữ liệu hoặc cần gỡ những hình nền mà nó từng cài.

PosterBoard vẫn là dữ liệu chung của thiết bị. TendiesVN chỉ gỡ các descriptor thuộc biên nhận của chính nó; bản mới không tự có biên nhận của 3105 hoặc bản TendiesVN cũ. Việc cài app mở được chưa xác nhận backend có quyền ghi; cần kiểm tra quyền và thử cài/gỡ trên máy.
