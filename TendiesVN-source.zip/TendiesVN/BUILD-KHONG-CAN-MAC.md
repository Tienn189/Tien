# Build và cài TendiesVN 1.2.1 · build 5 khi không có Mac

Dùng GitHub Actions để build trên runner macOS, rồi ký IPA ngay trên iPhone bằng công cụ bạn đang dùng, chẳng hạn ESign. Bundle ID mặc định mới là **`vn.tendies.wallpaper`** để app có thể tồn tại riêng với 3105.

**Trạng thái:** người dùng đã xác nhận bản 1.2 nhập được gói trên iPhone, nhưng vẫn báo **TP03** dù đã khởi tạo hình nền Apple trong Cài đặt. Bản 1.2.1 (build 5) thêm cách lấy UUID PosterBoard từ 3105 để bỏ qua bước tự tìm. Cách này chưa được xác nhận trên thiết bị đang gặp lỗi; lưu được UUID cũng chưa xác nhận quyền ghi. Môi trường làm việc này không trực tiếp chạy Xcode hoặc thử thiết bị.

## Đã có workflow: kiểm tra tên ZIP trước khi tải lên

1. Tải **`TendiesVN-1.2.1-build5-source.zip`**, giữ nguyên dạng ZIP.
2. Workflow gần nhất đang có dòng `ditto -x -k TendiesVN-1.2.0-build4-source.zip ...`. Chọn một trong hai cách: đổi tên bản ZIP mới thành **`TendiesVN-1.2.0-build4-source.zip`** rồi tải lên thay tệp cũ để giữ nguyên workflow; hoặc giữ tên mới và sửa tên tệp trong dòng `ditto` thành **`TendiesVN-1.2.1-build5-source.zip`**. Sau đó dùng **Add file → Upload files** để tải ZIP vào thư mục gốc và **Commit changes**. Nếu workflow dùng tên `TendiesVN-source.zip`, đổi tên ZIP mới thành tên đó trước khi tải lên.
3. Vào **Actions → Build IPA from ZIP → Run workflow**, chọn nhánh vừa cập nhật và chạy.
4. Trong lượt chạy mới thành công, tải artifact **TendiesVN-unsigned**. Giải nén trong ứng dụng **Tệp** để lấy `TendiesVN-unsigned.ipa`.
5. Ký IPA mới theo phần bên dưới. Không dùng lại artifact của lượt build cũ.

Tên tệp trong lệnh `ditto` phải khớp chính xác tên ZIP trong repository. Nếu chỉ tải lên ZIP tên mới mà workflow vẫn đọc tệp cũ, workflow có thể build lại bản cũ hoặc báo không tìm thấy tệp. Đổi tên ZIP chỉ đổi tên gói mã nguồn; nội dung mới vẫn là **1.2.1 (5)**. Các dòng sửa `lipo` và bộ chọn tệp trong workflow cũ được giữ tương thích với ZIP mới. Nếu dùng workflow mẫu bên dưới, có thể nhập Bundle ID riêng ở ô `bundle_id`; để mặc định nếu không cần đổi.

## Chưa có repository/workflow

1. Đăng nhập [GitHub](https://github.com) bằng Safari. Nếu thiếu nút, bật **Yêu cầu trang web cho máy tính**.
2. Tạo repository của bạn; chọn Private nếu muốn giữ riêng. Đổi tên tệp tải `TendiesVN-1.2.1-build5-source.zip` thành **`TendiesVN-source.zip`** cho khớp mẫu YAML dưới đây. Dùng **Add file → Upload files** để tải ZIP vào thư mục gốc, rồi commit.
3. Chọn **Add file → Create new file**, đặt tên `.github/workflows/build.yml`, dán YAML dưới đây và commit vào nhánh mặc định.

GitHub không tự giải nén ZIP khi upload. Workflow sẽ giải nén trên runner macOS, nên không cần chọn từng tệp mã nguồn hoặc thư mục ẩn trên iPhone. Nếu Safari đã tự giải nén, nén lại cả thư mục `TendiesVN` trong ứng dụng Tệp và đặt tên ZIP đúng như trên.

Có bản YAML để sao chép tại [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml):

```yaml
name: Build IPA from ZIP
on:
  workflow_dispatch:
    inputs:
      bundle_id:
        description: Bundle ID used for this build
        required: false
        default: vn.tendies.wallpaper
        type: string
permissions:
  contents: read
jobs:
  build:
    runs-on: macos-26
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - name: Extract source and build
        env:
          BUNDLE_ID: ${{ inputs.bundle_id || 'vn.tendies.wallpaper' }}
        run: |
          ditto -x -k TendiesVN-source.zip "$RUNNER_TEMP/tendiesvn"
          bash "$RUNNER_TEMP/tendiesvn/TendiesVN/scripts/build-unsigned.sh" --bundle-id "$BUNDLE_ID"
      - uses: actions/upload-artifact@v4
        with:
          name: TendiesVN-unsigned
          path: ${{ runner.temp }}/tendiesvn/TendiesVN/build/TendiesVN-unsigned.ipa
          if-no-files-found: error
```

Mở **Actions**, bật Actions nếu GitHub yêu cầu, rồi chạy **Build IPA from ZIP → Run workflow**. Runner `macos-26` sử dụng hạn mức GitHub của tài khoản; nếu lượt chạy bị chặn do hạn mức, xem thông báo GitHub trước. Chỉ khi lượt chạy thành công mới có IPA trong **Artifacts → TendiesVN-unsigned**.

## Ký và cài trên iPhone

IPA tải về chưa ký. Bạn cần công cụ ký, chứng chỉ `.p12` kèm mật khẩu và profile `.mobileprovision` phù hợp; riêng `.p12` chưa đủ.

1. Nhập chứng chỉ/profile và IPA vào công cụ ký trên iPhone.
2. Giữ ID mặc định **`vn.tendies.wallpaper`**, hoặc chọn ID riêng mà profile cho phép. Công cụ ký phải đặt **Bundle ID và CodeDirectory identifier cùng bằng ID thực tế đó**.
3. Ký rồi cài. Vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển và làm theo yêu cầu khởi động lại nếu xuất hiện.
4. Mở TendiesVN, vào Hướng dẫn để kiểm tra phiên bản **1.2.1 (5)**. Nút nhập phải hiện **Nhập .tendies hoặc .zip**. Nhập/cài gói theo [README](README.md). Nếu vẫn hiện bản cũ, kiểm tra tên ZIP workflow đọc và artifact vừa tải.

Nếu file `.tendies` vẫn không chọn được, nhấn giữ file trong ứng dụng Tệp → **Nhân bản**, đổi đuôi bản sao thành `.zip` (ví dụ `Family.tendies.zip`) rồi chọn bản sao ZIP trong app. Chỉ đổi đuôi, không nén file gốc vào một ZIP khác.

Bản mới dùng backend `bad_query`, nên không cần giữ ID `com.apple.mobile.MobileHouseArrest` như hướng dẫn của bản cũ. Không đưa chứng chỉ, mật khẩu, khóa riêng hoặc profile lên GitHub; workflow chỉ build IPA chưa ký.

Nếu đổi ID khi ký, profile và chữ ký phải cùng phù hợp với ID mới. Một ID khác nữa sẽ tạo một app/sandbox khác nữa; giữ cùng ID qua các lần cập nhật nếu muốn giữ thư viện và biên nhận trong app đó.

## Đã nhập được gói nhưng vẫn gặp TP03

Người dùng đã thử khởi tạo hình nền Apple và vẫn gặp TP03. Nếu có 3105, mở **Hướng dẫn → Khắc phục lỗi TP03** trong TendiesVN 1.2.1 và làm theo phần **Lấy mã từ 3105 trên iPhone**:

1. Trong 3105, vào bánh răng và bật **Chế độ nhà phát triển** nếu chưa có tab **Tệp**.
2. Ở tab **Tệp**, mở **com.apple.PosterBoard**, dừng tại thư mục gốc; không mở `Library` hoặc thư mục con.
3. Chọn **+ → Import nhiều tệp → Hủy**. Thao tác này chỉ tạo dòng đường dẫn trong nhật ký.
4. Quay lại danh sách ứng dụng 3105, mở **bánh răng → Mở nhật ký**, rồi sao chép nhật ký.
5. Trở lại TendiesVN, bấm **Dán** trong phần TP03 rồi **Xác minh và lưu mã**. App lấy UUID từ dòng `import requested destination`. Nếu không dán được cả nhật ký, dán riêng 36 ký tự UUID sau `/Containers/Data/Application/` trong dòng vừa tạo.
6. App tự kiểm tra quyền ghi ngay sau khi xác minh và lưu. Đọc kết quả trước khi thử cài; có thể dùng **Kiểm tra quyền cài** để thử lại.

App xác minh metadata và thư mục gốc đúng PosterBoard trước khi lưu UUID, rồi tự thử quyền ghi. Tên nút của 3105 có thể khác theo phiên bản/ngôn ngữ. Có thể chọn **Bỏ mã, dùng tự tìm** để xóa mã đã lưu. Đây là đường dự phòng cho bước tự tìm, chưa phải cách sửa đã được xác nhận trên thiết bị của người dùng.

## Giữ dữ liệu và cài song song với 3105

ID mới cho phép cài app riêng mà không thay app 3105 dùng ID MobileHouseArrest. Sandbox của hai app tách biệt, nên gói đã nhập và biên nhận cũ không tự chuyển sang bản mới. Giữ app cũ nếu còn cần dữ liệu hoặc cần gỡ những hình nền mà nó từng cài.

PosterBoard vẫn là dữ liệu chung của thiết bị. TendiesVN chỉ gỡ các descriptor thuộc biên nhận của chính nó; bản mới không tự có biên nhận của 3105 hoặc bản TendiesVN cũ. Việc cài app mở được chưa xác nhận backend có quyền ghi; cần kiểm tra quyền và thử cài/gỡ trên máy.
