# Build 1809 · 3.0.0 · bản dựng 11 bằng GitHub Actions

Tên app mới là **1809**. Bản này bỏ hoàn toàn trình chỉnh sửa hình nền, thay bằng giao diện trắng đen có chế độ sáng/tối, mục Cài đặt và quản lý pairing. Bundle ID mặc định vẫn là `vn.tendies.wallpaper` để cập nhật app cũ và giữ dữ liệu.

## Nếu repository đang build từ ZIP

1. Tải ZIP nguồn mới và đặt tên là **`TendiesVN-source.zip`** trước khi tải lên repository. Tên ZIP này được giữ để tương thích workflow cũ.
2. Thay ZIP cùng tên ở thư mục gốc rồi commit.
3. Giữ workflow cũ hoặc dùng mẫu [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml). ZIP mới tạo cả **`build/1809-unsigned.ipa`** và bản sao giống hệt **`build/TendiesVN-unsigned.ipa`**, nên đường dẫn upload cũ vẫn hoạt động.
4. Chạy **Actions → Build IPA from ZIP → Run workflow** để tạo lượt chạy mới trên commit vừa cập nhật. Không chọn **Re-run jobs** của lượt cũ vì lượt đó vẫn dùng ZIP ở commit cũ.
5. Khi build thành công, tải artifact rồi giải nén để lấy IPA. Workflow mẫu mới tạo artifact **1809-unsigned** chứa **`1809-unsigned.ipa`**; workflow cũ có thể giữ tên **TendiesVN-unsigned** và **`TendiesVN-unsigned.ipa`**.

Trong ZIP, thư mục gốc phải là `TendiesVN`; bên trong có `TendiesVN.xcodeproj`, `Config`, `scripts` và mã ứng dụng. Nếu ZIP được tải xuống với tên `1809-source.zip`, đổi tên thành `TendiesVN-source.zip` để khớp workflow.

## Nếu đã giải nén mã nguồn vào repository

Tải toàn bộ mã nguồn và thư mục ẩn `.github` lên repository. Workflow `.github/workflows/unsigned-ios.yml` chạy trực tiếp `scripts/build-unsigned.sh` trên runner `macos-26`. Chạy **Build unsigned iOS IPA** trong Actions để lấy cùng artifact **1809-unsigned**.

## Ký và kiểm tra bản mới

IPA từ Actions chưa có chữ ký. Dùng công cụ ký của bạn với chứng chỉ và profile hợp lệ, cùng Bundle ID mà profile cho phép. Giữ `vn.tendies.wallpaper` khi cập nhật app hiện tại để giữ thư viện và biên nhận. Sau khi cập nhật, mở **Cài đặt** trong 1809 để kiểm tra **Phiên bản ứng dụng: 3.0.0** và **Bản dựng: 11**.

Runner GitHub cần Xcode 26 trở lên; deployment target của app là iOS 17.0. Cả hai workflow chạy kiểm tra giải nén, đường dẫn, chữ ký, tương thích và pairing trước khi build Xcode. Không có bước npm hoặc dựng trình chỉnh sửa web.

## Trạng thái hỗ trợ và pairing

Mục Cài đặt liệt kê phạm vi được yêu cầu: iOS 17.0–17.7, 18.0–18.7.10, 26.0–26.7.0 và 27.0–27.0.1. **Backend hiện tại chỉ hỗ trợ cài hình nền trên iOS/iPadOS 26.0–26.6.1.** iOS 17, iOS 18, iOS 26.6.2–26.7.0 và iOS 27 chưa có backend cài đặt trong bản này; vẫn có thể nhập và xem thông tin gói. Trạng thái **Phiên bản hiện tại** dùng `installationSupported` để phản ánh hỗ trợ cài đặt thực tế, nên các phiên bản chưa có backend hiển thị **Không hỗ trợ**. Ngay trong phạm vi được backend hỗ trợ, quyền truy cập PosterBoard vẫn cần được kiểm tra trên máy thực tế.

iOS 27 trở lên yêu cầu pairing. Mục Pairing có hướng dẫn và thao tác nhập/xóa bản ghi ghép đôi. Tệp pairing đã nhập chỉ là dữ liệu ghép đôi được lưu trong app; bản mã nguồn hiện tại chưa có transport pairing để xác nhận cài hình nền qua pairing trên iOS 27.

Nguồn tham khảo: [Pocket-Poster của leminlimez](https://github.com/leminlimez/Pocket-Poster). Các nguồn backend và giấy phép được giữ trong [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
