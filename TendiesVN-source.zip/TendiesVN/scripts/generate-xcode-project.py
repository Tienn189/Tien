#!/usr/bin/env python3
"""Generate a deterministic Xcode project using only the Python standard library.

Run after adding sources, or use --check to verify the checked-in project.
The ThirdParty Rust tree is built separately and never added to app sources.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sys
from xml.sax.saxutils import escape


ROOT = Path(__file__).resolve().parent.parent
VENDOR = Path("vendor/TendiesWallpaper")
PROJECT = "1809.xcodeproj"
TARGET = "BQTool"


class Ref(str):
    """An unquoted identifier in an OpenStep property list."""


def identifier(label):
    return Ref(hashlib.sha256(label.encode("utf-8")).hexdigest()[:24].upper())


def encode(value, depth=0):
    indent = "\t" * depth
    if isinstance(value, Ref):
        return value
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, list):
        return "(" + ", ".join(encode(v, depth) for v in value) + ("," if value else "") + ")"
    if isinstance(value, dict):
        entries = "\n".join(
            f"{indent}\t{encode(k)} = {encode(v, depth + 1)};" for k, v in value.items()
        )
        return "{\n" + entries + "\n" + indent + "}"
    raise TypeError(type(value))


def generate():
    objects = {}

    def obj(label, isa, **values):
        key = identifier(label)
        objects[key] = {"isa": Ref(isa), **values}
        return key

    def file(path, kind=None, tree="SOURCE_ROOT", name=None):
        values = {"path": str(path), "sourceTree": tree}
        if kind:
            values["lastKnownFileType"] = kind
        if name:
            values["name"] = name
        return obj("file:" + str(path), "PBXFileReference", **values)

    def build_file(reference):
        return obj("build:" + reference, "PBXBuildFile", fileRef=reference)

    def paths(folder, suffixes):
        return sorted(
            (p.relative_to(ROOT) for p in (ROOT / folder).rglob("*") if p.suffix in suffixes),
            key=lambda p: p.as_posix(),
        )

    source_paths = paths(Path("src"), {".m", ".c", ".mm", ".swift"})
    source_paths += paths(VENDOR / "Engine", {".m", ".c", ".mm", ".swift"})
    source_paths += [VENDOR / "DeviceCompatibility.swift"]
    for path in source_paths:
        if not (ROOT / path).is_file():
            raise SystemExit(f"Required source missing: {path}")
    kinds = {".m": "sourcecode.c.objc", ".c": "sourcecode.c.c", ".mm": "sourcecode.cpp.objcpp", ".swift": "sourcecode.swift"}
    sources = [file(p, kinds[p.suffix]) for p in source_paths]
    headers = [file(p, "sourcecode.c.h") for p in paths(Path("src"), {".h"}) + paths(VENDOR / "Engine", {".h"})]
    sources_group = obj("group:sources", "PBXGroup", name="Sources", children=sources + headers, sourceTree="<group>")

    framework_refs = [
        file(f"System/Library/Frameworks/{name}.framework", "wrapper.framework", "SDKROOT", f"{name}.framework")
        for name in ("UIKit", "Foundation", "CoreFoundation", "CoreGraphics", "ImageIO", "AVFoundation", "WebKit", "Security", "SystemConfiguration", "Network", "IOSurface", "CryptoKit")
    ]
    framework_refs += [
        file(f"usr/lib/lib{name}.tbd", "sourcecode.text-based-dylib-definition", "SDKROOT", f"lib{name}.tbd")
        for name in ("z", "c++", "iconv", "resolv")
    ]
    framework_refs.append(file(VENDOR / "AirliftFFI.xcframework", "wrapper.xcframework"))
    frameworks_group = obj("group:frameworks", "PBXGroup", name="Frameworks", children=framework_refs, sourceTree="<group>")

    locales = sorted(p.parent.name[:-6] for p in (ROOT / "src").glob("*.lproj/Localizable.strings"))
    localized = [file(f"src/{locale}.lproj/Localizable.strings", "text.plist.strings", name=locale) for locale in locales]
    strings = obj("resource:strings", "PBXVariantGroup", name="Localizable.strings", children=localized, sourceTree="<group>")
    resources = [strings, file("src/respring.html", "text.html")]
    license_paths = [Path("LICENSE"), Path("THIRD_PARTY_NOTICES.md"), VENDOR / "LICENSE-GPL-3.0.txt", VENDOR / "UPSTREAM_THIRD_PARTY_NOTICES.md"]
    license_paths += sorted((p.relative_to(ROOT) for p in (ROOT / VENDOR / "ThirdParty").glob("*-LICENSE.txt")))
    resources += [file(p, "text") for p in license_paths]
    info = file("src/Info.plist", "text.plist.xml")
    resources_group = obj("group:resources", "PBXGroup", name="Resources", children=resources + [info], sourceTree="<group>")

    product = obj("product", "PBXFileReference", explicitFileType="wrapper.application", includeInIndex=0, path=f"{TARGET}.app", sourceTree="BUILT_PRODUCTS_DIR")
    products = obj("group:products", "PBXGroup", name="Products", children=[product], sourceTree="<group>")
    main = obj("group:main", "PBXGroup", children=[sources_group, resources_group, frameworks_group, products], sourceTree="<group>")
    sources_phase = obj("phase:sources", "PBXSourcesBuildPhase", buildActionMask=2147483647, files=[build_file(s) for s in sources], runOnlyForDeploymentPostprocessing=0)
    resources_phase = obj("phase:resources", "PBXResourcesBuildPhase", buildActionMask=2147483647, files=[build_file(r) for r in resources], runOnlyForDeploymentPostprocessing=0)
    frameworks_phase = obj("phase:frameworks", "PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[build_file(f) for f in framework_refs], runOnlyForDeploymentPostprocessing=0)

    common = {
        "ALWAYS_SEARCH_USER_PATHS": "NO",
        "CLANG_ENABLE_MODULES": "YES",
        "CLANG_ENABLE_OBJC_ARC": "YES",
        "CLANG_ENABLE_OBJC_WEAK": "YES",
        "GCC_C_LANGUAGE_STANDARD": "gnu17",
        "CLANG_CXX_LANGUAGE_STANDARD": "gnu++17",
        "IPHONEOS_DEPLOYMENT_TARGET": "17.0",
        "SDKROOT": "iphoneos",
        "SWIFT_VERSION": "5.0",
        "SWIFT_STRICT_CONCURRENCY": "minimal",
        "ENABLE_BITCODE": "NO",
        "ENABLE_USER_SCRIPT_SANDBOXING": "YES",
    }
    target_settings = {
        "PRODUCT_NAME": TARGET,
        "PRODUCT_MODULE_NAME": TARGET,
        "PRODUCT_BUNDLE_IDENTIFIER": "com.kamui.escape",
        "MARKETING_VERSION": "2.5.0",
        "CURRENT_PROJECT_VERSION": "250",
        "INFOPLIST_FILE": "src/Info.plist",
        "GENERATE_INFOPLIST_FILE": "NO",
        "TARGETED_DEVICE_FAMILY": "1",
        "ARCHS": "arm64",
        "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator",
        "SUPPORTS_MACCATALYST": "NO",
        "CODE_SIGN_STYLE": "Manual",
        "ALWAYS_EMBED_SWIFT_STANDARD_LIBRARIES": "YES",
        "SWIFT_OBJC_BRIDGING_HEADER": str(VENDOR / "Engine/TendiesWallpaper-Bridging-Header.h"),
        "SWIFT_INSTALL_OBJC_HEADER": "NO",
        "HEADER_SEARCH_PATHS": ["$(inherited)", "$(SRCROOT)/src", "$(SRCROOT)/vendor/TendiesWallpaper/Engine", "$(SRCROOT)/vendor/TendiesWallpaper/Engine/KernelExploit"],
        # PBXFrameworksBuildPhase processes the XCFramework and exposes its
        # modulemap through BUILT_PRODUCTS_DIR/include. Adding a source slice
        # here exposes a second modulemap and breaks Xcode's dependency scan.
        "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
        "OTHER_CFLAGS": ["$(inherited)", "-Wno-unused-parameter", "-Wno-deprecated-declarations"],
    }
    configs = {"project": [], "target": []}
    for name in ("Debug", "Release"):
        debug = name == "Debug"
        settings = {**common, "DEBUG_INFORMATION_FORMAT": "dwarf" if debug else "dwarf-with-dsym", "GCC_OPTIMIZATION_LEVEL": "0" if debug else "s", "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if debug else "-O"}
        if debug:
            settings.update({"SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG", "GCC_PREPROCESSOR_DEFINITIONS": ["$(inherited)", "DEBUG=1"], "ENABLE_TESTABILITY": "YES"})
        else:
            settings.update({"SWIFT_COMPILATION_MODE": "wholemodule", "ENABLE_NS_ASSERTIONS": "NO"})
        configs["project"].append(obj(f"config:project:{name}", "XCBuildConfiguration", name=name, buildSettings=settings))
        configs["target"].append(obj(f"config:target:{name}", "XCBuildConfiguration", name=name, buildSettings=target_settings))

    config_lists = {scope: obj(f"configs:{scope}", "XCConfigurationList", buildConfigurations=items, defaultConfigurationIsVisible=0, defaultConfigurationName="Release") for scope, items in configs.items()}
    target = obj("target", "PBXNativeTarget", name=TARGET, productName=TARGET, productReference=product, productType="com.apple.product-type.application", buildConfigurationList=config_lists["target"], buildPhases=[sources_phase, frameworks_phase, resources_phase], buildRules=[], dependencies=[])
    project = obj("project", "PBXProject", attributes={"BuildIndependentTargetsInParallel": "YES", "LastSwiftUpdateCheck": "2600", "LastUpgradeCheck": "2600"}, buildConfigurationList=config_lists["project"], compatibilityVersion="Xcode 14.0", developmentRegion="en", hasScannedForEncodings=0, knownRegions=locales + ["Base"], mainGroup=main, productRefGroup=products, projectDirPath="", projectRoot="", targets=[target])
    document = {"archiveVersion": 1, "classes": {}, "objectVersion": 56, "objects": dict(sorted(objects.items(), key=lambda item: (item[1]["isa"], item[0]))), "rootObject": project}
    project_text = "// !$*UTF8*$!\n" + encode(document) + "\n"
    scheme = f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2600" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES">
    <BuildActionEntries>
      <BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">
        <BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="{TARGET}.app" BlueprintName="{TARGET}" ReferencedContainer="container:{escape(PROJECT)}"/>
      </BuildActionEntry>
    </BuildActionEntries>
  </BuildAction>
  <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES">
    <BuildableProductRunnable runnableDebuggingMode="0">
      <BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="{TARGET}.app" BlueprintName="{TARGET}" ReferencedContainer="container:{escape(PROJECT)}"/>
    </BuildableProductRunnable>
  </LaunchAction>
  <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/>
  <AnalyzeAction buildConfiguration="Debug"/>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
'''
    return {ROOT / PROJECT / "project.pbxproj": project_text, ROOT / PROJECT / "xcshareddata/xcschemes" / f"{TARGET}.xcscheme": scheme}, len(source_paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="fail if generated files differ")
    args = parser.parse_args()
    outputs, source_count = generate()
    stale = []
    for path, content in outputs.items():
        if args.check:
            if not path.exists() or path.read_text(encoding="utf-8") != content:
                stale.append(str(path.relative_to(ROOT)))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
    if stale:
        print("Run scripts/generate-xcode-project.py to update: " + ", ".join(stale), file=sys.stderr)
        return 1
    print(f"{'Checked' if args.check else 'Generated'} {PROJECT}: {source_count} app sources; Rust dependencies excluded")
    return 0


if __name__ == "__main__":
    sys.exit(main())
