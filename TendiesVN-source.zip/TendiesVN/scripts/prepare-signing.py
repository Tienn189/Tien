#!/usr/bin/env python3
"""Validate an installed enterprise signing identity and its matching profile."""

import argparse
import hashlib
from pathlib import Path
import plistlib
import re
import subprocess
import sys
from signing_common import DEFAULT_BUNDLE_ID, bundle_identifier, profile_metadata


def prepare(profile_path: Path, requested_identity: str, options_path: Path,
            bundle_id: str = DEFAULT_BUNDLE_ID) -> tuple[str, str, str]:
    bundle_identifier(bundle_id)
    decoded = subprocess.run(
        ["security", "cms", "-D", "-i", str(profile_path)],
        check=True, capture_output=True,
    )
    profile = plistlib.loads(decoded.stdout)
    team, uuid = profile_metadata(profile, bundle_id)
    output = subprocess.run(
        ["security", "find-identity", "-v", "-p", "codesigning"],
        check=True, capture_output=True, text=True,
    ).stdout
    identities = re.findall(r'^\s*\d+\) ([0-9A-Fa-f]{40}) "([^"]+)"', output, flags=re.MULTILINE)
    matches = [fingerprint.upper() for fingerprint, name in identities
               if requested_identity.upper() == fingerprint.upper() or requested_identity == name]
    if len(matches) != 1:
        raise ValueError("Identity must match exactly one valid installed code signing certificate/private key; use its SHA-1 hash if names repeat.")
    fingerprint = matches[0]
    profile_certificates = {hashlib.sha1(cert).hexdigest().upper()
                            for cert in profile.get("DeveloperCertificates", []) if isinstance(cert, bytes)}
    if fingerprint not in profile_certificates:
        raise ValueError("Installed signing identity is not included in this provisioning profile.")
    options = {
        "method": "enterprise",
        "destination": "export",
        "signingStyle": "manual",
        "signingCertificate": fingerprint,
        "teamID": team,
        "provisioningProfiles": {bundle_id: uuid},
        "stripSwiftSymbols": True,
        "thinning": "<none>",
    }
    options_path.parent.mkdir(parents=True, exist_ok=True)
    with options_path.open("wb") as handle:
        plistlib.dump(options, handle)
    return team, uuid, fingerprint


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", required=True, type=Path)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--export-options", required=True, type=Path)
    parser.add_argument("--bundle-id", default=DEFAULT_BUNDLE_ID, help="Bundle ID permitted by the profile")
    args = parser.parse_args()
    try:
        values = prepare(args.profile, args.identity, args.export_options, args.bundle_id)
    except (OSError, ValueError, plistlib.InvalidFileException, subprocess.CalledProcessError) as exc:
        print(f"Signing validation failed: {exc}", file=sys.stderr)
        return 1
    print("\t".join(values))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
