#!/usr/bin/env python3
"""Validate an installed enterprise signing identity and its matching profile."""

import argparse
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import plistlib
import re
import subprocess
import sys
from uuid import UUID

BUNDLE_ID = "com.apple.mobile.MobileHouseArrest"


def prepare(profile_path: Path, requested_identity: str, options_path: Path) -> tuple[str, str, str]:
    decoded = subprocess.run(
        ["security", "cms", "-D", "-i", str(profile_path)],
        check=True, capture_output=True,
    )
    profile = plistlib.loads(decoded.stdout)
    if profile.get("ProvisionsAllDevices") is not True:
        raise ValueError("Profile must be an enterprise distribution profile (ProvisionsAllDevices).")
    expiry = profile.get("ExpirationDate")
    if not isinstance(expiry, datetime) or expiry.replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc):
        raise ValueError("Provisioning profile has expired or has no valid expiration date.")
    teams = profile.get("TeamIdentifier", [])
    prefixes = profile.get("ApplicationIdentifierPrefix", [])
    uuid = profile.get("UUID")
    if not teams or not prefixes or not isinstance(uuid, str) or not uuid:
        raise ValueError("Profile is missing a team, application prefix or UUID.")
    uuid = str(UUID(uuid)).upper()
    team = teams[0]
    if not isinstance(team, str) or not re.fullmatch(r"[A-Z0-9]{10}", team):
        raise ValueError("Profile contains an invalid team identifier.")
    entitlements = profile.get("Entitlements", {})
    if entitlements.get("get-task-allow", False):
        raise ValueError("Profile must disable get-task-allow for distribution.")
    app_id = entitlements.get("application-identifier", "")
    allowed = False
    for prefix in prefixes:
        if not isinstance(prefix, str) or not app_id.startswith(prefix + "."):
            continue
        suffix = app_id[len(prefix) + 1:]
        if suffix == BUNDLE_ID or (suffix.endswith("*") and "*" not in suffix[:-1] and BUNDLE_ID.startswith(suffix[:-1])):
            allowed = True
    if not allowed:
        raise ValueError(f"Profile does not permit {BUNDLE_ID}. An enterprise certificate alone is insufficient.")
    output = subprocess.run(
        ["security", "find-identity", "-v", "-p", "codesigning"],
        check=True, capture_output=True, text=True,
    ).stdout
    identities = re.findall(r'^\s*\d+\) ([0-9A-Fa-f]{40}) "([^"]+)"', output, flags=re.MULTILINE)
    matches = [fingerprint.upper() for fingerprint, name in identities
               if requested_identity.upper() == fingerprint.upper() or requested_identity == name]
    if len(matches) != 1:
        raise ValueError("Identity must match exactly one valid installed code signing certificate/private key; use its SHA-1 hash if names repeat.")
    fingerprint = matches[0]
    profile_certificates = {hashlib.sha1(cert).hexdigest().upper()
                            for cert in profile.get("DeveloperCertificates", []) if isinstance(cert, bytes)}
    if fingerprint not in profile_certificates:
        raise ValueError("Installed signing identity is not included in this provisioning profile.")
    options = {
        "method": "enterprise",
        "destination": "export",
        "signingStyle": "manual",
        "signingCertificate": fingerprint,
        "teamID": team,
        "provisioningProfiles": {BUNDLE_ID: uuid},
        "stripSwiftSymbols": True,
        "thinning": "<none>",
    }
    options_path.parent.mkdir(parents=True, exist_ok=True)
    with options_path.open("wb") as handle:
        plistlib.dump(options, handle)
    return team, uuid, fingerprint


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", required=True, type=Path)
    parser.add_argument("--identity", required=True)
    parser.add_argument("--export-options", required=True, type=Path)
    args = parser.parse_args()
    try:
        values = prepare(args.profile, args.identity, args.export_options)
    except (OSError, ValueError, plistlib.InvalidFileException, subprocess.CalledProcessError) as exc:
        print(f"Signing validation failed: {exc}", file=sys.stderr)
        return 1
    print("\t".join(values))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
