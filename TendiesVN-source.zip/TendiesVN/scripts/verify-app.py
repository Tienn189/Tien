#!/usr/bin/env python3
"""Reject missing/stub products and accidental installer identity changes."""

import argparse
from pathlib import Path
import plistlib
import subprocess
import sys

BUNDLE_ID = "com.apple.mobile.MobileHouseArrest"
MACHO_MAGICS = {
    b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf",  # Mach-O 64-bit
    b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",  # universal
    b"\xca\xfe\xba\xbf", b"\xbf\xba\xfe\xca",  # universal 64-bit
}


def verify_app(app: Path, require_signature: bool) -> None:
    with (app / "Info.plist").open("rb") as handle:
        info = plistlib.load(handle)
    if info.get("CFBundleIdentifier") != BUNDLE_ID:
        raise ValueError(f"CFBundleIdentifier must remain {BUNDLE_ID}.")
    name = info.get("CFBundleExecutable")
    if not isinstance(name, str) or not name or Path(name).name != name:
        raise ValueError("CFBundleExecutable is invalid.")
    executable = app / name
    with executable.open("rb") as handle:
        if handle.read(4) not in MACHO_MAGICS:
            raise ValueError("App executable is not a built 64-bit Mach-O binary.")
    if not executable.stat().st_mode & 0o111:
        raise ValueError("App binary is not executable.")
    if require_signature:
        subprocess.run(["codesign", "--verify", "--deep", "--strict", str(app)], check=True)
        description = subprocess.run(
            ["codesign", "--display", "--verbose=4", str(app)],
            check=True, capture_output=True, text=True,
        )
        lines = (description.stdout + "\n" + description.stderr).splitlines()
        if f"Identifier={BUNDLE_ID}" not in lines:
            raise ValueError(f"CodeDirectory identifier must remain {BUNDLE_ID}.")
        if "Signature=adhoc" in lines:
            raise ValueError("An ad hoc signature cannot be used for enterprise installation.")
        profile = app / "embedded.mobileprovision"
        decoded = subprocess.run(
            ["security", "cms", "-D", "-i", str(profile)],
            check=True, capture_output=True,
        )
        provisioning = plistlib.loads(decoded.stdout)
        if provisioning.get("ProvisionsAllDevices") is not True:
            raise ValueError("Embedded profile is not an enterprise distribution profile.")
        entitlements = provisioning.get("Entitlements", {})
        if entitlements.get("get-task-allow", False):
            raise ValueError("Embedded profile permits debugging rather than distribution.")
    print(f"Verified {app.name}: {BUNDLE_ID}" + ("; enterprise signature present" if require_signature else ""))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("app", type=Path)
    parser.add_argument("--require-signature", action="store_true")
    args = parser.parse_args()
    try:
        verify_app(args.app, args.require_signature)
    except (OSError, ValueError, plistlib.InvalidFileException, subprocess.CalledProcessError) as exc:
        print(f"Verification failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
