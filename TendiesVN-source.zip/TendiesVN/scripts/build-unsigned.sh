#!/bin/bash
# Build a real arm64 application on macOS, then package it for external signing.
set -euo pipefail

BUNDLE_ID="vn.tendies.wallpaper"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --bundle-id) [[ $# -ge 2 ]] || { echo "Missing value for --bundle-id" >&2; exit 2; }; BUNDLE_ID="$2"; shift 2 ;;
    -h|--help) echo "Usage: $0 [--bundle-id vn.tendies.wallpaper]"; exit 0 ;;
    *) echo "Usage: $0 [--bundle-id vn.tendies.wallpaper]" >&2; exit 2 ;;
  esac
done
if [[ ! "$BUNDLE_ID" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]]; then
  echo "Invalid Bundle ID: use dot-separated letters, numbers or hyphens." >&2
  exit 2
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build"
APP_DIR="$BUILD_DIR/DerivedData/Build/Products/Release-iphoneos/1809.app"

if [[ "$(uname -s)" != Darwin ]]; then
  echo "This build requires macOS with Xcode 26 or newer; no IPA was generated." >&2
  exit 1
fi
if ! xcrun --find xcodebuild >/dev/null 2>&1; then
  echo "Select Xcode 26 or newer with xcode-select before building." >&2
  exit 1
fi
XCODE_VERSION="$(xcodebuild -version)"
if [[ ! "$XCODE_VERSION" =~ ^Xcode[[:space:]]+([0-9]+) ]] || (( BASH_REMATCH[1] < 26 )); then
  echo "This source requires Xcode 26 or newer. Select a supported Xcode with xcode-select." >&2
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required for build verification." >&2
  exit 1
fi
echo "$XCODE_VERSION"

mkdir -p "$BUILD_DIR"
# Rebuild Airlift from the pinned source when the macOS runner has Rust.
# The bundled fallback remains usable on offline/local builds.
python3 "$ROOT_DIR/scripts/prepare-idevice.py" --platform iphoneos
if [[ -x "$ROOT_DIR/scripts/build-airlift.sh" ]]; then
  "$ROOT_DIR/scripts/build-airlift.sh"
fi
if xcodebuild \
  -project "$ROOT_DIR/TendiesVN.xcodeproj" \
  -scheme TendiesVN \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$BUILD_DIR/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY= \
  "PRODUCT_BUNDLE_IDENTIFIER=$BUNDLE_ID" \
  build 2>&1 | tee "$BUILD_DIR/xcodebuild.log"; then
  :
else
  BUILD_STATUS=$?
  python3 "$ROOT_DIR/scripts/summarize-build-log.py" "$BUILD_DIR/xcodebuild.log" || true
  exit "$BUILD_STATUS"
fi

python3 "$ROOT_DIR/scripts/verify-app.py" "$APP_DIR" --bundle-id "$BUNDLE_ID"
EXECUTABLE_NAME=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APP_DIR/Info.plist")
# lipo treats every argument after -verify_arch as an architecture name.
# Input paths must precede this option (see lipo(1)).
xcrun lipo "$APP_DIR/$EXECUTABLE_NAME" -verify_arch arm64

STAGING_DIR="$(mktemp -d "$BUILD_DIR/.unsigned-stage.XXXXXX")"
trap 'rm -rf "$STAGING_DIR"' EXIT
mkdir "$STAGING_DIR/Payload"
ditto "$APP_DIR" "$STAGING_DIR/Payload/1809.app"
ditto -c -k --keepParent "$STAGING_DIR/Payload" "$STAGING_DIR/1809-unsigned.ipa"
mv -f "$STAGING_DIR/1809-unsigned.ipa" "$BUILD_DIR/1809-unsigned.ipa"
# Existing ZIP workflows upload this legacy filename. Keep the same verified
# 1809 application available there so updating only the source ZIP still works.
cp "$BUILD_DIR/1809-unsigned.ipa" "$STAGING_DIR/TendiesVN-unsigned.ipa"
mv -f "$STAGING_DIR/TendiesVN-unsigned.ipa" "$BUILD_DIR/TendiesVN-unsigned.ipa"
echo "Created $BUILD_DIR/1809-unsigned.ipa"
echo "Created compatibility copy $BUILD_DIR/TendiesVN-unsigned.ipa"
echo "This IPA is unsigned. Sign it with a valid matching Apple identity and provisioning profile before installation."
