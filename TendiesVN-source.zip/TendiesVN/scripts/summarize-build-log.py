#!/usr/bin/env python3
"""Show the first Xcode error and its context after a failed build."""
from pathlib import Path
import re
import sys


def first_error_context(lines, count=10):
    for index, line in enumerate(lines):
        if re.search(r"\b(?:fatal )?error:", line):
            return lines[index:index + count]
    return []


def main():
    path = Path(sys.argv[1])
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    print("\n--- First Xcode error ---")
    context = first_error_context(lines)
    print("\n".join(context) if context else "No error: diagnostic found; inspect the complete build log.")
    print(f"Full log: {path}")


if __name__ == "__main__":
    main()
