#!/bin/bash
# Rebuild the bundled Airlift FFI with the iOS 27 ATC framing fix.
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AIRLIFT_DIR="$ROOT_DIR/ThirdParty/AirliftSource"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Airlift rebuild skipped: requires macOS and Xcode." >&2
  exit 0
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "Airlift rebuild skipped: xcodebuild not found; using bundled framework." >&2
  exit 0
fi
export PATH="$HOME/.cargo/bin:$PATH"
if ! command -v rustup >/dev/null 2>&1; then
  echo "Rustup not found; installing the minimal stable Rust toolchain for the Airlift rebuild." >&2
  curl --fail --silent --show-error --location https://sh.rustup.rs | sh -s -- -y --profile minimal
  export PATH="$HOME/.cargo/bin:$PATH"
fi
if ! command -v cargo >/dev/null 2>&1 || ! command -v rustup >/dev/null 2>&1; then
  echo "Airlift rebuild failed: Rust toolchain unavailable. Refusing to use the old iOS 27 framework." >&2
  exit 1
fi
rustup toolchain install stable --profile minimal
export RUSTUP_TOOLCHAIN=stable
cd "$AIRLIFT_DIR/rust-core"
rustup target add aarch64-apple-ios aarch64-apple-ios-sim
cargo build --release --target aarch64-apple-ios
cargo build --release --target aarch64-apple-ios-sim

OUT="$ROOT_DIR/AirliftFFI.xcframework"
rm -rf "$OUT"
xcodebuild -create-xcframework \
  -library "$AIRLIFT_DIR/rust-core/target/aarch64-apple-ios/release/libairlift_ffi.a" \
  -headers "$AIRLIFT_DIR/rust-core/include" \
  -library "$AIRLIFT_DIR/rust-core/target/aarch64-apple-ios-sim/release/libairlift_ffi.a" \
  -headers "$AIRLIFT_DIR/rust-core/include" \
  -output "$OUT"
