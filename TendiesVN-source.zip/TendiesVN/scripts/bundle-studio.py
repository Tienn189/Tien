#!/usr/bin/env python3
"""Package the prebuilt offline editor as one Xcode resource.

Run npm ci && npm run build in Studio first. GitHub's iOS build consumes this
resource directly and does not need to install web dependencies.
"""
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "Studio/dist"
OUTPUT = ROOT / "TendiesVN/Resources/StudioEditor.zip"

if not (DIST / "index.html").is_file():
    raise SystemExit("Build Studio first: cd Studio && npm ci && npm run build")

html = (DIST / "index.html").read_text()
# A single classic IIFE avoids file:// module CORS in WKWebView.
html = re.sub(r'\s+type="module"', " defer", html)
html = re.sub(r'\s+crossorigin(?:="[^"]*")?', "", html)
policy = (
    "default-src 'self' blob: data:; script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; "
    "media-src 'self' blob: data:; font-src 'self' data:; connect-src 'none'; "
    "frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'"
)
html = html.replace("<head>", '<head>\n    <meta http-equiv="Content-Security-Policy" content="' + policy + '">', 1)
OUTPUT.parent.mkdir(parents=True, exist_ok=True)

license_packages = ["react", "react-dom", "scheduler", "jszip", "pako", "lie", "immediate", "setimmediate", "readable-stream", "lucide-react"]
notices = ["TendiesVN Studio — runtime third-party notices\n"]
for name in license_packages:
    directory = ROOT / "Studio/node_modules" / name
    matches = sorted(p for p in directory.glob("*") if p.is_file() and p.name.lower().startswith(("license", "copying")))
    for path in matches:
        notices.append(f"\n--- {name}/{path.name} ---\n" + path.read_text(errors="replace"))

with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    archive.writestr("index.html", html)
    for path in sorted(DIST.rglob("*")):
        if path.is_file() and path.name != "index.html" and not path.name.endswith(".map"):
            archive.write(path, path.relative_to(DIST))
    archive.writestr("STUDIO_THIRD_PARTY.txt", "\n".join(notices))

with zipfile.ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    assert 'type="module"' not in archive.read("index.html").decode()
print(f"Created {OUTPUT.relative_to(ROOT)} ({OUTPUT.stat().st_size:,} bytes)")
