#!/usr/bin/env python3
"""Run all source regression suites with the same command locally and in CI.

Each suite runs in a separate interpreter so native fixtures and command-line
arguments cannot affect another suite. Platform-specific suites report their
own skipped checks when the required Apple SDK or Swift compiler is missing.
"""

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    suites = [ROOT / "scripts/test-signing.py", *sorted((ROOT / "tests").glob("test_*.py"))]
    failures = []
    for suite in suites:
        print(f"Running {suite.relative_to(ROOT)}", flush=True)
        result = subprocess.run([sys.executable, str(suite)], cwd=ROOT)
        if result.returncode:
            failures.append(str(suite.relative_to(ROOT)))
    if failures:
        print("Failed suites: " + ", ".join(failures), file=sys.stderr)
        return 1
    print(f"Completed {len(suites)} regression suites; see individual skip notices above.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
