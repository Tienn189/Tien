#!/usr/bin/env python3
"""Create an enterprise OTA manifest referencing an already signed, hosted IPA."""

import argparse
from pathlib import Path
import plistlib
import sys
from urllib.parse import urlsplit

from signing_common import DEFAULT_BUNDLE_ID, bundle_identifier


def https_url(value: str) -> str:
    try:
        parsed = urlsplit(value)
        port = parsed.port  # Validate malformed port syntax.
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Invalid HTTPS URL: {exc}") from exc
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username is not None
            or parsed.password is not None or parsed.fragment or any(c.isspace() or ord(c) < 32 for c in value)
            or (port is not None and not 1 <= port <= 65535)):
        raise argparse.ArgumentTypeError("IPA URL must be an absolute HTTPS URL without credentials, whitespace or a fragment.")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ipa-url", required=True, type=https_url)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--title", default="1809")
    parser.add_argument("--version", default="16", help="CFBundleVersion of the signed IPA (default: 16)")
    parser.add_argument("--bundle-id", default=DEFAULT_BUNDLE_ID, help="Bundle ID of the signed IPA")
    args = parser.parse_args()
    try:
        bundle_id = bundle_identifier(args.bundle_id)
    except ValueError as exc:
        parser.error(str(exc))
    manifest = {"items": [{
        "assets": [{"kind": "software-package", "url": args.ipa_url}],
        "metadata": {"bundle-identifier": bundle_id, "bundle-version": args.version,
                     "kind": "software", "title": args.title},
    }]}
    try:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("wb") as handle:
            plistlib.dump(manifest, handle, sort_keys=False)
    except OSError as exc:
        print(f"Cannot write manifest: {exc}", file=sys.stderr)
        return 1
    print(f"Created {args.output}. Host this manifest at an HTTPS URL for itms-services installation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
