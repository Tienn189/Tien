#!/bin/bash
# Use an already installed enterprise identity and provisioning profile.
set -euo pipefail

usage() {
  echo "Usage: $0 --profile /path/profile.mobileprovision --identity 'Apple Distribution: Name (TEAMID)' [--bundle-id vn.tendies.wallpaper]" >&2
}

PROFILE_PATH=""
SIGNING_IDENTITY=""
BUNDLE_ID="vn.tendies.wallpaper"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile) [[ $# -ge 2 ]] || { usage; exit 2; }; PROFILE_PATH="$2"; shift 2 ;;
    --identity) [[ $# -ge 2 ]] || { usage; exit 2; }; SIGNING_IDENTITY="$2"; shift 2 ;;
    --bundle-id) [[ $# -ge 2 ]] || { usage; exit 2; }; BUNDLE_ID="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) usage; exit 2 ;;
  esac
done
if [[ ! "$BUNDLE_ID" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]]; then
  echo "Invalid Bundle ID: use dot-separated letters, numbers or hyphens." >&2
  exit 2
fi
if [[ -z "$PROFILE_PATH" || -z "$SIGNING_IDENTITY" ]]; then
  usage
  exit 2
fi
if [[ "$(uname -s)" != Darwin ]] || ! xcrun --find xcodebuild >/dev/null 2>&1; then
  echo "Enterprise export requires macOS with Xcode 26 or newer." >&2
  exit 1
fi
XCODE_VERSION="$(xcodebuild -version)"
if [[ ! "$XCODE_VERSION" =~ ^Xcode[[:space:]]+([0-9]+) ]] || (( BASH_REMATCH[1] < 26 )); then
  echo "Enterprise export requires Xcode 26 or newer. Select a supported Xcode with xcode-select." >&2
  exit 1
fi
if [[ ! -f "$PROFILE_PATH" ]]; then
  echo "The specified provisioning profile does not exist." >&2
  exit 1
fi
echo "$XCODE_VERSION"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build"
ARCHIVE_PATH="$BUILD_DIR/1809.xcarchive"
EXPORT_DIR="$BUILD_DIR/enterprise"
OPTIONS_PATH="$BUILD_DIR/enterprise-export-options.plist"
mkdir -p "$BUILD_DIR"
python3 "$ROOT_DIR/scripts/prepare-idevice.py" --platform iphoneos

SIGNING_VALUES="$(python3 "$ROOT_DIR/scripts/prepare-signing.py" \
  --profile "$PROFILE_PATH" --identity "$SIGNING_IDENTITY" --export-options "$OPTIONS_PATH" --bundle-id "$BUNDLE_ID")"
IFS=$'\t' read -r TEAM_ID PROFILE_UUID CERTIFICATE_SHA1 <<< "$SIGNING_VALUES"

# Xcode resolves manual profiles by UUID from its profile store, rather than
# reading the --profile argument supplied to this script. Xcode 16+ uses this
# location. Install only after the matching identity/profile has been checked.
PROFILE_DIRECTORY="$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles"
PROFILE_DESTINATION="$PROFILE_DIRECTORY/$PROFILE_UUID.mobileprovision"
mkdir -p "$PROFILE_DIRECTORY"
if [[ ! "$PROFILE_PATH" -ef "$PROFILE_DESTINATION" ]]; then
  cp "$PROFILE_PATH" "$PROFILE_DESTINATION"
  chmod 600 "$PROFILE_DESTINATION"
fi
echo "Installed the validated enterprise provisioning profile for Xcode."

xcodebuild \
  -project "$ROOT_DIR/TendiesVN.xcodeproj" \
  -scheme TendiesVN \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$BUILD_DIR/SignedDerivedData" \
  -archivePath "$ARCHIVE_PATH" \
  CODE_SIGN_STYLE=Manual \
  "DEVELOPMENT_TEAM=$TEAM_ID" \
  "PROVISIONING_PROFILE_SPECIFIER=$PROFILE_UUID" \
  "CODE_SIGN_IDENTITY=$CERTIFICATE_SHA1" \
  "PRODUCT_BUNDLE_IDENTIFIER=$BUNDLE_ID" \
  archive

python3 "$ROOT_DIR/scripts/verify-app.py" \
  "$ARCHIVE_PATH/Products/Applications/1809.app" --require-signature --bundle-id "$BUNDLE_ID"

xcodebuild -exportArchive \
  -archivePath "$ARCHIVE_PATH" \
  -exportPath "$EXPORT_DIR" \
  -exportOptionsPlist "$OPTIONS_PATH"

IPA_PATH="$EXPORT_DIR/1809.ipa"
if [[ ! -f "$IPA_PATH" ]]; then
  echo "Xcode did not produce the expected $IPA_PATH." >&2
  exit 1
fi
STAGING_DIR="$(mktemp -d "$BUILD_DIR/.verify-export.XXXXXX")"
trap 'rm -rf "$STAGING_DIR"' EXIT
ditto -x -k "$IPA_PATH" "$STAGING_DIR"
python3 "$ROOT_DIR/scripts/verify-app.py" "$STAGING_DIR/Payload/1809.app" --require-signature --bundle-id "$BUNDLE_ID"
echo "Created and verified $IPA_PATH"
