"""Shared identifier and enterprise provisioning profile validation."""

from datetime import datetime, timezone
import re
from uuid import UUID

DEFAULT_BUNDLE_ID = "vn.tendies.wallpaper"


def bundle_identifier(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", value):
        raise ValueError("Bundle ID must contain dot-separated letters, numbers or hyphens, without wildcards.")
    return value


def profile_metadata(profile: dict, bundle_id: str) -> tuple[str, str]:
    """Check the profile permits this product; return team ID and profile UUID."""
    bundle_identifier(bundle_id)
    if profile.get("ProvisionsAllDevices") is not True:
        raise ValueError("Profile must be an enterprise distribution profile (ProvisionsAllDevices).")
    expiry = profile.get("ExpirationDate")
    if not isinstance(expiry, datetime):
        raise ValueError("Provisioning profile has no valid expiration date.")
    if expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=timezone.utc)
    if expiry <= datetime.now(timezone.utc):
        raise ValueError("Provisioning profile has expired.")
    teams = profile.get("TeamIdentifier", [])
    prefixes = profile.get("ApplicationIdentifierPrefix", [])
    uuid = profile.get("UUID")
    if not isinstance(teams, list) or not teams or not isinstance(prefixes, list) or not prefixes or not isinstance(uuid, str):
        raise ValueError("Profile is missing a team, application prefix or UUID.")
    uuid = str(UUID(uuid)).upper()
    team = teams[0]
    if not isinstance(team, str) or not re.fullmatch(r"[A-Z0-9]{10}", team):
        raise ValueError("Profile contains an invalid team identifier.")
    entitlements = profile.get("Entitlements", {})
    if not isinstance(entitlements, dict):
        raise ValueError("Profile entitlements are invalid.")
    if entitlements.get("get-task-allow", False):
        raise ValueError("Profile must disable get-task-allow for distribution.")
    entitlement_team = entitlements.get("com.apple.developer.team-identifier")
    if entitlement_team is not None and entitlement_team != team:
        raise ValueError("Provisioning profile entitlement team does not match its team identifier.")
    app_id = entitlements.get("application-identifier", "")
    if not isinstance(app_id, str):
        raise ValueError("Profile contains an invalid application identifier.")
    allowed = False
    for prefix in prefixes:
        if not isinstance(prefix, str) or not app_id.startswith(prefix + "."):
            continue
        suffix = app_id[len(prefix) + 1:]
        if suffix == bundle_id or (suffix.endswith("*") and "*" not in suffix[:-1] and bundle_id.startswith(suffix[:-1])):
            allowed = True
    if not allowed:
        raise ValueError(f"Profile does not permit {bundle_id}. A matching provisioning profile is required.")
    return team, uuid
