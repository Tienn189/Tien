# 1809 · 3.3.1 · bản dựng 16

Ứng dụng iPhone/iPad quản lý gói hình nền `.tendies` và `.zip`: nhập gói, xem ảnh/video bên trong, lưu tệp gốc vào Ảnh hoặc chia sẻ để lưu vào Tệp, rồi tự đặt hình nền trong Cài đặt iOS.

**Phần hình nền chỉ dùng API công khai.** Không có cài trực tiếp vào kho hình nền hệ thống, mã khai thác kernel, cấp sandbox extension hoặc trình mở PosterBoard bằng API riêng. Trình chỉnh sửa hình nền đã được bỏ.

Bản dựng 16 sửa cách khởi tạo SwiftUI Section có cả header/footer ở trang hướng dẫn. Build lỗi sẽ giữ mã thoát, lưu `build/xcodebuild.log` và in lại các lỗi compiler đầu tiên ở cuối log; workflow mẫu tải log thành artifact `1809-build-log`. Có bài type-check trang hướng dẫn bằng iOS SDK trên CI macOS.

Nguồn định dạng/tham khảo: [Pocket-Poster — leminlimez](https://github.com/leminlimez/Pocket-Poster) và [3105 — YangJiii](https://github.com/YangJiiii/3105). Nguồn gốc mã và giấy phép: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## Chức năng trong bản nguồn

- **Hình nền:** thư viện tối giản, nhập/xoá/xuất gói, tìm ảnh theo nội dung kể cả tệp tên `asset.resource`, thumbnail giảm kích thước, chọn ảnh hoặc phát video xem trước.
- **Lưu vào Ảnh:** Photos chỉ xin quyền **thêm**; giữ dữ liệu gốc và chỉ báo thành công sau khi Photos xác nhận. Không đọc hay xoá thư viện Ảnh.
- **Lưu vào Tệp / Chia sẻ:** tạo bản sao có đuôi phù hợp định dạng rồi mở share sheet của iOS. Huỷ chia sẻ không được ghi thành lần lưu thành công.
- **Đã lưu:** lịch sử những lần Photos đã xác nhận. Đây không phải danh sách hình nền đang sử dụng. Xoá bản ghi chỉ xoá lịch sử trong app.
- **Hướng dẫn:** Cài đặt → Hình nền → Thêm hình nền mới → Ảnh. Có hướng dẫn cấp lại quyền Photos bằng cài đặt của ứng dụng.
- **Giao diện:** Theo hệ thống/Sáng/Tối, 5 màu nhấn, màu tuỳ chỉnh, xem trước và khôi phục mặc định. Giữ icon hồ sơ màu xám.
- **Trạng thái:** xanh lá cho khả năng lưu/kết quả thành công hoặc pairing đã xác thực; đỏ cho lỗi/tính năng không có; vàng cho trạng thái chờ; xanh dương khi xử lý. Có cả chữ và biểu tượng, không chỉ màu.
- **Pairing:** giữ công cụ nhập/xoá hồ sơ trong Keychain, LocalDevVPN và xác thực kết nối đã có. **Không cần pairing/VPN để xem, chia sẻ hoặc lưu hình nền.**

Những chức năng trên đã được triển khai trong mã. Xem [VALIDATION.md](VALIDATION.md) để phân biệt kiểm tra đã thực thi với hành vi còn cần Xcode/iPhone xác nhận.

## Tương thích và giới hạn

Luồng lưu dùng Photos có từ trước deployment target **iOS 17.0**, không khoá theo build hay bản vá: iOS 17, 18, 26 và 27 đều đi cùng một luồng API công khai. Các nhãn iOS 27 Developer Beta 1–4/Public Beta 1–2 từ 3105 chỉ giúp hiển thị phiên bản, **không phải tuyên bố đã thử từng bản beta trên thiết bị**. Simulator dùng xem trước/chia sẻ; nút lưu Photos trong bản này yêu cầu máy thật.

iOS không cung cấp API công khai cho ứng dụng thông thường tự đặt hình nền Màn hình khóa/Màn hình chính. Vì vậy cài trực tiếp luôn hiển thị không khả dụng trên mọi phiên bản. Không đổi nhãn hỗ trợ để giả lập việc cài thành công.

Không phải gói `.tendies` nào cũng chứa ảnh hoặc video có thể dùng riêng. Hiệu ứng, cấu hình và các tài nguyên không đọc được vẫn nằm nguyên trong gói và có thể xuất nguyên gói. Video lưu như video thông thường, không tự trở thành Live Photo hoặc hình nền động.

Giới hạn gói: nén 512 MiB, giải nén 768 MiB, mỗi tệp 256 MiB, 20.000 mục, 64 descriptor và 512 media. Ảnh được kiểm tra kích thước trước khi tạo thumbnail: tối đa 64 MP, 16.384 px mỗi chiều, 512 frame. Quá giới hạn hoặc dữ liệu hỏng được báo lỗi, không ghi vào kho hệ thống.

## Cách sử dụng

1. Nhấn **+** trong Hình nền và chọn gói `.tendies`/`.zip` đã tải xong trong Tệp.
2. Mở gói, chọn ảnh/video trong **Nội dung trong gói**.
3. Chọn **Lưu vào Ảnh** và cho phép thêm ảnh khi iOS hỏi, hoặc **Lưu vào Tệp / Chia sẻ**.
4. Với ảnh tĩnh đã lưu, mở Cài đặt → Hình nền → Thêm hình nền mới → Ảnh và hoàn tất trong iOS.

Nếu đã từ chối quyền Photos, mở mục hướng dẫn rồi nhấn **Mở cài đặt ứng dụng**. Không cần cấp quyền đọc toàn bộ thư viện.

## Pairing tuỳ chọn

Tệp `.mobiledevicepairing`, `.mobilepair`, `.plist` được nhập bằng document picker native, kiểm tra và lưu vào Keychain `WhenUnlockedThisDeviceOnly`. Bật LocalDevVPN, nhập IP thiết bị (thường `10.7.0.1`) rồi chọn **Kiểm tra kết nối**. Lockdown và RPPairing dùng bắt tay riêng; chỉ có phản hồi xác thực mới tạo trạng thái đã kết nối. Trạng thái hết hạn sau 90 giây hoặc khi đổi IP/hồ sơ/rời app.

Ghép đôi trong Cài đặt trên iOS 27 vẫn là công cụ riêng, cần quyền Mạng cục bộ/Chế độ nhà phát triển và xác minh trên máy thật. Không dùng trạng thái pairing để đánh dấu đã cài wallpaper.

## Build và kiểm tra

Cần macOS, Xcode 26 trở lên và Python 3:

```sh
python3 scripts/run-checks.py
bash scripts/build-unsigned.sh
```

Script tải `idevice v0.1.68`, kiểm SHA256 và lấy slice phù hợp cho công cụ pairing. Không có thư viện đó trong ZIP nguồn và không tải khi app chạy. Swift autolink Photos, ImageIO, AVFoundation/AVKit.

Kết quả build: `build/1809-unsigned.ipa` và bản sao tương thích `build/TendiesVN-unsigned.ipa`. Bundle ID mặc định `vn.tendies.wallpaper`; tên nội bộ project/scheme vẫn `TendiesVN`, sản phẩm hiển thị **1809**. Đổi Bundle ID khi ký phải dùng profile phù hợp; giữ Bundle ID cũ để cập nhật và giữ dữ liệu.

Hướng dẫn GitHub Actions không cần Mac: [BUILD-KHONG-CAN-MAC.md](BUILD-KHONG-CAN-MAC.md). ZIP là mã nguồn, chưa phải IPA có thể cài.

## Dữ liệu khi cập nhật

Giữ thư viện gói đã nhập và tuỳ chọn giao diện. Lịch sử lưu Photos được lưu riêng trong container ứng dụng; không chuyển các bản ghi cài trực tiếp của phiên bản cũ thành lịch sử lưu giả. Dữ liệu/bản ghi cũ không bị tự xoá. Muốn bỏ hình nền đã đặt bằng bản cũ, dùng giao diện Hình nền trong Cài đặt iOS.
