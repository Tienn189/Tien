# 1809 · 3.1.0 · bản dựng 13

Ứng dụng iPhone/iPad để nhập, kiểm tra, cài và quản lý gói hình nền `.tendies` hoặc `.zip` tương thích. Giao diện SwiftUI dùng màu trắng đen, biểu tượng tối giản và hỗ trợ giao diện sáng/tối. Trình chỉnh sửa hình nền, mã web và tài nguyên đi kèm đã được loại bỏ.

Bản dựng 13 cập nhật icon hồ sơ màu xám theo ảnh được cung cấp, đồng bộ biểu tượng trong ứng dụng.

Nguồn tham khảo chính: **[Pocket-Poster — leminlimez](https://github.com/leminlimez/Pocket-Poster)**. Xem [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) để biết nguồn gốc và giấy phép của các thành phần còn được giữ lại.

## Các mục trong ứng dụng

- **Pairing:** IP và trạng thái VPN, nhập/xoá hồ sơ, xác thực kết nối qua LocalDevVPN, ghép đôi trực tiếp trên iOS 27.
- **Wallpapers:** nhập gói có sẵn, xem thông tin và thực hiện thao tác cài.
- **Đã cài:** xem biên nhận và gỡ các hình nền do ứng dụng cài.
- **Cài đặt:** xem **Phiên bản ứng dụng: 3.1.0**, **Bản dựng: 13**, trạng thái hỗ trợ cài đặt của iOS hiện tại, model phần cứng, phiên bản iOS, nguồn, giao diện và pairing.

Bundle ID mặc định vẫn là `vn.tendies.wallpaper` để giữ thư viện và biên nhận khi cập nhật bản cũ. Tên thư mục, project và scheme nội bộ vẫn là `TendiesVN` để tương thích quy trình build; tên hiển thị và sản phẩm là **1809**.

## Phạm vi iOS được cấu hình

| Nhánh iOS/iPadOS | Phiên bản |
| --- | --- |
| 17 | 17.0–17.7 |
| 18 | 18.0–18.7.10 |
| 26 | 26.0–26.7.0 |
| 27 | 27.0–27.0.1; yêu cầu pairing |

Danh sách trên là phạm vi được yêu cầu. **Backend hiện tại chỉ hỗ trợ cài hình nền trên iOS/iPadOS 26.0–26.6.1.** Các nhánh iOS 17, iOS 18, iOS 26.6.2–26.7.0 và iOS 27 hiện chưa có backend cài đặt trong bản mã nguồn này; người dùng vẫn có thể nhập và xem thông tin gói. Trạng thái **Phiên bản hiện tại** trong Cài đặt dựa trên `installationSupported`, phản ánh khả năng của backend thực tế, nên các phiên bản này hiển thị **Không hỗ trợ**.

Trong phạm vi 26.0–26.6.1, backend `bad_query` vẫn cần kiểm tra quyền truy cập PosterBoard trên thiết bị trước khi ghi; trạng thái hỗ trợ không tự cấp quyền truy cập.

## Pairing và LocalDevVPN

Màn Pairing có các thẻ Mạng, Hồ sơ pairing và Ghép đôi trên thiết bị. Bộ chọn tệp native đăng ký `.mobiledevicepairing`, `.mobilepair`, `.plist` và nhận các UTI của nhà cung cấp Tệp để tránh tệp hợp lệ bị xám. Khi mở hồ sơ bằng chia sẻ từ ứng dụng Tệp, 1809 cũng chuyển tới Pairing.

1. Bật LocalDevVPN và nhập IP thiết bị trong màn Pairing (mặc định `10.7.0.1`; có thể dán địa chỉ kèm `/32`).
2. Nhập hồ sơ Lockdown hoặc RPPairing của chính thiết bị. Hồ sơ được kiểm tra khoá/chứng chỉ và lưu trong Keychain `WhenUnlockedThisDeviceOnly`.
3. Chọn **Kiểm tra kết nối**. Hồ sơ Lockdown thực hiện StartSession/TLS rồi đọc thông tin thiết bị; RPPairing thực hiện bắt tay/tunnel RSD và đọc định danh. Không báo xác thực từ việc mở cổng TCP hoặc chỉ nhập tệp.
4. Trên iOS 27, có thể chọn **Ghép đôi trên thiết bị này** rồi vào Cài đặt → Quyền riêng tư & Bảo mật → Chế độ nhà phát triển → Ghép đôi với 1809. PIN hiện khi thiết bị kết nối. Chấp thuận PIN và quay lại 1809; hồ sơ mới được lưu tự động.

Cho phép Mạng cục bộ cho 1809 khi được hỏi. Phiên ghép đôi dùng Bonjour và âm thanh im lặng trong thời gian ngắn để duy trì thao tác khi sang Cài đặt; dừng khi hoàn tất, huỷ hoặc hết thời gian. Kết quả xác thực là ảnh chụp trạng thái tại thời điểm kiểm tra, được xoá khi đổi IP/hồ sơ, về nền hoặc hết hạn. Việc có giao diện VPN chưa chứng minh ghép đôi thành công.

**Kết nối pairing đã được tích hợp, nhưng bộ cài wallpaper qua pairing trên iOS 27 chưa được bổ sung.** Bộ cài hiện có vẫn chỉ dùng phạm vi 26.0–26.6.1 như trên. Không coi xác thực pairing là xác nhận quyền ghi hình nền.

## Build trên macOS

Cần Xcode 26 trở lên và iOS SDK. Deployment target là iOS 17.0; mở `TendiesVN.xcodeproj`, chọn scheme `TendiesVN`, hoặc chạy:

```sh
bash scripts/build-unsigned.sh
```

Trước Xcode, script tự tải thư viện [idevice v0.1.68](https://github.com/jkcoxson/idevice/releases/tag/v0.1.68), kiểm tra SHA256 và lấy slice cần dùng vào `build/Dependencies`. Lần đầu cần mạng và tải khoảng 204 MB; không tải thư viện khi chạy app. Chỉ các API ghép đôi/đọc thông tin thiết bị được dùng trong phần kết nối mới.

Nếu build trực tiếp bằng Xcode, chạy một lần:

```sh
python3 scripts/prepare-idevice.py --platform iphoneos
# Hoặc cho Simulator:
python3 scripts/prepare-idevice.py --platform iphonesimulator
```

Đầu ra: `build/1809-unsigned.ipa` và bản sao giống hệt `build/TendiesVN-unsigned.ipa` để tương thích workflow cũ. Có thể dùng `--bundle-id com.example.wallpaper` nếu profile ký yêu cầu ID riêng. IPA chưa ký cần được ký với profile và chứng chỉ phù hợp trước khi cài.

Để xuất bản doanh nghiệp bằng chứng chỉ đã có trong Keychain:

```sh
bash scripts/export-enterprise.sh --profile /absolute/path/Enterprise.mobileprovision --identity 'Apple Distribution: Ten Doanh Nghiep (TEAMID)' --bundle-id vn.tendies.wallpaper
```

Đầu ra: `build/enterprise/1809.ipa`. Script xác thực sự phù hợp của Bundle ID, profile và chữ ký. Không có chứng chỉ, khóa riêng hay profile được đóng gói trong mã nguồn.

Để tạo manifest cho IPA đã ký và đã được lưu trên HTTPS:

```sh
python3 scripts/make-ota-manifest.py --ipa-url https://example.com/1809.ipa --bundle-id vn.tendies.wallpaper --version 13 --output build/manifest.plist
```

## Build bằng GitHub Actions

Repository đã giải nén có workflow `.github/workflows/unsigned-ios.yml`. Nếu chỉ tải ZIP lên GitHub, dùng [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml); hướng dẫn nằm trong [BUILD-KHONG-CAN-MAC.md](BUILD-KHONG-CAN-MAC.md). Artifact mới có tên `1809-unsigned` và chứa `1809-unsigned.ipa`.

Nếu workflow cũ báo không tìm thấy `build/TendiesVN-unsigned.ipa`, tải `TendiesVN-source.zip` mới, thay ZIP ở thư mục gốc repository rồi commit và tạo lượt chạy workflow mới. Workflow cũ vẫn dùng được nhờ bản sao tương thích; không chọn **Re-run jobs** của lượt cũ vì lượt đó vẫn dùng ZIP ở commit cũ.

## Kiểm tra

```sh
python3 tests/test_extractor.py
python3 tests/test_posterboard_path.py
python3 scripts/test-signing.py
python3 tests/test_compatibility.py
python3 tests/test_pairing.py
python3 tests/test_pairing_transport.py
```

Hai workflow chạy các kiểm tra trên trước bước build Xcode. Kiểm tra C và ký chạy được trên Linux; kiểm tra tương thích cần `swiftc`, kiểm tra chứng chỉ pairing cần macOS với Security.framework. Các kiểm tra này không xác nhận giao diện SwiftUI, API riêng của iOS hoặc thao tác cài/gỡ trên thiết bị. Build native cần Xcode/iOS SDK, và kiểm tra cuối cần iPhone/iPad thực tế.

Bản 3.1.0 được kiểm tra cú pháp Swift và adapter C với phản hồi giao thức có kiểm soát. Môi trường sửa mã hiện tại không có Xcode/iPhone; chưa xác nhận build native hoặc bắt tay với thiết bị thật. CI macOS chạy kiểm tra chứng chỉ/RPPairing và build iOS.
