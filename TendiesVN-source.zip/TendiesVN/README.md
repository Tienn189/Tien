# 1809 — MobileGestalt toolbox + TendiesVN wallpaper engine

The app's display name is **1809**. The supplied **TendiesVN-source.zip**
contains a UIKit application derived from KAMUI with the TendiesVN wallpaper
engine integrated. This work updates its wallpaper section to follow
YanDevin's Wallpaper Studio flow. The existing MobileGestalt functions and
tab order are retained. Read the
[Vietnamese integration guide](docs/WALLPAPER-INTEGRATION.vi.md) for the exact
wallpaper support matrix, pairing setup and build instructions.

The archive filename remains `TendiesVN-source.zip` for the existing CI
workflow. The technical executable/target `BQTool`, project `1809.xcodeproj`,
and default bundle identifier `com.kamui.escape` remain for build/signing and
existing-install continuity; the name shown on the device is **1809**.

The wallpaper screen now follows YanDevin's Wallpaper Studio flow: preview
tiles, saved selection of up to five packs, per-pack installation, and
PosterBoard diagnostics. Known Collections/Mercury provider aliases and the
PosterBoard refresh marker are handled by the integrated engine. See
[source attribution](THIRD_PARTY_NOTICES.md) and the integration guide above.

**Wallpaper backends from the supplied source:** iOS 17.0–17.7 and
18.0–18.7.1 use 3105/PocketPoster; 26.0–26.6.1 and five exact iOS 27.0 beta
builds use BadQuery; other 27.0 builds and 27.0.1 use Airlift with an imported
pairing record. These are source compatibility declarations; wallpaper
installation has not been verified on an iOS device in this integration
session. Other versions can
manage packs but cannot install them through the new wallpaper engine.

The original **MobileGestalt/MCM** target remains iOS **27.0.1–27.2** (upstream
primary target 27.2 / 24B115); its support has not been expanded by this change.
The sections below about that primitive preserve the upstream documentation.

The combined application includes **GPL-3.0-only** wallpaper code. Original
KAMUI portions retain their MIT notice; distribution of the combined app must
meet GPL terms. See the [license notes](#12-license-and-release-assets).

---

## 0. Who can use it

**Everyone.** There is no invitation, tester list, waitlist or account. Clone
the repository, build the app, install the IPA, fork it, publish your own
build, subject to the combined application's GPL terms and retained third-party
notices.

The MobileGestalt editor itself has no access check and no allowlist. On
**iOS 27.2** the primary class-7 path needs at least one
`com.apple.security.application-groups` entitlement in the running app. KAMUI
2.4.3 also offers an **opt-in class-2 parent fallback** (Settings → Class-2
fallback), which renames the app's own `Library` and may work without an app
group. It is off by default because some builds terminate the app when
`Library` is moved. If both paths fail, the log shows exactly which step the
sandbox denied. On some **27.0.x** builds the legacy class-13 traversal may
work without an app group.

---

## 1. What this is

The original KAMUI `BQEscape` primitive is a **partial sandbox escape**: a
normally sandboxed app obtains a read/write sandbox extension outside its own
containers. The new wallpaper engine selects its own backend, including the
3105 kernel-based resolver on iOS 17–18. The original primitive can:

- read and write the live **MobileGestalt** cache
  (`systemgroup.com.apple.mobilegestaltcache/Library/Caches/com.apple.MobileGestalt.plist`);
- install custom **PosterBoard** wallpapers (`.tendies` descriptors) into the
  three provider descriptor folders;
- read and write other **MCM containers** whose path is known (app data, app
  group, SystemGroup).

The included app is a full UIKit toolbox:

- **Gestalt** — Dynamic Island on/off, Dynamic Island model picker (14/15/16/
  17/18 experimental or custom subtype), version spoof, Apple Intelligence,
  Siri AI US region, AI device spoof, iPadOS mode, Security Research Device
  (ResearchFuse), Store Demo Mode, AOD, Boot Chime, Charge Limit, Tap to Wake,
  Stage Manager, Apple Pencil, Action Button, Collision SOS, Parallax off,
  full `CacheExtra` editor (add/edit/delete; String/Integer/Boolean/Data),
  apply/revert/respring, backup.
- **PosterBoard** — import `.tendies`/ZIP, preview and select packs, online wallpaper catalog
  (`SerStars/Nugget-Wallpapers`), pairing/host setup, open PosterBoard and
  respring. TendiesVN replaces the former generation-61 writer with validated
  packages and version-specific backends. Local BadQuery installs have receipt
  rollback; Airlift/PocketPoster do not provide in-app rollback.
- **Settings** — diagnostics, in-place/atomic write toggle, log viewer, a
  test-device banner: “This iPhone is provided specifically for testing” with
  an editable “Managed by group:” label, and an in-app language picker.
- **Languages** — English, Russian, Korean, Arabic, Turkish, Ukrainian and
  Vietnamese, with automatic RTL layout for Arabic.

---

## 2. The bug

### 2.1 Old `bad_query` is patched on 27.2

`bad_query` used `container_query_operation_set_part_domain` with `..`
traversal:

```objc
query_set_class(q, 13);
query_set_group_identifiers(q, xpc_string_create("systemgroup.com.apple.mobilegestaltcache"));
query_set_part(q, 3);                 // Library/Caches
query_set_part_domain(q, "../../../../../../../.." + path);
query_set_flags(q, 0x8100000000);
```

On 27.2:

- `MCMXPCMessageQuery` rejects a `SystemDataDomain` containing `..`
  (`Rejecting query with invalid partDomain`).
- `MCMFileManager realPathForURL:ifChildOfURL:` resolves symlinks and rejects
  absolute/outside targets when `partDomain` is non-empty.
- A direct class-13 query returns the MG path but **no sandbox token** for an
  app without the matching entitlement.

### 2.2 The part-directory symlink

The fix validates `partDomain`, but **not the part directory itself** when the
domain is empty:

1. The app-group container is writable. Replace
   `<app group>/Library/Caches` with a symlink to the target container.
2. Query MCM:
   - class **7** (app group),
   - own group identifier,
   - part **3** (`Library/Caches`),
   - **empty** `partDomain`,
   - flags `0x8100000000` (include path + extension type 3).
3. `containermanagerd` builds `<app group>/Library/Caches`, sees a symlink, and
   issues the sandbox extension for the **resolved target**.
4. `sandbox_extension_consume` grants read/write to the target.

No traversal string is involved, so the 27.2 checks never see `..` and never
get a non-empty `partDomain` to validate.

The symlink is removed and the original `Library/Caches` restored after each
operation. Crashes are recovered on the next run (`Caches.bqtool` backup).

### 2.3 Class 2: part directories vs. the parent fallback

On iOS 27.2 the sandbox denies `rename()` of every class-2 part directory from
inside the app:

```
Library/Preferences  -> EPERM (errno 1)
Library/Caches       -> EPERM (errno 1)
Documents            -> EPERM (errno 1)
tmp                  -> EPERM (errno 1)
SystemData           -> EPERM (errno 1)
```

Only the app-group part directory is directly renameable. KAMUI 2.4.3 has an
**opt-in class-2 parent fallback** for builds without an app group. It is off
by default (2.2 ran it automatically and could crash on builds that kill the
process for moving `Library`):

1. Rename the app's own `Library` to `Library.bqtool`.
2. Create a small fresh `Library` and symlink `Library/Caches` to the target.
3. Query class 2 (own bundle identifier, part 3, empty `partDomain`,
   flags `0x8100000000`).
4. Restore the original `Library` immediately; the consumed token remains
   valid for the resolved target.

Enable it in **Settings → Class-2 fallback (experimental)** and then retry
Gestalt. The new wallpaper installer uses its own backend. If the app closes when it is enabled, relaunch, disable the
switch, and send `Documents/bqtool.log`. If the sandbox denies moving
`Library`, the log shows `class2-parent: move Library -> bak failed` and the
class-7 path still needs an app group.

### 2.4 Dynamic app group

Old builds hardcoded one group. KAMUI reads the app's own runtime entitlements:

```objc
SecTaskRef task = SecTaskCreateFromSelf(kCFAllocatorDefault);
CFTypeRef groups = SecTaskCopyValueForEntitlement(
    task, CFSTR("com.apple.security.application-groups"), NULL);
```

It picks the first group that yields a
`containerURLForSecurityApplicationGroupIdentifier` container. The MCM query
uses that group identifier. A build with **any** app group works; there is no
hardcoded identifier.

### 2.5 Multi-strategy escape (27.0.1–27.2)

`BQEscape` tries, in order, and logs every attempt:

| # | Strategy | Needs app group | Likely versions |
|---|---|---|---|
| 1 | class 13 + 8-level traversal to the MG plist file (`bad_query` file form) | no | 27.x where bad_query is open |
| 2 | class 13 + traversal to the target directory | no | 27.x where traversal is open |
| 3 | **class 12 `com.apple.geod` direct + symlinked Caches** | no | 27.2 if geod is still built-in allowed |
| 4 | class 7 part-directory symlink | yes | 27.2 |
| 5 | class 2 `RENAME_SWAP` / stage / subpath | no | 27.2 if allowed |
| 6 | class 2 parent `Library` symlink | no | opt-in, can terminate app |
| 7 | class 13 direct MG query | no | builds that issue a token |
| 8 | class 12 geod + traversal | no | older builds |

The first successful strategy is used. A result but no token is logged as
`token=NO consume=-5` (`-5` is the app's "no token / consume failed", not an
installation error).

---

## 3. Reachable targets

Historical upstream KAMUI observations on 27.2 (redacted; not revalidated by
this wallpaper integration):

- **MobileGestalt** — 10 740-byte binary plist, parsed as `__NSDictionaryI`,
  79→80 `CacheExtra` keys, opened `O_RDWR`, marker written.
- **PosterBoard** — app data container
  `/var/mobile/Containers/Data/Application/<UUID>`; all three descriptor
  folders writable:
  - `com.apple.WallpaperKit.CollectionsPoster/descriptors`
  - `com.apple.MercuryPoster/descriptors`
  - `com.apple.PhotosUIPrivate.PhotosPosterProvider/descriptors`
- **App data containers** — 245 containers enumerated with `fsgetpath` and
  opened with tokens.
- **PosterBoard `.tendies` pipeline** — 25-file ZIP extracted, descriptor
  found, IDs randomized, folder written to the WallpaperKit provider.

The same technique can reach other MCM containers whose path is known.

---

## 4. Build

Requirements: **macOS with Xcode 26 or newer**, Python 3 and network access
for Rust dependencies. The complete app includes Swift and requires iOS 17+.
The build rebuilds Airlift from the vendored pinned sources.

```bash
./build.sh
# -> build/1809-<version>-unsigned.ipa
```

The app displays **1809**. The default bundle identifier is `com.kamui.escape`
and executable/target is `BQTool`; these technical identifiers are retained
from the supplied KAMUI-derived source. Override the bundle identifier with
`BID=com.example.my1809 ./build.sh`. Sign the unsigned IPA with a matching
identity/profile before installation.

For a hosted build, use **Actions → Build unsigned iOS app → Run workflow**
and download the **1809-unsigned** artifact. The old Linux/clang/SDK-14.5 build
instructions do not apply to the integrated application.

---

## 5. Install and runtime requirement

Install the signed `1809-<version>-unsigned.ipa` on a device running iOS 17+.
Wallpaper installation follows the separate [support matrix and pairing
instructions](docs/WALLPAPER-INTEGRATION.vi.md).

The following app-group requirements describe the original **MobileGestalt/MCM**
engine; they do not establish new wallpaper support on 27.2.

The primary 27.2 strategy needs the running app to have at least one
`com.apple.security.application-groups` entitlement. KAMUI reads its own
entitlements at runtime and uses the first group that has a container URL.

- **With an app group** — class 7 is attempted after the class-13 fallback and
  is the working path on 27.2.
- **Without an app group** — the app logs `(none)` and tries the legacy
  class-13 traversal. That may work on some 27.0.x builds; it is closed on
  27.2.

There is no hardcoded group identifier, so any build that grants an app group
can use the primary path.

---

## 6. Usage

On first launch:

- Gestalt loads the live MG plist and creates
  `Documents/OriginalGestalt.plist` (true original) if missing.
- Apply writes the plist (in-place with rollback, or atomic), verifies it and
  offers a respring.
- Revert restores the backup.
- PosterBoard → Thiết lập hình nền / Pairing → check device support. Import
  pairing first if Airlift is selected, then Import `.tendies` / Explore
  Wallpapers → Apply → Open PosterBoard and close its App Switcher card.
- “Hoàn tác lần cài gần nhất” restores a receipt-backed local BadQuery install;
  it does not remove stock descriptors or undo Airlift/PocketPoster installs.

**Keep `OriginalGestalt.plist`.** If the app is deleted, the backup goes with
it.

---

## 7. Logs and diagnostics

- `Documents/bqtool.log` — session log (iOS build, group identifier, every
  strategy, MG reads/writes, ZIP/descriptor apply).
- Settings → Run Diagnostics — MG read/write check + PosterBoard container
  search.
- Settings → Open Log — viewer with refresh/clear.

If an escape fails, the first lines show which strategy failed and why:

```
strategy class13-traversal: ... result=0x0 token=NO consume=-5
strategy class7-symlink: ... result=0x... token=YES consume=3
escape: using class7 symlink
```

---

## 8. Version notes

The entries below preserve upstream KAMUI release history and its reported
device observations. They are not test results for this wallpaper integration.

- **2.4.3** — adds the class-12 `com.apple.geod` built-in container path:
  direct token + symlinked `Library/Caches`, which may work on a free
  certificate without an app group. Also includes all previous probes.
- **2.4.2** — adds the free-certificate `bad_query` file form (class 13,
  MobileGestalt SystemGroup, 8-level traversal, flags `0x8000000000`, direct
  `com.apple.MobileGestalt.plist` target), plus `RENAME_SWAP` and class-2
  stage/subpath probes. Also includes the `.tendies` provider fix.
- **2.4.1** — adds the safe class-2 staged symlink probe, both Collections
  providers and the PosterBoard refresh marker for `.tendies`.
- **2.4.0** — adds Russian, Korean, Arabic, Turkish, Ukrainian and Vietnamese
  localization with an in-app language picker; adds the class-2 subpath token
  probe and iterates all app groups; fixes `.tendies` installation by writing
  both Collections providers and the PosterBoard refresh marker.
- **2.3.1** — crash-guard hotfix: the class-2 fallback is opt-in and is
  automatically disabled after an unfinished attempt. 2.2 ran it
  automatically and could terminate the app when `Library` was moved.
- **2.2** — added the class-2 parent fallback,
  Dynamic Island enable/disable and model picker, version spoof, Apple
  Intelligence, Siri AI US region, AI device spoof, iPadOS mode, ResearchFuse
  (Security Research Device), Store Demo Mode, and the in-app test-device /
  “Managed by group” banner.
- **27.2 (24B115)** — primary, tested: class-13 traversal closed; class-7
  part-directory symlink works.
- **27.0.1 / 27.1** — the class-13 traversal or class-12 geod fallback may
  still work, possibly without an app group. If all strategies return `-5`,
  send `Documents/bqtool.log`; the log distinguishes an entitlement problem
  from a build-specific MCM change.
- The former app used the iOS 14.5 SDK. The integrated version now requires
  Xcode 26+ and has a minimum deployment target of iOS 17.

### Diagnostic notes

For each device/build send the first 15–20 lines of `Documents/bqtool.log`:

```
=== BQEscape start | iOS <build> | bundle ...
app group entitlement: <group or (none)>
strategy class13-traversal: result=... token=... consume=...
strategy class7-symlink: result=... token=... consume=...
strategy class2-parent: result=... token=... consume=...
escape: using ...
```

This distinguishes:

- no app group + traversal closed → entitlement/installation limitation;
- app group present + class 7 neither result nor token → version-specific MCM
  change;
- result but no token → entitlement or target-path issue;
- token but consume fails → kernel/extension mismatch.

---

## 9. Limitations and safety

- The original KAMUI primitive is scoped to MCM containers (or paths reachable
  through its legacy traversal). Wallpaper installation uses separate scoped
  backends, including a kernel-based resolver on iOS 17–18.
- POSIX DAC still applies; write only where user `mobile` can write.
- MobileGestalt edits can break features or soft-brick the device. Keep the
  backup. Do not apply unknown keys.
- iPadOS mode, Apple Intelligence/Siri spoofing, ResearchFuse, Store Demo Mode
  and version spoofing are behind confirmation prompts for a reason. iPadOS
  mode patches the binary `CacheData` blob; AI/Siri spoofing can break Face ID;
  version spoofing can break OTA updates. Revert if anything misbehaves.
- Wallpaper rollback uses receipts for new local BadQuery installs only.
  Airlift/PocketPoster can leave a partially installed pack when a write fails;
  inspect PosterBoard before retrying. The broad PosterBoard Reset action has
  been replaced in the UI.
- Use it only on devices you own or have permission to modify.

---

## 10. Disclosure and public use

The original KAMUI primitive and MobileGestalt editor remain public research
under their MIT notice. This combined app also contains GPL-3.0-only wallpaper
code; see the license section. There is no tester list or private group.

- If you find a bug in KAMUI, open a GitHub issue or security advisory.
- If you want to report the underlying MCM behavior to Apple, use **Apple
  Security Bounty** (Sandbox Escape category) and include the iOS build, the
  exact query (class 7 / part 3 / empty `partDomain` / flags `0x8100000000`),
  the symlinked part-directory behavior, and a video/log of MobileGestalt
  write + PosterBoard descriptor write.
- Suggested fix direction: canonicalize and validate the **part directory**
  against the container for every part, and reject symlinked part directories
  regardless of `partDomain`. The current checks cover `partDomain` but not the
  part path itself.

See [SECURITY.md](SECURITY.md).

---

## 11. Credits

- KAMUI primitive, app, dynamic group and multi-strategy: this project.
- `bad_query` research: forcequitOS, 0xjohnny.
- UI/feature inspiration: rooootdev/mond.
- NeoSpring respring: neonmodder123, skadz108.
- Wallpaper catalog: SerStars/Nugget-Wallpapers.
- TendiesVN/1809 wallpaper integration: the supplied Tienn189 archive, 3105,
  PocketPoster, Placard, AirCard/Airlift and their contributors; see
  [vendored notices](vendor/TendiesWallpaper/UPSTREAM_THIRD_PARTY_NOTICES.md).
- Theos tooling (original build).

---

## 12. License and release assets

The combined application includes **GPL-3.0-only** wallpaper code and must be
redistributed under GPL-3.0 terms with corresponding source. The original
KAMUI code retains its MIT copyright/permission notice. Airlift and other
components retain their own notices. See [LICENSE](LICENSE), the
[wallpaper GPL text](vendor/TendiesWallpaper/LICENSE-GPL-3.0.txt), and
[third-party notices](vendor/TendiesWallpaper/UPSTREAM_THIRD_PARTY_NOTICES.md).

New builds produce `build/1809-<version>-unsigned.ipa` and the stable alias
`build/1809-unsigned.ipa`; the app displays **1809** after signing and
installation. The source archive remains `TendiesVN-source.zip`. Older upstream
`KAMUI-2.4.3.ipa` release assets do not contain this integration. Source and
build scripts are included here.
