# 1809 · 3.0.0 · bản dựng 11

Ứng dụng iPhone/iPad để nhập, kiểm tra, cài và quản lý gói hình nền `.tendies` hoặc `.zip` tương thích. Giao diện SwiftUI dùng màu trắng đen, biểu tượng tối giản và hỗ trợ giao diện sáng/tối. Trình chỉnh sửa hình nền, mã web và tài nguyên đi kèm đã được loại bỏ.

Nguồn tham khảo chính: **[Pocket-Poster — leminlimez](https://github.com/leminlimez/Pocket-Poster)**. Xem [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) để biết nguồn gốc và giấy phép của các thành phần còn được giữ lại.

## Các mục trong ứng dụng

- **Hình nền:** nhập gói có sẵn, xem thông tin và thực hiện thao tác cài.
- **Đã cài:** xem biên nhận và gỡ các hình nền do ứng dụng cài.
- **Cài đặt:** xem **Phiên bản ứng dụng: 3.0.0**, **Bản dựng: 11**, trạng thái hỗ trợ cài đặt của iOS hiện tại, model phần cứng, phiên bản iOS, nguồn, giao diện và pairing.

Bundle ID mặc định vẫn là `vn.tendies.wallpaper` để giữ thư viện và biên nhận khi cập nhật bản cũ. Tên thư mục, project và scheme nội bộ vẫn là `TendiesVN` để tương thích quy trình build; tên hiển thị và sản phẩm là **1809**.

## Phạm vi iOS được cấu hình

| Nhánh iOS/iPadOS | Phiên bản |
| --- | --- |
| 17 | 17.0–17.7 |
| 18 | 18.0–18.7.10 |
| 26 | 26.0–26.7.0 |
| 27 | 27.0–27.0.1; yêu cầu pairing |

Danh sách trên là phạm vi được yêu cầu. **Backend hiện tại chỉ hỗ trợ cài hình nền trên iOS/iPadOS 26.0–26.6.1.** Các nhánh iOS 17, iOS 18, iOS 26.6.2–26.7.0 và iOS 27 hiện chưa có backend cài đặt trong bản mã nguồn này; người dùng vẫn có thể nhập và xem thông tin gói. Trạng thái **Phiên bản hiện tại** trong Cài đặt dựa trên `installationSupported`, phản ánh khả năng của backend thực tế, nên các phiên bản này hiển thị **Không hỗ trợ**.

Trong phạm vi 26.0–26.6.1, backend `bad_query` vẫn cần kiểm tra quyền truy cập PosterBoard trên thiết bị trước khi ghi; trạng thái hỗ trợ không tự cấp quyền truy cập.

Từ iOS 27, phần Cài đặt yêu cầu pairing và có hướng dẫn tạo/nhập bản ghi. Việc nhập và kiểm tra tệp pairing chỉ quản lý thông tin ghép đôi tại chỗ, chưa cung cấp một transport pairing hoạt động để cài hình nền trên iOS 27. Không coi trạng thái đã nhập tệp là xác nhận quyền ghi hoặc cài đặt thành công.

## Build trên macOS

Cần Xcode 26 trở lên và iOS SDK. Deployment target là iOS 17.0; mở `TendiesVN.xcodeproj`, chọn scheme `TendiesVN`, hoặc chạy:

```sh
bash scripts/build-unsigned.sh
```

Đầu ra: `build/1809-unsigned.ipa` và bản sao giống hệt `build/TendiesVN-unsigned.ipa` để tương thích workflow cũ. Có thể dùng `--bundle-id com.example.wallpaper` nếu profile ký yêu cầu ID riêng. IPA chưa ký cần được ký với profile và chứng chỉ phù hợp trước khi cài.

Để xuất bản doanh nghiệp bằng chứng chỉ đã có trong Keychain:

```sh
bash scripts/export-enterprise.sh --profile /absolute/path/Enterprise.mobileprovision --identity 'Apple Distribution: Ten Doanh Nghiep (TEAMID)' --bundle-id vn.tendies.wallpaper
```

Đầu ra: `build/enterprise/1809.ipa`. Script xác thực sự phù hợp của Bundle ID, profile và chữ ký. Không có chứng chỉ, khóa riêng hay profile được đóng gói trong mã nguồn.

Để tạo manifest cho IPA đã ký và đã được lưu trên HTTPS:

```sh
python3 scripts/make-ota-manifest.py --ipa-url https://example.com/1809.ipa --bundle-id vn.tendies.wallpaper --version 11 --output build/manifest.plist
```

## Build bằng GitHub Actions

Repository đã giải nén có workflow `.github/workflows/unsigned-ios.yml`. Nếu chỉ tải ZIP lên GitHub, dùng [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml); hướng dẫn nằm trong [BUILD-KHONG-CAN-MAC.md](BUILD-KHONG-CAN-MAC.md). Artifact mới có tên `1809-unsigned` và chứa `1809-unsigned.ipa`.

Nếu workflow cũ báo không tìm thấy `build/TendiesVN-unsigned.ipa`, tải `TendiesVN-source.zip` mới, thay ZIP ở thư mục gốc repository rồi commit và tạo lượt chạy workflow mới. Workflow cũ vẫn dùng được nhờ bản sao tương thích; không chọn **Re-run jobs** của lượt cũ vì lượt đó vẫn dùng ZIP ở commit cũ.

## Kiểm tra

```sh
python3 tests/test_extractor.py
python3 tests/test_posterboard_path.py
python3 scripts/test-signing.py
python3 tests/test_compatibility.py
python3 tests/test_pairing.py
```

Hai workflow chạy các kiểm tra trên trước bước build Xcode. Kiểm tra C và ký chạy được trên Linux; kiểm tra tương thích cần `swiftc`, kiểm tra chứng chỉ pairing cần macOS với Security.framework. Các kiểm tra này không xác nhận giao diện SwiftUI, API riêng của iOS hoặc thao tác cài/gỡ trên thiết bị. Build native cần Xcode/iOS SDK, và kiểm tra cuối cần iPhone/iPad thực tế.
