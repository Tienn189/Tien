# 1809 · 3.4.0 · bản dựng 18

Khôi phục cách cài gói `.tendies`/`.zip` và mở **PosterBoard** như build 14: app ghi các descriptor vào Bộ sưu tập, đóng màn cài rồi mở PosterBoard. Người dùng mở đa nhiệm và vuốt đóng thẻ PosterBoard để làm mới, sau đó chọn hình nền trong Cài đặt iOS.

Đã bỏ luồng lưu vào Ảnh, quyền Photos và lịch sử lưu ảnh của build 15–17. Không có màn chi tiết, lưới ảnh/video, xem trước hoặc trình chỉnh sửa. Thư viện, giao diện sáng/tối, màu nhấn, icon xám và công cụ pairing được giữ.

Màu nhấn có đủ **6 ô**, thêm màu Than chì. Các hàng Cài đặt co theo nội dung và xuống dòng khi cần, bỏ khoảng trắng cao bất thường; màu trạng thái vẫn giữ xanh/đỏ/vàng riêng.

## Tương thích thực tế của mã nguồn

- App có deployment target **iOS 17.0**; vẫn nhập/xoá/xuất gói trên các phiên bản chạy được app.
- **Backend cũ chỉ có cho iOS 26.0–26.6.1.** Cài/gỡ còn phụ thuộc kiểm tra quyền ghi PosterBoard thực tế. Có backend không chứng minh đã chạy thành công trên máy thật.
- **Chưa có backend cài cho iOS 17, 18, iOS 26 sau 26.6.1 hoặc iOS 27**, bao gồm Developer Beta 1–4/Public Beta 1–2. Các phiên bản này hiện đỏ ở khả năng cài; không đổi nhãn để giả lập hỗ trợ.
- Pairing/LocalDevVPN được giữ riêng. Xác thực pairing không cấp quyền ghi wallpaper và không bổ sung bộ cài cho iOS 27.
- Simulator chỉ quản lý thư viện; không cài vào hệ thống và không mở PosterBoard.

Bộ cài được khôi phục dùng cơ chế `bad_query` và API riêng của iOS từ nguồn cũ, giới hạn vào container đã xác minh là `com.apple.PosterBoard`. **Bản này không còn là bản chỉ dùng API công khai**. Không tích hợp backend khai thác kernel mới. Phạm vi phiên bản ở Swift khớp với giới hạn trong bridge native.

## Cách sử dụng

1. Trong Cài đặt → Hình nền, tạo và dùng một hình nền Bộ sưu tập của Apple để kho dữ liệu tồn tại.
2. Mở 1809 → Hình nền → **+**, chọn gói `.tendies` hoặc `.zip` đã tải xong trong Tệp.
3. Mở gói, nhấn **Cài hình nền**. App kiểm tra gói và quyền ghi trước mỗi lần cài; giữ app mở khi đang xử lý.
4. Sau khi ghi thành công, màn cài đóng rồi PosterBoard mở. Mở đa nhiệm, vuốt đóng thẻ **PosterBoard**, rồi chọn hình nền mới trong Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập.
5. Nếu tự mở PosterBoard thất bại, app báo riêng và giữ kết quả ghi thành công. Có nút **Mở PosterBoard** trên thông báo để thử lại; không tự cài lại gói.

Tab **Đã cài** chứa bản ghi những descriptor app đã thêm, không chứng minh hình nền nào đang được chọn. Trước khi gỡ, chuyển sang hình nền Apple khác rồi chọn đúng lần cài. Cài gián đoạn có bản ghi để dọn lại. Xoá bản nhập trong thư viện không gỡ hình nền đã thêm.

## Dữ liệu và thao tác ghi

Giữ Bundle ID `vn.tendies.wallpaper` để cập nhật và giữ thư viện, giao diện, Keychain và các bản ghi cài cũ. Không tự xoá lịch sử Photos cũ hoặc ảnh đã lưu bởi build 15–17; chúng không được hiển thị như bản ghi cài PosterBoard.

Bộ cài tạo descriptor có UUID mới, ghi journal trước khi chép, kiểm tra cây tệp/giới hạn và rollback khi lỗi. Gỡ chỉ nhắm các descriptor của lần cài được chọn; không thay thế hình nền gốc. Không có trình duyệt hệ thống hoặc API nhận đường dẫn tuỳ ý từ giao diện.

Giới hạn archive giữ nguyên: nén 512 MiB, giải nén 768 MiB, mỗi tệp 256 MiB, 20.000 mục và 64 descriptor. Bộ chọn tệp dùng coordinated read cho File Provider/iCloud. Đổi đuôi ảnh thường thành `.tendies` không tạo được gói hợp lệ.

## Pairing

Giữ nhập `.mobiledevicepairing`, `.mobilepair`, `.plist` bằng document picker và khoá Keychain `WhenUnlockedThisDeviceOnly`. Bật LocalDevVPN, nhập IP đúng (thường `10.7.0.1`) rồi kiểm tra kết nối. Chỉ phản hồi xác thực tạo trạng thái kết nối xanh; import tệp hoặc biểu tượng VPN không đủ. Có hướng dẫn ghép đôi trên iOS 27 và nhập lại hồ sơ khi cần.

## Build và kiểm tra

Cần macOS, Xcode 26 trở lên và Python 3:

```sh
python3 scripts/run-checks.py
bash scripts/build-unsigned.sh
```

Script chuẩn bị `idevice v0.1.68` cho pairing, kiểm SHA256 và không đóng thư viện vào ZIP nguồn. Xcode build scheme/project `TendiesVN`, module `App1809`, tên hiển thị **1809**.

Kết quả: `build/1809-unsigned.ipa` và bản sao tương thích `build/TendiesVN-unsigned.ipa`. Ký bằng chứng chỉ/profile phù hợp trước khi cài. Nếu build lỗi, script giữ mã thoát và in **First compiler errors**; workflow mẫu tải full log dưới artifact **1809-build-log**.

Hướng dẫn CI: [BUILD-KHONG-CAN-MAC.md](BUILD-KHONG-CAN-MAC.md). Mức xác nhận và kiểm tra cần làm trên thiết bị: [VALIDATION.md](VALIDATION.md). Môi trường sửa mã không có Xcode/iPhone nên chưa xác nhận IPA/native hoặc cài thực tế.

Nguồn: [Pocket-Poster — leminlimez](https://github.com/leminlimez/Pocket-Poster), [3105 — YangJiii](https://github.com/YangJiiii/3105), [idevice — jkcoxson](https://github.com/jkcoxson/idevice). Ghi công và giấy phép: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
