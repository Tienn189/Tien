# TendiesVN

Ứng dụng iOS bằng SwiftUI để nhập và cài hình nền `.tendies` từ CAPlayground vào PosterBoard. Có thư viện gói đã nhập, biên nhận từng lần cài và gỡ các descriptor thuộc biên nhận đó.

**Trạng thái bàn giao:** đây là mã nguồn và cấu hình dựng ứng dụng. Môi trường thực hiện là Linux, không có Xcode/iOS SDK, chứng chỉ hoặc iPhone kết nối; chưa có IPA đã biên dịch/ký và chưa thử cài hình nền trên thiết bị thật. Không nên xem kiểm tra mã nguồn là xác nhận cài thành công trên iOS 26.6.

## Tương thích và cách hoạt động

- Bản này hướng tới iOS **26.6** theo yêu cầu. [3105 upstream](https://github.com/YangJiiii/3105/tree/a72617ed4c764a65d8aac1e91aca95231e72a2cb) công bố dải iOS 26.0–26.6.1; TendiesVN chưa tự kiểm chứng dải đó.
- App dùng cơ chế MobileHouseArrest/MobileContainerManager của upstream để xin quyền truy cập container `com.apple.PosterBoard`, sau đó kiểm tra thực tế quyền ghi trước khi cài. Chứng chỉ doanh nghiệp tự nó không cấp quyền đổi hình nền.
- Khi ký phải giữ **cả Bundle ID và CodeDirectory identifier** là `com.apple.mobile.MobileHouseArrest`. Công cụ ký tự đổi ID có thể khiến app mở được nhưng không truy cập PosterBoard.
- Vì dùng cùng Bundle ID, TendiesVN có thể thay thế hoặc xung đột với 3105/FilzaSlop khác đã cài bằng ID này. Hãy sao lưu dữ liệu của ứng dụng hiện có trước khi cài.
- App cần chứng chỉ doanh nghiệp còn hiệu lực và provisioning profile cho phép đúng identity trên. Chỉ có chứng chỉ `.p12` là chưa đủ. Không có chứng chỉ, khóa riêng hoặc profile nào trong dự án.

Mã nguồn sử dụng API riêng và phụ thuộc hành vi hệ điều hành có thể bị Apple sửa. App không phải bản phát hành trên App Store. Đọc [ghi chú ký của FilzaSlop](https://github.com/0xjohnnydev/FilzaSlop#signing) để hiểu yêu cầu identity; bản dùng AltStore/SideStore hoặc LiveContainer với Bundle ID khác không cung cấp quyền truy cập này.

## Không có Mac

Có thể dùng runner macOS của GitHub Actions để build IPA chưa ký, sau đó ký trên iPhone bằng chứng chỉ/profile doanh nghiệp của bạn. Workflow đã có trong dự án; không cần đưa khoá ký lên GitHub. Xem [hướng dẫn thao tác không cần Mac](BUILD-KHONG-CAN-MAC.md).

## Dựng và ký trên máy Mac

Cần macOS và Xcode 26 có iOS SDK. Mở dự án `TendiesVN.xcodeproj`, chọn scheme `TendiesVN` và đích `Any iOS Device (arm64)`.

Dựng IPA chưa ký:

```sh
./scripts/build-unsigned.sh
```

Đầu ra: `build/TendiesVN-unsigned.ipa`. IPA chưa ký là đầu vào cho công cụ ký, không thể cài trực tiếp.

Nếu chứng chỉ đã được nhập vào Keychain trên Mac và có profile phù hợp, có thể xuất bản doanh nghiệp bằng script:

```sh
./scripts/export-enterprise.sh \
  --profile /absolute/path/Enterprise.mobileprovision \
  --identity 'Apple Distribution: Ten Doanh Nghiep (TEAMID)'
```

Đầu ra: `build/enterprise/TendiesVN.ipa`. Script kiểm tra Bundle ID, signing identifier và profile; nó không tạo quyền ký một identity mà profile của bạn không cho phép.

Sau khi xác thực, script chép profile vào `~/Library/Developer/Xcode/UserData/Provisioning Profiles` để Xcode nhận diện profile theo UUID. Khoá ký vẫn nằm trong Keychain của bạn.

Khi ký lại bằng công cụ của bạn:

1. Dùng chứng chỉ và provisioning profile của bạn tại máy cục bộ.
2. Tắt tùy chọn tự tạo Bundle ID; giữ `com.apple.mobile.MobileHouseArrest`.
3. Kiểm tra chữ ký ứng dụng và profile trước khi cài.
4. Cài IPA đã ký bằng phương thức doanh nghiệp phù hợp với chứng chỉ của bạn.

Trên iPhone, vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển. iOS 18 trở lên có thể yêu cầu **Cho phép & Khởi động lại**. Thiết bị cần mạng để xác minh chứng chỉ. Xem [hướng dẫn Apple](https://support.apple.com/118254).

Nếu phát hành qua máy chủ HTTPS của bạn, tạo manifest sau khi tải IPA đã ký lên máy chủ:

```sh
python3 scripts/make-ota-manifest.py \
  --ipa-url https://example.com/TendiesVN.ipa \
  --output build/manifest.plist
```

Tải `manifest.plist` lên HTTPS rồi dùng liên kết `itms-services://?action=download-manifest&url=<URL-HTTPS-manifest-đã-mã-hóa>`. Script chỉ tạo manifest; không ký, tải lên hoặc lưu trữ ứng dụng.

## Cài hình nền CAPlayground

1. Sao lưu iPhone trước khi thử thay đổi dữ liệu PosterBoard.
2. Vào **Cài đặt → Hình nền → Thêm hình nền mới**, thêm và dùng sẵn một hình nền **Bộ sưu tập** của Apple để khởi tạo kho descriptor. Sau đó xuất `.tendies` từ [CAPlayground](https://caplayground.vercel.app) và lưu vào ứng dụng **Tệp**.
3. Mở TendiesVN, nhập tệp `.tendies` rồi kiểm tra số descriptor được nhận diện.
4. Chạy kiểm tra quyền truy cập. Nếu app báo không hỗ trợ hoặc từ chối truy cập, không tiếp tục cài.
5. Chọn gói và cài. Kết quả thành công nghĩa là descriptor đã được ghi; chưa có nghĩa iOS đã chọn hình nền đó làm hình nền hiện tại.
6. Khởi động lại iPhone, rồi mở **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập**, hoặc mở bộ chọn hình nền từ màn hình khóa, để chọn hình nền vừa thêm.

TendiesVN lưu biên nhận để gỡ đúng descriptor do lần cài đó thêm vào. Muốn gỡ hình nền đang dùng, hãy chọn hình nền khác trước rồi gỡ theo biên nhận. Không xóa app trước khi gỡ nếu bạn muốn giữ biên nhận; xóa app không tự hoàn tác dữ liệu đã ghi vào PosterBoard.

## Định dạng nhận vào

`.tendies` trong hệ sinh thái Nugget là gói ZIP chứa cấu trúc PosterBoard, không phải tệp ảnh thông thường. Bản xuất CAPlayground hiện dùng `descriptors/<UUID>/...`, kể cả hình nền gyro. Gói có thể chứa nhiều descriptor. Tài sản và giấy phép trong tệp nhập vẫn thuộc tác giả của chúng.

Bộ đọc xử lý biến thể `descriptor`/`descriptors` và `container` theo cấu trúc upstream; biến thể `video`/`photos`/`mercury` còn phụ thuộc extension có trên thiết bị. Không bảo đảm mọi gói bên ngoài hoặc mọi hiệu ứng Core Animation đều hoạt động trên mọi thiết bị.

App từ chối đường dẫn thoát thư mục, liên kết tượng trưng và gói vượt giới hạn. Giới hạn mặc định: ZIP 512 MiB, giải nén 768 MiB, từng tệp 256 MiB, 20.000 entry, 64 descriptor. Nếu gặp lỗi nhập, hãy xuất lại `.tendies` từ CAPlayground; chỉ đổi tên một ảnh/MP4 thành `.tendies` không tạo gói hợp lệ.

## Nguồn và giấy phép

Engine hình nền được trích và sửa từ [YangJiiii/3105](https://github.com/YangJiiii/3105) tại commit `a72617ed4c764a65d8aac1e91aca95231e72a2cb`. Bản này chỉ cung cấp luồng hình nền; thay đổi giao diện và tích hợp của TendiesVN được thực hiện ngày 2026-10-16.

Xem [LICENSE](LICENSE) và [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). GPL-3.0 của 3105 không tự cấp lại giấy phép cho tài liệu bên thứ ba có nguồn gốc chưa rõ; cần giải quyết các điều khoản đó trước khi phân phối bản phái sinh cho người khác. Dự án không đóng gói hình nền của CAPlayground hoặc Apple.

## Kiểm tra bản bàn giao

Đã chạy bộ kiểm tra C với các gói ZIP sinh tại chỗ và hai mẫu thường/gyro của CAPlayground: 4 bài kiểm tra đạt, 76 tệp mẫu giải nén khớp từng byte. Các trường hợp sai CRC, sai dung lượng, bị cắt cụt, tệp đích đã tồn tại và symlink được kiểm tra. Mẫu CAPlayground không được đưa vào gói mã nguồn.

Chạy lại kiểm tra độc lập, cần Python 3, trình biên dịch C và zlib:

```sh
python3 tests/test_extractor.py
```

Không cung cấp `--templates-root` thì bài kiểm tra tài nguyên CAPlayground được bỏ qua. Phần cú pháp 10 file Swift, cấu trúc dự án Xcode, Info.plist, scheme, icon và chuỗi lỗi đã được kiểm tra tĩnh. Kiểm tra này không thay thế biên dịch bằng Swift/iOS SDK hoặc kiểm thử thiết bị.

Có sẵn workflow **Build unsigned iOS IPA** trong `.github/workflows/unsigned-ios.yml`. Nếu đưa mã nguồn vào repository GitHub của bạn, có thể chạy thủ công workflow này trên runner macOS để tạo IPA chưa ký; workflow chưa được chạy trong lần bàn giao này.
