# TendiesVN 1.3.1 · build 7

Ứng dụng iOS bằng SwiftUI để nhập và cài hình nền `.tendies` từ CAPlayground vào PosterBoard, lưu biên nhận từng lần cài và gỡ đúng descriptor trong biên nhận. Có thể nhập bản sao cùng gói đổi đuôi `.zip` nếu bộ chọn tệp chặn đuôi `.tendies`.

**Thay đổi ở 1.3.1:** mở rộng cách nhận diện container từ đường dẫn tệp con mà kernel trả về, thay vì chỉ chờ inode của thư mục gốc nằm trong phạm vi dò. App kiểm tra cặp filesystem bằng đường dẫn thuộc sandbox của chính nó và bổ sung chẩn đoán bước tìm container. Giữ luồng sau khi ghi gói: đóng màn chi tiết, thử mở PosterBoard, người dùng vuốt đóng thẻ trong đa nhiệm rồi chọn hình nền trong Cài đặt.

Bundle ID độc lập mặc định **`vn.tendies.wallpaper`**, có thể đổi khi build/ký, để cài song song với 3105. Backend truy cập PosterBoard dùng `bad_query` như bản 1.1.

**Trạng thái:** người dùng đã thử bản 1.3 trên iPhone: bước tìm container vẫn báo TP03 với 0 ứng viên, dù kernel trả về 190.578 đường dẫn. Bản 1.3.1 mở rộng phạm vi nhận diện ứng viên để xử lý trường hợp này; chưa xác nhận cài thành công trên thiết bị. Môi trường Linux này không có iOS SDK để thử quyền cài hoặc thao tác mở PosterBoard trên iOS 26.6.

## Bundle ID riêng và dữ liệu cũ

- ID mặc định `vn.tendies.wallpaper` khác ID của 3105, nên hai app có thể tồn tại riêng trên máy.
- Có thể chọn ID khác, chẳng hạn `com.example.tendiesvn`, nếu profile cho phép. **CFBundleIdentifier và CodeDirectory identifier trong chữ ký phải cùng là ID thực tế đã chọn.** Không giữ signing identifier MobileHouseArrest khi đổi Bundle ID.
- Mỗi ID có sandbox riêng. Gói đã nhập, cài đặt và biên nhận của bản cũ **không tự chuyển** sang app có ID mới. Giữ ứng dụng cũ nếu còn cần dữ liệu hoặc chức năng gỡ hình nền do nó cài.
- Các app cùng tác động vào PosterBoard của thiết bị. TendiesVN chỉ gỡ descriptor ghi trong biên nhận của chính lần cài của nó; app mới không tự quản lý hình nền do 3105 hoặc bản cũ cài.

## Tương thích và quyền truy cập

Bản này hướng tới iOS **26.6**; giới hạn cài là iOS/iPadOS **26.0–26.6.1**, theo dải [tác giả `bad_query` công bố](https://github.com/forcequitOS/bad_query). Đây là phạm vi upstream, chưa phải kết quả thử tất cả phiên bản bằng TendiesVN.

Backend tìm container `com.apple.PosterBoard`, kiểm tra danh tính rồi xin quyền có giới hạn cho container đó. Quyền ghi được thử trên máy trước khi cài. Phương án tìm container dự phòng có thể mất thời gian; tìm được đường dẫn chưa có nghĩa đã có quyền ghi.

Giới hạn dò vẫn là 2.000.000 inode và 4.096 ứng viên metadata. Việc nhận đường dẫn tệp con chỉ giúp suy ra thư mục gốc cần kiểm tra; quyền vào thư mục gốc chỉ được xin sau khi xác nhận metadata của PosterBoard. App đọc metadata để xác minh danh tính, không mở tệp nội dung của các ứng dụng khác.

App dùng API riêng và hành vi hệ điều hành có thể bị Apple thay đổi. Chứng chỉ doanh nghiệp tự nó không cấp quyền đổi hình nền. Simulator dùng để xem giao diện/kiểm tra nhập gói; không xác nhận chức năng cài lên hệ thống.

## Không có Mac

Dùng runner macOS của GitHub Actions để build IPA chưa ký, rồi ký trên iPhone bằng công cụ bạn đang dùng. **Không tải chứng chỉ, mật khẩu, khóa riêng hoặc profile lên GitHub.** Xem [BUILD-KHONG-CAN-MAC.md](BUILD-KHONG-CAN-MAC.md).

Workflow hiện tại đọc **`TendiesVN-source.zip`**. Tải ZIP mới cùng tên lên thay tệp đó trong repository, commit rồi chạy lại workflow; không cần sửa YAML. Bản có tên phiên bản **`TendiesVN-1.3.1-build7-source.zip`** chứa cùng mã nguồn; nếu tải bản đó, đổi tên thành `TendiesVN-source.zip` trước khi tải lên. Tải artifact của lượt chạy mới để tránh ký nhầm IPA cũ. Xem các bước trong [hướng dẫn build](BUILD-KHONG-CAN-MAC.md).

## Dựng và ký trên Mac

Cần macOS và Xcode 26 có iOS SDK. Mở `TendiesVN.xcodeproj`, scheme `TendiesVN`, đích `Any iOS Device (arm64)`, hoặc chạy:

```sh
./scripts/build-unsigned.sh
```

Đầu ra là `build/TendiesVN-unsigned.ipa`, dùng ID mặc định. Muốn build bằng ID riêng:

```sh
./scripts/build-unsigned.sh --bundle-id com.example.tendiesvn
```

IPA chưa ký chưa cài trực tiếp được. Nếu có chứng chỉ trong Keychain và profile doanh nghiệp phù hợp, dựng/xuất IPA đã ký:

```sh
./scripts/export-enterprise.sh \
  --profile /absolute/path/Enterprise.mobileprovision \
  --identity 'Apple Distribution: Ten Doanh Nghiep (TEAMID)' \
  --bundle-id vn.tendies.wallpaper
```

Đầu ra là `build/enterprise/TendiesVN.ipa`. Thay `--bundle-id` nếu dùng ID riêng. Script kiểm tra profile/chứng chỉ và hai identifier; nó không tạo quyền ký ID nằm ngoài profile. Sau xác thực, profile được chép vào kho profile của Xcode trên Mac.

Khi ký lại trên iPhone, chọn ID mặc định hoặc ID riêng được profile cho phép và dùng cùng ID trong chữ ký. Riêng `.p12` chưa đủ; cần profile `.mobileprovision` phù hợp. Sau khi cài, vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển và làm theo yêu cầu khởi động lại. Xem [hướng dẫn Apple](https://support.apple.com/118254).

Tạo manifest OTA cho IPA đã ký, đã tải lên HTTPS:

```sh
python3 scripts/make-ota-manifest.py \
  --ipa-url https://example.com/TendiesVN.ipa \
  --bundle-id vn.tendies.wallpaper \
  --version 7 \
  --output build/manifest.plist
```

ID/version manifest phải khớp `CFBundleIdentifier`/`CFBundleVersion` trong IPA thực tế. Script chỉ tạo manifest, không ký hoặc tải app lên máy chủ.

## Cài hình nền CAPlayground

1. Sao lưu iPhone trước khi thử thay đổi dữ liệu PosterBoard.
2. Vào **Cài đặt → Hình nền → Thêm hình nền mới**, thêm và dùng một hình nền **Bộ sưu tập** của Apple để khởi tạo kho descriptor.
3. Xuất `.tendies` từ [CAPlayground](https://caplayground.vercel.app), lưu vào **Tệp** và chờ tải xong nếu dùng iCloud.
4. Mở TendiesVN, nhập tệp, kiểm tra số hình nền nhận diện được và kiểm tra quyền truy cập. Nếu bị từ chối, đọc thông báo lỗi trước khi thử lại.
5. Chọn gói và bấm **Cài và mở PosterBoard**. Khi ghi xong, app đóng màn chi tiết và thử mở **PosterBoard**. Ghi xong chưa có nghĩa hình nền hiện tại đã được chọn.
6. Tự mở trình đa nhiệm của iPhone/iPad và **vuốt đóng thẻ PosterBoard**.
7. Mở **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập** rồi chọn hình nền mới.

Nếu tệp `.tendies` vẫn không chọn được, mở ứng dụng **Tệp**, nhấn giữ tệp và chọn **Nhân bản**. Đổi tên bản sao thành `Family.tendies.zip` hoặc tên tương tự rồi xác nhận dùng `.zip`. Trong TendiesVN, bấm **Nhập .tendies hoặc .zip** và chọn bản sao đó. Chỉ đổi đuôi bản sao; không dùng thao tác Nén để bọc file `.tendies` vào một ZIP khác. Giữ tệp gốc để sử dụng sau.

Muốn gỡ, chọn hình nền khác trước rồi dùng biên nhận trong tab **Đã cài**. Xóa app không tự hoàn tác dữ liệu đã ghi vào PosterBoard và làm mất biên nhận trong sandbox của app đó.

## Nếu PosterBoard không mở hoặc Bộ sưu tập chưa cập nhật

App chỉ yêu cầu mở ứng dụng hệ thống `com.apple.PosterBoard` qua `LSApplicationWorkspace`. iOS có thể từ chối API riêng này. App không tự mở trình đa nhiệm hoặc vuốt đóng thẻ; người dùng thực hiện bước đó.

Nếu mở tự động bị từ chối, app hiển thị hướng dẫn dự phòng. Mở **Cài đặt → Hình nền → Thêm hình nền mới**, sau đó mở đa nhiệm và đóng thẻ PosterBoard nếu có. Quay lại **Bộ sưu tập** để kiểm tra. Nếu chưa cập nhật, khởi động lại thiết bị rồi mở lại Bộ sưu tập.

Nếu bước truy cập hoặc ghi bị từ chối, đọc thông báo trong app và thử **Kiểm tra quyền cài** sau khi đã thêm, dùng một hình nền Bộ sưu tập của Apple. Việc sửa kiểm tra đường dẫn không bảo đảm có quyền ghi trên mọi thiết bị hoặc bản iOS.

## Định dạng nhận vào

`.tendies` là ZIP chứa cấu trúc PosterBoard. App chấp nhận `.tendies` hoặc bản sao `.zip` có cùng cấu trúc bên trong, và từ chối ZIP thông thường không chứa descriptor hình nền. CAPlayground thường và gyro dùng `descriptors/<UUID>/...`; một gói có thể chứa nhiều descriptor. Bộ đọc cũng xử lý biến thể `descriptor`/`descriptors` và `container`; biến thể `video`/`photos`/`mercury` phụ thuộc extension trên thiết bị.

Giới hạn: ZIP 512 MiB, giải nén 768 MiB, từng tệp 256 MiB, 20.000 entry, 64 descriptor. App từ chối đường dẫn thoát thư mục, symlink và ZIP không hợp lệ. Đổi tên ảnh/MP4 thành `.tendies` không tạo gói hợp lệ. Tài sản và giấy phép trong gói vẫn thuộc tác giả của chúng.

## Nguồn, giấy phép và kiểm tra

Engine hình nền được trích/sửa từ [YangJiiii/3105](https://github.com/YangJiiii/3105) tại commit `a72617ed4c764a65d8aac1e91aca95231e72a2cb`. Backend mới tham khảo `bad_query`, Placard và Bad-Poster; nguồn cụ thể và điểm giấy phép chưa rõ có trong [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). [LICENSE](LICENSE) chứa GPL-3.0; giấy phép đó không tự thay thế quyền của thành phần bên thứ ba.

Kiểm tra đường dẫn, giải nén và metadata ký độc lập; bài đường dẫn cần trình biên dịch C, bài giải nén cần thêm zlib:

```sh
python3 tests/test_extractor.py
python3 tests/test_posterboard_path.py
PYTHONDONTWRITEBYTECODE=1 python3 scripts/test-signing.py
```

Kiểm tra này không chạy API PosterBoard và không thay thế build bằng iOS SDK hoặc thử cài/gỡ trên iPhone. Dự án không đóng gói hình nền CAPlayground/Apple, chứng chỉ, khóa riêng, profile hoặc IPA đã ký.
