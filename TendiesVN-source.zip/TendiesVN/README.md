# TendiesVN Studio 2.1.0 · build 9

Ứng dụng iOS để tạo, chỉnh sửa, xuất và cài gói hình nền `.tendies`. Bundle ID giữ nguyên **`vn.tendies.wallpaper`** để cập nhật app đang có.

## Bản mới có gì

- Thẻ trạng thái cài đặt đồng bộ giao diện, hiển thị bước đang thực hiện; chỉ báo **Cài hình nền thành công** sau khi ghi thành công. Khi quay lại từ PosterBoard có thông báo hoàn tất.
- Tab **Studio**: tạo hình nền mới hoặc mở gói trong thư viện. Khung **Canvas** và công cụ **Panels** có màn riêng; Panels tách **Layers/States** với **Inspector** để tập trung từng việc.
- Chọn và sửa riêng **Background** hoặc **Floating**. Thêm ảnh, chữ, hình khối, gradient và nhóm lớp; kéo, đổi kích thước, sắp xếp lớp; chỉnh hình học, màu, độ mờ, bộ lọc và chuyển động; hoàn tác/làm lại.
- Trạng thái **Base / Locked / Unlock / Sleep**: Base đặt thuộc tính mặc định, các trạng thái còn lại có phần ghi đè riêng. Chỉnh thời gian và đường cong chuyển cảnh, phát thử **Locked → Unlock**.
- **Xuất** tạo gói `.tendies` mới trong thư viện, cho phép chia sẻ/lưu vào Tệp hoặc mở để cài. Gói gốc không bị ghi đè.
- Trình sửa chạy ngoại tuyến trong app. Không cần tài khoản hay tải tài nguyên trên mạng.

## Sử dụng Studio

1. Chọn **Studio → Bắt đầu hình nền mới**, hoặc mở chi tiết gói → **Chỉnh sửa trong Studio**. Nút **Mở** nhận gói `.tendies` có sẵn.
2. Chọn **Background** hoặc **Floating** ở thanh dưới. Hai phần có danh sách lớp riêng; có thể bật nền khi xem Floating để kiểm tra bố cục tổng thể.
3. Dùng **Add/Thêm** để thêm ảnh, chữ, hình khối, gradient hoặc nhóm. Trên Canvas, chọn và kéo lớp; dùng phóng to, thu nhỏ, vừa khung hoặc di chuyển khung nhìn khi cần.
4. Mở **Panels**. Trong **Layers/States**, chọn lớp hoặc trạng thái; sang **Inspector** để chỉnh thuộc tính của lớp đang chọn. Quay lại Canvas để xem bố cục.
5. Chọn **Base** để sửa mặc định. Chọn **Locked**, **Unlock** hoặc **Sleep** trước khi sửa thuộc tính cho riêng trạng thái đó. Có thể xóa phần ghi đè để trạng thái dùng lại Base. Chỉnh thời gian chuyển cảnh và đường cong `linear`, `easeIn`, `easeOut` hoặc `easeInOut`, rồi phát thử **Locked → Unlock**.
6. Nhấn **Xuất**, rồi **Chia sẻ / Lưu vào Tệp** hoặc **Xem gói và cài**. Bản xuất được lưu thành gói mới; gói đã mở không bị ghi đè. Xuất trước khi đóng Studio nếu muốn giữ thay đổi.

Các file từ CAPlayground có thể chứa mask, filter, trạng thái hoặc chuyển động nâng cao mà Studio chưa dựng được đầy đủ. App thông báo khi gặp những thành phần này và giữ dữ liệu gốc khi xuất; không cam kết mọi gói đều xem trước giống hoàn toàn. Bản xuất có manifest riêng để mở lại các lớp, trạng thái và chuyển động do Studio tạo. Giới hạn trình sửa là 128 MB dữ liệu và 128 lớp mỗi cảnh.

Ảnh thêm mới được chuyển thành PNG có hướng đúng, tối đa cạnh 4096 và 8 triệu điểm ảnh. Ảnh/tài nguyên có sẵn trong gói nhập được giữ nguyên.

## Cài hình nền

Cơ chế cài giữ nguyên từ bản **1.3.1 (7)** mà người dùng đã xác nhận cài được. Sau khi ghi thành công, app thử mở PosterBoard; mở đa nhiệm và vuốt đóng thẻ PosterBoard, rồi chọn hình nền mới trong **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập**.

Phạm vi backend là iOS/iPadOS 26.0–26.6.1. Chứng chỉ doanh nghiệp dùng để ký/cài app; quyền ghi được kiểm tra riêng trên thiết bị. Giữ cùng Bundle ID khi cập nhật để giữ thư viện và biên nhận. Mỗi lần xuất tạo một bản mới; gỡ hình nền theo biên nhận trong tab **Đã cài**.

## Không có Mac

Tải **`TendiesVN-source.zip`** mới, tải lên thay ZIP cùng tên ở thư mục gốc repository, commit rồi chạy lại **Actions → Build IPA from ZIP → Run workflow**. Không cần sửa workflow đang dùng. Tải artifact **TendiesVN-unsigned** của lượt chạy mới, giải nén rồi ký IPA bằng công cụ trên iPhone như trước. Kiểm tra trong app đã hiện **2.1.0 (9)**.

Bản có tên `TendiesVN-2.1.0-build9-source.zip` chứa cùng mã nguồn; đổi tên thành `TendiesVN-source.zip` trước khi upload. Xem [hướng dẫn không cần Mac](BUILD-KHONG-CAN-MAC.md).

## Kiểm tra và giới hạn xác nhận

Các kiểm tra TypeScript/build Studio, vòng mở–sửa–xuất gói, XML/plist và C/ký giúp kiểm tra mã nhưng không thay thế thử thiết bị. Môi trường hiện tại không có Xcode/iOS SDK: Studio 2.1 chưa được xác nhận trên iPhone tại đây. GitHub Actions thực hiện bước build native; việc hiển thị trạng thái, chuyển cảnh và hình nền mới tạo trong PosterBoard cần kiểm tra trên thiết bị. Cơ chế cài giữ nguyên từ bản 1.3.1 đã được người dùng xác nhận.

## Dựng lại tài nguyên Studio

ZIP nguồn đã kèm `TendiesVN/Resources/StudioEditor.zip`; build iOS dùng trực tiếp, không chạy npm hay tải tài nguyên mạng. Nếu sửa mã Studio, dùng Node.js để dựng lại:

```sh
cd Studio
npm ci
npm test
npm run build
cd ..
python3 scripts/bundle-studio.py
```

Studio được viết riêng để tương tác với cấu trúc gói, không kèm mã, artwork hay ZIP mẫu của CAPlayground. Giấy phép runtime nằm trong `StudioEditor.zip/STUDIO_THIRD_PARTY.txt`.

## Dựng và ký trên Mac

Cần macOS và Xcode 26 có iOS SDK. Mở `TendiesVN.xcodeproj`, scheme `TendiesVN`, đích `Any iOS Device (arm64)`, hoặc chạy:

```sh
./scripts/build-unsigned.sh
```

Đầu ra là `build/TendiesVN-unsigned.ipa`, dùng ID mặc định. Muốn build bằng ID riêng:

```sh
./scripts/build-unsigned.sh --bundle-id com.example.tendiesvn
```

IPA chưa ký chưa cài trực tiếp được. Nếu có chứng chỉ trong Keychain và profile doanh nghiệp phù hợp, dựng/xuất IPA đã ký:

```sh
./scripts/export-enterprise.sh \
  --profile /absolute/path/Enterprise.mobileprovision \
  --identity 'Apple Distribution: Ten Doanh Nghiep (TEAMID)' \
  --bundle-id vn.tendies.wallpaper
```

Đầu ra là `build/enterprise/TendiesVN.ipa`. Thay `--bundle-id` nếu dùng ID riêng. Script kiểm tra profile/chứng chỉ và hai identifier; nó không tạo quyền ký ID nằm ngoài profile. Sau xác thực, profile được chép vào kho profile của Xcode trên Mac.

Khi ký lại trên iPhone, chọn ID mặc định hoặc ID riêng được profile cho phép và dùng cùng ID trong chữ ký. Riêng `.p12` chưa đủ; cần profile `.mobileprovision` phù hợp. Sau khi cài, vào **Cài đặt → Cài đặt chung → VPN & Quản lý thiết bị** để tin cậy nhà phát triển và làm theo yêu cầu khởi động lại. Xem [hướng dẫn Apple](https://support.apple.com/118254).

Tạo manifest OTA cho IPA đã ký, đã tải lên HTTPS:

```sh
python3 scripts/make-ota-manifest.py \
  --ipa-url https://example.com/TendiesVN.ipa \
  --bundle-id vn.tendies.wallpaper \
  --version 9 \
  --output build/manifest.plist
```

ID/version manifest phải khớp `CFBundleIdentifier`/`CFBundleVersion` trong IPA thực tế. Script chỉ tạo manifest, không ký hoặc tải app lên máy chủ.

## Cài hình nền CAPlayground

1. Sao lưu iPhone trước khi thử thay đổi dữ liệu PosterBoard.
2. Vào **Cài đặt → Hình nền → Thêm hình nền mới**, thêm và dùng một hình nền **Bộ sưu tập** của Apple để khởi tạo kho descriptor.
3. Xuất `.tendies` từ [CAPlayground](https://caplayground.vercel.app), lưu vào **Tệp** và chờ tải xong nếu dùng iCloud.
4. Mở TendiesVN, nhập tệp, kiểm tra số hình nền nhận diện được và kiểm tra quyền truy cập. Nếu bị từ chối, đọc thông báo lỗi trước khi thử lại.
5. Chọn gói và bấm **Cài và mở PosterBoard**. Khi ghi xong, app đóng màn chi tiết và thử mở **PosterBoard**. Ghi xong chưa có nghĩa hình nền hiện tại đã được chọn.
6. Tự mở trình đa nhiệm của iPhone/iPad và **vuốt đóng thẻ PosterBoard**.
7. Mở **Cài đặt → Hình nền → Thêm hình nền mới → Bộ sưu tập** rồi chọn hình nền mới.

Nếu tệp `.tendies` vẫn không chọn được, mở ứng dụng **Tệp**, nhấn giữ tệp và chọn **Nhân bản**. Đổi tên bản sao thành `Family.tendies.zip` hoặc tên tương tự rồi xác nhận dùng `.zip`. Trong TendiesVN, bấm **Nhập .tendies hoặc .zip** và chọn bản sao đó. Chỉ đổi đuôi bản sao; không dùng thao tác Nén để bọc file `.tendies` vào một ZIP khác. Giữ tệp gốc để sử dụng sau.

Muốn gỡ, chọn hình nền khác trước rồi dùng biên nhận trong tab **Đã cài**. Xóa app không tự hoàn tác dữ liệu đã ghi vào PosterBoard và làm mất biên nhận trong sandbox của app đó.

## Nếu PosterBoard không mở hoặc Bộ sưu tập chưa cập nhật

App chỉ yêu cầu mở ứng dụng hệ thống `com.apple.PosterBoard` qua `LSApplicationWorkspace`. iOS có thể từ chối API riêng này. App không tự mở trình đa nhiệm hoặc vuốt đóng thẻ; người dùng thực hiện bước đó.

Nếu mở tự động bị từ chối, app hiển thị hướng dẫn dự phòng. Mở **Cài đặt → Hình nền → Thêm hình nền mới**, sau đó mở đa nhiệm và đóng thẻ PosterBoard nếu có. Quay lại **Bộ sưu tập** để kiểm tra. Nếu chưa cập nhật, khởi động lại thiết bị rồi mở lại Bộ sưu tập.

Nếu bước truy cập hoặc ghi bị từ chối, đọc thông báo trong app và thử **Kiểm tra quyền cài** sau khi đã thêm, dùng một hình nền Bộ sưu tập của Apple. Việc sửa kiểm tra đường dẫn không bảo đảm có quyền ghi trên mọi thiết bị hoặc bản iOS.

## Định dạng nhận vào

`.tendies` là ZIP chứa cấu trúc PosterBoard. App chấp nhận `.tendies` hoặc bản sao `.zip` có cùng cấu trúc bên trong, và từ chối ZIP thông thường không chứa descriptor hình nền. CAPlayground thường và gyro dùng `descriptors/<UUID>/...`; một gói có thể chứa nhiều descriptor. Bộ đọc cũng xử lý biến thể `descriptor`/`descriptors` và `container`; biến thể `video`/`photos`/`mercury` phụ thuộc extension trên thiết bị.

Giới hạn: ZIP 512 MiB, giải nén 768 MiB, từng tệp 256 MiB, 20.000 entry, 64 descriptor. App từ chối đường dẫn thoát thư mục, symlink và ZIP không hợp lệ. Đổi tên ảnh/MP4 thành `.tendies` không tạo gói hợp lệ. Tài sản và giấy phép trong gói vẫn thuộc tác giả của chúng.

## Nguồn, giấy phép và kiểm tra

Engine hình nền được trích/sửa từ [YangJiiii/3105](https://github.com/YangJiiii/3105) tại commit `a72617ed4c764a65d8aac1e91aca95231e72a2cb`. Backend mới tham khảo `bad_query`, Placard và Bad-Poster; nguồn cụ thể và điểm giấy phép chưa rõ có trong [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). [LICENSE](LICENSE) chứa GPL-3.0; giấy phép đó không tự thay thế quyền của thành phần bên thứ ba.

Kiểm tra đường dẫn, giải nén và metadata ký độc lập; bài đường dẫn cần trình biên dịch C, bài giải nén cần thêm zlib:

```sh
python3 tests/test_extractor.py
python3 tests/test_posterboard_path.py
PYTHONDONTWRITEBYTECODE=1 python3 scripts/test-signing.py
```

Kiểm tra này không chạy API PosterBoard và không thay thế build bằng iOS SDK hoặc thử cài/gỡ trên iPhone. Dự án không đóng gói hình nền CAPlayground/Apple, chứng chỉ, khóa riêng, profile hoặc IPA đã ký.
