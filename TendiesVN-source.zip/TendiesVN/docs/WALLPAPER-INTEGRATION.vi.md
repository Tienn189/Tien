# Cài hình nền TendiesVN theo luồng YanDevin

Bản sửa đưa bộ cài hình nền từ [TendiesVN-source.zip](https://github.com/Tienn189/Tien/blob/main/TendiesVN-source.zip) vào app tại `murk-sus/kamui-escape`. Giao diện UIKit, tên hiển thị **KAMUI**, bundle ID mặc định `com.kamui.escape` và executable `BQTool` được giữ lại; tên tệp IPA mới bắt đầu bằng `1809`.

Màn hình PosterBoard hiện dùng bộ cài TendiesVN qua `TNWallpaperEngine`, thay cho bộ ghi cũ cố định generation `61`. Tích hợp này chỉ mở rộng phần hình nền. Chức năng MobileGestalt và phạm vi hỗ trợ của cơ chế KAMUI gốc không được mở rộng theo bảng dưới đây.

Màn hình thư viện hình nền được bổ sung theo luồng **Wallpaper Studio** của [YanDevin](https://github.com/minhdepzailaocai2010-bit/YanDevin/blob/7bc249bdf7ce27ee4bd35cc02d6fb4a9fca096a4/YanDevin/PosterBoardView.swift): xem trước gói, xem số hình nền và loại provider, chọn gói cần cài rồi áp dụng. Bộ cài được đối chiếu phần nhận diện descriptor, alias provider, generation và làm mới PosterBoard của nguồn đó. Giao diện được tích hợp bằng UIKit vào ứng dụng hiện có.

## Phạm vi iOS của bộ cài hình nền

Bảng này phản ánh điều kiện chọn backend trong mã nguồn được cung cấp. Chưa có bản build iOS hoặc kết quả thử trên thiết bị thật trong phiên tích hợp này.

| Phiên bản / build | Backend | Điều kiện sử dụng |
| --- | --- | --- |
| iOS 17.0–17.7 | 3105 / PocketPoster | Tự tìm container PosterBoard trên thiết bị; generation `61`. Điều kiện gốc chấp nhận mọi patch của nhánh 17.0–17.7. |
| iOS 18.0–18.7.1 | 3105 / PocketPoster | Tự tìm container; có thể lưu UUID thủ công làm phương án dự phòng. |
| iOS 26.0–26.6.1 | BadQuery | Tự tìm container, nhận diện generation đang có và kiểm tra quyền ghi. |
| iOS 27.0, đúng một trong các build beta bên dưới | BadQuery | Kiểm tra build chính xác; không áp dụng chung cho mọi bản beta. |
| iOS 27.0 ngoài danh sách BadQuery, hoặc 27.0.1 | Airlift | Cần hồ sơ pairing của thiết bị và kết nối qua LocalDevVPN. |

Danh sách build beta iOS 27.0 dùng BadQuery:

| Build | Nhãn tham chiếu trong nguồn |
| --- | --- |
| `24A5355q` | Developer Beta 1 |
| `24A5370h` | Developer Beta 2 |
| `24A5380h` | Developer Beta 3 / Public Beta 1 |
| `24A5380l` | Bản sửa đổi Developer Beta 3 cho iPad |
| `24A5390f` | Developer Beta 4 / Public Beta 2 |

Các bản ngoài điều kiện trên, gồm iOS 18.7.2, 26.6.2 và 27.1–27.2, chưa có backend hình nền trong bản tích hợp này. Vẫn có thể nhập và tải gói. Simulator không cài hình nền vào hệ thống. Các ghi nhận hỗ trợ iOS 27.2 của KAMUI gốc trong README thuộc cơ chế MobileGestalt/MCM cũ, không phải xác nhận cho bộ cài hình nền mới.

## Build IPA

Cần macOS, Xcode 26 trở lên, Python 3 và kết nối mạng để tải công cụ/phụ thuộc Rust. Script dựng lại Airlift từ nguồn đã ghim thay vì sử dụng thư viện nhị phân cũ trong ZIP.

```sh
./build.sh
# Kết quả: build/1809-<version>-unsigned.ipa
```

Nếu cần dùng bundle ID phù hợp với cấu hình ký của bạn:

```sh
BID=com.example.my1809 ./build.sh
```

Có thể build trên GitHub: đẩy mã nguồn lên repository của bạn, mở **Actions → Build unsigned iOS app → Run workflow**, chờ hoàn thành rồi tải artifact **1809-unsigned**. Workflow nằm tại `.github/workflows/build-ios.yml`.

Với cấu hình Codemagic hiện có của `Tienn189/Tien`, giữ nguyên tên tệp **TendiesVN-source.zip** ở gốc repo. ZIP được đóng gói với thư mục gốc **TendiesVN/** để khớp lệnh `test -f extracted/TendiesVN/scripts/build-unsigned.sh`. Script build tạo IPA có phiên bản và bản sao tên cố định **build/1809-unsigned.ipa** để bước đóng gói `TendiesVN-download.zip` hiện có hoạt động. Log Xcode được lưu tại **build/xcodebuild.log**. Khi thay ZIP trên GitHub, chạy lại workflow **tendies-vn**; không cần đổi tên ứng dụng hay sửa `codemagic.yaml` hiện có.

Đã sửa lỗi trong log Codemagic/Xcode 26.3 được cung cấp: `redefinition of module 'AirliftFFI'`. Xcode đã đưa modulemap của XCFramework vào thư mục sản phẩm `include`; cấu hình cũ còn thêm trực tiếp thư mục `Headers` của từng slice vào `SWIFT_INCLUDE_PATHS`, làm module bị khai báo hai lần. Project generator đã bỏ hai đường dẫn trực tiếp đó, giữ XCFramework trong bước liên kết. Không tắt explicit modules và không thay SDK. Nếu build thất bại, script in lại lỗi Xcode đầu tiên ở cuối log; kết quả build Xcode sau bản sửa này vẫn cần xác nhận trên Codemagic/macOS.

Log tiếp theo (`Tien_3_artifacts.zip`) đã qua bước quét module và báo lỗi trong `BQCore.m`: `typedef redefinition with different types ('void *' vs 'NSObject<OS_xpc_object> *')`. Kiểu con trỏ opaque dùng riêng cho lời gọi XPC động đã được đổi thành `bq_xpc_object_t`, giữ cách giải phóng tường minh hiện có và không định nghĩa lại `xpc_object_t` của SDK. Bản sửa này vẫn cần build lại trên Codemagic để xác nhận toàn bộ IPA.

IPA được xuất chưa ký. Ký bằng danh tính và provisioning profile phù hợp trước khi cài. Bản đầy đủ dùng Objective-C cùng Swift, yêu cầu iOS 17 trở lên; lệnh build clang/Linux với SDK 14.5 của KAMUI cũ đã được thay thế.

## Sử dụng hình nền

1. Mở **PosterBoard → Thiết lập hình nền / Pairing** để xem backend được chọn cho thiết bị.
2. Trên iOS 17–18, app tự tìm container khi cài lần đầu. Nếu có UUID container `com.apple.PosterBoard` của chính thiết bị, có thể nhập ở mục **UUID container PosterBoard**; để trống để xóa giá trị đã lưu và tìm lại.
3. Với Airlift, bật **LocalDevVPN**, cài ứng dụng **Sách của Apple** và mở Sách ít nhất một lần. Nhập hồ sơ `.mobilepair`, `.mobiledevicepairing` hoặc `.plist` của thiết bị vào **Nhập hồ sơ pairing**. Địa chỉ IPv4 mặc định là `10.7.0.1`; chỉ đổi khi cấu hình VPN dùng địa chỉ khác. Bộ kết nối hiện không nhận IPv6 hoặc tên máy. Bản tích hợp cung cấp nhập hồ sơ, không có giao diện tạo pairing mới trên thiết bị.
4. Nhập gói `.tendies` / `.zip` từ ứng dụng Tệp hoặc tải từ danh mục hình nền. Mỗi gói có số descriptor, provider và ảnh xem trước; gói video có thể dùng khung hình video làm ảnh xem trước. Chọn các gói cần cài rồi nhấn áp dụng. Lựa chọn được lưu cho lần mở app tiếp theo. Giữ thiết bị mở khóa khi cài qua Airlift. Việc nhập hồ sơ chỉ xác nhận định dạng; kết nối được xác thực khi bắt đầu cài.
5. Cài xong, mở **PosterBoard** rồi vuốt đóng thẻ đó trong đa nhiệm để làm mới Bộ sưu tập. Giao diện cũng giữ nút Respring của KAMUI.

## Gói hình nền và hoàn tác

Bộ cài nhận `.tendies` hoặc `.zip` có cấu trúc descriptor hợp lệ, gồm các gói `container`, descriptor thường, ordered descriptor và video/photo descriptor mà nguồn TendiesVN xử lý. Tệp ZIP thông thường chỉ chứa ảnh không tự trở thành gói hình nền.

Trên backend BadQuery, bộ cài nhận diện generation số mới nhất đang có và ghi vào alias provider cũ/mới phù hợp như YanDevin. Các thư mục descriptor còn thiếu của provider đã biết được tạo trong container đã xác thực. Gói xuất nguyên container giữ nội dung identifier gốc; khi tên thư mục UUID đã tồn tại, bộ cài dùng thư mục mới để giữ hình nền có sẵn. Bộ cài ghi dấu làm mới PosterBoard sau khi cài; việc đóng thẻ PosterBoard vẫn cần thiết trên các bản iOS giữ cache. Airlift vẫn dùng generation `61` theo backend đi kèm, nên thay đổi này không xác nhận hỗ trợ generation khác qua Airlift.

Xóa một gói trong thư viện chỉ xóa bản nhập của app; hình nền đã cài trong iOS được quản lý riêng. Ảnh xem trước là thumbnail, không thay thế việc kiểm tra hình nền thực tế trong Cài đặt iOS.

Giới hạn được giữ từ nguồn:

- Tệp nén tối đa **512 MiB**; tổng sau giải nén tối đa **768 MiB**.
- Mỗi entry tối đa **256 MiB**, tối đa **20.000 entry** và **64 descriptor**.
- Dùng ZIP stored/deflate; không nhận ZIP64, gói mã hóa, symlink hoặc đường dẫn vượt ra ngoài thư mục giải nén. Bộ giải nén kiểm tra kích thước và CRC.

**Hoàn tác lần cài gần nhất** dùng nhật ký/biên nhận của bộ cài BadQuery mới để gỡ đúng descriptor thuộc lần cài đó, giữ các mục có sẵn. Nó không hoàn tác các lần cài bằng bộ ghi KAMUI cũ. Nút reset xóa toàn bộ provider đã được thay khỏi giao diện.

Airlift và PocketPoster chưa có hoàn tác bằng biên nhận trong app; quản lý/xóa hình nền qua Cài đặt iOS. Nếu lỗi giữa lúc ghi bằng hai backend này, một phần gói có thể đã được cài; kiểm tra PosterBoard trước khi cài lại.

## Kiểm tra đã thực hiện

```sh
python3 -m unittest discover -s tests -v
```

Kết quả trong môi trường Linux: **26 kiểm tra, 24 đạt, 2 bỏ qua**. Hai mục bỏ qua là archive mẫu tùy chọn và bộ kiểm tra Swift cần macOS. Kiểm tra kiểu XPC dùng compiler C với chính các typedef trong BQCore, xác nhận không xung đột khi SDK đã định nghĩa xpc_object_t. Hai kiểm tra cấu hình mới xác nhận Airlift chỉ được liên kết một lần qua XCFramework và không thêm trực tiếp đường dẫn header của slice. Project generator xác nhận 41 tệp nguồn và các script build đạt kiểm tra cú pháp. Bộ kiểm tra Swift mới dùng chính mã model/installer để kiểm tra 6 nhóm tình huống; GitHub Actions sẽ chạy bộ này trên macOS trước khi build IPA.

Các kiểm tra dùng mã C thực để kiểm tra ranh giới phiên bản/build BadQuery, đường dẫn container và giải nén ZIP. Kiểm tra archive mẫu tùy chọn được bỏ qua khi chưa cung cấp `--templates-root`. Kiểm tra portable không chứng minh Swift/UIKit đã build thành công hoặc backend hoạt động trên thiết bị. Môi trường Linux của phiên tích hợp không có Xcode hay thiết bị iOS; cần hoàn thành build macOS và các bước thử thiết bị trong [tests/README.md](../tests/README.md) trước khi xác nhận hoạt động trên từng thiết bị/build.

## Giấy phép

Ứng dụng kết hợp mã hình nền GPL-3.0-only phải được phân phối theo GPL-3.0; giữ thông báo MIT cho phần KAMUI gốc. Xem [thông báo giấy phép của bản kết hợp](../THIRD_PARTY_NOTICES.md), [thông báo MIT gốc](../LICENSE), [giấy phép nguồn hình nền](../vendor/TendiesWallpaper/LICENSE-GPL-3.0.txt), [thông báo bên thứ ba](../vendor/TendiesWallpaper/UPSTREAM_THIRD_PARTY_NOTICES.md) và [nguồn gốc archive](../vendor/TendiesWallpaper/README.md). Khi phân phối ứng dụng đã kết hợp, cung cấp mã nguồn tương ứng theo điều kiện GPL.
