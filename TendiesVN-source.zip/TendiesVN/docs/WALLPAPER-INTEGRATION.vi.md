# Tích hợp hình nền TendiesVN vào KAMUI / 1809

Bản sửa đưa bộ cài hình nền từ [TendiesVN-source.zip](https://github.com/Tienn189/Tien/blob/main/TendiesVN-source.zip) vào app tại `murk-sus/kamui-escape`. Giao diện UIKit, tên hiển thị **KAMUI**, bundle ID mặc định `com.kamui.escape` và executable `BQTool` được giữ lại; tên tệp IPA mới bắt đầu bằng `1809`.

Màn hình PosterBoard hiện dùng bộ cài TendiesVN qua `TNWallpaperEngine`, thay cho bộ ghi cũ cố định generation `61`. Tích hợp này chỉ mở rộng phần hình nền. Chức năng MobileGestalt và phạm vi hỗ trợ của cơ chế KAMUI gốc không được mở rộng theo bảng dưới đây.

## Phạm vi iOS của bộ cài hình nền

Bảng này phản ánh điều kiện chọn backend trong mã nguồn được cung cấp. Chưa có bản build iOS hoặc kết quả thử trên thiết bị thật trong phiên tích hợp này.

| Phiên bản / build | Backend | Điều kiện sử dụng |
| --- | --- | --- |
| iOS 17.0–17.7 | 3105 / PocketPoster | Tự tìm container PosterBoard trên thiết bị; generation `61`. Điều kiện gốc chấp nhận mọi patch của nhánh 17.0–17.7. |
| iOS 18.0–18.7.1 | 3105 / PocketPoster | Tự tìm container; có thể lưu UUID thủ công làm phương án dự phòng. |
| iOS 26.0–26.6.1 | BadQuery | Tự tìm container, nhận diện generation đang có và kiểm tra quyền ghi. |
| iOS 27.0, đúng một trong các build beta bên dưới | BadQuery | Kiểm tra build chính xác; không áp dụng chung cho mọi bản beta. |
| iOS 27.0 ngoài danh sách BadQuery, hoặc 27.0.1 | Airlift | Cần hồ sơ pairing của thiết bị và kết nối qua LocalDevVPN. |

Danh sách build beta iOS 27.0 dùng BadQuery:

| Build | Nhãn tham chiếu trong nguồn |
| --- | --- |
| `24A5355q` | Developer Beta 1 |
| `24A5370h` | Developer Beta 2 |
| `24A5380h` | Developer Beta 3 / Public Beta 1 |
| `24A5380l` | Bản sửa đổi Developer Beta 3 cho iPad |
| `24A5390f` | Developer Beta 4 / Public Beta 2 |

Các bản ngoài điều kiện trên, gồm iOS 18.7.2, 26.6.2 và 27.1–27.2, chưa có backend hình nền trong bản tích hợp này. Vẫn có thể nhập và tải gói. Simulator không cài hình nền vào hệ thống. Các ghi nhận hỗ trợ iOS 27.2 của KAMUI gốc trong README thuộc cơ chế MobileGestalt/MCM cũ, không phải xác nhận cho bộ cài hình nền mới.

## Build IPA

Cần macOS, Xcode 26 trở lên, Python 3 và kết nối mạng để tải công cụ/phụ thuộc Rust. Script dựng lại Airlift từ nguồn đã ghim thay vì sử dụng thư viện nhị phân cũ trong ZIP.

```sh
./build.sh
# Kết quả: build/1809-<version>-unsigned.ipa
```

Nếu cần dùng bundle ID phù hợp với cấu hình ký của bạn:

```sh
BID=com.example.my1809 ./build.sh
```

Có thể build trên GitHub: đẩy mã nguồn lên repository của bạn, mở **Actions → Build unsigned iOS app → Run workflow**, chờ hoàn thành rồi tải artifact **1809-unsigned**. Workflow nằm tại `.github/workflows/build-ios.yml`.

IPA được xuất chưa ký. Ký bằng danh tính và provisioning profile phù hợp trước khi cài. Bản đầy đủ dùng Objective-C cùng Swift, yêu cầu iOS 17 trở lên; lệnh build clang/Linux với SDK 14.5 của KAMUI cũ đã được thay thế.

## Sử dụng hình nền

1. Mở **PosterBoard → Thiết lập hình nền / Pairing** để xem backend được chọn cho thiết bị.
2. Trên iOS 17–18, app tự tìm container khi cài lần đầu. Nếu có UUID container `com.apple.PosterBoard` của chính thiết bị, có thể nhập ở mục **UUID container PosterBoard**; để trống để xóa giá trị đã lưu và tìm lại.
3. Với Airlift, bật **LocalDevVPN**, cài ứng dụng **Sách của Apple** và mở Sách ít nhất một lần. Nhập hồ sơ `.mobilepair`, `.mobiledevicepairing` hoặc `.plist` của thiết bị vào **Nhập hồ sơ pairing**. Địa chỉ IPv4 mặc định là `10.7.0.1`; chỉ đổi khi cấu hình VPN dùng địa chỉ khác. Bộ kết nối hiện không nhận IPv6 hoặc tên máy. Bản tích hợp cung cấp nhập hồ sơ, không có giao diện tạo pairing mới trên thiết bị.
4. Chọn **Import .tendies** hoặc **Explore Wallpapers**, rồi **Apply All / Apply now**. Giữ thiết bị mở khóa khi cài qua Airlift. Việc nhập hồ sơ chỉ xác nhận định dạng; kết nối được xác thực khi bắt đầu cài.
5. Cài xong, mở **PosterBoard** rồi vuốt đóng thẻ đó trong đa nhiệm để làm mới Bộ sưu tập. Giao diện cũng giữ nút Respring của KAMUI.

## Gói hình nền và hoàn tác

Bộ cài nhận `.tendies` hoặc `.zip` có cấu trúc descriptor hợp lệ, gồm các gói `container`, descriptor thường, ordered descriptor và video/photo descriptor mà nguồn TendiesVN xử lý. Tệp ZIP thông thường chỉ chứa ảnh không tự trở thành gói hình nền.

Giới hạn được giữ từ nguồn:

- Tệp nén tối đa **512 MiB**; tổng sau giải nén tối đa **768 MiB**.
- Mỗi entry tối đa **256 MiB**, tối đa **20.000 entry** và **64 descriptor**.
- Dùng ZIP stored/deflate; không nhận ZIP64, gói mã hóa, symlink hoặc đường dẫn vượt ra ngoài thư mục giải nén. Bộ giải nén kiểm tra kích thước và CRC.

**Hoàn tác lần cài gần nhất** dùng nhật ký/biên nhận của bộ cài BadQuery mới để gỡ đúng descriptor thuộc lần cài đó, giữ các mục có sẵn. Nó không hoàn tác các lần cài bằng bộ ghi KAMUI cũ. Nút reset xóa toàn bộ provider đã được thay khỏi giao diện.

Airlift và PocketPoster chưa có hoàn tác bằng biên nhận trong app; quản lý/xóa hình nền qua Cài đặt iOS. Nếu lỗi giữa lúc ghi bằng hai backend này, một phần gói có thể đã được cài; kiểm tra PosterBoard trước khi cài lại.

## Kiểm tra đã thực hiện

```sh
python3 -m unittest discover -s tests -v
```

Đã chạy **22 kiểm tra: 21 đạt, 1 bỏ qua có chủ đích** do thiếu bộ archive mẫu tùy chọn. Các kiểm tra dùng mã C thực để kiểm tra ranh giới phiên bản/build BadQuery, đường dẫn container và giải nén ZIP. Chúng không chứng minh Swift/UIKit đã build thành công hoặc backend hoạt động trên thiết bị. Chưa chạy Xcode, xuất IPA hay cài thử trên iOS trong môi trường Linux của phiên này.

## Giấy phép

Ứng dụng kết hợp mã hình nền GPL-3.0-only phải được phân phối theo GPL-3.0; giữ thông báo MIT cho phần KAMUI gốc. Xem [thông báo giấy phép của bản kết hợp](../THIRD_PARTY_NOTICES.md), [thông báo MIT gốc](../LICENSE), [giấy phép nguồn hình nền](../vendor/TendiesWallpaper/LICENSE-GPL-3.0.txt), [thông báo bên thứ ba](../vendor/TendiesWallpaper/UPSTREAM_THIRD_PARTY_NOTICES.md) và [nguồn gốc archive](../vendor/TendiesWallpaper/README.md). Khi phân phối ứng dụng đã kết hợp, cung cấp mã nguồn tương ứng theo điều kiện GPL.
