#!/usr/bin/env python3
"""Type-check the production guide against the real iOS SwiftUI SDK.

This catches API overload errors that a syntax parser cannot detect.
Linux explicitly skips because SwiftUI and the iOS SDK are unavailable.
"""

from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(sys.platform == "darwin" and shutil.which("xcrun") and shutil.which("swiftc"),
                     "requires Xcode with the iOS Simulator SDK")
class SwiftUIGuideTests(unittest.TestCase):
    def test_real_guide_uses_supported_swiftui_initializers(self):
        sdk = subprocess.check_output(["xcrun", "--sdk", "iphonesimulator", "--show-sdk-path"], text=True).strip()
        architecture = "arm64" if platform.machine() == "arm64" else "x86_64"
        with tempfile.TemporaryDirectory(prefix="1809-guide-typecheck-") as temporary:
            helper = Path(temporary) / "GuideTheme.swift"
            helper.write_text("import SwiftUI\nextension Color { static var appBackground: Color { .clear } }\n")
            subprocess.run([
                "xcrun", "swiftc", "-typecheck", "-swift-version", "5",
                "-sdk", sdk, "-target", architecture + "-apple-ios17.0-simulator",
                str(ROOT / "TendiesVN/Views/WallpaperGuideView.swift"),
                str(ROOT / "TendiesVN/App/DeviceCompatibility.swift"), str(helper),
            ], check=True, timeout=120)


if __name__ == "__main__":
    unittest.main()
