#!/usr/bin/env python3
"""Exercise the shared native/Swift PosterBoard compatibility policy as C."""
# SPDX-License-Identifier: GPL-3.0-only
import ctypes
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
RECOGNIZED_BUILDS = (
    b"24A5355q", b"24A5370h", b"24A5380h", b"24A5380l", b"24A5390f",
)


class PosterBoardSupportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
        if compiler is None:
            raise RuntimeError("A C compiler is required")
        cls.build = tempfile.TemporaryDirectory(prefix="1809-support-build-")
        cls.addClassCleanup(cls.build.cleanup)
        library = Path(cls.build.name) / "posterboard_support.so"
        shared_flag = "-dynamiclib" if sys.platform == "darwin" else "-shared"
        subprocess.run([
            compiler, "-std=c11", "-Wall", "-Wextra", "-Werror", "-fPIC", shared_flag,
            str(ROOT / "vendor/TendiesWallpaper/Engine/posterboard_support.c"), "-o", str(library),
        ], check=True)
        cls.library = ctypes.CDLL(str(library))
        cls.supports = cls.library.tendies_posterboard_backend_supports
        cls.supports.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_char_p]
        cls.supports.restype = ctypes.c_bool

    def test_ios26_range_boundaries_do_not_require_a_build_string(self):
        for version in [(26, 0, 0), (26, 0, 99), (26, 5, 99), (26, 6, 0), (26, 6, 1)]:
            for build in [None, b"", b"unknown"]:
                with self.subTest(version=version, build=build):
                    self.assertTrue(self.supports(*version, build))
        for version in [(26, 6, 2), (26, 6, 99), (26, 7, 0), (26, 99, 0)]:
            with self.subTest(version=version):
                self.assertFalse(self.supports(*version, RECOGNIZED_BUILDS[0]))

    def test_ios27_accepts_each_recognized_phone_or_revised_ipad_build(self):
        for build in RECOGNIZED_BUILDS:
            with self.subTest(build=build):
                self.assertTrue(self.supports(27, 0, 0, build))

    def test_ios27_build_matches_are_exact_and_null_safe(self):
        invalid = [None, b"", b"unknown", b"24A5380i", b"24A5390g", b"24A5400a"]
        for build in RECOGNIZED_BUILDS:
            invalid.extend([
                build.lower(), build.upper(), build[:-1], build + b"x",
                b" " + build, build + b" ", build + b"\n",
            ])
        for build in invalid:
            with self.subTest(build=build):
                self.assertFalse(self.supports(27, 0, 0, build))

    def test_other_versions_stay_unsupported_even_with_a_recognized_build(self):
        for version in [
            (0, 0, 0), (16, 7, 0), (17, 0, 0), (17, 7, 0),
            (18, 0, 0), (18, 7, 1), (25, 0, 0),
            (27, 0, 1), (27, 1, 0), (28, 0, 0),
        ]:
            with self.subTest(version=version):
                self.assertFalse(self.supports(*version, RECOGNIZED_BUILDS[0]))

    def test_negative_version_components_are_rejected(self):
        for version in [
            (-1, 0, 0), (26, -1, 0), (26, 0, -1),
            (27, -1, 0), (27, 0, -1), (-1, -1, -1),
        ]:
            with self.subTest(version=version):
                self.assertFalse(self.supports(*version, RECOGNIZED_BUILDS[0]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
