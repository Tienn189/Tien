"""Check the build graph contract for Xcode-managed XCFramework modules.

Xcode processes a static XCFramework into BUILT_PRODUCTS_DIR/include. Exposing
its original slice headers as well makes Clang discover the same module twice.
The Codemagic Xcode 26.3 failure was this duplicate AirliftFFI definition.
"""
# SPDX-License-Identifier: GPL-3.0-only
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


def generated_objects():
    spec = importlib.util.spec_from_file_location(
        "xcode_project_generator", ROOT / "scripts/generate-xcode-project.py"
    )
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    encode = generator.encode
    captured = {}

    def capture_document(value, depth=0):
        if depth == 0 and isinstance(value, dict) and "objects" in value:
            captured.update(value["objects"])
        return encode(value, depth)

    # Observe the actual graph serialized by the generator, rather than
    # reconstructing its IDs or reimplementing the OpenStep plist serializer.
    generator.encode = capture_document
    generator.generate()
    return captured


def strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from strings(item)


class XCFrameworkProjectTests(unittest.TestCase):
    def test_airlift_is_linked_once_as_an_xcframework(self):
        objects = generated_objects()
        phases = [obj for obj in objects.values()
                  if obj["isa"] == "PBXFrameworksBuildPhase"]
        self.assertTrue(phases, "The app needs a framework linking phase")
        linked = [objects[objects[build_id]["fileRef"]]
                  for phase in phases for build_id in phase["files"]]
        airlift = [ref for ref in linked if "AirliftFFI" in ref.get("path", "")]
        self.assertEqual(len(airlift), 1)
        self.assertEqual(airlift[0]["lastKnownFileType"], "wrapper.xcframework")
        self.assertEqual(airlift[0]["path"],
                         "vendor/TendiesWallpaper/AirliftFFI.xcframework")

    def test_no_configuration_exposes_original_xcframework_slice_headers(self):
        objects = generated_objects()
        configs = [obj for obj in objects.values()
                   if obj["isa"] == "XCBuildConfiguration"]
        self.assertTrue(configs)
        for config in configs:
            with self.subTest(configuration=config["name"]):
                for value in strings(config["buildSettings"]):
                    self.assertNotIn(
                        "AirliftFFI.xcframework/", value,
                        "Xcode supplies processed XCFramework headers; a raw "
                        "slice search path redefines AirliftFFI in Clang",
                    )
