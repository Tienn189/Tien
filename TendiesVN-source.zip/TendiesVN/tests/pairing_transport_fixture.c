// Tests adapter authentication and error/ownership handling without a device.
#include "PairingTransport.h"
#include "IDevice/idevice.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

static int scenario, session_ok, reads, raw_attempts, live;
static int client_fd = -1, server_fd = -1;
static char *text(const char *s) {
    char *p = malloc(strlen(s) + 1);
    assert(p); strcpy(p, s); return p;
}
static void *handle(void) { live++; return malloc(1); }
static void drop(void *p) { if (p) { live--; free(p); } }
static struct IdeviceFfiError *failure(void) {
    struct IdeviceFfiError *p = malloc(sizeof(*p));
    p->code = 1; p->sub_code = 2; p->message = text("fixture authentication failure");
    return p;
}
void idevice_error_free(struct IdeviceFfiError *p) { if (p) { free((void *)p->message); free(p); } }
void idevice_set_global_timeout(uint64_t seconds) { assert(seconds > 0 && seconds <= 10); }
void idevice_string_free(char *p) { free(p); }
void rsd_free_string(char *p) { free(p); }
void idevice_data_free(uint8_t *p, uintptr_t n) { (void)n; free(p); }
void plist_mem_free(void *p) { free(p); }
void plist_free(plist_t p) { free(p); }
void plist_get_string_val(plist_t p, char **out) { *out = text(p); }
struct IdeviceFfiError *idevice_pairing_file_from_bytes(const uint8_t *p, uintptr_t n, struct IdevicePairingFile **out) {
    assert(p && n); *out = handle(); return NULL;
}
void idevice_pairing_file_free(struct IdevicePairingFile *p) { drop(p); }
struct IdeviceFfiError *idevice_tcp_provider_new(const idevice_sockaddr *address, struct IdevicePairingFile *record, const char *label, struct IdeviceProviderHandle **out) {
    assert(address && label); drop(record); *out = handle(); return NULL;
}
void idevice_provider_free(struct IdeviceProviderHandle *p) { drop(p); }
struct IdeviceFfiError *lockdownd_connect(struct IdeviceProviderHandle *provider, struct LockdowndClientHandle **out) {
    assert(provider);
    if (scenario == 5) {
        int listener = socket(AF_INET, SOCK_STREAM, 0);
        assert(listener >= 0);
        struct sockaddr_in local = {0};
#ifdef __APPLE__
        local.sin_len = sizeof(local);
#endif
        local.sin_family = AF_INET;
        local.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        assert(bind(listener, (struct sockaddr *)&local, sizeof(local)) == 0);
        assert(listen(listener, 1) == 0);
        socklen_t length = sizeof(local);
        assert(getsockname(listener, (struct sockaddr *)&local, &length) == 0);
        client_fd = socket(AF_INET, SOCK_STREAM, 0);
        assert(connect(client_fd, (struct sockaddr *)&local, sizeof(local)) == 0);
        server_fd = accept(listener, NULL, NULL);
        assert(server_fd >= 0);
        close(listener);
    }
    *out = handle(); return NULL;
}
struct IdeviceFfiError *lockdownd_start_session(struct LockdowndClientHandle *client, struct IdevicePairingFile *record) {
    assert(client && record);
    if (scenario == 1) return failure();
    if (scenario == 5) {
        char byte;
        assert(recv(client_fd, &byte, 1, 0) <= 0);
        return failure();
    }
    session_ok = 1; return NULL;
}
struct IdeviceFfiError *lockdownd_get_value(struct LockdowndClientHandle *client, const char *key, const char *domain, plist_t *out) {
    assert(client && key && !domain && session_ok);
    reads++;
    *out = text(strcmp(key, "UniqueDeviceID") == 0 ? "0000000000000000000000000000000000000000" :
                strcmp(key, "DeviceName") == 0 ? "Fixture Device" :
                strcmp(key, "ProductType") == 0 ? "iPhoneFixture,1" : "27.0.1");
    return NULL;
}
void lockdownd_client_free(struct LockdowndClientHandle *p) {
    drop(p);
    if (client_fd >= 0) { close(client_fd); client_fd = -1; }
    if (server_fd >= 0) { close(server_fd); server_fd = -1; }
}
struct IdeviceFfiError *rp_pairing_file_from_bytes(const uint8_t *p, uintptr_t n, struct RpPairingFileHandle **out) {
    assert(p && n); *out = handle(); return NULL;
}
void rp_pairing_file_free(struct RpPairingFileHandle *p) { drop(p); }
struct IdeviceFfiError *rp_pairing_file_to_bytes(struct RpPairingFileHandle *p, uint8_t **out, uintptr_t *size) {
    assert(p); *out = (uint8_t *)text("fixture"); *size = 7; return NULL;
}
struct IdeviceFfiError *tunnel_create_remotexpc(const idevice_sockaddr *address, idevice_socklen_t size, const char *name, struct RpPairingFileHandle *record, const char *(*pin)(void *), void *context, struct AdapterHandle **adapter, struct RsdHandshakeHandle **handshake) {
    assert(address && size && name && record && !pin && !context);
    if (scenario == 3) return failure();
    *adapter = handle(); *handshake = handle(); return NULL;
}
struct IdeviceFfiError *tunnel_create_rppairing(const idevice_sockaddr *address, idevice_socklen_t size, const char *name, struct RpPairingFileHandle *record, const char *(*pin)(void *), void *context, struct AdapterHandle **adapter, struct RsdHandshakeHandle **handshake) {
    assert(address && size && name && record && !pin && !context);
    raw_attempts++; *adapter = handle(); *handshake = handle(); return NULL;
}
struct IdeviceFfiError *rsd_get_uuid(struct RsdHandshakeHandle *handshake, char **out) {
    assert(handshake);
    *out = text(scenario == 4 ? "" : "00000000-0000-0000-0000-000000000000"); return NULL;
}
struct IdeviceFfiError *lockdownd_connect_rsd(struct AdapterHandle *adapter, struct RsdHandshakeHandle *handshake, struct LockdowndClientHandle **client) {
    assert(adapter && handshake); *client = NULL; return failure();
}
void rsd_handshake_free(struct RsdHandshakeHandle *p) { drop(p); }
struct IdeviceFfiError *adapter_close(struct AdapterHandle *p) { assert(p); return NULL; }
void adapter_free(struct AdapterHandle *p) { drop(p); }

int main(void) {
    const uint8_t bytes[] = {1};
    for (scenario = 0; scenario <= 5; scenario++) {
        session_ok = reads = raw_attempts = 0;
        TDPairingResult result;
        char *error = NULL;
        int remote = scenario >= 2 && scenario <= 4;
        int status = td_pairing_verify(bytes, sizeof(bytes), scenario == 5 ? "127.0.0.1" : "10.7.0.1", 49152, remote, &result, &error);
        if (scenario == 1 || scenario == 4 || scenario == 5) {
            assert(status != 0 && error && !result.identifier && !result.transport);
            assert(reads == 0);
        } else {
            assert(status == 0 && !error && result.identifier && result.transport);
            if (scenario >= 2) assert(result.updated_record && result.updated_record_size == 7);
            assert(scenario == 0 ? reads == 4 : reads == 0);
        }
        assert(raw_attempts == (scenario == 3 ? 1 : 0));
        td_pairing_result_free(&result); td_pairing_string_free(error);
        assert(live == 0);
    }
    TDPairingResult result;
    char *error = NULL;
    assert(td_pairing_verify(bytes, sizeof(bytes), "bad address", 49152, 0, &result, &error) != 0);
    td_pairing_result_free(&result); td_pairing_string_free(error);
    assert(live == 0);
    puts("Pairing adapter passed: authenticated session required, RSD fallback, missing identity rejection, ownership cleanup.");
    return 0;
}
