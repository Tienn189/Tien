// Controlled worker responses; does not open apps or access a real device.
import SwiftUI
import Foundation

struct WallpaperDescriptorStub {}
struct TendiesPayload { var descriptors = [WallpaperDescriptorStub()] }
struct WallpaperStagedPackage: Identifiable { let id = UUID(); var displayName = "Fixture"; var payload = TendiesPayload() }
enum WallpaperInstallStatus { case installed, preparing, restored }
struct WallpaperInstallReceipt: Identifiable { let id = UUID(); var status = WallpaperInstallStatus.installed }
struct WallpaperAccessReport { var canInstall = true }
struct WallpaperOperationStatus: Identifiable {
    enum Kind { case working, success, failure }
    let id: UUID
    var kind: Kind
    var title: String
    var detail: String
    var phases: [String]
    var activePhase: Int?
    init(id: UUID = UUID(), kind: Kind, title: String, detail: String, phases: [String] = [], activePhase: Int? = nil) {
        self.id=id; self.kind=kind; self.title=title; self.detail=detail; self.phases=phases; self.activePhase=activePhase
    }
}
enum DeviceCompatibility {
    static var installationSupported = true
    static var installationReady = true
    static var currentVersion = 18
    static var hasConfiguredPocketPosterHash = false
    static func supportsPocketPoster(_: Int) -> Bool { false }
    static let explanation = "Unavailable fixture OS"
}
enum WallpaperLabError: Error { case accessDenied }
enum AirliftWallpaperService {
    static var shouldUse = false
    static func checkConnection() throws {
        Fixture.airliftChecks += 1
        if Fixture.failAirliftCheck { throw FixtureFailure.rejected }
    }
}
enum PocketPosterWallpaperService {
    static var shouldUse = false
}
enum PairingRecordKind { case remote, lockdown }
struct PairingRecordSummary { var kind: PairingRecordKind? }
@MainActor final class PairingStore {
    static let shared = PairingStore()
    var connection: String? = "fixture"
    var record: PairingRecordSummary? = PairingRecordSummary(kind: .remote)
    var lastFailure: String?
    func refresh() async { Fixture.pairingLoads += 1 }
    func refreshNetwork() {}
    func verifyConnection() async {
        Fixture.classicPairingChecks += 1
        connection = Fixture.failClassicPairing ? nil : "fixture"
        lastFailure = Fixture.failClassicPairing ? "Fixture pairing rejected" : nil
    }
    func refreshAndVerify() async { Fixture.pairingChecks += 1 }
}
enum FixtureFailure: Error { case rejected }
enum Fixture {
    static var failInstall = false
    static var failRestore = false
    static var launchSucceeds = true
    static var launches = 0
    static var writes = 0
    static var records: [WallpaperInstallReceipt] = []
    static var airliftChecks = 0
    static var pairingChecks = 0
    static var pairingLoads = 0
    static var classicPairingChecks = 0
    static var failClassicPairing = false
    static var localChecks = 0
    static var probeCanInstall = true
    static var failAirliftCheck = false
}
enum WallpaperPackageStore {
    static func packages() -> [WallpaperStagedPackage] { [] }
    static func importPackage(from: URL) throws -> WallpaperStagedPackage { WallpaperStagedPackage() }
    static func delete(_: WallpaperStagedPackage) throws {}
}
enum WallpaperDeviceAccessService {
    static func report() throws -> WallpaperAccessReport { Fixture.localChecks += 1; return WallpaperAccessReport(canInstall: Fixture.probeCanInstall) }
    static func receipts() -> [WallpaperInstallReceipt] { Fixture.records }
    static func install(_: WallpaperStagedPackage) throws -> WallpaperAccessReport {
        if Fixture.failInstall { throw FixtureFailure.rejected }
        Fixture.writes += 1
        let receipt = WallpaperInstallReceipt()
        Fixture.records = [receipt]
        return WallpaperAccessReport()
    }
    static func restore(receipt: WallpaperInstallReceipt) throws -> WallpaperAccessReport {
        if Fixture.failRestore { throw FixtureFailure.rejected }
        Fixture.records = []
        return WallpaperAccessReport()
    }
}
func TendiesOpenPosterBoard() -> Bool { Fixture.launches += 1; return Fixture.launchSucceeds }

@main
struct WallpaperModelFlowTests {
    @MainActor
    static func settled(_ model: WallpaperModel) async {
        let deadline = Date().addingTimeInterval(10)
        while model.isBusy {
            precondition(Date() < deadline, "Worker timed out")
            await Task.yield()
        }
    }

    @MainActor
    static func main() async {
        let model = WallpaperModel()
        let package = WallpaperStagedPackage()
        // Airlift discovery must not call the local BadQuery probe or claim a
        // successful write before the actual installation.
        AirliftWallpaperService.shouldUse = true
        model.checkAccess()
        await settled(model)
        precondition(Fixture.pairingChecks == 1 && Fixture.airliftChecks == 1 && Fixture.localChecks == 0)
        precondition(model.successNotice?.kind == .success && model.successNotice?.detail.contains("chỉ được kiểm tra khi cài") == true)
        Fixture.failAirliftCheck = true
        model.checkAccess()
        await settled(model)
        precondition(model.successNotice?.kind == .failure && Fixture.localChecks == 0)
        AirliftWallpaperService.shouldUse = false
        // Legacy resolution may use a cached UUID: neither proves write access.
        PocketPosterWallpaperService.shouldUse = true
        model.checkAccess()
        await settled(model)
        precondition(Fixture.localChecks == 1)
        precondition(model.successNotice?.title == "Đã có mã container PosterBoard")
        precondition(model.successNotice?.detail.contains("Quyền ghi sẽ được kiểm tra khi cài") == true)
        PocketPosterWallpaperService.shouldUse = false
        model.checkAccess()
        await settled(model)
        precondition(Fixture.localChecks == 2)
        precondition(model.successNotice?.title == "Đã kiểm tra quyền ghi")
        Fixture.probeCanInstall = false
        model.checkAccess()
        await settled(model)
        precondition(model.successNotice?.kind == .failure)
        Fixture.probeCanInstall = true
        model.message = nil
        model.selectedPackage = package
        // Committed install must wait for dismissal and launch exactly once.
        model.install(package)
        await settled(model)
        precondition(model.successNotice?.kind == .success && Fixture.writes == 1)
        precondition(model.selectedPackage == nil && Fixture.launches == 0)
        model.sheetDismissed()
        model.sheetDismissed()
        precondition(Fixture.launches == 1 && model.message == nil)
        model.sceneBecameActive()
        precondition(model.message != nil)
        model.message = nil
        model.sceneBecameActive()
        precondition(model.message == nil)
        // Failed writes never open PosterBoard or leave old completion state.
        Fixture.failInstall = true
        model.install(package)
        await settled(model)
        model.sheetDismissed()
        model.openPosterBoardForRefresh()
        precondition(model.successNotice?.kind == .failure && Fixture.launches == 1)
        precondition(model.refreshInstructions == nil)
        // A rejected launch must preserve the successful filesystem outcome.
        Fixture.failInstall = false
        Fixture.launchSucceeds = false
        model.install(package)
        await settled(model)
        model.sheetDismissed()
        precondition(Fixture.launches == 2 && model.successNotice?.kind == .success)
        precondition(model.message != nil && model.activeReceipts.count == 1)
        model.message = nil
        model.sceneBecameActive()
        precondition(model.message == nil)
        // Restore launches after success; failure retains a recoverable receipt.
        let receipt = model.activeReceipts[0]
        Fixture.failRestore = true
        model.restore(receipt)
        await settled(model)
        precondition(Fixture.launches == 2 && model.activeReceipts.count == 1)
        Fixture.failRestore = false
        model.restore(receipt)
        await settled(model)
        precondition(Fixture.launches == 3 && model.activeReceipts.isEmpty)
        // Unsupported versions cannot invoke the worker or the launcher.
        DeviceCompatibility.installationSupported = false
        let writes = Fixture.writes
        model.install(package)
        model.sheetDismissed()
        model.openPosterBoardForRefresh()
        precondition(Fixture.writes == writes && Fixture.launches == 3)
        precondition(model.successNotice?.kind == .failure)
        // A successful Airlift request is not proof that PosterBoard imported it.
        DeviceCompatibility.installationSupported = true
        AirliftWallpaperService.shouldUse = true
        DeviceCompatibility.installationReady = false
        let writesWithoutPairing = Fixture.writes
        model.install(package)
        await settled(model)
        precondition(Fixture.writes == writesWithoutPairing)
        precondition(model.successNotice?.kind == .failure)
        DeviceCompatibility.installationReady = true
        let pairingChecksBeforeInstall = Fixture.pairingChecks
        model.install(package)
        await settled(model)
        precondition(Fixture.pairingChecks == pairingChecksBeforeInstall)
        precondition(model.successNotice?.title == "Đã gửi gói hình nền")
        precondition(model.successNotice?.detail.contains("chưa xác nhận") == true)
        // Lockdown still verifies the responding device once when needed.
        PairingStore.shared.record = PairingRecordSummary(kind: .lockdown)
        PairingStore.shared.connection = nil
        model.install(package)
        await settled(model)
        precondition(Fixture.classicPairingChecks == 1)
        precondition(model.successNotice?.kind == .success)
        // A failed classic verification cannot start an installation.
        PairingStore.shared.connection = nil
        Fixture.failClassicPairing = true
        let writesBeforeRejectedPairing = Fixture.writes
        model.install(package)
        await settled(model)
        precondition(Fixture.classicPairingChecks == 2)
        precondition(Fixture.writes == writesBeforeRejectedPairing)
        precondition(model.successNotice?.kind == .failure)
        print("Model flow: post-dismiss launch, foreground notice, failed writes, rejected launch, restore and OS gate passed with mocks.")
    }
}
