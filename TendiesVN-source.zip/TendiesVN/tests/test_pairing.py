#!/usr/bin/env python3
"""Run the native Security pairing validator suite on macOS.

Temporary self-signed credentials are created for the tests and deleted on exit.
No device connection or persistent Keychain write occurs.
"""
import base64
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def run(*arguments):
    subprocess.run(arguments, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def pem_to_der(source, destination):
    lines = Path(source).read_text().splitlines()
    Path(destination).write_bytes(base64.b64decode("".join(line for line in lines if not line.startswith("-----"))))


class PairingTests(unittest.TestCase):
    @unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc") and shutil.which("openssl"),
                         "Apple Security, Swift and OpenSSL are required (macOS)")
    def test_native_pairing_validator(self):
        with tempfile.TemporaryDirectory(prefix="1809-pairing-tests-") as directory:
            temporary = Path(directory)
            key = temporary / "generated-key.pem"
            pkcs1 = temporary / "key-pkcs1.pem"
            pkcs8 = temporary / "key-pkcs8.pem"
            openssl = shutil.which("openssl")
            run(openssl, "genrsa", "-out", str(key), "2048")
            # OpenSSL 3 needs -traditional; macOS LibreSSL already writes PKCS#1.
            conversion = subprocess.run([openssl, "rsa", "-in", str(key), "-traditional", "-out", str(pkcs1)],
                                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            if conversion.returncode:
                run(openssl, "rsa", "-in", str(key), "-out", str(pkcs1))
            self.assertIn("BEGIN RSA PRIVATE KEY", pkcs1.read_text())
            run(openssl, "pkcs8", "-topk8", "-nocrypt", "-in", str(pkcs1), "-out", str(pkcs8))
            run(openssl, "req", "-new", "-x509", "-key", str(pkcs1), "-subj", "/CN=1809 Test Only",
                "-days", "1", "-out", str(temporary / "certificate.pem"))
            run(openssl, "genrsa", "-out", str(temporary / "other-key.pem"), "2048")
            for name in ["key-pkcs1", "key-pkcs8", "certificate"]:
                pem_to_der(temporary / (name + ".pem"), temporary / (name + ".der"))
            binary = temporary / "pairing-tests"
            subprocess.run([
                shutil.which("swiftc"),
                "-target", f"{platform.machine()}-apple-macosx13.0",
                str(ROOT / "TendiesVN/Engine/PairingRecordValidator.swift"),
                str(ROOT / "tests/PairingValidationTests.swift"),
                "-o", str(binary),
            ], check=True)
            environment = os.environ.copy()
            environment["APP1809_PAIRING_FIXTURES"] = str(temporary)
            subprocess.run([str(binary)], check=True, env=environment)


if __name__ == "__main__":
    unittest.main()
