#!/usr/bin/env python3
"""Exercise the production pairing adapter with controlled protocol responses."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PairingTransportTests(unittest.TestCase):
    def test_authentication_errors_fallback_and_ownership(self):
        compiler = shutil.which("cc")
        self.assertIsNotNone(compiler, "A C compiler is required")
        with tempfile.TemporaryDirectory(prefix="1809-transport-") as directory:
            binary = Path(directory) / "transport-test"
            subprocess.run([
                compiler, "-std=c11", "-D_POSIX_C_SOURCE=200809L", "-DTD_PAIRING_TIMEOUT_MS=150",
                "-pthread", "-Wall", "-Wextra", "-Werror",
                "-I", str(ROOT / "TendiesVN/Engine"),
                str(ROOT / "TendiesVN/Engine/PairingTransport.c"),
                str(ROOT / "tests/pairing_transport_fixture.c"), "-o", str(binary)
            ], check=True)
            subprocess.run([str(binary)], check=True)


if __name__ == "__main__":
    unittest.main()
