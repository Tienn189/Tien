from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT / "TendiesVN" / "Engine" / "KernelExploit"


class KernelFailureSafetyTests(unittest.TestCase):
    def test_post_exploit_probe_fails_closed_without_exit(self):
        source = (KERNEL / "kexploit_opa334.m").read_text(encoding="utf-8")
        self.assertIn("volatile bool g_krwHealthy = true", source)
        self.assertIn("Never terminate the host app from a post-exploit validation read", source)
        self.assertIn("if (!g_krwHealthy)", source)
        self.assertIn("rejected invalid post-exploit kernel read", source)

    def test_swift_checks_native_probe_health(self):
        source = (KERNEL.parent / "TendiesKernelExploit.swift").read_text(encoding="utf-8")
        self.assertIn("kexploit_krw_is_healthy()", source)
        self.assertIn("failed safely", source)
        self.assertIn("lastError", source)

    def test_legacy_ios_accepts_kernel_rw_without_full_sandbox_escape(self):
        source = (KERNEL.parent / "TendiesKernelExploit.swift").read_text(encoding="utf-8")
        # 3105 treats kernel R/W as the successful state on iOS 17–18;
        # requiring the iOS 26-style outside-sandbox probe rejects valid
        # legacy devices before PosterBoard discovery can run.
        self.assertIn("DeviceCompatibility.currentVersion.major < 26", source)
        self.assertIn("kernel R/W active; sandbox escape unavailable", source)
        self.assertIn("if sandbox_access_is_active() == 1", source)

    def test_sandbox_probe_does_not_require_writing_container_parent(self):
        source = (KERNEL / "sandbox_escape.m").read_text(encoding="utf-8")
        self.assertIn("probe_directory_readable", source)
        self.assertIn("parent is deliberately non-writable", source)
        self.assertNotIn("probe_write_read_delete", source)


if __name__ == "__main__":
    unittest.main()
