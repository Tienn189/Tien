// SPDX-License-Identifier: GPL-3.0-only
// Run against the real Foundation models/installer; no device backend or mocks.
import Foundation
import Darwin

struct CheckFailure: Error, CustomStringConvertible {
    let description: String
}

func check(_ condition: @autoclosure () throws -> Bool, _ message: String) throws {
    if try condition() == false { throw CheckFailure(description: message) }
}

let files = FileManager.default
let scratch = files.temporaryDirectory.appendingPathComponent("wallpaper-models-\(UUID().uuidString)", isDirectory: true)
try files.createDirectory(at: scratch, withIntermediateDirectories: true)
defer { try? files.removeItem(at: scratch) }
let marker = "com.apple.posterkit.provider.descriptor.identifier"

func directory(_ relative: String) throws -> URL {
    let url = scratch.appendingPathComponent(relative, isDirectory: true)
    try files.createDirectory(at: url, withIntermediateDirectories: true)
    return url
}

func descriptor(_ root: URL, name: String = UUID().uuidString, identifier: String = "ORIGINAL") throws -> URL {
    let url = root.appendingPathComponent(name, isDirectory: true)
    try files.createDirectory(at: url, withIntermediateDirectories: true)
    try Data(identifier.utf8).write(to: url.appendingPathComponent(marker))
    return url
}

func layout(_ label: String) throws -> (URL, WallpaperPosterLayout) {
    let root = try directory(label)
    let modern = root.appendingPathComponent("\(WallpaperLayoutScanner.storeRelativePath)/72/Extensions/\(WallpaperPosterLayout.modernCollectionsExtension)/descriptors", isDirectory: true)
    try files.createDirectory(at: modern, withIntermediateDirectories: true)
    let scanned = try WallpaperLayoutScanner.scan(containerURL: root, rootValidator: { $0 == root })
    return (root, scanned)
}

func testAliasesAndMissingDirectories() throws {
    let (_, scanned) = try layout("aliases")
    try check(scanned.generation == "72", "Must discover device generation")
    try check(scanned.supportsCollections, "Modern Collections must satisfy Collections capability")
    let prepared = try WallpaperLayoutScanner.prepareDestinations(in: scanned, for: [WallpaperPosterLayout.collectionsExtension, WallpaperPosterLayout.mercuryExtension])
    for provider in [WallpaperPosterLayout.collectionsExtension, WallpaperPosterLayout.modernCollectionsExtension,
                     WallpaperPosterLayout.mercuryExtension, WallpaperPosterLayout.modernMercuryExtension] {
        try check(prepared.extensionDescriptorDirectories[provider] != nil, "Missing provider destination: \(provider)")
        let destination = prepared.extensionDescriptorDirectories[provider]!
        try check(files.fileExists(atPath: destination.path), "Preparation must create descriptor directories")
    }
}

func testProviderDiscovery() throws {
    let root = try directory("providers")
    let loose = try descriptor(root)
    try files.createDirectory(at: loose.appendingPathComponent("VideoCAML"), withIntermediateDirectories: false)
    let videoPayload = try TendiesPackageInspector.inspectExtractedPackage(at: root)
    try check(videoPayload.descriptors.count == 1, "Raw UUID descriptor should import")
    try check(videoPayload.descriptors[0].extensionIdentifier == WallpaperPosterLayout.photosExtension, "VideoCAML must use Photos provider")
    let mercuryRoot = try directory("mercury/mercury-descriptors")
    _ = try descriptor(mercuryRoot)
    let mercuryPayload = try TendiesPackageInspector.inspectExtractedPackage(at: scratch.appendingPathComponent("mercury"))
    try check(mercuryPayload.descriptors.first?.extensionIdentifier == WallpaperPosterLayout.mercuryExtension, "Mercury descriptor must retain provider")
    let invalid = try directory("invalid/descriptors/not-a-descriptor")
    try Data("invalid".utf8).write(to: invalid.appendingPathComponent("random-file"))
    do {
        _ = try TendiesPackageInspector.inspectExtractedPackage(at: scratch.appendingPathComponent("invalid"))
        throw CheckFailure(description: "Descriptor without identity marker must be rejected")
    } catch WallpaperLabError.noDescriptors { }
}

func testExportPreservationAndCollision() throws {
    let exportedRoot = try directory("export/container/\(WallpaperLayoutScanner.storeRelativePath)/72/Extensions/\(WallpaperPosterLayout.modernCollectionsExtension)/descriptors")
    let name = UUID().uuidString
    _ = try descriptor(exportedRoot, name: name, identifier: "EXPORTED-IDENTITY")
    let payload = try TendiesPackageInspector.inspectExtractedPackage(at: scratch.appendingPathComponent("export"))
    try check(payload.descriptors.count == 1 && payload.descriptors[0].preservesIdentity, "Container exports must preserve descriptor identity")
    let (root, scanned) = try layout("preserve-target")
    let prepared = try WallpaperLayoutScanner.prepareDestinations(in: scanned, for: [WallpaperPosterLayout.collectionsExtension])
    let backups = try directory("preserve-backups")
    let receipt = try WallpaperInstaller.install(payload: payload, layout: prepared, backupRoot: backups)
    try check(receipt.installedDescriptors.count == 2, "Collections should be mirrored to legacy and modern providers")
    for installed in receipt.installedDescriptors {
        let destination = prepared.extensionDescriptorDirectories[installed.extensionIdentifier]!
        let target = destination.appendingPathComponent(installed.directoryName)
        try check(installed.directoryName == name, "Unoccupied exported UUID name should be preserved")
        let identity = try String(contentsOf: target.appendingPathComponent(marker), encoding: .utf8)
        try check(identity == "EXPORTED-IDENTITY", "Exported identity contents must not be randomized")
    }
    let second = try WallpaperInstaller.install(payload: payload, layout: prepared, backupRoot: backups)
    for installed in second.installedDescriptors {
        try check(installed.directoryName != name, "Name collision must not replace existing descriptor")
    }
    try WallpaperInstaller.restore(receipt: second, containerURL: root, rootValidator: { $0 == root })
    for installed in receipt.installedDescriptors {
        let original = prepared.extensionDescriptorDirectories[installed.extensionIdentifier]!.appendingPathComponent(name)
        try check(files.fileExists(atPath: original.path), "Restore must preserve the previous installation")
    }
    try WallpaperInstaller.restore(receipt: receipt, containerURL: root, rootValidator: { $0 == root })
    for destination in prepared.extensionDescriptorDirectories.values {
        try check(try files.contentsOfDirectory(atPath: destination.path).isEmpty, "Restore must remove every mirrored descriptor")
    }
}

func testRollbackAfterPartialInstall() throws {
    let source = try directory("rollback-source/descriptors")
    _ = try descriptor(source, name: "A")
    let broken = try descriptor(source, name: "B")
    try Data("not a plist".utf8).write(to: broken.appendingPathComponent("Wallpaper.plist"))
    let payload = try TendiesPackageInspector.inspectExtractedPackage(at: scratch.appendingPathComponent("rollback-source"))
    let (_, scanned) = try layout("rollback-target")
    let prepared = try WallpaperLayoutScanner.prepareDestinations(in: scanned, for: [WallpaperPosterLayout.collectionsExtension])
    let stock = try descriptor(prepared.extensionDescriptorDirectories[WallpaperPosterLayout.collectionsExtension]!, name: "STOCK")
    let backups = try directory("rollback-backups")
    do {
        _ = try WallpaperInstaller.install(payload: payload, layout: prepared, backupRoot: backups)
        throw CheckFailure(description: "Malformed second descriptor should fail after first descriptor writes")
    } catch WallpaperLabError.unsupportedPackage { }
    try check(files.fileExists(atPath: stock.path), "Rollback must preserve stock descriptors")
    for (provider, destination) in prepared.extensionDescriptorDirectories {
        let entries = try files.contentsOfDirectory(atPath: destination.path)
        try check(entries == (provider == WallpaperPosterLayout.collectionsExtension ? ["STOCK"] : []), "Partial descriptor writes must be removed")
    }
    try check(WallpaperInstaller.receipts(in: backups).first?.status == .rolledBack, "Rollback journal must record successful recovery")
}

func testSymlinkDestinations() throws {
    let (_, scanned) = try layout("symlink-target")
    let outside = try directory("outside")
    let legacy = scanned.storeURL.appendingPathComponent("72/Extensions/\(WallpaperPosterLayout.collectionsExtension)")
    try files.createSymbolicLink(at: legacy, withDestinationURL: outside)
    do {
        _ = try WallpaperLayoutScanner.prepareDestinations(in: scanned, for: [WallpaperPosterLayout.collectionsExtension])
        throw CheckFailure(description: "Symlink provider destination must be rejected")
    } catch WallpaperLabError.symbolicLinkUnsupported { }
    try check(try files.contentsOfDirectory(atPath: outside.path).isEmpty, "Preparation must not write through a symlink")
}

func testRefreshPreferences() throws {
    let root = try directory("refresh-target")
    _ = try directory("refresh-target/Library")
    let existing = try PropertyListSerialization.data(fromPropertyList: ["UnrelatedSetting": "keep", "PersistedPosterContainerBundleIdentifiers": ["existing.provider"]], format: .binary, options: 0)
    let preferences = try directory("refresh-target/Library/Preferences")
    let target = preferences.appendingPathComponent(WallpaperPosterRefresh.fileName)
    try existing.write(to: target)
    try check(WallpaperPosterRefresh.write(in: root), "Refresh marker should be writable")
    let refreshed = try PropertyListSerialization.propertyList(from: Data(contentsOf: target), options: [], format: nil) as! [String: Any]
    try check(refreshed["UnrelatedSetting"] as? String == "keep", "Refresh should preserve unrelated preference values")
    try check(refreshed["PBF_RESET_FILE_PROTECTIONS"] as? Bool == true, "Refresh must set file protection marker")
    let providers = refreshed["PersistedPosterContainerBundleIdentifiers"] as? [String] ?? []
    try check(providers.contains("existing.provider") && providers.contains(WallpaperPosterLayout.modernCollectionsExtension), "Refresh providers should merge old and modern names")
    let outside = scratch.appendingPathComponent("outside-preferences.plist")
    try existing.write(to: outside)
    try files.removeItem(at: target)
    try files.createSymbolicLink(at: target, withDestinationURL: outside)
    try check(!WallpaperPosterRefresh.write(in: root), "Refresh must reject symlink preference files")
    try check(try Data(contentsOf: outside) == existing, "Refresh must not change symlink destination")
}

do {
    try testAliasesAndMissingDirectories()
    try testProviderDiscovery()
    try testExportPreservationAndCollision()
    try testRollbackAfterPartialInstall()
    try testSymlinkDestinations()
    try testRefreshPreferences()
    print("6 wallpaper model regression cases passed")
} catch {
    fputs("Wallpaper regression failure: \(error)\n", stderr)
    exit(1)
}
