#!/usr/bin/env python3
"""Check the app's actual history codec without opening the user's history file.

The Swift executable only exchanges in-memory Data. It never calls
WallpaperSaveHistory, WallpaperSandboxFiles, or any Photos API.
"""
# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

HARNESS = r'''
import Foundation

@main struct HistoryChecks {
    static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        if !condition() { fatalError(message) }
    }
    static func reject(_ message: String, _ operation: () throws -> Void) {
        do {
            try operation()
            fatalError("Accepted invalid history: " + message)
        } catch WallpaperSaveHistoryError.invalidHistory {
            // Expected domain error, rather than a crash or silent empty history.
        } catch {
            fatalError("Unexpected error for \(message): \(error)")
        }
    }
    static func receipt(
        id: UUID = UUID(),
        packageID: UUID = UUID(),
        packageName: String = "Bộ sưu tập 🌿",
        assetName: String = "Hình nền.heic",
        kind: WallpaperAssetKind = .image,
        time: TimeInterval = 1_800_000_000
    ) -> WallpaperSaveReceipt {
        WallpaperSaveReceipt(
            id: id, packageID: packageID, packageName: packageName,
            assetName: assetName, kind: kind, savedAt: Date(timeIntervalSince1970: time)
        )
    }
    static func main() throws {
        let package = UUID()
        let older = receipt(packageID: package, time: 1_700_000_000)
        let newer = receipt(packageID: package, assetName: "Video.mov", kind: .video)
        let data = try WallpaperHistoryCodec.encode([older, newer])
        let restored = try WallpaperHistoryCodec.decode(data)
        require(restored == [newer, older], "Receipt round trip, media kind or newest-first order lost")
        require(restored[0].packageID == restored[1].packageID, "Two saves from one package must be allowed")
        let empty = try WallpaperHistoryCodec.decode(WallpaperHistoryCodec.encode([]))
        require(empty.isEmpty, "Empty history failed")

        reject("duplicate receipt IDs on write") {
            _ = try WallpaperHistoryCodec.encode([older, older])
        }
        reject("duplicate receipt IDs from disk") {
            _ = try WallpaperHistoryCodec.decode(JSONEncoder().encode([older, older]))
        }
        reject("corrupt JSON") { _ = try WallpaperHistoryCodec.decode(Data("[{".utf8)) }
        reject("wrong JSON root") { _ = try WallpaperHistoryCodec.decode(Data("{}".utf8)) }
        reject("missing receipt fields") { _ = try WallpaperHistoryCodec.decode(Data("[{}]".utf8)) }

        var unknownKind = String(decoding: try JSONEncoder().encode([older]), as: UTF8.self)
        unknownKind = unknownKind.replacingOccurrences(of: "\"image\"", with: "\"not-a-media-kind\"")
        reject("unknown media kind") { _ = try WallpaperHistoryCodec.decode(Data(unknownKind.utf8)) }

        for invalid in [
            receipt(packageName: ""), receipt(assetName: ""),
            receipt(packageName: String(repeating: "é", count: 513)),
            receipt(assetName: String(repeating: "a", count: 1_025)),
            receipt(time: -1), receipt(time: .infinity), receipt(time: .nan)
        ] {
            reject("invalid receipt values on write") { _ = try WallpaperHistoryCodec.encode([invalid]) }
        }
        let badDate = receipt(time: -1)
        reject("negative saved date from disk") {
            _ = try WallpaperHistoryCodec.decode(JSONEncoder().encode([badDate]))
        }

        let limit = WallpaperHistoryCodec.maximumRecords
        let atLimit = (0..<limit).map { receipt(time: 1_800_000_000 + Double($0)) }
        let decodedAtLimit = try WallpaperHistoryCodec.decode(WallpaperHistoryCodec.encode(atLimit))
        require(decodedAtLimit.count == limit, "Exactly the record limit must be accepted")
        let tooMany = atLimit + [receipt()]
        reject("record count on write") { _ = try WallpaperHistoryCodec.encode(tooMany) }
        reject("record count on read") {
            _ = try WallpaperHistoryCodec.decode(JSONEncoder().encode(tooMany))
        }

        // Valid JSON padded with whitespace exercises the byte limit itself.
        var boundary = Data("[]".utf8)
        boundary.append(Data(repeating: 0x20, count: Int(WallpaperHistoryCodec.maximumBytes) - boundary.count))
        let decodedBoundary = try WallpaperHistoryCodec.decode(boundary)
        require(decodedBoundary.isEmpty, "Exact byte boundary rejected")
        boundary.append(0x20)
        reject("byte limit on read") { _ = try WallpaperHistoryCodec.decode(boundary) }
        let oversizedEncoding = (0..<limit).map { _ in
            receipt(packageName: String(repeating: "a", count: 1_024),
                    assetName: String(repeating: "b", count: 1_024))
        }
        reject("byte limit on write") { _ = try WallpaperHistoryCodec.encode(oversizedEncoding) }
        print("Passed: Unicode/media round trip, date order, duplicate IDs, corrupt JSON, field validation, exact record/byte boundaries, oversized data rejection; no history file accessed")
    }
}
'''


@unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc"),
                     "requires macOS Foundation file-protection definitions and Swift")
class WallpaperHistoryTests(unittest.TestCase):
    def test_actual_codec_without_user_storage(self):
        with tempfile.TemporaryDirectory(prefix="1809-wallpaper-history-") as temp:
            directory = Path(temp)
            harness = directory / "HistoryChecks.swift"
            harness.write_text(HARNESS)
            executable = directory / "history-checks"
            subprocess.run([
                "swiftc", "-parse-as-library", "-swift-version", "5",
                str(ROOT / "TendiesVN/Engine/WallpaperAsset.swift"),
                str(ROOT / "TendiesVN/Engine/WallpaperSaveHistory.swift"),
                str(harness), "-o", str(executable),
            ], check=True, timeout=120)
            subprocess.run([str(executable)], check=True, timeout=60)


if __name__ == "__main__":
    unittest.main()
