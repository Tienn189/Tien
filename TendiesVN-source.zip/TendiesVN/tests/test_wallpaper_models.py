"""Compile and run the actual Foundation wallpaper model/installer on macOS."""
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
ENGINE = ROOT / "vendor/TendiesWallpaper/Engine"


@unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc"), "Requires macOS and swiftc")
class WallpaperModelTests(unittest.TestCase):
    def test_real_swift_models_and_transactions(self):
        with tempfile.TemporaryDirectory(prefix="wallpaper-model-tests-") as folder:
            executable = pathlib.Path(folder) / "wallpaper-model-tests"
            result = subprocess.run([
                "swiftc", "-o", str(executable),
                str(ENGINE / "WallpaperLabModels.swift"),
                str(ENGINE / "WallpaperInstaller.swift"),
                str(ENGINE / "WallpaperPosterRefresh.swift"),
                str(ROOT / "tests/wallpaper-models/main.swift"),
            ], capture_output=True, text=True, timeout=120)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            result = subprocess.run([str(executable)], capture_output=True, text=True, timeout=60)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("6 wallpaper model regression cases passed", result.stdout)
