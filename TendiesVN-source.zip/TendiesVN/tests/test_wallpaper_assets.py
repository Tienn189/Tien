#!/usr/bin/env python3
"""Exercise the real Swift media catalog with Apple's public frameworks.

Run on macOS with Xcode/Swift installed. Linux cannot execute ImageIO or
AVFoundation, so it reports an explicit skip rather than a simulated pass.
"""
# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

HARNESS = r'''
import Foundation
import CoreGraphics
import ImageIO
import UniformTypeIdentifiers

enum WallpaperLabError: Error {
    case unsafeArchive, symbolicLinkUnsupported, packageTooLarge
}
enum WallpaperLabLimits {
    static let maximumEntryCount = 20_000
    static let maximumPathBytes = 4_096
    static let maximumEntryBytes: Int64 = 256 * 1_024 * 1_024
    static let maximumExpandedBytes: Int64 = 768 * 1_024 * 1_024
}
struct WallpaperStagedPackage {
    let extractedURL: URL
}
enum WallpaperPackageStore {
    static var approvedRoot: URL!
    static var validations = 0
    static func validated(_ package: WallpaperStagedPackage) throws -> WallpaperStagedPackage {
        validations += 1
        guard package.extractedURL == approvedRoot else { throw WallpaperLabError.unsafeArchive }
        return package
    }
}

@main struct CatalogChecks {
    static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        if !condition() { fatalError(message) }
    }
    static func png(width: Int, height: Int) -> Data {
        let bytes = Data(repeating: 160, count: width * height * 4)
        let provider = CGDataProvider(data: bytes as CFData)!
        let image = CGImage(
            width: width, height: height, bitsPerComponent: 8, bitsPerPixel: 32,
            bytesPerRow: width * 4, space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipLast.rawValue),
            provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent
        )!
        let data = NSMutableData()
        let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil)!
        CGImageDestinationAddImage(destination, image, nil)
        require(CGImageDestinationFinalize(destination), "PNG fixture failed")
        return data as Data
    }
    static func main() throws {
        let manager = FileManager.default
        let root = manager.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try manager.createDirectory(at: root, withIntermediateDirectories: false)
        defer { try? manager.removeItem(at: root) }
        WallpaperPackageStore.approvedRoot = root
        let package = WallpaperStagedPackage(extractedURL: root)
        let image = png(width: 48, height: 32)
        let nested = root.appendingPathComponent("versions/1", isDirectory: true)
        try manager.createDirectory(at: nested, withIntermediateDirectories: true)
        try image.write(to: nested.appendingPathComponent("asset.resource"))
        try Data("not a movie".utf8).write(to: root.appendingPathComponent("fake.mov"))
        try Data("metadata".utf8).write(to: root.appendingPathComponent("metadata.plist"))
        try png(width: 20_000, height: 1).write(to: root.appendingPathComponent("too-wide.png"))

        let assets = try WallpaperAssetCatalog.assets(in: package)
        require(WallpaperPackageStore.validations == 1, "Package must be revalidated")
        require(assets.count == 1, "Only actual images and video tracks belong in catalog")
        require(assets[0].id == "versions/1/asset.resource", "Identity must be relative")
        require(assets[0].kind == .image, "Extensionless media sniffing failed")
        require(assets[0].uniformTypeIdentifier == UTType.png.identifier, "Content UTI lost")
        require(assets[0].byteCount == Int64(image.count), "Byte count mismatch")
        let originalBytes = try Data(contentsOf: assets[0].fileURL)
        require(originalBytes == image, "Original media changed")
        let thumbnail = WallpaperAssetCatalog.thumbnail(for: assets[0], maxPixelSize: 16)
        require(thumbnail != nil, "Thumbnail generation failed")
        require(thumbnail!.width <= 16 && thumbnail!.height <= 16, "Thumbnail limit ignored")
        require(WallpaperAssetCatalog.thumbnail(for: assets[0], maxPixelSize: 0) == nil, "Zero-size thumbnail accepted")

        let link = root.appendingPathComponent("link.png")
        try manager.createSymbolicLink(at: link, withDestinationURL: nested.appendingPathComponent("asset.resource"))
        do {
            _ = try WallpaperAssetCatalog.assets(in: package)
            fatalError("Symlink accepted")
        } catch is WallpaperLabError { }
        try manager.removeItem(at: link)

        for index in 0..<WallpaperAssetCatalog.maximumAssetCount {
            try image.write(to: root.appendingPathComponent("image-\(index).png"))
        }
        do {
            _ = try WallpaperAssetCatalog.assets(in: package)
            fatalError("Asset limit ignored")
        } catch WallpaperLabError.packageTooLarge { }
        let bytesAfterLimit = try Data(contentsOf: nested.appendingPathComponent("asset.resource"))
        require(bytesAfterLimit == image, "Limit check changed package")
        print("Passed: content sniffing, invalid movie rejection, dimension guard, identity, downsampling, symlink and count limits, source preservation")
    }
}
'''


@unittest.skipUnless(sys.platform == "darwin" and shutil.which("swiftc"),
                     "requires macOS ImageIO/AVFoundation and Swift")
class WallpaperAssetTests(unittest.TestCase):
    def test_public_framework_catalog(self):
        with tempfile.TemporaryDirectory(prefix="1809-wallpaper-assets-") as temp:
            directory = Path(temp)
            harness = directory / "CatalogChecks.swift"
            harness.write_text(HARNESS)
            executable = directory / "catalog-checks"
            subprocess.run([
                "swiftc", "-parse-as-library", "-swift-version", "5",
                str(ROOT / "TendiesVN/Engine/WallpaperAsset.swift"),
                str(ROOT / "TendiesVN/Engine/WallpaperAssetCatalog.swift"),
                str(harness), "-o", str(executable),
                "-framework", "AVFoundation", "-framework", "ImageIO",
                "-framework", "UniformTypeIdentifiers", "-framework", "CoreGraphics",
            ], check=True, timeout=120)
            subprocess.run([str(executable)], check=True, timeout=60)


if __name__ == "__main__":
    unittest.main()
