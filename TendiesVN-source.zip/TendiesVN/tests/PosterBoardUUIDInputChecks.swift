import Foundation

@main
enum PosterBoardUUIDInputChecks {
    static func main() {
        let first = "12345678-1234-4ABC-8DEF-1234567890AB"
        let second = "87654321-4321-4CBA-8FED-BA0987654321"
        let base = "/private/var/mobile/Containers/Data/Application/"
        let marker = "filebrowser: import requested destination="
        let cases: [(String, String?)] = [
            (" \n" + first.lowercased() + "\n", first),
            (base + first, first),
            ("/var/mobile/Containers/Data/Application/" + first + "/", first),
            ("[08:00] " + marker + base + first + "\nfilebrowser: import session cancelled", first),
            (marker + base + first + "\n" + marker + base + second, second),
            (marker + base + first + "\n" + marker + base + second + "/Library", first),
            (base + first + "/Library", nil),
            (base + first + "/.com.apple.mobile_container_manager.metadata.plist", nil),
            (base + "../" + first, nil),
            ("/var/mobile/Containers/Data/InternalDaemon/" + first, nil),
            ("unrelated UUID=" + first, nil),
            (first + "extra", nil),
            ("", nil),
            (String(repeating: "x", count: 2 * 1024 * 1024 + 1), nil)
        ]
        for (index, item) in cases.enumerated() {
            guard PosterBoardUUIDInput.uuid(from: item.0) == item.1 else {
                fatalError("PosterBoard UUID input check \(index + 1) failed")
            }
        }
        print("PosterBoard UUID input: \(cases.count) checks passed")
    }
}
