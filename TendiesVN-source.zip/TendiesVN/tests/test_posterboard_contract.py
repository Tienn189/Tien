#!/usr/bin/env python3
"""Check the restored installer's scope and shipped metadata without an iOS SDK.

Source checks cannot establish that private APIs or device writes work.
"""
from pathlib import Path
import plistlib
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "TendiesVN"


class PosterBoardContractTests(unittest.TestCase):
    def test_photos_workflow_and_gallery_are_removed(self):
        info = plistlib.loads((APP / "Info.plist").read_bytes())
        self.assertNotIn("NSPhotoLibraryAddUsageDescription", info)
        self.assertNotIn("NSPhotoLibraryUsageDescription", info)
        removed = {"WallpaperPhotoLibrary.swift", "WallpaperShareSheet.swift", "WallpaperAssetPreview.swift", "PackageDetailView.swift"}
        self.assertFalse(removed.intersection(path.name for path in APP.rglob("*")))
        source = "\n".join(path.read_text() for path in APP.rglob("*.swift"))
        self.assertNotRegex(source, r"\b(?:PHPhotoLibrary|PHAssetCreationRequest|saveToPhotos|WallpaperAssetPreview)\b")

    def test_launcher_is_limited_to_posterboard(self):
        source = (APP / "Engine/PosterBoardRefresh.m").read_text()
        identifiers = re.findall(r'@"(com\.[^"]+)"', source)
        self.assertEqual(set(identifiers), {"com.apple.PosterBoard"})
        self.assertNotRegex(source, r"\b(?:kill|killall|system|posix_spawn|execve)\s*\(")
        self.assertIn("NSThread.isMainThread", source)

    def test_bridge_keeps_identity_and_root_validation(self):
        source = (APP / "Engine/PosterBoardBridge.m").read_text()
        self.assertIn('metadata[@"MCMMetadataIdentifier"]', source)
        self.assertIn("TendiesCanonicalPosterBoardRootPath", source)
        self.assertIn("SupportedSystemVersion()", source)
        self.assertIn("iOS 26.0 through 26.6.1", source)
        self.assertIn("MetadataIdentifiesPosterBoard(rootPath", source)
        self.assertIn("TendiesLegacyPosterBoardContainerPath", source)
        self.assertIn("DiscoverPosterBoardRoot(error)", source)

    def test_legacy_discovery_has_generation_61_shape_fallback(self):
        source = (APP / "Engine/PosterBoardBridge.m").read_text()
        self.assertIn("PosterBoardStoreShapeMatches", source)
        self.assertIn("PRBPosterExtensionDataStore/61/Extensions", source)
        self.assertIn("com.apple.WallpaperKit.CollectionsPoster", source)
        self.assertIn("com.apple.Posters.MercuryPosterApp", source)
        self.assertIn("if (!valid && PosterBoardStoreShapeMatches(root))", source)
        self.assertIn("if (lookupRoot && CanonicalApplicationRoot(lookupRoot)) return lookupRoot;", source)

    def test_legacy_kernel_backend_is_isolated(self):
        """The opt-in iOS 17–18 backend stays in its dedicated directory."""
        backend = APP / "Engine/KernelExploit"
        self.assertTrue((backend / "kexploit_opa334.m").exists())
        self.assertTrue((backend / "offsets.m").exists())
        self.assertTrue((backend / "sandbox_escape.m").exists())
        wrapper = (APP / "Engine/TendiesKernelExploit.swift").read_text()
        resolver = (APP / "Engine/LegacyPosterBoardContainerResolver.swift").read_text()
        bridge_header = (APP / "Engine/PosterBoardBridge.h").read_text()
        self.assertIn("supportsPocketPoster", wrapper)
        self.assertIn("kexploit_opa334()", wrapper)
        self.assertIn("TendiesKernelExploit.activate()", resolver)
        self.assertIn("TendiesLegacyPosterBoardContainerPath", resolver)
        self.assertIn("TendiesLegacyPosterBoardContainerPath", bridge_header)
        # The main PosterBoard bridge remains the scoped BadQuery backend;
        # kernel primitives are not mixed into iOS 26/27 code paths.
        bridge = (APP / "Engine/PosterBoardBridge.m").read_text()
        self.assertNotRegex(bridge, r"(?i)\b(?:kexploit[A-Za-z0-9_]*|kernel_task|task_for_pid|mach_vm_write|tfp0)\b")

    def test_versions_and_minimum_os_match(self):
        info = plistlib.loads((APP / "Info.plist").read_bytes())
        config = dict(re.findall(r"^([A-Z_]+)\s*=\s*(.*?)\s*$", (ROOT / "Config/Base.xcconfig").read_text(), re.M))
        self.assertEqual(config["IPHONEOS_DEPLOYMENT_TARGET"], "17.0")
        self.assertEqual(config["MARKETING_VERSION"], info["CFBundleShortVersionString"])
        self.assertEqual(config["CURRENT_PROJECT_VERSION"], info["CFBundleVersion"])

    def test_default_bundle_id_is_denrindz_1809(self):
        expected = "com.Denrindz.1809"
        config = dict(re.findall(r"^([A-Z_]+)\s*=\s*(.*?)\s*$", (ROOT / "Config/Base.xcconfig").read_text(), re.M))
        self.assertEqual(config["PRODUCT_BUNDLE_IDENTIFIER"], expected)
        for relative in (
            "scripts/build-unsigned.sh",
            "scripts/export-enterprise.sh",
            "scripts/signing_common.py",
            "BUILD-FROM-ZIP.yml",
            ".github/workflows/unsigned-ios.yml",
        ):
            self.assertIn(expected, (ROOT / relative).read_text())

    def test_pairing_and_airlift_recovery_paths_are_enabled(self):
        pairing = (APP / "Engine/PairingStore.swift").read_text()
        host = (APP / "Engine/PairingHost.swift").read_text()
        airlift = (APP / "Engine/AirliftWallpaperService.swift").read_text()
        self.assertIn("try AirliftPairingStore.save(data)", pairing)
        self.assertIn("try AirliftPairingStore.save(updated)", pairing)
        self.assertIn("Array(Set([port, UInt16(49_152)])).sorted()", pairing)
        self.assertIn("service.includesPeerToPeer = true", host)
        self.assertIn("for attempt in 0..<3", airlift)
        self.assertIn("targetExtensionIdentifiers", airlift)
        self.assertIn("com.apple.Posters.CollectionsPosterApp", airlift)
        self.assertIn("injectIntoFirstAvailable", airlift)
        self.assertNotIn("try? inject(folder: staged", airlift)

    def test_legacy_install_preserves_resolver_diagnostics(self):
        source = (APP / "Engine/PocketPosterWallpaperService.swift").read_text()
        self.assertIn("let appHash = try PocketPosterConfiguration.discoverAppHashIfNeeded()", source)
        self.assertNotIn("let appHash = try? PocketPosterConfiguration.discoverAppHashIfNeeded()", source)
        self.assertIn("fileManager.createDirectory(", source)
        self.assertIn(".Trash transfer route", source)

    def test_settings_are_compact_and_credits_are_updated(self):
        source = (APP / "Views/SettingsView.swift").read_text()
        self.assertNotIn('Section("Nguồn")', source)
        self.assertNotIn('title: "Mak5er"', source)
        self.assertNotIn('title: "YangJiii"', source)
        self.assertNotIn('attributionRow(title: "1809"', source)
        self.assertNotIn("3105", source)
        compatibility = (APP / "App/DeviceCompatibility.swift").read_text()
        ranges = [
            compatibility.index("iOS 17.0 – 17.7"),
            compatibility.index("iOS 18.0 – 18.7.1"),
            compatibility.index("iOS 26.0 – 26.6.1"),
            compatibility.index("iOS 27.0 – 27.0.1"),
        ]
        self.assertEqual(ranges, sorted(ranges))


if __name__ == "__main__":
    unittest.main()
