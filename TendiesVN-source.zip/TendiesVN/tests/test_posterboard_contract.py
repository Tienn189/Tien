#!/usr/bin/env python3
"""Check the restored installer's scope and shipped metadata without an iOS SDK.

Source checks cannot establish that private APIs or device writes work.
"""
from pathlib import Path
import plistlib
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "TendiesVN"


class PosterBoardContractTests(unittest.TestCase):
    def test_photos_workflow_and_gallery_are_removed(self):
        info = plistlib.loads((APP / "Info.plist").read_bytes())
        self.assertNotIn("NSPhotoLibraryAddUsageDescription", info)
        self.assertNotIn("NSPhotoLibraryUsageDescription", info)
        removed = {"WallpaperPhotoLibrary.swift", "WallpaperShareSheet.swift", "WallpaperAssetPreview.swift", "PackageDetailView.swift"}
        self.assertFalse(removed.intersection(path.name for path in APP.rglob("*")))
        source = "\n".join(path.read_text() for path in APP.rglob("*.swift"))
        self.assertNotRegex(source, r"\b(?:PHPhotoLibrary|PHAssetCreationRequest|saveToPhotos|WallpaperAssetPreview)\b")

    def test_launcher_is_limited_to_posterboard(self):
        source = (APP / "Engine/PosterBoardRefresh.m").read_text()
        identifiers = re.findall(r'@"(com\.[^"]+)"', source)
        self.assertEqual(set(identifiers), {"com.apple.PosterBoard"})
        self.assertNotRegex(source, r"\b(?:kill|killall|system|posix_spawn|execve)\s*\(")
        self.assertIn("NSThread.isMainThread", source)

    def test_bridge_keeps_identity_and_root_validation(self):
        source = (APP / "Engine/PosterBoardBridge.m").read_text()
        self.assertIn('metadata[@"MCMMetadataIdentifier"]', source)
        self.assertIn("TendiesCanonicalPosterBoardRootPath", source)
        self.assertIn("SupportedSystemVersion()", source)
        self.assertIn("iOS 26.0 through 26.6.1", source)
        self.assertIn("MetadataIdentifiesPosterBoard(rootPath", source)
        self.assertIn("TendiesLegacyPosterBoardContainerPath", source)
        self.assertIn("sandbox_access_is_active()", source)

    def test_legacy_kernel_backend_is_isolated(self):
        """The opt-in iOS 17–18 backend stays in its dedicated directory."""
        backend = APP / "Engine/KernelExploit"
        self.assertTrue((backend / "kexploit_opa334.m").exists())
        self.assertTrue((backend / "offsets.m").exists())
        self.assertTrue((backend / "sandbox_escape.m").exists())
        wrapper = (APP / "Engine/TendiesKernelExploit.swift").read_text()
        resolver = (APP / "Engine/LegacyPosterBoardContainerResolver.swift").read_text()
        bridge_header = (APP / "Engine/PosterBoardBridge.h").read_text()
        self.assertIn("supportsPocketPoster", wrapper)
        self.assertIn("kexploit_opa334()", wrapper)
        self.assertIn("TendiesKernelExploit.activate()", resolver)
        self.assertIn("TendiesLegacyPosterBoardContainerPath", resolver)
        self.assertIn("TendiesLegacyPosterBoardContainerPath", bridge_header)
        # The main PosterBoard bridge remains the scoped BadQuery backend;
        # kernel primitives are not mixed into iOS 26/27 code paths.
        bridge = (APP / "Engine/PosterBoardBridge.m").read_text()
        self.assertNotRegex(bridge, r"(?i)\b(?:kexploit[A-Za-z0-9_]*|kernel_task|task_for_pid|mach_vm_write|tfp0)\b")

    def test_versions_and_minimum_os_match(self):
        info = plistlib.loads((APP / "Info.plist").read_bytes())
        config = dict(re.findall(r"^([A-Z_]+)\s*=\s*(.*?)\s*$", (ROOT / "Config/Base.xcconfig").read_text(), re.M))
        self.assertEqual(config["IPHONEOS_DEPLOYMENT_TARGET"], "17.0")
        self.assertEqual(config["MARKETING_VERSION"], info["CFBundleShortVersionString"])
        self.assertEqual(config["CURRENT_PROJECT_VERSION"], info["CFBundleVersion"])


if __name__ == "__main__":
    unittest.main()
