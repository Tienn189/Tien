#!/usr/bin/env python3
"""Guard the app's public-API wallpaper contract without requiring an iOS SDK.

These checks inspect production sources and permission/build metadata. They
detect known privileged wallpaper mechanisms and misleading success claims;
they do not substitute for a native build or on-device Photos authorization.
"""

from pathlib import Path
import plistlib
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "TendiesVN"
SOURCE_SUFFIXES = {".swift", ".m", ".mm", ".c", ".h"}
FORBIDDEN_SYMBOLS = re.compile(
    r"\b(?:sandbox_extension_[A-Za-z0-9_]*|container_query[A-Za-z0-9_]*|"
    r"LSApplicationWorkspace|kexploit[A-Za-z0-9_]*|sandbox_escape[A-Za-z0-9_]*|"
    r"TendiesPosterBoard[A-Za-z0-9_]*|TendiesOpenPosterBoard[A-Za-z0-9_]*|"
    r"SBSUIWallpaper[A-Za-z0-9_]*|SBSWallpaper[A-Za-z0-9_]*|"
    r"SBSSetWallpaper[A-Za-z0-9_]*|SBWallpaperController|PosterBoardServices)\b",
    re.IGNORECASE,
)
AUTOMATIC_WALLPAPER_CALLS = re.compile(
    r"\b(?:setWallpaper[A-Za-z0-9_]*|set_wallpaper[A-Za-z0-9_]*|"
    r"installWallpaper[A-Za-z0-9_]*|applyWallpaper[A-Za-z0-9_]*)\s*(?:\(|:)",
    re.IGNORECASE,
)


def sources():
    return sorted(path for path in APP.rglob("*") if path.suffix in SOURCE_SUFFIXES)


def build_settings():
    settings = {}
    for line in (ROOT / "Config/Base.xcconfig").read_text().splitlines():
        match = re.fullmatch(r"\s*([A-Z_]+)\s*=\s*(.*?)\s*", line)
        if match:
            settings[match[1]] = match[2]
    return settings


class PublicWallpaperContractTests(unittest.TestCase):
    def test_no_privileged_wallpaper_symbols_or_setters(self):
        for source in sources():
            with self.subTest(source=str(source.relative_to(ROOT))):
                content = source.read_text()
                self.assertIsNone(FORBIDDEN_SYMBOLS.search(content))
                self.assertIsNone(AUTOMATIC_WALLPAPER_CALLS.search(content))

    def test_obsolete_native_wallpaper_backend_is_absent(self):
        removed = {
            "PosterBoardBridge.m", "PosterBoardBridge.h",
            "PosterBoardRefresh.m", "PosterBoardRefresh.h",
            "posterboard_path.c", "posterboard_path.h", "WallpaperInstaller.swift",
        }
        self.assertFalse(removed.intersection(path.name for path in APP.rglob("*")))
        bridge = (APP / "Engine/TendiesVN-Bridging-Header.h").read_text()
        self.assertNotRegex(bridge, r"(?i)posterboard|posterboard_path|WallpaperInstaller")

    def test_photo_permission_only_allows_adding(self):
        info = plistlib.loads((APP / "Info.plist").read_bytes())
        description = info.get("NSPhotoLibraryAddUsageDescription")
        self.assertIsInstance(description, str)
        self.assertTrue(description.strip())
        self.assertNotIn("NSPhotoLibraryUsageDescription", info)
        content = "\n".join(source.read_text() for source in sources() if source.suffix == ".swift")
        calls = re.findall(
            r"PHPhotoLibrary\.(?:authorizationStatus|requestAuthorization)\s*"
            r"\(\s*for\s*:\s*\.([A-Za-z]+)", content
        )
        self.assertTrue(calls, "The public save flow must explicitly request its Photos access level")
        self.assertEqual(set(calls), {"addOnly"})
        self.assertNotRegex(content, r"PHPhotoLibrary\.requestAuthorization\s*\(\s*(?!for\b)\S")
        self.assertNotRegex(content, r"\bPHAsset\.(?:fetchAssets|fetchAssetsWith)[A-Za-z0-9_]*\s*\(")
        self.assertNotRegex(content, r"\bPHAssetChangeRequest\.deleteAssets\s*\(")

    def test_no_automatic_wallpaper_success_claim(self):
        claims = re.compile(
            r"cài hình nền thành công|đã cài hình nền|"
            r"wallpaper installed successfully|automatically installed wallpaper|"
            r"ready to exploit",
            re.IGNORECASE,
        )
        for source in APP.rglob("*"):
            if source.suffix not in {".swift", ".strings"}:
                continue
            with self.subTest(source=str(source.relative_to(ROOT))):
                self.assertIsNone(claims.search(source.read_text()))

    def test_deployment_and_versions_match_the_app(self):
        info = plistlib.loads((APP / "Info.plist").read_bytes())
        settings = build_settings()
        self.assertEqual(settings["IPHONEOS_DEPLOYMENT_TARGET"], "17.0")
        self.assertEqual(settings["MARKETING_VERSION"], info["CFBundleShortVersionString"])
        self.assertEqual(settings["CURRENT_PROJECT_VERSION"], info["CFBundleVersion"])


if __name__ == "__main__":
    unittest.main()
