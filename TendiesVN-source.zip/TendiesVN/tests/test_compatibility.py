#!/usr/bin/env python3
"""Run production Swift compatibility predicates on macOS or Swift-equipped Linux."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class CompatibilityTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("swiftc"), "Swift compiler is not installed")
    def test_production_version_boundaries(self):
        with tempfile.TemporaryDirectory(prefix="1809-compatibility-") as directory:
            binary = Path(directory) / "compatibility-tests"
            policy_object = Path(directory) / "posterboard-support.o"
            subprocess.run([
                shutil.which("cc"), "-std=c11", "-c",
                str(ROOT / "TendiesVN/Engine/posterboard_support.c"), "-o", str(policy_object),
            ], check=True)
            subprocess.run([
                shutil.which("swiftc"),
                "-import-objc-header", str(ROOT / "TendiesVN/Engine/posterboard_support.h"),
                str(ROOT / "TendiesVN/App/DeviceCompatibility.swift"),
                str(ROOT / "tests/DeviceCompatibilityTests.swift"),
                str(policy_object),
                "-o", str(binary),
            ], check=True)
            subprocess.run([str(binary)], check=True)


if __name__ == "__main__":
    unittest.main()
