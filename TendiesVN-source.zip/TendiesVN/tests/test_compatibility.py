#!/usr/bin/env python3
"""Run production Swift compatibility predicates on macOS or Swift-equipped Linux."""
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class CompatibilityTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("swiftc"), "Swift compiler is not installed")
    def test_production_version_boundaries(self):
        with tempfile.TemporaryDirectory(prefix="1809-compatibility-") as directory:
            binary = Path(directory) / "compatibility-tests"
            subprocess.run([
                shutil.which("swiftc"),
                str(ROOT / "TendiesVN/App/DeviceCompatibility.swift"),
                str(ROOT / "tests/DeviceCompatibilityTests.swift"),
                "-o", str(binary),
            ], check=True)
            subprocess.run([str(binary)], check=True)


if __name__ == "__main__":
    unittest.main()
