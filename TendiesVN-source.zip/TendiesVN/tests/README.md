# Portable wallpaper regression tests

These three suites are adapted from the supplied TendiesVN 3.5.0/build-19 source archive; only their engine source paths were changed. Their upstream GPL-3.0-only notices remain in each file. See `vendor/TendiesWallpaper/README.md` for archive provenance and licensing.

Run from the repository root:

```sh
python3 -m unittest discover -s tests -v
```

Requirements: Python 3, a C compiler (`cc`, `gcc`, or `clang`), and zlib development headers/library. The tests compile the actual vendored C implementation into temporary shared libraries. They exercise exact native BadQuery version/build boundaries, fixed PosterBoard container path validation, and streaming extraction of stored/deflate ZIP entries, including corrupt input and existing destination preservation.

The optional `test_extractor.py --templates-root /path/to/templates` check needs local wallpaper archives and skips when none are supplied. These portable tests do not run the Swift adapter, the iOS kernel/BadQuery/Airlift backends, or a device installation. Those require macOS/Xcode and supported physical devices.
