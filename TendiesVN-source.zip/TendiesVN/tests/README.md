# Portable wallpaper regression tests

The three C suites are adapted from the supplied TendiesVN 3.5.0/build-19 source archive; only their engine source paths were changed. Their upstream GPL-3.0-only notices remain in each file. See `vendor/TendiesWallpaper/README.md` for archive provenance and licensing. `test_wallpaper_models.py` additionally compiles the real Swift models, installer, and refresh helper on macOS with the Swift toolchain; it skips when that SDK/toolchain is unavailable.

Run from the repository root:

```sh
python3 -m unittest discover -s tests -v
```

Requirements: Python 3, a C compiler (`cc`, `gcc`, or `clang`), and zlib development headers/library. The tests compile the actual vendored C implementation into temporary shared libraries. They exercise exact native BadQuery version/build boundaries, fixed PosterBoard container path validation, and streaming extraction of stored/deflate ZIP entries, including corrupt input and existing destination preservation.

The project graph regression checks that Airlift is linked once through its
XCFramework and that source-slice modulemap paths cannot reintroduce the
duplicate `AirliftFFI` module reported by Xcode 26.3. This configuration check
does not replace an actual Xcode compile.

The optional `test_extractor.py --templates-root /path/to/templates` check needs local wallpaper archives and skips when none are supplied. The macOS Swift suite covers descriptor discovery, provider aliases, missing target directories, container identifier preservation/collisions, undo, and refresh-marker writing using temporary filesystem fixtures. These tests do not run the UIKit screen/host adapter, the iOS kernel/BadQuery/Airlift backends, or a device installation. Those require macOS/Xcode and supported physical devices.

`test_dynamic_xpc.py` compiles the production MCM typedef block alongside a predeclared SDK-like XPC type. It catches the `xpc_object_t` collision reported in `BQCore.m`; this portable C check does not validate Objective-C ARC or replace an iOS compilation.

Project/build checks after adding or changing source files:

```sh
python3 scripts/generate-xcode-project.py
python3 scripts/generate-xcode-project.py --check
bash -n build.sh scripts/build-unsigned.sh vendor/TendiesWallpaper/scripts/build-airlift.sh
```

On macOS with Xcode 26 or newer, run `./build.sh` to rebuild the Airlift
XCFramework, compile the complete Objective-C/Swift application, and package
the unsigned IPA. The GitHub Actions workflow performs the portable checks
and the same build. An unsigned IPA must be signed before device installation.

Before reporting wallpaper installation as tested, record the device model,
exact iOS version/build, selected backend, package structure, and these results:

1. Import a valid `.tendies` file and the equivalent `.zip`; confirm descriptor
   counts, provider names, and image/video previews. An invalid archive must
   report an error and leave existing library packs intact.
2. Change pack selection, relaunch, and confirm selection persists. Apply only
   selected packs; check that deselected packs were not installed. Repeat an
   install using an ordered pack and a full container export.
3. Open PosterBoard, close its App Switcher card, and inspect iOS wallpaper
   settings. Confirm the new wallpaper appears and renders, including video
   packs when the device supports them.
4. On the BadQuery route, apply a pack, undo the latest install, and confirm
   pre-existing wallpapers remain. Repeat after relaunch. Airlift/PocketPoster
   do not offer receipt-based undo.
5. Remove an imported pack and confirm this only removes the app's library
   copy. For Airlift, also check the missing-pairing and unreachable-VPN cases;
   errors must not claim that no remote files were written.

These are device validation steps, not results obtained by the portable suite.
