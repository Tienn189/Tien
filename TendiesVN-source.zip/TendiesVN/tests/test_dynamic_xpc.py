"""Compile the actual dynamic MCM typedefs alongside an existing XPC type.

The SDK exposes xpc_object_t as an Objective-C object pointer under ARC. A
separate pointer type is enough to reproduce its typedef collision in portable
C; this test does not claim to compile the iOS SDK or validate ARC behavior.
"""
# SPDX-License-Identifier: GPL-3.0-only
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DynamicXPCTypesTests(unittest.TestCase):
    def test_mcm_typedefs_coexist_with_sdk_xpc_type(self):
        source = (ROOT / "src/BQCore.m").read_text()
        section = source.split("MCM API ---", 1)[1].split("typedef struct {", 1)[0]
        opaque = re.search(r"typedef\s+void\s*\*\s*(\w+)\s*;", section)
        self.assertIsNotNone(opaque, "The dynamic MCM ABI needs its opaque pointer type")
        compiler = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
        if not compiler:
            raise RuntimeError("A C compiler is required")
        fixture = """#include <stdint.h>
struct sdk_xpc_object;
typedef struct sdk_xpc_object *xpc_object_t;
""" + section + f"""
_Static_assert(sizeof({opaque.group(1)}) == sizeof(xpc_object_t),
               "Dynamic XPC object handles must preserve pointer ABI");
int main(void) {{ return 0; }}
"""
        with tempfile.TemporaryDirectory(prefix="dynamic-xpc-types-") as folder:
            path = Path(folder) / "types.c"
            path.write_text(fixture)
            result = subprocess.run(
                [compiler, "-std=c11", "-Werror", "-fsyntax-only", str(path)],
                capture_output=True, text=True, timeout=30,
            )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
