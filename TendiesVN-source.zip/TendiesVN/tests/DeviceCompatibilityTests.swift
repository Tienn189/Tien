import Foundation

@main
struct DeviceCompatibilityTests {
    static func main() {
        // Public Photos saving has a minimum OS version, not a private backend's
        // patch/build allowlist. A later patch or beta must not disable saving.
        let supported = [
            SystemVersion(17), SystemVersion(17, 7), SystemVersion(17, 7, 1), SystemVersion(17, 8),
            SystemVersion(18), SystemVersion(18, 7, 10), SystemVersion(18, 7, 11), SystemVersion(18, 8),
            SystemVersion(26), SystemVersion(26, 6, 1), SystemVersion(26, 7, 1), SystemVersion(26, 8),
            SystemVersion(27), SystemVersion(27, 0, 1), SystemVersion(27, 1), SystemVersion(28)
        ]
        let unsupported = [
            SystemVersion(16, 9, 9), SystemVersion(0), SystemVersion(-1),
            SystemVersion(18, -1), SystemVersion(18, 7, -1)
        ]
        for version in supported {
            precondition(DeviceCompatibility.isSupported(version), "Expected save support: \(version)")
            precondition(DeviceCompatibility.capability(for: version) == .saveAndManualSet)
            precondition(DeviceCompatibility.capability(for: version, simulator: true) == .simulator)
            precondition(!DeviceCompatibility.hasLocalBackend(version), "Direct wallpaper installation must stay unavailable")
        }
        for version in unsupported {
            precondition(!DeviceCompatibility.isSupported(version), "Expected unsupported: \(version)")
            precondition(DeviceCompatibility.capability(for: version) == .unsupported)
            precondition(DeviceCompatibility.capability(for: version, simulator: true) == .unsupported)
            precondition(!DeviceCompatibility.hasLocalBackend(version))
        }
        precondition(!DeviceCompatibility.directInstallationSupported)
        precondition(!DeviceCompatibility.installationSupported)
        precondition(DeviceCompatibility.mediaSavingSupported ==
                     (DeviceCompatibility.versionIsSupported && !DeviceCompatibility.isSimulator))
        precondition(SystemVersion(18, 7, 9) < SystemVersion(18, 7, 10))
        precondition(SystemVersion(18, 7, 10) < SystemVersion(18, 8))

        // Pairing's separate utility never gates saving or enables installation.
        precondition(!DeviceCompatibility.needsPairing(SystemVersion(26, 99, 99)))
        for version in [SystemVersion(27), SystemVersion(27, 0, 1), SystemVersion(28)] {
            precondition(DeviceCompatibility.needsPairing(version))
            precondition(DeviceCompatibility.capability(for: version) == .saveAndManualSet)
        }

        // Beta ordinals are release labels, not OS minor/patch components.
        let betaLabels = (1...4).map { "27.0 Developer Beta \($0)" }
            + (1...2).map { "27.0 Public Beta \($0)" }
            + ["27.0 (Build beta)", " 27.0\n", "27"]
        for label in betaLabels {
            guard let version = SystemVersion(versionString: label) else {
                preconditionFailure("Could not parse beta version: \(label)")
            }
            precondition(version == SystemVersion(27))
            precondition(DeviceCompatibility.isSupported(version))
            precondition(DeviceCompatibility.capability(for: version) == .saveAndManualSet)
            precondition(!DeviceCompatibility.hasLocalBackend(version))
        }
        precondition(SystemVersion(versionString: "18.7.10") == SystemVersion(18, 7, 10))
        precondition(SystemVersion(versionString: "27.0.1") == SystemVersion(27, 0, 1))
        for invalid in ["", "beta 27", "-27.0", "27..0", "27.0.1.2"] {
            precondition(SystemVersion(versionString: invalid) == nil)
        }
        precondition(DeviceCompatibility.betaRelease(for: "24A5380h")?.publicBeta == 1)
        precondition(DeviceCompatibility.betaRelease(for: "24A5390f")?.publicBeta == 2)
        precondition(DeviceCompatibility.betaRelease(for: "24A5355q")?.developerBeta == 1)
        precondition(DeviceCompatibility.betaRelease(for: "24A5370h")?.publicBeta == nil)
        for unknownBuild in ["24A5390g", "24A5390f-extra", ""] {
            precondition(DeviceCompatibility.betaRelease(for: unknownBuild) == nil)
        }
        print("Compatibility checks passed: Photos minimum OS, beta labels, simulator and unavailable direct wallpaper installation.")
    }
}
