import Foundation

@main
struct DeviceCompatibilityTests {
    static func main() {
        let libraryVersions = [SystemVersion(17), SystemVersion(17, 8), SystemVersion(18), SystemVersion(18, 7, 10), SystemVersion(26, 6, 2), SystemVersion(26, 7), SystemVersion(27), SystemVersion(27, 0, 1), SystemVersion(28)]
        for version in libraryVersions {
            precondition(DeviceCompatibility.isSupported(version))
            precondition(!DeviceCompatibility.hasLocalBackend(version))
            precondition(DeviceCompatibility.capability(for: version) == .libraryOnly)
            precondition(DeviceCompatibility.capability(for: version, simulator: true) == .simulator)
        }
        for version in [SystemVersion(26), SystemVersion(26, 1), SystemVersion(26, 5, 99), SystemVersion(26, 6), SystemVersion(26, 6, 1)] {
            precondition(DeviceCompatibility.hasLocalBackend(version))
            precondition(DeviceCompatibility.capability(for: version) == .localInstallation)
            precondition(DeviceCompatibility.capability(for: version, simulator: true) == .simulator)
        }
        for version in [SystemVersion(16, 9), SystemVersion(0), SystemVersion(-1), SystemVersion(26, -1), SystemVersion(26, 6, -1)] {
            precondition(!DeviceCompatibility.isSupported(version))
            precondition(!DeviceCompatibility.hasLocalBackend(version))
            precondition(DeviceCompatibility.capability(for: version) == .unsupported)
        }
        precondition(DeviceCompatibility.installationSupported == (DeviceCompatibility.hasLocalBackend(DeviceCompatibility.currentVersion, build: DeviceCompatibility.systemBuild) && !DeviceCompatibility.isSimulator))
        precondition(DeviceCompatibility.directInstallationSupported == DeviceCompatibility.installationSupported)
        precondition(SystemVersion(18, 7, 9) < SystemVersion(18, 7, 10))
        precondition(!DeviceCompatibility.needsPairing(SystemVersion(26, 99)))
        precondition(DeviceCompatibility.needsPairing(SystemVersion(27)))
        for label in (1...4).map({ "27.0 Developer Beta \($0)" }) + (1...2).map({ "27.0 Public Beta \($0)" }) {
            let version = SystemVersion(versionString: label)!
            precondition(version == SystemVersion(27))
            precondition(DeviceCompatibility.capability(for: version) == .libraryOnly)
            precondition(!DeviceCompatibility.hasLocalBackend(version))
        }
        let betaBuilds = ["24A5355q", "24A5370h", "24A5380h", "24A5380l", "24A5390f"]
        for build in betaBuilds {
            precondition(DeviceCompatibility.hasLocalBackend(SystemVersion(27), build: build))
            precondition(DeviceCompatibility.capability(for: SystemVersion(27), build: build) == .localInstallation)
            precondition(DeviceCompatibility.capability(for: SystemVersion(27), build: build, simulator: true) == .simulator)
            precondition(!DeviceCompatibility.hasLocalBackend(SystemVersion(27, 0, 1), build: build))
            precondition(!DeviceCompatibility.hasLocalBackend(SystemVersion(27, 1), build: build))
        }
        for build in ["", "24A5390g", "24A5390f-extra", "24a5390f", "24A5390f\0-extra"] {
            precondition(!DeviceCompatibility.hasLocalBackend(SystemVersion(27), build: build))
        }
        precondition(!DeviceCompatibility.hasLocalBackend(SystemVersion(Int.max), build: "24A5390f"))
        for invalid in ["", "beta 27", "-27.0", "27..0", "27.0.1.2"] {
            precondition(SystemVersion(versionString: invalid) == nil)
        }
        precondition(DeviceCompatibility.betaRelease(for: "24A5380h")?.publicBeta == 1)
        precondition(DeviceCompatibility.betaRelease(for: "24A5390f")?.publicBeta == 2)
        precondition(DeviceCompatibility.betaRelease(for: "24A5355q")?.developerBeta == 1)
        precondition(DeviceCompatibility.betaRelease(for: "24A5370h")?.publicBeta == nil)
        precondition(DeviceCompatibility.betaRelease(for: "24A5390f-extra") == nil)
        print("Compatibility: shared native policy, exact beta builds, library-only OS versions and simulator passed.")
    }
}
