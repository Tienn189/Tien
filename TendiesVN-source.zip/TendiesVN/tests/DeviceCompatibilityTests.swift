import Foundation

@main
struct DeviceCompatibilityTests {
    static func main() {
        let supported = [
            SystemVersion(17), SystemVersion(17, 6, 9), SystemVersion(17, 7),
            SystemVersion(18), SystemVersion(18, 7, 9), SystemVersion(18, 7, 10),
            SystemVersion(26), SystemVersion(26, 6, 1), SystemVersion(26, 7),
            SystemVersion(27), SystemVersion(27, 0, 1)
        ]
        let unsupported = [
            SystemVersion(16, 9, 9), SystemVersion(17, 7, 1), SystemVersion(17, 8),
            SystemVersion(18, 7, 11), SystemVersion(18, 8), SystemVersion(19),
            SystemVersion(25, 9, 9), SystemVersion(26, 7, 1), SystemVersion(26, 8),
            SystemVersion(27, 0, 2), SystemVersion(27, 1), SystemVersion(28),
            SystemVersion(-1), SystemVersion(18, -1), SystemVersion(18, 7, -1)
        ]
        for version in supported {
            precondition(DeviceCompatibility.isSupported(version), "Expected supported: \(version)")
        }
        for version in unsupported {
            precondition(!DeviceCompatibility.isSupported(version), "Expected unsupported: \(version)")
        }
        precondition(SystemVersion(18, 7, 9) < SystemVersion(18, 7, 10))
        precondition(SystemVersion(18, 7, 10) < SystemVersion(18, 8))
        precondition(DeviceCompatibility.hasLocalBackend(SystemVersion(26)))
        precondition(DeviceCompatibility.hasLocalBackend(SystemVersion(26, 6, 1)))
        for version in [SystemVersion(17), SystemVersion(18), SystemVersion(26, 6, 2),
                        SystemVersion(26, 7), SystemVersion(27)] {
            precondition(!DeviceCompatibility.hasLocalBackend(version), "Unexpected backend: \(version)")
        }
        precondition(!DeviceCompatibility.needsPairing(SystemVersion(26, 99, 99)))
        for version in [SystemVersion(27), SystemVersion(27, 0, 1), SystemVersion(28)] {
            precondition(DeviceCompatibility.needsPairing(version))
        }
        precondition(DeviceCompatibility.supportedRanges.count == 4)
        print("Compatibility boundaries passed (\(supported.count + unsupported.count) support cases, backend and pairing checks).")
    }
}
