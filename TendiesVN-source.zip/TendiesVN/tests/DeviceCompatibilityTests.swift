import Foundation

@main
struct DeviceCompatibilityTests {
    static func main() {
        let libraryVersions = [SystemVersion(17), SystemVersion(17, 8), SystemVersion(18), SystemVersion(18, 7, 10), SystemVersion(26, 6, 2), SystemVersion(26, 7), SystemVersion(27), SystemVersion(27, 0, 1), SystemVersion(28)]
        for version in libraryVersions {
            precondition(DeviceCompatibility.isSupported(version))
            precondition(!DeviceCompatibility.hasLocalBackend(version))
            precondition(DeviceCompatibility.capability(for: version) == .libraryOnly)
            precondition(DeviceCompatibility.capability(for: version, simulator: true) == .simulator)
        }
        for version in [SystemVersion(26), SystemVersion(26, 1), SystemVersion(26, 5, 99), SystemVersion(26, 6), SystemVersion(26, 6, 1)] {
            precondition(DeviceCompatibility.hasLocalBackend(version))
            precondition(DeviceCompatibility.capability(for: version) == .localInstallation)
            precondition(DeviceCompatibility.capability(for: version, simulator: true) == .simulator)
        }
        for version in [SystemVersion(16, 9), SystemVersion(0), SystemVersion(-1), SystemVersion(26, -1), SystemVersion(26, 6, -1)] {
            precondition(!DeviceCompatibility.isSupported(version))
            precondition(!DeviceCompatibility.hasLocalBackend(version))
            precondition(DeviceCompatibility.capability(for: version) == .unsupported)
        }
        precondition(DeviceCompatibility.installationSupported == (DeviceCompatibility.hasLocalBackend(DeviceCompatibility.currentVersion) && !DeviceCompatibility.isSimulator))
        precondition(DeviceCompatibility.directInstallationSupported == DeviceCompatibility.installationSupported)
        precondition(SystemVersion(18, 7, 9) < SystemVersion(18, 7, 10))
        precondition(!DeviceCompatibility.needsPairing(SystemVersion(26, 99)))
        precondition(DeviceCompatibility.needsPairing(SystemVersion(27)))
        for label in (1...4).map({ "27.0 Developer Beta \($0)" }) + (1...2).map({ "27.0 Public Beta \($0)" }) {
            let version = SystemVersion(versionString: label)!
            precondition(version == SystemVersion(27))
            precondition(DeviceCompatibility.capability(for: version) == .libraryOnly)
            precondition(!DeviceCompatibility.hasLocalBackend(version))
        }
        for invalid in ["", "beta 27", "-27.0", "27..0", "27.0.1.2"] {
            precondition(SystemVersion(versionString: invalid) == nil)
        }
        precondition(DeviceCompatibility.betaRelease(for: "24A5380h")?.publicBeta == 1)
        precondition(DeviceCompatibility.betaRelease(for: "24A5390f")?.publicBeta == 2)
        precondition(DeviceCompatibility.betaRelease(for: "24A5355q")?.developerBeta == 1)
        precondition(DeviceCompatibility.betaRelease(for: "24A5370h")?.publicBeta == nil)
        precondition(DeviceCompatibility.betaRelease(for: "24A5390f-extra") == nil)
        print("Compatibility: local installer boundaries, library-only OS versions, simulator and beta labels passed.")
    }
}
