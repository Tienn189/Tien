from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUST = ROOT / "ThirdParty" / "AirliftSource" / "rust-core" / "src" / "exploit.rs"
BUILD = ROOT / "scripts" / "build-airlift.sh"


class AirliftFramingTests(unittest.TestCase):
    def test_reader_accepts_ios27_bare_binary_plist(self):
        source = RUST.read_text(encoding="utf-8")
        self.assertIn('if &prefix == b"bpli"', source)
        self.assertIn('body.starts_with(b"bplist00")', source)
        self.assertIn("ATC_BARE_PLIST.store(true", source)
        self.assertIn("write bare plist", source)
        self.assertIn("ATC bare plist exceeds 10 MiB", source)

    def test_build_rebuilds_patched_framework_on_macos(self):
        source = BUILD.read_text(encoding="utf-8")
        self.assertIn("cargo build --release --target aarch64-apple-ios", source)
        self.assertIn("xcodebuild -create-xcframework", source)
        build_script = (ROOT / "scripts" / "build-unsigned.sh").read_text(encoding="utf-8")
        self.assertIn('"$ROOT_DIR/scripts/build-airlift.sh"', build_script)

    def test_injection_cleans_airtraffic_state_after_channel_failure(self):
        source = RUST.read_text(encoding="utf-8")
        self.assertIn("async fn cleanup_inject_state", source)
        self.assertIn("ATC read error: {e}", source)
        self.assertIn("restored original Books.plist after failed injection", source)

    def test_container_lookup_accepts_ios27_data_container_key(self):
        source = RUST.read_text(encoding="utf-8")
        self.assertIn('for key in ["Container", "DataContainer"]', source)
        self.assertIn("/var/mobile/Containers/Data/Application/", source)


if __name__ == "__main__":
    unittest.main()
