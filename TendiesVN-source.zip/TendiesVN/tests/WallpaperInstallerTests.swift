// Only temporary fixture directories are used; no device or system access.
import Foundation

@main
struct WallpaperInstallerTests {
    static func main() throws {
        let fm = FileManager.default
        let root = fm.temporaryDirectory.appendingPathComponent("1809-installer-\(UUID())", isDirectory: true)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: root) }
        let container = root.appendingPathComponent("Container", isDirectory: true)
        let descriptors = container.appendingPathComponent("\(WallpaperLayoutScanner.storeRelativePath)/72/Extensions/\(WallpaperPosterLayout.collectionsExtension)/descriptors", isDirectory: true)
        let original = descriptors.appendingPathComponent("APPLE-ORIGINAL", isDirectory: true)
        try fm.createDirectory(at: original, withIntermediateDirectories: true)
        let originalData = Data("preserve original wallpaper".utf8)
        try originalData.write(to: original.appendingPathComponent("data"))
        let package = root.appendingPathComponent("Package", isDirectory: true)
        let source = package.appendingPathComponent("descriptors/Example", isDirectory: true)
        try fm.createDirectory(at: source, withIntermediateDirectories: true)
        let media = Data([1, 2, 3, 4, 5])
        try media.write(to: source.appendingPathComponent("asset.resource"))
        let plist = try PropertyListSerialization.data(fromPropertyList: ["identifier": 7], format: .binary, options: 0)
        try plist.write(to: source.appendingPathComponent("Wallpaper.plist"))
        let payload = try TendiesPackageInspector.inspectExtractedPackage(at: package)
        let layout = try WallpaperLayoutScanner.scan(containerURL: container, rootValidator: { $0 == container.standardizedFileURL })
        let backup = root.appendingPathComponent("Backups", isDirectory: true)
        func names() throws -> Set<String> { Set(try fm.contentsOfDirectory(atPath: descriptors.path)) }
        func checkOriginal() throws {
            let data = try Data(contentsOf: original.appendingPathComponent("data"))
            precondition(data == originalData)
        }
        func checkOnlyOriginal() throws {
            let entries = try names()
            precondition(entries == Set(["APPLE-ORIGINAL"]))
            try checkOriginal()
        }
        // The real transaction creates a new descriptor, preserves the old one,
        // records its journal and changes only the copy's identifier.
        let receipt = try WallpaperInstaller.install(payload: payload, layout: layout, backupRoot: backup)
        precondition(receipt.status == .installed && receipt.installedDescriptors.count == 1)
        let added = descriptors.appendingPathComponent(receipt.installedDescriptors[0].directoryName)
        let copied = try Data(contentsOf: added.appendingPathComponent("asset.resource"))
        precondition(copied == media)
        let changed = try PropertyListSerialization.propertyList(from: Data(contentsOf: added.appendingPathComponent("Wallpaper.plist")), format: nil) as! [String: Any]
        precondition((changed["identifier"] as? Int) != 7)
        let unchangedSource = try Data(contentsOf: source.appendingPathComponent("Wallpaper.plist"))
        precondition(unchangedSource == plist)
        precondition(WallpaperInstaller.receipts(in: backup).first?.status == .installed)
        try checkOriginal()
        try WallpaperInstaller.restore(receipt: receipt, containerURL: container, rootValidator: { $0 == container.standardizedFileURL })
        try checkOnlyOriginal()
        precondition(WallpaperInstaller.receipts(in: backup).first?.status == .restored)
        try checkOriginal()
        // A second unsupported provider fails after the first copy: rollback
        // removes that new copy, preserves Apple's data and records the result.
        let first = payload.descriptors[0]
        let missing = WallpaperDescriptorSource(extensionIdentifier: "com.example.MissingProvider", directoryURL: first.directoryURL, byteCount: first.byteCount, fileCount: first.fileCount, isOrdered: false)
        let invalid = TendiesPayload(descriptors: [first, missing], totalBytes: first.byteCount * 2, fileCount: first.fileCount * 2)
        var rejected = false
        do { _ = try WallpaperInstaller.install(payload: invalid, layout: layout, backupRoot: backup) }
        catch { rejected = true }
        precondition(rejected)
        try checkOnlyOriginal()
        precondition(WallpaperInstaller.receipts(in: backup).contains { $0.status == .rolledBack })
        try checkOriginal()
        // Interrupted copies are also removed using the journal's fixed staging
        // name, while unrelated originals remain untouched.
        var interrupted = try WallpaperInstaller.install(payload: payload, layout: layout, backupRoot: backup)
        interrupted.status = .preparing
        let encoder = PropertyListEncoder()
        try encoder.encode(interrupted).write(to: interrupted.journalURL, options: .atomic)
        let name = interrupted.installedDescriptors[0].directoryName
        let staging = descriptors.appendingPathComponent(".tendiesvn-wallpaper-\(interrupted.id.uuidString)-\(name)")
        try fm.copyItem(at: descriptors.appendingPathComponent(name), to: staging)
        precondition(WallpaperInstaller.receipts(in: backup).contains { $0.id == interrupted.id && $0.status == .preparing })
        try WallpaperInstaller.restore(receipt: interrupted, containerURL: container, rootValidator: { $0 == container.standardizedFileURL })
        try checkOnlyOriginal()
        try checkOriginal()
        // A symlink in source media cannot be copied into PosterBoard.
        try fm.createSymbolicLink(at: source.appendingPathComponent("link"), withDestinationURL: original)
        rejected = false
        do { _ = try TendiesPackageInspector.inspectExtractedPackage(at: package) }
        catch WallpaperLabError.symbolicLinkUnsupported { rejected = true }
        precondition(rejected)
        print("Installer fixtures passed: commit, original preservation, identifier rewrite, rollback, interrupted recovery and symlink rejection.")
    }
}
