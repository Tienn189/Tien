import Foundation

final class PairingValidationTests {
    private func expectNoThrow(_ value: @autoclosure () throws -> Any) {
        do { _ = try value() } catch { fatalError("Unexpected validation error: \(error)") }
    }

    private func expectThrows(_ value: @autoclosure () throws -> Any, _ context: String = "") {
        do {
            _ = try value()
            fatalError("Expected rejection: \(context)")
        } catch {}
    }

    private func expectEqual<T: Equatable>(_ lhs: T, _ rhs: T) { precondition(lhs == rhs) }
    private func expectNil<T>(_ value: T?) { precondition(value == nil) }

    private func fixture(_ name: String) throws -> Data {
        let path = ProcessInfo.processInfo.environment["APP1809_PAIRING_FIXTURES"]!
        return try Data(contentsOf: URL(fileURLWithPath: path).appendingPathComponent(name))
    }

    private func record(key: String = "key-pkcs1.pem") throws -> [String: Any] {
        [
            "HostID": "b2a5cc52-c3ae-45b0-863c-69682b86eb3d",
            "SystemBUID": "2CAC1682-57B8-4CDE-9124-B4A90506BC1B",
            "HostCertificate": try fixture("certificate.pem"),
            "RootCertificate": try fixture("certificate.pem"),
            "DeviceCertificate": try fixture("certificate.pem"),
            "HostPrivateKey": try fixture(key),
            "RootPrivateKey": try fixture(key),
            "EscrowBag": Data([1, 2, 3])
        ]
    }

    private func serialized(_ record: [String: Any], format: PropertyListSerialization.PropertyListFormat = .xml) throws -> Data {
        try PropertyListSerialization.data(fromPropertyList: record, format: format, options: 0)
    }

    func testPKCS1AndPKCS8KeysInXMLAndBinaryRecords() throws {
        for key in ["key-pkcs1.pem", "key-pkcs8.pem"] {
            for format in [PropertyListSerialization.PropertyListFormat.xml, .binary] {
                expectNoThrow(try PairingRecordValidator.validate(serialized(record(key: key), format: format)))
            }
        }
    }

    func testDERCertificatesAndBothKeyContainers() throws {
        var value = try record()
        for name in ["HostCertificate", "RootCertificate", "DeviceCertificate"] {
            value[name] = try fixture("certificate.der")
        }
        value["HostPrivateKey"] = try fixture("key-pkcs1.der")
        value["RootPrivateKey"] = try fixture("key-pkcs8.der")
        expectNoThrow(try PairingRecordValidator.validate(serialized(value)))
    }

    func testMismatchedPrivateKeyIsRejected() throws {
        var value = try record()
        value["HostPrivateKey"] = try fixture("other-key.pem")
        expectThrows(try PairingRecordValidator.validate(serialized(value)))
    }

    func testMissingFieldsMalformedPlistAndInvalidCertificatesAreRejected() throws {
        for name in ["HostID", "SystemBUID", "HostCertificate", "RootCertificate", "DeviceCertificate",
                     "HostPrivateKey", "RootPrivateKey"] {
            var value = try record()
            value.removeValue(forKey: name)
            expectThrows(try PairingRecordValidator.validate(serialized(value)), name)
        }
        for data in [Data(), Data("not a pairing record".utf8), try serialized(["HostID": "bad"])] {
            expectThrows(try PairingRecordValidator.validate(data))
        }
        var value = try record()
        value["DeviceCertificate"] = Data([0x30, 0xFF])
        expectThrows(try PairingRecordValidator.validate(serialized(value)))
    }

    func testOversizedRecordAndMalformedKeyDERAreRejected() throws {
        expectThrows(try PairingRecordValidator.validate(Data(repeating: 1, count: 1_024 * 1_024 + 1)))
        for key in [Data([0x30, 0x80]), Data([0x30, 0x84, 0xFF, 0xFF, 0xFF, 0xFF]),
                    Data([0x30, 0x81, 0x01, 0x00]), Data([0x30, 0x00, 0x00])] {
            var value = try record()
            value["HostPrivateKey"] = key
            expectThrows(try PairingRecordValidator.validate(serialized(value)))
        }
    }

    func testDeviceIdentifierIsOnlyAnOptionalLabel() {
        let modern = "00008110-00123456789ABCDE"
        expectEqual(PairingRecordValidator.deviceIdentifier(record: [:], fileName: modern + ".mobiledevicepairing"), modern)
        expectNil(PairingRecordValidator.deviceIdentifier(record: [:], fileName: "pairing.plist"))
        expectNil(PairingRecordValidator.deviceIdentifier(record: ["UDID": "../../record"], fileName: "pairing.plist"))
    }

}

@main
struct PairingValidationTestRunner {
    static func main() throws {
        let tests = PairingValidationTests()
        try tests.testPKCS1AndPKCS8KeysInXMLAndBinaryRecords()
        try tests.testDERCertificatesAndBothKeyContainers()
        try tests.testMismatchedPrivateKeyIsRejected()
        try tests.testMissingFieldsMalformedPlistAndInvalidCertificatesAreRejected()
        try tests.testOversizedRecordAndMalformedKeyDERAreRejected()
        tests.testDeviceIdentifierIsOnlyAnOptionalLabel()
        print("Pairing validation passed (6 test groups; PEM/DER, PKCS#1/PKCS#8, malformed records and key matching).")
    }
}
