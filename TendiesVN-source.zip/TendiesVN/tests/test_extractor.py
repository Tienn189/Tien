#!/usr/bin/env python3
"""Verify the C streaming extractor using generated ZIPs (no iOS SDK needed).

    python3 tests/test_extractor.py
    python3 tests/test_extractor.py --templates-root /path/to/CAPlayground/apps/web/public/templates

The optional template check reads local upstream assets; it never downloads or
bundles them. Swift path validation and iOS permissions require separate checks.
"""
# SPDX-License-Identifier: GPL-3.0-only
import argparse
import ctypes
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
import zipfile

OPTIONS = argparse.ArgumentParser(add_help=False)
OPTIONS.add_argument("--templates-root", type=Path)
ARGS, UNITTEST_ARGS = OPTIONS.parse_known_args()
ROOT = Path(__file__).resolve().parents[1]


def entry_offset(archive, entry):
    with Path(archive).open("rb") as handle:
        handle.seek(entry.header_offset)
        header = handle.read(30)
    assert header[:4] == b"PK\x03\x04"
    name_length, extra_length = struct.unpack_from("<HH", header, 26)
    return entry.header_offset + 30 + name_length + extra_length


class ExtractorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.build_directory = tempfile.TemporaryDirectory(prefix="tendiesvn-extractor-build-")
        library = Path(cls.build_directory.name) / "extractor.so"
        compiler = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
        if not compiler:
            raise RuntimeError("A C compiler and zlib development headers are required")
        shared_flag = "-dynamiclib" if sys.platform == "darwin" else "-shared"
        subprocess.run([
            compiler, "-std=c11", "-D_GNU_SOURCE", "-Wall", "-Wextra", "-Werror",
            "-fPIC", shared_flag, str(ROOT / "TendiesVN/Engine/wallpaper_zip.c"),
            "-lz", "-o", str(library),
        ], check=True)
        cls.library = ctypes.CDLL(str(library))
        cls.extract = cls.library.wallpaper_zip_extract_entry
        cls.extract.argtypes = [
            ctypes.c_char_p, ctypes.c_uint64, ctypes.c_uint64, ctypes.c_uint16,
            ctypes.c_char_p, ctypes.c_uint64, ctypes.c_uint32,
        ]
        cls.extract.restype = ctypes.c_int

    @classmethod
    def tearDownClass(cls):
        cls.build_directory.cleanup()

    def setUp(self):
        self.workspace = tempfile.TemporaryDirectory(prefix="tendiesvn-extractor-test-")
        self.directory = Path(self.workspace.name)

    def tearDown(self):
        self.workspace.cleanup()

    def fixture(self, method):
        archive = self.directory / f"fixture-{method}.tendies"
        payload = bytes(range(256)) * 512 + b"TendiesVN"
        with zipfile.ZipFile(archive, "w", compression=method) as handle:
            handle.writestr("descriptors/example/versions/1/data.bin", payload)
        with zipfile.ZipFile(archive) as handle:
            entry = handle.infolist()[0]
        return archive, entry, payload

    def extract_entry(self, archive, entry, destination, **overrides):
        arguments = dict(
            offset=entry_offset(archive, entry), compressed_size=entry.compress_size,
            method=entry.compress_type, expected_size=entry.file_size, crc=entry.CRC,
        )
        arguments.update(overrides)
        return self.extract(
            str(archive).encode(), arguments["offset"], arguments["compressed_size"],
            arguments["method"], str(destination).encode(), arguments["expected_size"],
            arguments["crc"],
        )

    def test_stored_and_deflate_match_original_bytes(self):
        for method in [zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED]:
            with self.subTest(method=method):
                archive, entry, payload = self.fixture(method)
                destination = self.directory / f"valid-{method}"
                self.assertEqual(self.extract_entry(archive, entry, destination), 0)
                self.assertEqual(destination.read_bytes(), payload)

    def test_corruption_removes_partial_destination(self):
        for method in [zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED]:
            for issue in ["crc", "size", "truncated", "extra_compressed_byte"]:
                with self.subTest(method=method, issue=issue):
                    archive, entry, _ = self.fixture(method)
                    overrides = {}
                    if issue == "crc":
                        overrides["crc"] = entry.CRC ^ 1
                    elif issue == "size":
                        overrides["expected_size"] = entry.file_size + 1
                    elif issue == "truncated":
                        archive.write_bytes(archive.read_bytes()[:entry_offset(archive, entry) + entry.compress_size - 1])
                    else:
                        overrides["compressed_size"] = entry.compress_size + 1
                    destination = self.directory / f"invalid-{method}-{issue}"
                    self.assertNotEqual(self.extract_entry(archive, entry, destination, **overrides), 0)
                    self.assertFalse(destination.exists())

    def test_existing_file_and_symlink_are_preserved(self):
        archive, entry, _ = self.fixture(zipfile.ZIP_DEFLATED)
        existing = self.directory / "existing.bin"
        existing.write_bytes(b"keep")
        link = self.directory / "destination-link"
        link.symlink_to(existing)
        for destination in [existing, link]:
            with self.subTest(destination=destination.name):
                self.assertNotEqual(self.extract_entry(archive, entry, destination), 0)
                self.assertEqual(existing.read_bytes(), b"keep")
        self.assertTrue(link.is_symlink())

    def test_optional_caplayground_templates(self):
        if ARGS.templates_root is None:
            self.skipTest("pass --templates-root to check local CAPlayground templates")
        count = 0
        for name in ["tendies.zip", "gyro-tendies.zip"]:
            archive = ARGS.templates_root / name
            self.assertTrue(archive.is_file(), str(archive))
            with zipfile.ZipFile(archive) as handle:
                for entry in handle.infolist():
                    if entry.is_dir():
                        continue
                    destination = self.directory / f"template-{count}"
                    self.assertEqual(self.extract_entry(archive, entry, destination), 0, entry.filename)
                    self.assertEqual(destination.read_bytes(), handle.read(entry), entry.filename)
                    count += 1
        self.assertGreater(count, 0)
        print(f"Verified {count} CAPlayground template files")


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0], *UNITTEST_ARGS])
