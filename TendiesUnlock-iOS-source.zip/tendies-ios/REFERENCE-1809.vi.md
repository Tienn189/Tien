# Đối chiếu giao diện 1809

Nguồn người dùng chỉ định: <https://github.com/Tienn189/Tien/blob/main/TendiesVN-source.zip>

Tải ngày 07/11/2026 UTC. Source tự khai báo **1809 3.5.0 (build 19)**.

- SHA-256 ZIP tham khảo: `d4f15d4145255d95d95a26ba2727583281967ab4eb934c9e5f5ce6389e12a5eb`
- File đã đọc: `Views/ContentView.swift`, `Views/SettingsView.swift`, `Views/AppearanceView.swift`, `Views/WallpaperFilePicker.swift`, `Views/StatusBadge.swift`, `App/AppTheme.swift`, `App/TendiesVNApp.swift`, `scripts/build-unsigned.sh`.

## Các thông số áp dụng cho Denrindz

| Thành phần | Cách dựng trong source mẫu và Denrindz |
| --- | --- |
| Thanh tab | `TabView`, mỗi tab có `NavigationStack`, `.tabItem` và `.tag` |
| Điều hướng | `.navigationTitle`, tiêu đề lớn tự thu gọn, nút quay lại hệ thống |
| Trang Cài đặt | `List` kiểu `insetGrouped`, thẻ app và nhóm Cá nhân hóa |
| Nền sáng | RGB `0.955 / 0.965 / 0.995` |
| Nền tối | Đen; thẻ xám `white: 0.11` |
| Thẻ Giao diện | Xem trước bo 24, chế độ bo 22, màu riêng bo 20, ô màu bo 18 |
| Khoảng cách | Padding trang 20; các nhóm Giao diện cách 28; lưới màu cách 12 |
| Bảng màu | Đại dương `1688F5`, Lá xanh `17845B`, Tím khói `8062CD`, Đỏ đào `C34865`, Hổ phách `A96B14`, Than chì `5A6372` |
| Bảng nhập | `UIDocumentPickerViewController` trong `.sheet` mặc định |
| Build | Xcode 26+, để thành phần hệ thống có Liquid Glass khi chạy iOS 26+ |

Denrindz giữ hai mục nhập tendies/ZIP và core xử lý riêng. Tên app, icon ảnh đại diện, Bundle ID, key tùy chọn đã lưu và đầu ra IPA của Denrindz được giữ. Tài liệu này ghi lại nguồn đối chiếu và thông số giao diện; engine cài hình nền/pairing của 1809 không thuộc lần sửa này.
