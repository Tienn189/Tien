# Build IPA bằng GitHub Actions

GitHub dùng máy Mac của GitHub để chạy kiểm thử và tạo **IPA chưa ký**. Không cần Mac cá nhân, chứng chỉ hay GitHub Secrets. Bạn tải IPA về rồi ký bằng chứng chỉ doanh nghiệp theo cách bạn đang dùng.

## Đưa source lên GitHub

1. Tạo repository GitHub mới, có thể để **Private**.
2. Giải nén bộ source và đưa **nội dung bên trong thư mục `tendies-ios`** vào thư mục gốc của repository. Cần thấy `TendiesDecryptor.xcodeproj`, `TendiesDecryptor`, `Tests`, `scripts` và **`.github/workflows/build-ios.yml`** ở đúng vị trí.
3. Đưa cả thư mục ẩn `.github` lên repo. Chỉ upload nguyên file ZIP sẽ không chạy được workflow.

Nếu dùng Git trên máy tính, chạy từ thư mục source đã giải nén:

```bash
git init
git add .
git commit -m "Add Denrindz iPhone app"
git branch -M main
git remote add origin https://github.com/TEN_CUA_BAN/TEN_REPO.git
git push -u origin main
```

Thay `TEN_CUA_BAN/TEN_REPO` bằng repo của bạn. Nếu repo đã có sẵn, dùng cách commit/push thông thường của repo đó.

## Build và tải IPA

1. Vào tab **Actions** của repo, bật Actions nếu GitHub yêu cầu.
2. Chọn workflow **Build iPhone IPA** → **Run workflow** → chọn nhánh → **Run workflow**.
3. Chờ job **Test and build unsigned IPA** chạy thành công. Workflow chạy kiểm thử core trên macOS, sau đó kiểm thử bộ đọc file, CryptoKit và đóng gói trên iPhone Simulator trước khi build.
4. Trong trang lần chạy, kéo xuống **Artifacts**, tải **TendiesUnlock-unsigned-IPA**.
5. Giải nén artifact tải về để lấy **`TendiesUnlock-unsigned.ipa`**.
6. Ký IPA này bằng công cụ và chứng chỉ doanh nghiệp bạn đang dùng, rồi cài lên iPhone.

IPA do workflow tạo ra chưa có chữ ký Apple và chưa thể cài trực tiếp. Workflow không cần biết hay nhận chứng chỉ của bạn. Artifact được giữ 7 ngày; có thể chạy lại workflow để tạo bản mới.

## Nếu build báo lỗi

Mở lần chạy bị lỗi và đọc bước màu đỏ. Nếu không thấy nút **Run workflow**, kiểm tra file `.github/workflows/build-ios.yml` đã nằm trên nhánh mặc định của repo. Nếu tài khoản hết hạn mức GitHub Actions, cần xử lý hạn mức đó trên GitHub rồi chạy lại.

Source này được chuẩn bị trong môi trường Linux: bộ test đóng gói chạy được tại đây, còn Xcode, các test Apple và UI cần workflow/macOS. Lần build đầu cần mạng để lấy ZIPFoundation 0.9.20; không cần mạng để dùng tính năng đóng gói sau khi cài app.

Nếu đang dùng workflow giải nén source ZIP và gọi `scripts/build-ipa.sh`, thay ZIP bằng bản **Denrindz 1.2.5 (build 14)**. Gói giao source vẫn có tên `TendiesUnlock-iOS-source.zip` và thư mục gốc `tendies-ios` để giữ tương thích với bước giải nén đang dùng. Tên file IPA đầu ra vẫn là `TendiesUnlock-unsigned.ipa`, còn tên hiển thị khi cài là **Denrindz**. Build script tự chạy test core trước khi tạo IPA. Workflow trong project chạy test riêng và đặt `RUN_IMPORT_TESTS=0` ở bước build để tránh chạy lại.

Script tự chọn **Xcode 26 trở lên đã cài trên runner** trước khi chạy test/build. Nếu lựa chọn hiện tại quá cũ, `scripts/select-xcode.sh` tìm Xcode hợp lệ và iOS SDK 26+ trong `/Applications`, rồi xuất `DEVELOPER_DIR` cho các lệnh tiếp theo. Workflow build toàn source cũng dùng script này và truyền lựa chọn qua `GITHUB_ENV`. Liquid Glass xuất hiện khi app chạy trên iOS 26 trở lên; iOS cũ giữ giao diện hệ thống tương ứng.

## Workflow hai ZIP trong repo Tien

Workflow người dùng gửi có bước `Select Xcode 26 for TendiesVN` với điều kiện chỉ chạy cho `matrix.app == 'TendiesVN'`. Vì thế job TendiesUnlock bỏ qua bước chọn SDK và bản 1.2.4 dừng ở kiểm tra Xcode.

Với Denrindz 1.2.5, **chỉ cần thay `TendiesUnlock-iOS-source.zip` rồi chạy lại** khi runner đã có Xcode 26: build script tự chọn SDK ngay cả khi bước bên ngoài bị bỏ qua.

Bản workflow đã sửa được kèm tại [BUILD-FROM-ZIP.yml](BUILD-FROM-ZIP.yml). Có thể dùng nó thay nội dung `.github/workflows/build-from-zip.yml` ở repo để bước chọn Xcode áp dụng cho cả hai app. Phần sửa chính:

```yaml
- name: Select Xcode 26 for both apps
  if: steps.source.outputs.found == 'true'
```

Giữ nguyên hai mục matrix, tên ZIP, thư mục, script và đường dẫn IPA như workflow hiện tại.
