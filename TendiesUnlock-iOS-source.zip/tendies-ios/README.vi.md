# Tendies Unlock cho iPhone

Ứng dụng SwiftUI chọn file `.tendies` / `.wallive`, giải mã trên thiết bị và xuất file ZIP để lưu vào Tệp hoặc chia sẻ. Mã nguồn không dùng backend, quảng cáo hay thư viện bên ngoài. Bản hiện tại: **1.0.3 (build 4)**.

## Phạm vi hỗ trợ

- iOS / iPadOS 16 trở lên.
- File có header `WALLIVE1` và cùng khoá với file `milk_frog.tendies` đã kiểm tra.
- AES-256-GCM qua CryptoKit, kiểm tra tag xác thực trước khi xuất kết quả.
- Tối đa 64 MiB mỗi file, chọn và xử lý từng file để giới hạn bộ nhớ trên iPhone.
- Không ghi đè file gốc. Kết quả có đuôi `.decrypted.zip`.
- `WALLIVE2`, file lỗi, file dùng khoá khác hoặc ZIP chưa mã hoá sẽ được báo rõ; app không đoán khoá.

File ZIP bên trong có thể chứa ảnh, `.js`, `.caml`, `.plist`. Sau khi lưu ZIP vào ứng dụng Tệp, chạm vào ZIP để giải nén. Một số `.plist` của Apple ở dạng nhị phân nên cần công cụ hỗ trợ nếu muốn chỉnh sửa.

## Nhập file trực tiếp

1. Nhấn **Chọn file để giải mã** và chọn một file trong Tệp hoặc iCloud Drive.
2. Bộ chọn mở file tại chỗ (`asCopy: false`). Ứng dụng giữ quyền truy cập ngay khi nhận URL, trước khi đóng bộ chọn.
3. Ứng dụng tự yêu cầu tải dữ liệu iCloud khi cần, dùng `NSFileCoordinator` để đọc trong luồng nền và hiển thị tiến trình. File không được sao chép sang thư mục trung gian.
4. Sau khi đọc thành công, ứng dụng xác thực và giải mã rồi xuất ZIP. Có thể hủy thao tác hoặc thử lại khi việc đọc không hoàn tất.

Nếu nhà cung cấp file làm mờ `.tendies` trong bộ chọn, dùng nút **Chọn từ thư mục** ngay trong app. Chọn thư mục chứa file và cấp quyền mở thư mục. Ứng dụng hiển thị danh sách file riêng để bạn chọn file cần giải mã; danh sách này không dùng bộ lọc UTI theo từng file của bộ chọn hệ thống. Không cần đổi đuôi hay sao chép file.

Ứng dụng vẫn giữ lựa chọn file trực tiếp với tập kiểu nội dung gồm kiểu `.tendies`/`.wallive` đã khai báo, các kiểu được nhận diện từ phần mở rộng và kiểu dữ liệu chung. Việc provider quyết định file có thể chọn trong bộ chọn hệ thống có thể khác nhau; đường chọn thư mục giúp tránh phụ thuộc vào quyết định lọc từng file đó.

Không cần di chuyển hay sao chép file thủ công trong Tệp. Nếu nhà cung cấp file trả lỗi hoặc không cung cấp dữ liệu trong thời gian chờ, ứng dụng báo lỗi để người dùng thử lại; bộ giải mã không thể tự sửa một dịch vụ lưu trữ đang mất kết nối.

## Build IPA bằng GitHub Actions

Xem [README-GITHUB.vi.md](README-GITHUB.vi.md) để đưa source vào repository và chạy workflow `Build iPhone IPA` trong `.github/workflows/build-ios.yml`.

Workflow dùng máy macOS của GitHub để build và tạo **IPA chưa ký**. Không cần đưa chứng chỉ, `.p12` hay provisioning profile vào repository. Sau khi tải IPA từ mục Artifacts, ký bằng công cụ và chứng chỉ doanh nghiệp của bạn rồi cài lên iPhone như quy trình bạn đang dùng.

IPA chưa ký không cài trực tiếp lên iPhone được. GitHub Actions build gói cài đặt; bước ký app được thực hiện riêng.

## Chạy trực tiếp bằng Xcode

1. Trên Mac, cài Xcode 15 trở lên, mở Xcode một lần để hoàn tất cài iOS SDK.
2. Mở `TendiesDecryptor.xcodeproj`.
3. Chọn scheme **TendiesDecryptor** và một iPhone simulator để chạy thử.
4. Để chạy trên iPhone thật, vào target **TendiesDecryptor → Signing & Capabilities**, chọn Team của bạn và đổi Bundle Identifier nếu Xcode yêu cầu.
5. Bấm Run. Trên app, chọn file, giải mã, rồi lưu hoặc chia sẻ ZIP.

Mặc định project dùng Bundle Identifier `com.local.TendiesDecryptor`. Không có Team, tài khoản hay chứng chỉ được nhúng trong source.

## Build IPA chưa ký trên Mac

Mở Terminal trong thư mục source rồi chạy:

```bash
bash scripts/build-ipa.sh
```

Kết quả:

```text
build/TendiesUnlock-unsigned.ipa
```

Script dùng iOS SDK của Xcode và `CODE_SIGNING_ALLOWED=NO`. Nó chạy bộ XCTest của bộ đọc file và bộ giải mã bằng Swift Package Manager trên macOS trước, chỉ tiếp tục tạo IPA khi test thành công. Bộ test dùng đúng source Foundation/CryptoKit của app, không phụ thuộc vào việc runner có sẵn iPhone Simulator. Sau đó script biên dịch app iOS, dùng thư mục staging tạm và đóng gói `Payload/TendiesDecryptor.app` bằng `ditto`.

Workflow Codemagic/GitHub đang gọi `scripts/build-ipa.sh` tiếp tục dùng được với ZIP source mới. Nếu một workflow đã tự chạy đầy đủ XCTest trước đó, đặt `RUN_IMPORT_TESTS=0` cho bước build để tránh chạy hai lần. Đây không phải cấu hình mặc định của bản build từ ZIP.

## Kiểm tra trên Mac

Các test kiểm tra giải mã, xác thực, đọc file trực tiếp, danh sách thư mục, tập kiểu nội dung và các tình huống lỗi/cancel/timeout. Chạy bằng Apple SDK trên Mac:

```bash
bash scripts/test-core.sh
```

Log nằm ở `build/core-tests.log`. Có thể kiểm tra cùng bộ test trên iPhone Simulator qua Xcode **Product → Test** (`⌘U`) hoặc tự chọn simulator tương thích với SDK:

```bash
bash scripts/test-ios.sh
```

Log simulator nằm ở `build/import-tests.log`; kết quả XCTest đầy đủ nằm trong `build/test-results.*/ImportTests.xcresult`.

Môi trường tạo source này là Linux, không có Xcode hoặc Apple SDK. Bản sửa nhập file chưa được biên dịch hay chạy thử trên iPhone tại đây; bước test trong build script sẽ xác nhận XCTest của bộ đọc/giải mã trên máy Apple khi chạy ở Codemagic/GitHub, rồi biên dịch app iOS. Vẫn cần thử thao tác chọn file thật từ iCloud trên thiết bị để xác nhận luồng nhà cung cấp file. Thuật toán giải mã đã được đối chiếu với file mẫu: ZIP đầu ra có SHA-256 `d1512cd81cfbed01a555d5791f4da05d318b7185cf4671610b6d4c1001cf7eb1`.

## Cấu trúc source

```text
TendiesDecryptor.xcodeproj/    Project Xcode và shared scheme
TendiesDecryptor/             Giao diện SwiftUI, bộ giải mã và icon
Tests/                       XCTest
scripts/build-ipa.sh          Build và đóng gói IPA chưa ký trên Mac
scripts/test-core.sh          XCTest bộ đọc/giải mã bằng SwiftPM trên macOS
scripts/test-ios.sh           Chạy XCTest bằng simulator tương thích SDK
.github/workflows/           GitHub Actions
```

File gốc và nội dung đã giải mã không được đưa vào repository/project này.
