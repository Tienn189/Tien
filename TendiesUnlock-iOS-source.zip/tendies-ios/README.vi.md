# Tendies Unlock cho iPhone

Ứng dụng SwiftUI chọn file `.tendies` / `.wallive`, giải mã trên thiết bị và xuất file ZIP để lưu vào Tệp hoặc chia sẻ. Mã nguồn không dùng backend, quảng cáo hay thư viện bên ngoài.

## Phạm vi hỗ trợ

- iOS / iPadOS 16 trở lên.
- File có header `WALLIVE1` và cùng khoá với file `milk_frog.tendies` đã kiểm tra.
- AES-256-GCM qua CryptoKit, kiểm tra tag xác thực trước khi xuất kết quả.
- Tối đa 64 MiB mỗi file, xử lý lần lượt để giới hạn bộ nhớ trên iPhone.
- Không ghi đè file gốc. Kết quả có đuôi `.decrypted.zip`.
- `WALLIVE2`, file lỗi, file dùng khoá khác hoặc ZIP chưa mã hoá sẽ được báo rõ; app không đoán khoá.

File ZIP bên trong có thể chứa ảnh, `.js`, `.caml`, `.plist`. Sau khi lưu ZIP vào ứng dụng Tệp, chạm vào ZIP để giải nén. Một số `.plist` của Apple ở dạng nhị phân nên cần công cụ hỗ trợ nếu muốn chỉnh sửa.

## Build IPA bằng GitHub Actions

Xem [README-GITHUB.vi.md](README-GITHUB.vi.md) để đưa source vào repository và chạy workflow `Build iPhone IPA` trong `.github/workflows/build-ios.yml`.

Workflow dùng máy macOS của GitHub để build và tạo **IPA chưa ký**. Không cần đưa chứng chỉ, `.p12` hay provisioning profile vào repository. Sau khi tải IPA từ mục Artifacts, ký bằng công cụ và chứng chỉ doanh nghiệp của bạn rồi cài lên iPhone như quy trình bạn đang dùng.

IPA chưa ký không cài trực tiếp lên iPhone được. GitHub Actions build gói cài đặt; bước ký app được thực hiện riêng.

## Chạy trực tiếp bằng Xcode

1. Trên Mac, cài Xcode 15 trở lên, mở Xcode một lần để hoàn tất cài iOS SDK.
2. Mở `TendiesDecryptor.xcodeproj`.
3. Chọn scheme **TendiesDecryptor** và một iPhone simulator để chạy thử.
4. Để chạy trên iPhone thật, vào target **TendiesDecryptor → Signing & Capabilities**, chọn Team của bạn và đổi Bundle Identifier nếu Xcode yêu cầu.
5. Bấm Run. Trên app, chọn file, giải mã, rồi lưu hoặc chia sẻ ZIP.

Mặc định project dùng Bundle Identifier `com.local.TendiesDecryptor`. Không có Team, tài khoản hay chứng chỉ được nhúng trong source.

## Build IPA chưa ký trên Mac

Mở Terminal trong thư mục source rồi chạy:

```bash
bash scripts/build-ipa.sh
```

Kết quả:

```text
build/TendiesUnlock-unsigned.ipa
```

Script dùng iOS SDK của Xcode và `CODE_SIGNING_ALLOWED=NO`. Nó kiểm tra macOS/iOS SDK trước khi chạy, dùng thư mục staging tạm và đóng gói `Payload/TendiesDecryptor.app` bằng `ditto`.

## Kiểm tra trên Mac

Trong Xcode, chọn iPhone simulator rồi bấm **Product → Test** (`⌘U`). Bộ test kiểm tra giải mã, xác thực và các đầu vào sai. Có thể chạy qua Terminal; thay tên simulator bằng thiết bị có trên máy:

```bash
xcodebuild \
  -project TendiesDecryptor.xcodeproj \
  -scheme TendiesDecryptor \
  -destination 'platform=iOS Simulator,name=iPhone 16' \
  test
```

Môi trường tạo source này là Linux, không có Xcode hoặc iOS SDK. Project chưa được biên dịch hay chạy thử trên iPhone tại đây; cần kiểm tra workflow GitHub hoặc build bằng Xcode để xác nhận bản iOS. Thuật toán giải mã đã được đối chiếu với file mẫu: ZIP đầu ra có SHA-256 `d1512cd81cfbed01a555d5791f4da05d318b7185cf4671610b6d4c1001cf7eb1`.

## Cấu trúc source

```text
TendiesDecryptor.xcodeproj/    Project Xcode và shared scheme
TendiesDecryptor/             Giao diện SwiftUI, bộ giải mã và icon
Tests/                       XCTest
scripts/build-ipa.sh          Build và đóng gói IPA chưa ký trên Mac
.github/workflows/           GitHub Actions
```

File gốc và nội dung đã giải mã không được đưa vào repository/project này.
