# Denrindz cho iPhone

Ứng dụng SwiftUI giải mã `WALLIVE1` thành ZIP và tự đóng gói bản xuất PosterBoard đã giải mã sẵn thành `.tendies`. Các thao tác chạy trên thiết bị, không dùng backend hoặc quảng cáo. Bản hiện tại: **1.2.4 (build 13)**. Bộ đọc/nén ZIP dùng ZIPFoundation 0.9.20, giấy phép MIT.

## Giao diện và màu chủ đề

Giao diện đã được đối chiếu trực tiếp với **1809 3.5.0 (19)** trong source ZIP người dùng chỉ định: <https://github.com/Tienn189/Tien/blob/main/TendiesVN-source.zip>. Bản này dùng cùng cách dựng thanh tab, thanh điều hướng và bảng Tệp bằng thành phần iOS gốc. Nền sáng có RGB `0.955 / 0.965 / 0.995`, nền tối đen; thẻ nội dung trắng hoặc xám tối, bo góc 20–24. Xem [REFERENCE-1809.vi.md](REFERENCE-1809.vi.md) để đối chiếu thông số.

**Icon giữ ảnh đại diện xám do người dùng cung cấp**, chuẩn hóa thành PNG vuông 1024 px. Màn hình chính có đúng hai dòng nhập: **Nhập file tendies** và **Nhập file zip**. Tiến trình, lỗi và kết quả chỉ xuất hiện sau khi bắt đầu thao tác.

Thanh tab nằm dưới màn hình với **Nhập file** và **Cài đặt**, dùng `TabView` và `NavigationStack` như source mẫu. Tiêu đề lớn tự thu gọn khi cuộn, nút quay lại và thanh tab do iOS vẽ. Góc trên màn hình chính không có nút thông tin. Cài đặt dùng List nhóm, có **Giao diện**, **Hướng dẫn và thông tin**, tên/phiên bản app. Model tác vụ thuộc màn hình gốc, được giữ khi chuyển tab.

Nhấn **Cài đặt → Giao diện** để xem trước chủ đề và chọn **Theo hệ thống / Sáng / Tối**. Bảng màu có **Đại dương, Lá xanh, Tím khói, Đỏ đào, Hổ phách, Than chì**, dùng đúng sáu mã màu của source mẫu. **Màu của bạn** mở bộ chọn màu iOS và hiển thị mã hex khi tùy chỉnh. Trang này giữ thanh tab bên dưới, dùng nút quay lại hệ thống. Thay đổi được lưu trên thiết bị; cài mới và **Khôi phục giao diện mặc định** dùng Theo hệ thống + Đại dương. Cập nhật vẫn giữ lựa chọn đã lưu trước đó.

Build yêu cầu **Xcode 26 trở lên**, cùng yêu cầu SDK của source 1809. Khi chạy trên **iOS 26 trở lên**, hệ thống áp dụng Liquid Glass cho tab bar, navigation bar và bảng Tệp. Các phiên bản iOS cũ dùng giao diện hệ thống của phiên bản đó; deployment target vẫn là iOS 16. Source không vẽ đè thanh tab, nút quay lại hoặc nền kính cho thẻ. Bảng màu tự chuyển sang hai cột ở cỡ chữ Trợ năng, hàng Cài đặt tự xuống dòng theo nội dung.

Tiến trình, hủy, thử lại và chia sẻ kết quả nằm ngay trong màn hình chính. Cả hai dòng nhập mở **bộ duyệt Tệp gốc qua sheet mặc định của iOS**, cùng cách trình bày trong source 1809; không ép góc bo hoặc tiêu đề thư mục. Hình dạng, tìm kiếm, vị trí duyệt và các tab của Tệp do iOS quản lý. Bảng chia sẻ mở khi bạn lưu file. Mở Cài đặt không hủy tác vụ đang chạy. Hướng dẫn và bước nhập gần nhất nằm trong **Cài đặt → Hướng dẫn và thông tin**.

## Tự đóng gói bản xuất PosterBoard

1. Trong 3105 hoặc công cụ quản lý dữ liệu bạn đang dùng, xuất **cả thư mục cấu hình** của đúng hình nền và nén thành ZIP trong Tệp/iCloud Drive.
2. Trên màn hình chính Denrindz, nhấn **Nhập file zip**.
3. Chọn ZIP đã xuất. Ứng dụng tự tìm cấu hình trong thư mục bao ngoài, kiểm tra mã CAML và các tài nguyên được tham chiếu, rồi tạo `.tendies`.
4. Nhấn **Lưu/chia sẻ .tendies → Lưu vào Tệp** để giữ kết quả. Có thể hủy và thử lại; tiến trình và kết quả xuất hiện ngay trên màn hình chính, được giữ trong phiên hiện tại cho đến khi bạn xóa chúng.

Đầu vào phải là **bản rõ mà ứng dụng gốc đã xuất sau khi giải mã**. Ví dụ:

```text
<UUID cấu hình>/
  com.apple.posterkit.provider.descriptor.identifier
  com.apple.posterkit.role.identifier
  ...metadata...
  versions/
    0/
      contents/
        ...wallpaper/
          Wallpaper.plist
          ...Background...ca/
          ...Foreground...ca/
          ...Floating...ca/
```

Số phiên bản trong `versions` được giữ nguyên, không ép về `0` hoặc làm phẳng thư mục. ZIP đã có cấu trúc `descriptors/<UUID>/...` cũng được nhận diện. Ứng dụng xuất gói ZIP chưa mã hóa với phần mở rộng `.tendies` và thư mục `descriptors` ở gốc, giữ nguyên byte của CAML, ảnh và metadata nội dung. Những file `scratch`, `RuntimeSnapshot*`, `.DS_Store` và `__MACOSX` được bỏ khỏi **bản sao làm việc**, không xóa khỏi dữ liệu gốc.

Nén riêng `.wallpaper` hoặc một thư mục `.ca` là chưa đủ metadata để tạo descriptor; hãy nén cả thư mục cấu hình bao ngoài. Nếu ảnh hoặc file cảnh bị thiếu, ứng dụng báo đường dẫn cần bổ sung thay vì xuất gói thiếu tài nguyên.

Giới hạn đóng gói: đầu vào/đầu ra ZIP tối đa 512 MiB; dữ liệu giải nén tối đa 768 MiB; mỗi file tối đa 256 MiB; 20.000 mục và 64 cấu hình. ZIP được đọc/ghi theo khối để tránh nạp toàn bộ ảnh vào bộ nhớ. Đầu ra có tên duy nhất và không ghi đè file gốc.

Tính năng này không tự truy cập vùng dữ liệu của PosterBoard hoặc app khác và không lấy khoá Keychain. Một file `WALLIVE2` còn mã hóa vẫn cần được mở bởi ứng dụng có giấy phép trước khi xuất dữ liệu. App cũng không tự cài hình nền; khả năng nhập/chạy gói cần được kiểm tra bằng công cụ cài trên iPhone.

## Phạm vi hỗ trợ

- iOS / iPadOS 16 trở lên.
- File có header `WALLIVE1` và cùng khoá với file `milk_frog.tendies` đã kiểm tra.
- AES-256-GCM qua CryptoKit, kiểm tra tag xác thực trước khi xuất kết quả.
- Luồng giải mã: tối đa 64 MiB mỗi file, chọn và xử lý từng file để giới hạn bộ nhớ trên iPhone. Luồng đóng gói PosterBoard có giới hạn riêng ở trên.
- Không ghi đè file gốc. Kết quả có đuôi `.decrypted.zip`.
- `WALLIVE2`, file lỗi hoặc file dùng khoá khác sẽ được báo rõ; app không đoán khoá. Gói ZIP đã giải mã vẫn có thể nhập và xuất lại thành ZIP.

File ZIP bên trong có thể chứa ảnh, `.js`, `.caml`, `.plist`. Sau khi lưu ZIP vào ứng dụng Tệp, chạm vào ZIP để giải nén. Một số `.plist` của Apple ở dạng nhị phân nên cần công cụ hỗ trợ nếu muốn chỉnh sửa.

## Nhập file trực tiếp

1. Nhấn **Nhập file tendies** và chọn file gốc trong Tệp hoặc iCloud Drive.
2. Bộ chọn dùng chế độ nhập (`asCopy: true`) để hệ thống tự bàn giao dữ liệu file, kể cả khi provider không hỗ trợ mở tại chỗ. Người dùng không phải tự sao chép hay đổi đuôi file.
3. Ứng dụng đọc toàn bộ byte thô, không yêu cầu file mã hóa có chữ ký ZIP. Bộ đọc chạy trong nền, có tiến trình, thời gian chờ và hủy. Yêu cầu tải iCloud chỉ là gợi ý; nếu gợi ý bị từ chối, ứng dụng vẫn thử đọc qua `NSFileCoordinator`.
4. Sau khi đọc thành công, ứng dụng kiểm tra header `WALLIVE1`, xác thực AES-GCM rồi xuất ZIP. File đã là ZIP được xuất lại thay vì bị từ chối.

Ứng dụng chọn file trực tiếp với tập kiểu nội dung gồm kiểu `.tendies`/`.wallive` đã khai báo, các kiểu được nhận diện từ phần mở rộng và kiểu dữ liệu chung. Việc provider quyết định file có thể chọn trong bộ chọn hệ thống có thể khác nhau. Bản giao diện này chỉ giữ hai dòng nhập file, không có nút chọn thư mục.

Không cần di chuyển hay sao chép file thủ công trong Tệp. Nếu nhà cung cấp file trả lỗi hoặc không cung cấp dữ liệu trong thời gian chờ, ứng dụng báo lỗi để người dùng thử lại; bộ giải mã không thể tự sửa một dịch vụ lưu trữ đang mất kết nối.

## Build IPA bằng GitHub Actions

Xem [README-GITHUB.vi.md](README-GITHUB.vi.md) để đưa source vào repository và chạy workflow `Build iPhone IPA` trong `.github/workflows/build-ios.yml`.

Workflow dùng máy macOS của GitHub để chạy kiểm thử, build và tạo **IPA chưa ký**. Lần build đầu cần mạng để Swift Package Manager lấy ZIPFoundation 0.9.20; app sau khi cài vẫn hoạt động ngoại tuyến. Không cần đưa chứng chỉ, `.p12` hay provisioning profile vào repository. Sau khi tải IPA từ mục Artifacts, ký bằng công cụ và chứng chỉ doanh nghiệp của bạn rồi cài lên iPhone như quy trình bạn đang dùng.

IPA chưa ký không cài trực tiếp lên iPhone được. GitHub Actions build gói cài đặt; bước ký app được thực hiện riêng.

## Chạy trực tiếp bằng Xcode

1. Trên Mac, cài Xcode 26 trở lên, mở Xcode một lần để hoàn tất cài iOS SDK.
2. Mở `TendiesDecryptor.xcodeproj`.
3. Chọn scheme **TendiesDecryptor** và một iPhone simulator để chạy thử.
4. Để chạy trên iPhone thật, vào target **TendiesDecryptor → Signing & Capabilities**, chọn Team của bạn và đổi Bundle Identifier nếu Xcode yêu cầu.
5. Bấm Run. Trên app, chọn file, giải mã, rồi lưu hoặc chia sẻ ZIP.

Mặc định project dùng Bundle Identifier `com.local.TendiesDecryptor`. Không có Team, tài khoản hay chứng chỉ được nhúng trong source.

## Build IPA chưa ký trên Mac

Mở Terminal trong thư mục source rồi chạy:

```bash
bash scripts/build-ipa.sh
```

Kết quả:

```text
build/TendiesUnlock-unsigned.ipa
```

Script dùng iOS SDK của Xcode và `CODE_SIGNING_ALLOWED=NO`. Nó chạy bộ XCTest của bộ đọc file và bộ giải mã bằng Swift Package Manager trên macOS trước, chỉ tiếp tục tạo IPA khi test thành công. Bộ test dùng đúng source Foundation/CryptoKit của app, không phụ thuộc vào việc runner có sẵn iPhone Simulator. Sau đó script biên dịch app iOS, dùng thư mục staging tạm và đóng gói `Payload/TendiesDecryptor.app` bằng `ditto`.

Workflow Codemagic/GitHub đang gọi `scripts/build-ipa.sh` tiếp tục dùng được với ZIP source mới. Nếu một workflow đã tự chạy đầy đủ XCTest trước đó, đặt `RUN_IMPORT_TESTS=0` cho bước build để tránh chạy hai lần. Đây không phải cấu hình mặc định của bản build từ ZIP.

## Kiểm tra trên Mac

Các test kiểm tra giải mã, xác thực, đọc file trực tiếp, danh sách thư mục, tập kiểu nội dung và các tình huống lỗi/cancel/timeout. Bộ test đóng gói kiểm tra cấu trúc descriptor, giữ nguyên tài nguyên, loại cache, đầu vào ZIP/thư mục, dữ liệu thiếu hoặc không hợp lệ và hủy/dọn file tạm. Chạy bằng Apple SDK trên Mac:

```bash
bash scripts/test-core.sh
```

Log nằm ở `build/core-tests.log`. Trên Linux có Swift 5.9 trở lên, cùng script chỉ chạy bộ test đóng gói; các test CryptoKit/NSFileCoordinator/UIKit vẫn yêu cầu Apple SDK. Có thể kiểm tra cùng bộ test trên iPhone Simulator qua Xcode **Product → Test** (`⌘U`) hoặc tự chọn simulator tương thích với SDK:

```bash
bash scripts/test-ios.sh
```

Log simulator nằm ở `build/import-tests.log`; kết quả XCTest đầy đủ nằm trong `build/test-results.*/ImportTests.xcresult`.

Môi trường chỉnh sửa là Linux, không có Xcode hoặc Apple SDK. Kết quả kiểm thử thực hiện trong lần chỉnh sửa được ghi ở `VALIDATION.vi.md`. Build iOS, luồng bộ chọn iCloud trên thiết bị và phát hoạt ảnh phải được kiểm tra bằng Xcode/iPhone; script build chạy test Apple trước khi tạo IPA. Thuật toán giải mã cũ đã được đối chiếu với file mẫu: ZIP đầu ra có SHA-256 `d1512cd81cfbed01a555d5791f4da05d318b7185cf4671610b6d4c1001cf7eb1`.

## Cấu trúc source

```text
TendiesDecryptor.xcodeproj/    Project Xcode và shared scheme
TendiesDecryptor/             Giao diện SwiftUI, bộ giải mã và icon
Tests/                       XCTest
scripts/build-ipa.sh          Build và đóng gói IPA chưa ký trên Mac
scripts/test-core.sh          XCTest bộ đọc/giải mã bằng SwiftPM trên macOS
scripts/test-ios.sh           Chạy XCTest bằng simulator tương thích SDK
.github/workflows/           GitHub Actions
```

File gốc và nội dung đã giải mã không được đưa vào repository/project này.

## Thư viện và định dạng

- ZIPFoundation 0.9.20: <https://github.com/weichsel/ZIPFoundation>, MIT; bản quyền đầy đủ trong `THIRD_PARTY_NOTICES.md` và được kèm trong tài nguyên app.
- Bố cục `.tendies`: theo cấu trúc descriptor của Pocket-Poster/Nugget, <https://github.com/leminlimez/Nugget/blob/main/documentation.md>. Đây là đóng gói bản xuất sẵn có, không phải phát hiện khoá giải mã mới.

## Kiểm tra bản cài và bước nhập

Phiên bản xuất hiện trên thẻ Denrindz. Tab **Cài đặt** hiển thị cả phiên bản/build. Vào **Cài đặt → Hướng dẫn và thông tin → Bước nhập gần nhất** để xem bộ chọn đã bàn giao file hay chưa, số byte đã đọc hoặc lỗi từ provider. Một bài kiểm thử tích hợp dùng fixture `WALLIVE1` tạo độc lập bằng Python, đọc file `.tendies` rồi giải mã và kiểm tra ZIP đầu ra. Các kiểm thử provider mô phỏng metadata thiếu/lỗi và placeholder iCloud.
