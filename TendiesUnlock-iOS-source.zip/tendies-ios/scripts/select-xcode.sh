#!/bin/bash
# Source this file so DEVELOPER_DIR also applies to tests and xcodebuild.
# Select an installed SDK without changing the machine's global xcode-select.

_denrindz_try_xcode() {
    local candidate_dir="$1"
    local candidate_version candidate_sdk
    if [[ "$candidate_dir" == *.app ]]; then
        candidate_dir="$candidate_dir/Contents/Developer"
    fi
    [[ -d "$candidate_dir" ]] || return 1
    candidate_version="$(DEVELOPER_DIR="$candidate_dir" xcodebuild -version 2>/dev/null)" || return 1
    [[ "$candidate_version" =~ ^Xcode[[:space:]]+([0-9]+) ]] || return 1
    (( BASH_REMATCH[1] >= 26 )) || return 1
    candidate_sdk="$(DEVELOPER_DIR="$candidate_dir" xcrun --sdk iphoneos --show-sdk-version 2>/dev/null)" || return 1
    [[ "$candidate_sdk" =~ ^([0-9]+) ]] || return 1
    (( BASH_REMATCH[1] >= 26 )) || return 1

    export DEVELOPER_DIR="$candidate_dir"
    printf '%s\n' "$candidate_version"
    printf 'iOS SDK: %s\nDEVELOPER_DIR=%s\n' "$candidate_sdk" "$DEVELOPER_DIR"
}

denrindz_select_xcode() {
    local active_dir candidate_app
    local applications_dir="${DENRINDZ_XCODE_APPLICATIONS_DIR:-/Applications}"
    if ! command -v xcodebuild >/dev/null 2>&1 || ! command -v xcrun >/dev/null 2>&1; then
        echo "Không tìm thấy công cụ Xcode. Cần máy macOS có Xcode 26+ và iOS SDK 26+." >&2
        return 1
    fi

    active_dir="${DEVELOPER_DIR:-}"
    if [[ -z "$active_dir" ]]; then
        active_dir="$(xcode-select --print-path 2>/dev/null)" || active_dir=""
    fi
    if [[ -n "$active_dir" ]] && _denrindz_try_xcode "$active_dir"; then
        return 0
    fi

    for candidate_app in "$applications_dir"/Xcode*.app; do
        [[ -d "$candidate_app/Contents/Developer" ]] || continue
        # Prefer installed releases; use a beta when explicitly selected above.
        case "${candidate_app##*/}" in *[Bb][Ee][Tt][Aa]*) continue ;; esac
        if _denrindz_try_xcode "$candidate_app/Contents/Developer"; then
            return 0
        fi
    done

    echo "Không tìm thấy Xcode 26+ kèm iOS SDK 26+ đã cài trong $applications_dir. Chọn runner GitHub hoặc cấu hình Codemagic có Xcode 26 trở lên." >&2
    return 1
}

denrindz_select_xcode
