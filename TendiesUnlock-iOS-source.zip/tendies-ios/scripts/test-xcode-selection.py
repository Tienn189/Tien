from pathlib import Path
import os, subprocess, tempfile

selector = Path(__file__).resolve().with_name('select-xcode.sh')
build = selector.with_name('build-ipa.sh')

with tempfile.TemporaryDirectory(prefix='denrindz-xcode-selection-') as tmp:
    base = Path(tmp)
    binaries = base / 'bin'
    binaries.mkdir()
    commands = {
        'uname': '#!/bin/bash\nprintf "Darwin\\n"\n',
        'xcode-select': '#!/bin/bash\nprintf "%s\\n" "$DENRINDZ_TEST_ACTIVE_DIR"\n',
        'xcodebuild': '''#!/bin/bash
if [[ "${1:-}" == "-version" ]]; then
    cat "$DEVELOPER_DIR/.test-version"
else
    printf '%s\\n' "$DEVELOPER_DIR" > "$DENRINDZ_TEST_BUILD_TRACE"
    echo STOP_BEFORE_NATIVE_COMPILATION >&2
    exit 73
fi
''',
        'xcrun': '''#!/bin/bash
if [[ -s "$DEVELOPER_DIR/.test-sdk" ]]; then
    cat "$DEVELOPER_DIR/.test-sdk"
else
    exit 1
fi
''',
    }
    for name, text in commands.items():
        path = binaries / name
        path.write_text(text)
        path.chmod(0o755)

    def run_case(name, active, apps, selected, *, explicit=None, integration=False):
        case = base / name
        applications = case / 'Applications'
        applications.mkdir(parents=True)
        def app(label, version, sdk):
            path = applications / label / 'Contents/Developer'
            path.mkdir(parents=True)
            (path / '.test-version').write_text('Xcode ' + version + '\nBuild version TEST\n')
            (path / '.test-sdk').write_text(sdk)
            return path
        active_path = app('Active.app', *active) if active else case / 'CommandLineTools'
        candidates = {label: app(label, version, sdk) for label, version, sdk in apps}
        env = os.environ.copy()
        env.pop('DEVELOPER_DIR', None)
        env.update(PATH=str(binaries) + os.pathsep + env['PATH'],
                   DENRINDZ_TEST_ACTIVE_DIR=str(active_path),
                   DENRINDZ_XCODE_APPLICATIONS_DIR=str(applications),
                   DENRINDZ_TEST_BUILD_TRACE=str(case / 'build-trace'),
                   RUN_IMPORT_TESTS='0')
        if explicit:
            env['DEVELOPER_DIR'] = str(candidates[explicit])
        if integration:
            result = subprocess.run(['bash', str(build)], env=env, text=True, capture_output=True)
            assert result.returncode == 73, (name, result.stdout, result.stderr)
            assert (case / 'build-trace').read_text().strip() == str(candidates[selected])
        else:
            result = subprocess.run(['bash', '-c', 'set -euo pipefail; source "$1"; printf "SELECTED=%s\\n" "$DEVELOPER_DIR"',
                                     'test', str(selector)], env=env, text=True, capture_output=True)
            if selected is None:
                assert result.returncode != 0 and 'Không tìm thấy Xcode 26+' in result.stderr, (name, result.stdout, result.stderr)
            else:
                expected = active_path if selected == 'active' else candidates[selected]
                assert result.returncode == 0 and 'SELECTED=' + str(expected) in result.stdout, (name, result.stdout, result.stderr)
        print('PASS:', name)

    run_case('keep-supported-current', ('26.2', '26.2'), [('Xcode_26.0.app', '26.0', '26.0')], 'active')
    run_case('upgrade-old-current', ('16.4', '18.5'), [('Xcode_16.app', '16.4', '18.5'), ('Xcode_26.1.app', '26.1', '26.1')], 'Xcode_26.1.app')
    run_case('command-line-tools-current', None, [('Xcode.app', '26.0', '26.0')], 'Xcode.app')
    run_case('app-path-with-spaces', ('16.0', '18.0'), [('Xcode 26.2.app', '26.2', '26.2')], 'Xcode 26.2.app')
    run_case('reject-missing-ios-sdk', ('26.0', ''), [('Xcode_26.1.app', '26.1', '26.1')], 'Xcode_26.1.app')
    run_case('no-supported-installation', ('16.4', '18.5'), [('Xcode_25.app', '25.0', '25.0')], None)
    run_case('skip-unselected-beta', ('16.4', '18.5'), [('Xcode-beta.app', '27.0', '27.0'), ('Xcode_26.app', '26.1', '26.1')], 'Xcode_26.app')
    run_case('respect-selected-beta', None, [('Xcode-beta.app', '27.0', '27.0')], 'Xcode-beta.app', explicit='Xcode-beta.app')
    run_case('sdk-version-is-validated', ('26.0', '18.5'), [('Xcode_26.app', '26.1', '26.1')], 'Xcode_26.app')
    run_case('actual-build-script-inherits-sdk', ('16.4', '18.5'), [('Xcode_26.app', '26.1', '26.1')], 'Xcode_26.app', integration=True)
print('10 SDK selection checks passed. Integration stopped before native compilation; no IPA generated.')
