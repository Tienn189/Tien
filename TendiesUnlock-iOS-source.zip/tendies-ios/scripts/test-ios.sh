#!/bin/bash
# Exercise the file reader and decryption engine with Apple's iOS Simulator SDK.
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "Kiểm thử iOS cần macOS và Xcode." >&2
    exit 1
fi
for tool in xcodebuild xcrun python3; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "Thiếu công cụ kiểm thử: $tool" >&2
        exit 1
    fi
done

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
mkdir -p "$BUILD_DIR"

TENDIES_SIMULATOR_ID="${IOS_TEST_SIMULATOR_ID:-}"
if [[ -z "$TENDIES_SIMULATOR_ID" ]]; then
    TENDIES_SIMULATOR_ID="$(python3 - <<'PY'
import json
import re
import subprocess
import sys

sdk = subprocess.check_output(
    ["xcrun", "--sdk", "iphonesimulator", "--show-sdk-version"], text=True
).strip()
sdk_major = int(sdk.split(".")[0])
devices = json.loads(subprocess.check_output(
    ["xcrun", "simctl", "list", "devices", "available", "--json"], text=True
))["devices"]
candidates = []
for runtime, entries in devices.items():
    match = re.search(r"\.iOS-(\d+)(?:-(\d+))?", runtime)
    if not match:
        continue
    version = (int(match[1]), int(match[2] or 0))
    if not 16 <= version[0] <= sdk_major:
        continue
    for device in entries:
        if device.get("isAvailable") and device["name"].startswith("iPhone"):
            candidates.append((version, device["name"], device["udid"]))
if not candidates:
    sys.exit("Không có iPhone Simulator khả dụng cho Xcode đã chọn. Cần cài một iOS runtime tương thích trước khi build IPA.")
print(max(candidates)[2])
PY
)"
fi

TENDIES_RESULT_DIR="$(mktemp -d "$BUILD_DIR/test-results.XXXXXX")"
echo "Chạy XCTest trên iPhone Simulator: $TENDIES_SIMULATOR_ID"
xcodebuild test \
    -project "$PROJECT_DIR/TendiesDecryptor.xcodeproj" \
    -scheme TendiesDecryptor \
    -configuration Debug \
    -destination "platform=iOS Simulator,id=$TENDIES_SIMULATOR_ID" \
    -destination-timeout 180 \
    -parallel-testing-enabled NO \
    -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" \
    -resultBundlePath "$TENDIES_RESULT_DIR/ImportTests.xcresult" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    2>&1 | tee "$BUILD_DIR/import-tests.log"
