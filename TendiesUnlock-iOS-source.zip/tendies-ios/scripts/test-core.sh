#!/bin/bash
# Test the complete core with Apple's SDK, or the portable packager on Linux.
set -euo pipefail

case "$(uname -s)" in
    Darwin)
        if ! command -v xcrun >/dev/null 2>&1 || ! xcrun --find swift >/dev/null 2>&1; then
            echo "Không có Swift của Xcode để chạy kiểm thử." >&2
            exit 1
        fi
        SWIFT_COMMAND=(xcrun swift)
        TEST_BUILD_NAME=CoreTests
        TEST_LOG_NAME=core-tests.log
        ;;
    Linux)
        if ! command -v swift >/dev/null 2>&1; then
            echo "Cần cài Swift để chạy kiểm thử PosterBoard packager trên Linux." >&2
            exit 1
        fi
        echo "Linux: chỉ chạy kiểm thử PosterBoard packager. Bộ đọc file và giải mã vẫn cần macOS/Apple SDK."
        SWIFT_COMMAND=(swift)
        TEST_BUILD_NAME=PackagerTests
        TEST_LOG_NAME=packager-tests.log
        ;;
    *)
        echo "Kiểm thử cần macOS với Xcode hoặc Linux với Swift." >&2
        exit 1
        ;;
esac

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
mkdir -p "$BUILD_DIR"
"${SWIFT_COMMAND[@]}" test \
    --package-path "$PROJECT_DIR" \
    --scratch-path "$BUILD_DIR/$TEST_BUILD_NAME" \
    2>&1 | tee "$BUILD_DIR/$TEST_LOG_NAME"
