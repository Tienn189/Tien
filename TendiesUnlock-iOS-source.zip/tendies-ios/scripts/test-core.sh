#!/bin/bash
# Test the app's real Foundation/CryptoKit engine using the host Apple SDK.
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "Kiểm thử bộ đọc file cần macOS và Apple SDK (NSFileCoordinator/CryptoKit)." >&2
    exit 1
fi
if ! command -v xcrun >/dev/null 2>&1 || ! xcrun --find swift >/dev/null 2>&1; then
    echo "Không có Swift của Xcode để chạy kiểm thử." >&2
    exit 1
fi

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
mkdir -p "$BUILD_DIR"
xcrun swift test \
    --package-path "$PROJECT_DIR" \
    --scratch-path "$BUILD_DIR/CoreTests" \
    2>&1 | tee "$BUILD_DIR/core-tests.log"
