#!/bin/bash
# Test the complete core with Apple's SDK, or the portable packager on Linux.
set -euo pipefail

case "$(uname -s)" in
    Darwin)
        if ! command -v xcrun >/dev/null 2>&1 || ! xcrun --find swift >/dev/null 2>&1; then
            echo "Không có Swift của Xcode để chạy kiểm thử." >&2
            exit 1
        fi
        SWIFT_COMMAND=(xcrun swift)
        TEST_BUILD_NAME=CoreTests
        TEST_LOG_NAME=core-tests.log
        ;;
    Linux)
        if ! command -v swift >/dev/null 2>&1; then
            echo "Cần cài Swift để chạy kiểm thử PosterBoard packager trên Linux." >&2
            exit 1
        fi
        echo "Linux: chỉ chạy kiểm thử PosterBoard packager. Bộ đọc file và giải mã vẫn cần macOS/Apple SDK."
        SWIFT_COMMAND=(swift)
        TEST_BUILD_NAME=PackagerTests
        TEST_LOG_NAME=packager-tests.log
        ;;
    *)
        echo "Kiểm thử cần macOS với Xcode hoặc Linux với Swift." >&2
        exit 1
        ;;
esac

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
mkdir -p "$BUILD_DIR"
TEST_LOG_PATH="$BUILD_DIR/$TEST_LOG_NAME"
if "${SWIFT_COMMAND[@]}" test \
    --package-path "$PROJECT_DIR" \
    --scratch-path "$BUILD_DIR/$TEST_BUILD_NAME" \
    2>&1 | tee "$TEST_LOG_PATH"; then
    exit 0
else
    TEST_EXIT_STATUS=$?
fi

# Keep the failing exit status, including failures from tee under pipefail.
# Repeat the first useful diagnostics after XCTest's long suite summary so
# they remain visible near the bottom of an Actions log on a phone.
printf '\n%s\n' "Các lỗi kiểm thử đầu tiên (tối đa 30 dòng):" >&2
if [[ -f "$TEST_LOG_PATH" ]]; then
    awk '/error:|threw error:|XCTAssert|Test Case .*failed/ { if (++shown <= 30) print }' "$TEST_LOG_PATH" >&2 || true
fi
printf '%s\n' "Toàn bộ log: $TEST_LOG_PATH" >&2

# Workflow command data must be escaped before printing test-controlled text.
# Keep percent first so the CR/LF escapes introduced below are not escaped twice.
escape_workflow_data() {
    local value="$1"
    value="${value//%/%25}"
    value="${value//$'\r'/%0D}"
    value="${value//$'\n'/%0A}"
    printf '%s' "$value"
}

escape_summary_html() {
    local value="$1"
    value="${value//&/\&amp;}"
    value="${value//</\&lt;}"
    value="${value//>/\&gt;}"
    printf '%s' "$value"
}

TEST_DIAGNOSTICS=""
if [[ -f "$TEST_LOG_PATH" ]]; then
    TEST_DIAGNOSTICS="$(awk '/error:|threw error:|XCTAssert|Test Case .*failed/ { if (++shown <= 10) print }' "$TEST_LOG_PATH" || true)"
fi
if [[ "${GITHUB_ACTIONS:-}" == "true" ]]; then
    if [[ -n "$TEST_DIAGNOSTICS" ]]; then
        while IFS= read -r diagnostic; do
            printf '::error title=Core test failure::%s\n' "$(escape_workflow_data "$diagnostic")" >&2
        done <<< "$TEST_DIAGNOSTICS"
    else
        printf '%s\n' '::error::Kiểm thử core thất bại. Không tìm thấy dòng XCTest lỗi; xem toàn bộ log theo đường dẫn phía trên.' >&2
    fi
fi
if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
    # HTML escaping keeps arbitrary test output inside the preformatted block.
    # Reporting errors must never replace the test/tee pipeline's exit status.
    {
        printf '%s\n\n' '### Kiểm thử core thất bại'
        printf '%s\n' '<pre>'
        if [[ -n "$TEST_DIAGNOSTICS" ]]; then
            escape_summary_html "$TEST_DIAGNOSTICS"
            printf '\n'
        else
            printf '%s\n' 'Không tìm thấy dòng XCTest lỗi trong log.'
        fi
        printf '%s\n\n' '</pre>'
        printf 'Toàn bộ log: <code>%s</code>\n' "$(escape_summary_html "$TEST_LOG_PATH")"
    } >> "$GITHUB_STEP_SUMMARY" || printf '%s\n' 'Không ghi được phần tổng kết; mã lỗi kiểm thử được giữ nguyên.' >&2
fi
exit "$TEST_EXIT_STATUS"
