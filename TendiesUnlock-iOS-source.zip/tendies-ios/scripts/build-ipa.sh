#!/bin/bash
# Build and package an unsigned IPA using Apple's local iOS SDK.
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "Cần macOS và Xcode để build IPA. Script này không chạy được trên Linux/Windows." >&2
    exit 1
fi
if ! command -v xcodebuild >/dev/null 2>&1 || ! xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
    echo "Chưa có iOS SDK. Cài Xcode, mở Xcode một lần và chọn Xcode trong Settings > Locations > Command Line Tools." >&2
    exit 1
fi

# Match the SDK used by the supplied 1809 reference so iOS 26 applies its
# native Liquid Glass navigation, tab bar and document-picker appearance.
XCODE_VERSION="$(xcodebuild -version)"
if [[ ! "$XCODE_VERSION" =~ ^Xcode[[:space:]]+([0-9]+) ]] || (( BASH_REMATCH[1] < 26 )); then
    echo "Denrindz cần Xcode 26 trở lên để build giao diện hệ thống như app 1809. Chọn Xcode 26+ trong cấu hình Codemagic/Xcode rồi build lại." >&2
    exit 1
fi
echo "$XCODE_VERSION"

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
DERIVED_DATA="$BUILD_DIR/DerivedData"
if [[ "${RUN_IMPORT_TESTS:-1}" != "0" ]]; then
    # Exercise the same reader and CryptoKit engine on the host Apple SDK.
    # This does not depend on a Simulator runtime being installed on the runner.
    # CI workflows that have already tested this suite can set RUN_IMPORT_TESTS=0.
    bash "$PROJECT_DIR/scripts/test-core.sh"
fi
STAGING_DIR="$(mktemp -d "${TMPDIR:-/tmp}/tendies-ipa.XXXXXX")"
trap 'rm -rf "$STAGING_DIR"' EXIT
mkdir -p "$BUILD_DIR" "$STAGING_DIR/Payload"

xcodebuild \
    -project "$PROJECT_DIR/TendiesDecryptor.xcodeproj" \
    -scheme TendiesDecryptor \
    -configuration Release \
    -sdk iphoneos \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$DERIVED_DATA" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    build

APP_PATH="$DERIVED_DATA/Build/Products/Release-iphoneos/TendiesDecryptor.app"
if [[ ! -d "$APP_PATH" ]]; then
    echo "Không tìm thấy app sau khi build: $APP_PATH" >&2
    exit 1
fi
/usr/bin/ditto "$APP_PATH" "$STAGING_DIR/Payload/TendiesDecryptor.app"
IPA_PATH="$BUILD_DIR/TendiesUnlock-unsigned.ipa"
(cd "$STAGING_DIR" && /usr/bin/ditto -c -k --keepParent Payload "$IPA_PATH")
echo "Đã tạo: $IPA_PATH"
echo "Đây là IPA CHƯA KÝ. Cần ký bằng tài khoản/chứng chỉ của bạn trước khi cài lên iPhone."
