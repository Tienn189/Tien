// swift-tools-version: 5.9
import PackageDescription

// Apple hosts exercise the app's complete Foundation/CryptoKit core. Linux
// exercises only the portable PosterBoard packager, which uses Foundation + ZIPFoundation.
// SwiftUI/UIKit remain in the Xcode app target.
let appleCoreSources = ["WalliveDecryptor.swift", "DocumentReader.swift", "DirectoryReader.swift", "FilePickerTypes.swift"]
let appOnlyFiles = ["ContentView.swift", "FolderImportView.swift", "PosterBoardExportView.swift", "TendiesDecryptorApp.swift", "Assets.xcassets", "Info.plist", "ZIPFoundation-LICENSE.txt"]

#if os(Linux)
let coreSources = ["PosterBoardPackager.swift"]
let coreExcludes = appOnlyFiles + appleCoreSources
let testExcludes = ["WalliveDecryptorTests.swift", "DocumentReaderTests.swift", "DirectoryReaderTests.swift", "FilePickerTypesTests.swift"]
let testSources: [String]? = ["PosterBoardPackagerTests.swift"]
#else
let coreSources = appleCoreSources + ["PosterBoardPackager.swift"]
let coreExcludes = appOnlyFiles
let testExcludes: [String] = []
let testSources: [String]? = nil
#endif

let package = Package(
    name: "TendiesDecryptorCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "TendiesDecryptor", targets: ["TendiesDecryptor"])],
    dependencies: [
        .package(url: "https://github.com/weichsel/ZIPFoundation", exact: "0.9.20")
    ],
    targets: [
        .target(
            name: "TendiesDecryptor",
            dependencies: [.product(name: "ZIPFoundation", package: "ZIPFoundation")],
            path: "TendiesDecryptor",
            exclude: coreExcludes,
            sources: coreSources
        ),
        .testTarget(
            name: "TendiesDecryptorTests",
            dependencies: ["TendiesDecryptor", .product(name: "ZIPFoundation", package: "ZIPFoundation")],
            path: "Tests",
            exclude: testExcludes,
            sources: testSources
        )
    ]
)
