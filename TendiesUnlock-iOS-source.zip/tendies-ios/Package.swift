// swift-tools-version: 5.9
import PackageDescription

// Exercise the same Foundation/CryptoKit source used by the iPhone app.
// SwiftUI/UIKit remain in the Xcode app target, which is built for iOS separately.
let package = Package(
    name: "TendiesDecryptorCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "TendiesDecryptor", targets: ["TendiesDecryptor"])],
    targets: [
        .target(
            name: "TendiesDecryptor",
            path: "TendiesDecryptor",
            exclude: ["ContentView.swift", "TendiesDecryptorApp.swift", "Assets.xcassets", "Info.plist"],
            sources: ["WalliveDecryptor.swift", "DocumentReader.swift"]
        ),
        .testTarget(
            name: "TendiesDecryptorTests",
            dependencies: ["TendiesDecryptor"],
            path: "Tests"
        )
    ]
)
