# 1.2.4 (build 13)

- Đối chiếu trực tiếp source 1809 3.5.0 (19) từ link GitHub người dùng gửi. Chuyển tab, điều hướng và bảng nhập file sang thành phần hệ thống giống cách source mẫu dựng giao diện.
- Dùng cùng nền sáng/tối, sáu mã màu, khoảng cách và góc bo trong trang Giao diện. Cài đặt dùng List nhóm; tiêu đề lớn, nút quay lại và thanh tab do iOS quản lý.
- Bỏ lớp nền kính, nút quay lại và thanh tab tự vẽ. Cả hai bộ chọn dùng sheet mặc định, để iOS quản lý hình dạng và tiêu đề vị trí.
- Cài mới/khôi phục dùng Theo hệ thống + Đại dương. Giữ các khóa tùy chọn đã lưu và icon người dùng gửi.
- Yêu cầu Xcode 26+ như source mẫu; thêm kiểm tra SDK trong build script/workflow. Core, model tác vụ, kiểm thử và đường dẫn IPA giữ nguyên.

# 1.2.3 (build 12)

- Dùng ảnh đại diện do người dùng gửi cho AppIcon và BrandMark; giữ trọn nội dung ảnh, chuẩn hóa PNG RGB 1024 px.
- Đưa Cài đặt xuống thanh tab dưới cùng, cùng tab Nhập file. Dùng TabView Liquid Glass hệ thống trên iOS 26 và thanh kính nổi trên iOS cũ.
- Bỏ nút thông tin và bánh răng ở góc trên. Chuyển hướng dẫn, thông tin và phiên bản vào tab Cài đặt; trang Giao diện mở trong tab này.
- Chuyển cả hai bộ chọn tendies/zip từ toàn màn hình sang bảng Tệp nổi bo tròn, có thể vuốt đóng. Giữ bộ chọn Tệp gốc của iOS, chế độ import và delegate đọc file.
- Giữ model tác vụ ở màn hình gốc để chuyển tab không hủy xử lý. Ghi nhận hủy bộ chọn khi vuốt đóng bảng tendies. Core, test, script và workflow giữ nguyên.

# 1.2.2 (build 11)

- Đổi icon thành **ổ khoá bị bẻ gãy càng**, thân kính xanh và càng kim loại. Thay cả AppIcon và BrandMark.
- Đổi màn hình chính và kết quả sang thẻ kính, nền xanh tím nhẹ, nút nổi, viền phản sáng và hiệu ứng nhấn nhẹ. Giữ đúng hai dòng nhập tendies/zip.
- Dựng lại trang Giao diện theo ảnh tham khảo: nút quay lại tròn, thẻ xem trước, ba hàng chế độ hiển thị, sáu ô màu nhấn, chọn màu riêng và nút khôi phục.
- Dùng Liquid Glass gốc với Xcode 26 + iOS 26; có lớp kính material cho Xcode/iOS cũ. Hỗ trợ Giảm độ trong suốt, Giảm chuyển động và lưới màu hai cột ở cỡ chữ Trợ năng.
- Giữ nguyên core, model xử lý tác vụ, delegate chọn file, kiểm thử và script/workflow build.

# 1.2.1 (build 10)

- Đổi tên hiển thị ứng dụng thành **Denrindz**, dùng icon móc khoá bị gãy và cùng biểu tượng trên thẻ giới thiệu.
- Đổi màn hình chính sang nền xám tím nhạt, thẻ trắng bo tròn và màu nhấn xanh dương theo ảnh tham khảo.
- Chỉ giữ hai dòng **Nhập file tendies** và **Nhập file zip**, bỏ các nút chọn thư mục và dòng phụ trên màn hình ban đầu. Tiến trình, lỗi và kết quả xuất hiện sau thao tác.
- Cài mới hoặc đặt lại giao diện dùng Sáng + Xanh dương; giữ các lựa chọn đã lưu khi cập nhật. Giữ nguyên bộ giải mã, bộ đóng gói, đọc file và các script build.

# 1.2.0 (build 9)

- Đổi màn hình chính sang Form theo giao diện iOS: nền/chữ trắng đen, nhóm hàng hệ thống, thanh tiêu đề và nút Cài đặt.
- Đưa toàn bộ luồng đóng gói .tendies lên màn hình chính: chọn ZIP/thư mục, tiến trình, hủy, lỗi, thử lại, kết quả và chia sẻ. Bỏ màn hình đóng gói riêng.
- Thêm chế độ Hệ thống/Sáng/Tối, năm màu chủ đề, màu Trắng đen và bộ chọn màu tùy chỉnh. Lưu lựa chọn bằng UserDefaults và có nút đặt lại.
- Dùng màu ngữ nghĩa của iOS, giữ chữ/nút quan trọng dễ đọc kể cả với màu tùy chỉnh rất sáng hoặc tối. Bộ duyệt thư mục theo cùng chủ đề.
- Giữ nguyên bộ giải mã, bộ đóng gói và logic quản lý tác vụ của bản 1.1.2 đã được người dùng xác nhận build thành công.

# 1.1.2 (build 8)

- Sửa dung lượng ZIP bị đọc từ bộ nhớ đệm metadata URL trên Apple. Bộ đóng gói đọc kích thước hiện tại qua file handle khi kiểm tra giới hạn và báo dung lượng kết quả, thay vì giữ kích thước sau mục ZIP đầu tiên.
- Giữ nguyên kiểm thử đã phát hiện `archiveBytes` là 307 trong khi file thực tế là 6.398 byte. Thêm kiểm thử cùng URL sau khi file tăng/giảm dung lượng và đối chiếu dung lượng ZIP thực tế trong test `gm.zip`.
- Đưa nguyên văn các dòng lỗi XCTest vào Annotations và tổng kết Actions để có thể đọc đúng nguyên nhân nếu test thất bại. Giữ nguyên điều kiện test phải đạt trước khi build IPA.
- Đã chạy 21 test đóng gói trên Linux, gồm ZIP thực tế: 21 đạt, 0 lỗi. Cần chạy lại workflow để xác minh bản mới bằng Apple SDK.

# 1.1.1 (build 7)

- Sửa kiểm tra đường dẫn của bộ đóng gói trên Apple: `/var/...` và `/private/var/...` được nhận diện là cùng một vị trí. Bản trước có thể từ chối nhầm cả bản xuất và thư mục tạm, khiến các test đóng gói trên macOS lỗi.
- Chuẩn hóa thư mục gốc và phần thư mục cha của từng mục trước khi kiểm tra vị trí; vẫn phát hiện và từ chối file/thư mục symlink trong dữ liệu hình nền.
- Thêm ba kiểm thử cho đường dẫn tương đương, đóng gói qua đường dẫn có thư mục cha tương đương, và symlink trỏ ra ngoài cấu hình. 20 test đóng gói đạt trên Linux, gồm ZIP thực tế; cần chạy lại Actions để xác minh trên macOS.
- Khi test core lỗi, script build in lại các dòng lỗi cụ thể và giữ nguyên mã thoát thất bại, giúp đọc nguyên nhân trên giao diện Actions.

# 1.1.0 (build 6)

- Thêm **Đóng gói lại .tendies**: chọn ZIP/thư mục PosterBoard đã giải mã sẵn, tự tìm cấu hình và xuất gói `descriptors/<UUID>/...`.
- Giữ nguyên phiên bản, CAML, ảnh và metadata; kiểm tra tài nguyên được tham chiếu trước khi xuất. Chỉ bỏ scratch, RuntimeSnapshot và rác Finder trong bản sao làm việc.
- Đọc/ghi ZIP theo khối bằng ZIPFoundation 0.9.20, có giới hạn dung lượng và kiểm tra đường dẫn, liên kết, trùng tên, CRC.
- Thêm tiến trình, hủy, thử lại, lưu/chia sẻ và giữ kết quả khi đóng màn hình. Dữ liệu gốc được giữ nguyên.
- Tích hợp kiểm thử đóng gói vào SwiftPM, Xcode và workflow build IPA. Xem `VALIDATION.vi.md` để biết kiểm tra đã chạy và phần còn cần Apple SDK.

Luồng này nhận dữ liệu đã được ứng dụng gốc giải mã và xuất ra; không bổ sung khoá hay cơ chế giải mã WALLIVE2.

# 1.0.4 (build 5)

- Nút **Nhập .tendies mã hóa** dùng chế độ import của hệ thống, không yêu cầu provider hỗ trợ mở file tại chỗ. Không có thao tác sao chép hay đổi đuôi thủ công.
- Đọc byte thô trước, nhận diện WALLIVE1 và xác thực AES-GCM sau; file mã hóa không phải ZIP vẫn được đưa đến bộ giải mã. ZIP đã giải mã cũng có thể xuất lại.
- Yêu cầu tải iCloud là best effort; lỗi ở bước gợi ý này không chặn bước đọc phối hợp. Metadata chưa đầy đủ không tự động khiến file bị từ chối.
- Danh sách thư mục giữ các mục khả dụng khi một file lỗi metadata, hiển thị đuôi chưa biết và placeholder iCloud theo tên logic, tránh trùng với file đã tải xong.
- Hiển thị phiên bản/build ở màn hình chính và bước nhập gần nhất trong Thông tin để phân biệt lỗi trước/sau khi nhận URL.
- Thêm fixture WALLIVE1 độc lập và test tích hợp đọc file mã hóa → giải mã → xuất ZIP, cùng các kiểm thử lỗi metadata/placeholder.

Đã kiểm tra cú pháp và cấu trúc project ở môi trường tạo source. XCTest thực tế chạy trên macOS trong bước build; native Files/iCloud vẫn cần được xác minh trên thiết bị.

# 1.0.3 (build 4)

- Sửa tập kiểu nội dung của bộ chọn file: khai báo rõ `.tendies`/`.wallive`, kiểu nhận diện từ phần mở rộng và các kiểu dữ liệu chung, thay vì chỉ dựa vào một kiểu gốc.
- Thêm **Chọn từ thư mục**: cấp quyền cho thư mục rồi chọn file trong danh sách của app. Danh sách này không phụ thuộc bộ lọc UTI theo từng file của trình chọn hệ thống, giúp nhập file bị làm mờ trong bộ chọn trực tiếp mà không đổi đuôi hay sao chép thủ công.
- Giữ quyền truy cập thư mục trong suốt thao tác liệt kê và đọc file con. Bộ đọc dùng `NSFileCoordinator`, thời gian chờ, hủy và thử lại.
- Thêm kiểm thử danh sách thư mục và chính sách kiểu file vào cả Xcode project lẫn SwiftPM. Giữ kiểm thử tự động trước khi tạo IPA.

Chưa thể xác nhận mọi nhà cung cấp file đều hiển thị `.tendies` có thể chọn trong bộ chọn hệ thống. Bản này cung cấp đường chọn thư mục trong app để tránh phụ thuộc bộ lọc đó. Vẫn cần build bằng Apple SDK và thử trên thiết bị để xác nhận UI/provider thực tế.

# 1.0.2 (build 3)

- Nhập trực tiếp bằng `UIDocumentPickerViewController` ở chế độ mở tại chỗ (`asCopy: false`), chọn từng file. Ứng dụng không chờ bộ chọn tạo bản sao và không yêu cầu người dùng di chuyển file.
- Giữ quyền truy cập file ngay trong callback chọn file, trước khi đóng bộ chọn. Quyền truy cập được giữ đến khi công việc đọc thật sự kết thúc.
- Dùng `NSFileCoordinator` trong luồng nền để đọc URL của nhà cung cấp file; tự yêu cầu dữ liệu iCloud khi cần.
- Hiển thị giai đoạn đọc/tải/giải mã. Có hủy, thời gian chờ và thử lại, để lỗi truy cập dữ liệu được báo trong app.
- Bỏ khai báo MIME chung `application/octet-stream` cho kiểu file riêng; bộ giải mã tiếp tục xác thực header và AES-GCM.
- Thêm kiểm thử cho bộ đọc file. Script build ZIP chạy XCTest bằng SwiftPM với Apple SDK trên macOS trước khi biên dịch app iOS và tạo IPA, không phụ thuộc simulator. Có thể chạy cùng bộ test bằng iPhone Simulator qua `scripts/test-ios.sh`; workflow đã test riêng có thể dùng `RUN_IMPORT_TESTS=0` để tránh trùng lặp.

Đã kiểm tra cú pháp và cấu trúc project trong môi trường tạo source. Môi trường này là Linux, không có Xcode/iOS SDK để chạy XCTest hoặc thử bộ chọn iCloud. Build trên Codemagic/GitHub và kiểm tra trên iPhone sẽ xác nhận phần nhập file thực tế.

Nếu nhà cung cấp file không cung cấp được dữ liệu, ứng dụng hiển thị lỗi để thử lại. Bản sửa không thể phục hồi dữ liệu không còn tồn tại hoặc tự khôi phục kết nối của dịch vụ lưu trữ.
