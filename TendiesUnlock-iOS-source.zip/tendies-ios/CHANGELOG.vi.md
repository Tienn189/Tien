# 1.0.2 (build 3)

- Nhập trực tiếp bằng `UIDocumentPickerViewController` ở chế độ mở tại chỗ (`asCopy: false`), chọn từng file. Ứng dụng không chờ bộ chọn tạo bản sao và không yêu cầu người dùng di chuyển file.
- Giữ quyền truy cập file ngay trong callback chọn file, trước khi đóng bộ chọn. Quyền truy cập được giữ đến khi công việc đọc thật sự kết thúc.
- Dùng `NSFileCoordinator` trong luồng nền để đọc URL của nhà cung cấp file; tự yêu cầu dữ liệu iCloud khi cần.
- Hiển thị giai đoạn đọc/tải/giải mã. Có hủy, thời gian chờ và thử lại, để lỗi truy cập dữ liệu được báo trong app.
- Bỏ khai báo MIME chung `application/octet-stream` cho kiểu file riêng; bộ giải mã tiếp tục xác thực header và AES-GCM.
- Thêm kiểm thử cho bộ đọc file. Script build ZIP chạy XCTest bằng SwiftPM với Apple SDK trên macOS trước khi biên dịch app iOS và tạo IPA, không phụ thuộc simulator. Có thể chạy cùng bộ test bằng iPhone Simulator qua `scripts/test-ios.sh`; workflow đã test riêng có thể dùng `RUN_IMPORT_TESTS=0` để tránh trùng lặp.

Đã kiểm tra cú pháp và cấu trúc project trong môi trường tạo source. Môi trường này là Linux, không có Xcode/iOS SDK để chạy XCTest hoặc thử bộ chọn iCloud. Build trên Codemagic/GitHub và kiểm tra trên iPhone sẽ xác nhận phần nhập file thực tế.

Nếu nhà cung cấp file không cung cấp được dữ liệu, ứng dụng hiển thị lỗi để thử lại. Bản sửa không thể phục hồi dữ liệu không còn tồn tại hoặc tự khôi phục kết nối của dịch vụ lưu trữ.
