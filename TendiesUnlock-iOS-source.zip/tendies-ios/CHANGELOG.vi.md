# 1.1.2 (build 8)

- Sửa dung lượng ZIP bị đọc từ bộ nhớ đệm metadata URL trên Apple. Bộ đóng gói đọc kích thước hiện tại qua file handle khi kiểm tra giới hạn và báo dung lượng kết quả, thay vì giữ kích thước sau mục ZIP đầu tiên.
- Giữ nguyên kiểm thử đã phát hiện `archiveBytes` là 307 trong khi file thực tế là 6.398 byte. Thêm kiểm thử cùng URL sau khi file tăng/giảm dung lượng và đối chiếu dung lượng ZIP thực tế trong test `gm.zip`.
- Đưa nguyên văn các dòng lỗi XCTest vào Annotations và tổng kết Actions để có thể đọc đúng nguyên nhân nếu test thất bại. Giữ nguyên điều kiện test phải đạt trước khi build IPA.
- Đã chạy 21 test đóng gói trên Linux, gồm ZIP thực tế: 21 đạt, 0 lỗi. Cần chạy lại workflow để xác minh bản mới bằng Apple SDK.

# 1.1.1 (build 7)

- Sửa kiểm tra đường dẫn của bộ đóng gói trên Apple: `/var/...` và `/private/var/...` được nhận diện là cùng một vị trí. Bản trước có thể từ chối nhầm cả bản xuất và thư mục tạm, khiến các test đóng gói trên macOS lỗi.
- Chuẩn hóa thư mục gốc và phần thư mục cha của từng mục trước khi kiểm tra vị trí; vẫn phát hiện và từ chối file/thư mục symlink trong dữ liệu hình nền.
- Thêm ba kiểm thử cho đường dẫn tương đương, đóng gói qua đường dẫn có thư mục cha tương đương, và symlink trỏ ra ngoài cấu hình. 20 test đóng gói đạt trên Linux, gồm ZIP thực tế; cần chạy lại Actions để xác minh trên macOS.
- Khi test core lỗi, script build in lại các dòng lỗi cụ thể và giữ nguyên mã thoát thất bại, giúp đọc nguyên nhân trên giao diện Actions.

# 1.1.0 (build 6)

- Thêm **Đóng gói lại .tendies**: chọn ZIP/thư mục PosterBoard đã giải mã sẵn, tự tìm cấu hình và xuất gói `descriptors/<UUID>/...`.
- Giữ nguyên phiên bản, CAML, ảnh và metadata; kiểm tra tài nguyên được tham chiếu trước khi xuất. Chỉ bỏ scratch, RuntimeSnapshot và rác Finder trong bản sao làm việc.
- Đọc/ghi ZIP theo khối bằng ZIPFoundation 0.9.20, có giới hạn dung lượng và kiểm tra đường dẫn, liên kết, trùng tên, CRC.
- Thêm tiến trình, hủy, thử lại, lưu/chia sẻ và giữ kết quả khi đóng màn hình. Dữ liệu gốc được giữ nguyên.
- Tích hợp kiểm thử đóng gói vào SwiftPM, Xcode và workflow build IPA. Xem `VALIDATION.vi.md` để biết kiểm tra đã chạy và phần còn cần Apple SDK.

Luồng này nhận dữ liệu đã được ứng dụng gốc giải mã và xuất ra; không bổ sung khoá hay cơ chế giải mã WALLIVE2.

# 1.0.4 (build 5)

- Nút **Nhập .tendies mã hóa** dùng chế độ import của hệ thống, không yêu cầu provider hỗ trợ mở file tại chỗ. Không có thao tác sao chép hay đổi đuôi thủ công.
- Đọc byte thô trước, nhận diện WALLIVE1 và xác thực AES-GCM sau; file mã hóa không phải ZIP vẫn được đưa đến bộ giải mã. ZIP đã giải mã cũng có thể xuất lại.
- Yêu cầu tải iCloud là best effort; lỗi ở bước gợi ý này không chặn bước đọc phối hợp. Metadata chưa đầy đủ không tự động khiến file bị từ chối.
- Danh sách thư mục giữ các mục khả dụng khi một file lỗi metadata, hiển thị đuôi chưa biết và placeholder iCloud theo tên logic, tránh trùng với file đã tải xong.
- Hiển thị phiên bản/build ở màn hình chính và bước nhập gần nhất trong Thông tin để phân biệt lỗi trước/sau khi nhận URL.
- Thêm fixture WALLIVE1 độc lập và test tích hợp đọc file mã hóa → giải mã → xuất ZIP, cùng các kiểm thử lỗi metadata/placeholder.

Đã kiểm tra cú pháp và cấu trúc project ở môi trường tạo source. XCTest thực tế chạy trên macOS trong bước build; native Files/iCloud vẫn cần được xác minh trên thiết bị.

# 1.0.3 (build 4)

- Sửa tập kiểu nội dung của bộ chọn file: khai báo rõ `.tendies`/`.wallive`, kiểu nhận diện từ phần mở rộng và các kiểu dữ liệu chung, thay vì chỉ dựa vào một kiểu gốc.
- Thêm **Chọn từ thư mục**: cấp quyền cho thư mục rồi chọn file trong danh sách của app. Danh sách này không phụ thuộc bộ lọc UTI theo từng file của trình chọn hệ thống, giúp nhập file bị làm mờ trong bộ chọn trực tiếp mà không đổi đuôi hay sao chép thủ công.
- Giữ quyền truy cập thư mục trong suốt thao tác liệt kê và đọc file con. Bộ đọc dùng `NSFileCoordinator`, thời gian chờ, hủy và thử lại.
- Thêm kiểm thử danh sách thư mục và chính sách kiểu file vào cả Xcode project lẫn SwiftPM. Giữ kiểm thử tự động trước khi tạo IPA.

Chưa thể xác nhận mọi nhà cung cấp file đều hiển thị `.tendies` có thể chọn trong bộ chọn hệ thống. Bản này cung cấp đường chọn thư mục trong app để tránh phụ thuộc bộ lọc đó. Vẫn cần build bằng Apple SDK và thử trên thiết bị để xác nhận UI/provider thực tế.

# 1.0.2 (build 3)

- Nhập trực tiếp bằng `UIDocumentPickerViewController` ở chế độ mở tại chỗ (`asCopy: false`), chọn từng file. Ứng dụng không chờ bộ chọn tạo bản sao và không yêu cầu người dùng di chuyển file.
- Giữ quyền truy cập file ngay trong callback chọn file, trước khi đóng bộ chọn. Quyền truy cập được giữ đến khi công việc đọc thật sự kết thúc.
- Dùng `NSFileCoordinator` trong luồng nền để đọc URL của nhà cung cấp file; tự yêu cầu dữ liệu iCloud khi cần.
- Hiển thị giai đoạn đọc/tải/giải mã. Có hủy, thời gian chờ và thử lại, để lỗi truy cập dữ liệu được báo trong app.
- Bỏ khai báo MIME chung `application/octet-stream` cho kiểu file riêng; bộ giải mã tiếp tục xác thực header và AES-GCM.
- Thêm kiểm thử cho bộ đọc file. Script build ZIP chạy XCTest bằng SwiftPM với Apple SDK trên macOS trước khi biên dịch app iOS và tạo IPA, không phụ thuộc simulator. Có thể chạy cùng bộ test bằng iPhone Simulator qua `scripts/test-ios.sh`; workflow đã test riêng có thể dùng `RUN_IMPORT_TESTS=0` để tránh trùng lặp.

Đã kiểm tra cú pháp và cấu trúc project trong môi trường tạo source. Môi trường này là Linux, không có Xcode/iOS SDK để chạy XCTest hoặc thử bộ chọn iCloud. Build trên Codemagic/GitHub và kiểm tra trên iPhone sẽ xác nhận phần nhập file thực tế.

Nếu nhà cung cấp file không cung cấp được dữ liệu, ứng dụng hiển thị lỗi để thử lại. Bản sửa không thể phục hồi dữ liệu không còn tồn tại hoặc tự khôi phục kết nối của dịch vụ lưu trữ.
