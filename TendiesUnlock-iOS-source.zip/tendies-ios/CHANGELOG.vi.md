# 1.0.4 (build 5)

- Nút **Nhập .tendies mã hóa** dùng chế độ import của hệ thống, không yêu cầu provider hỗ trợ mở file tại chỗ. Không có thao tác sao chép hay đổi đuôi thủ công.
- Đọc byte thô trước, nhận diện WALLIVE1 và xác thực AES-GCM sau; file mã hóa không phải ZIP vẫn được đưa đến bộ giải mã. ZIP đã giải mã cũng có thể xuất lại.
- Yêu cầu tải iCloud là best effort; lỗi ở bước gợi ý này không chặn bước đọc phối hợp. Metadata chưa đầy đủ không tự động khiến file bị từ chối.
- Danh sách thư mục giữ các mục khả dụng khi một file lỗi metadata, hiển thị đuôi chưa biết và placeholder iCloud theo tên logic, tránh trùng với file đã tải xong.
- Hiển thị phiên bản/build ở màn hình chính và bước nhập gần nhất trong Thông tin để phân biệt lỗi trước/sau khi nhận URL.
- Thêm fixture WALLIVE1 độc lập và test tích hợp đọc file mã hóa → giải mã → xuất ZIP, cùng các kiểm thử lỗi metadata/placeholder.

Đã kiểm tra cú pháp và cấu trúc project ở môi trường tạo source. XCTest thực tế chạy trên macOS trong bước build; native Files/iCloud vẫn cần được xác minh trên thiết bị.

# 1.0.3 (build 4)

- Sửa tập kiểu nội dung của bộ chọn file: khai báo rõ `.tendies`/`.wallive`, kiểu nhận diện từ phần mở rộng và các kiểu dữ liệu chung, thay vì chỉ dựa vào một kiểu gốc.
- Thêm **Chọn từ thư mục**: cấp quyền cho thư mục rồi chọn file trong danh sách của app. Danh sách này không phụ thuộc bộ lọc UTI theo từng file của trình chọn hệ thống, giúp nhập file bị làm mờ trong bộ chọn trực tiếp mà không đổi đuôi hay sao chép thủ công.
- Giữ quyền truy cập thư mục trong suốt thao tác liệt kê và đọc file con. Bộ đọc dùng `NSFileCoordinator`, thời gian chờ, hủy và thử lại.
- Thêm kiểm thử danh sách thư mục và chính sách kiểu file vào cả Xcode project lẫn SwiftPM. Giữ kiểm thử tự động trước khi tạo IPA.

Chưa thể xác nhận mọi nhà cung cấp file đều hiển thị `.tendies` có thể chọn trong bộ chọn hệ thống. Bản này cung cấp đường chọn thư mục trong app để tránh phụ thuộc bộ lọc đó. Vẫn cần build bằng Apple SDK và thử trên thiết bị để xác nhận UI/provider thực tế.

# 1.0.2 (build 3)

- Nhập trực tiếp bằng `UIDocumentPickerViewController` ở chế độ mở tại chỗ (`asCopy: false`), chọn từng file. Ứng dụng không chờ bộ chọn tạo bản sao và không yêu cầu người dùng di chuyển file.
- Giữ quyền truy cập file ngay trong callback chọn file, trước khi đóng bộ chọn. Quyền truy cập được giữ đến khi công việc đọc thật sự kết thúc.
- Dùng `NSFileCoordinator` trong luồng nền để đọc URL của nhà cung cấp file; tự yêu cầu dữ liệu iCloud khi cần.
- Hiển thị giai đoạn đọc/tải/giải mã. Có hủy, thời gian chờ và thử lại, để lỗi truy cập dữ liệu được báo trong app.
- Bỏ khai báo MIME chung `application/octet-stream` cho kiểu file riêng; bộ giải mã tiếp tục xác thực header và AES-GCM.
- Thêm kiểm thử cho bộ đọc file. Script build ZIP chạy XCTest bằng SwiftPM với Apple SDK trên macOS trước khi biên dịch app iOS và tạo IPA, không phụ thuộc simulator. Có thể chạy cùng bộ test bằng iPhone Simulator qua `scripts/test-ios.sh`; workflow đã test riêng có thể dùng `RUN_IMPORT_TESTS=0` để tránh trùng lặp.

Đã kiểm tra cú pháp và cấu trúc project trong môi trường tạo source. Môi trường này là Linux, không có Xcode/iOS SDK để chạy XCTest hoặc thử bộ chọn iCloud. Build trên Codemagic/GitHub và kiểm tra trên iPhone sẽ xác nhận phần nhập file thực tế.

Nếu nhà cung cấp file không cung cấp được dữ liệu, ứng dụng hiển thị lỗi để thử lại. Bản sửa không thể phục hồi dữ liệu không còn tồn tại hoặc tự khôi phục kết nối của dịch vụ lưu trữ.
