# Kiểm tra bản 1.1.0 (build 6)

Ngày kiểm tra: 06/11/2026. Môi trường: Linux, Swift 6.0.3 ở chế độ ngôn ngữ Swift 5; ZIPFoundation 0.9.20, revision `22787ffb59de99e5dc1fbfe80b19c97a904ad48d`.

## Đã chạy

- Biên dịch và chạy **17 XCTest của PosterBoardPackager: 17 đạt, 0 lỗi**, bao gồm bản xuất thực tế `gm.zip` do người dùng cung cấp.
- Bộ test kiểm tra đầu vào ZIP/thư mục, thư mục bao ngoài, nhiều descriptor, giữ nguyên metadata ẩn và phiên bản `versions/7`, bỏ cache trong bản sao, thiếu ảnh/CAML, đường dẫn thoát thư mục, liên kết, mục ZIP trùng tên, dữ liệu WALLIVE còn mã hóa, hủy tác vụ và dọn đầu ra.
- Kiểm tra metadata gợi ý là tùy chọn; cấu hình không có file suggestionMetadata vẫn được đóng gói.
- Kiểm thử dữ liệu thực tế giữ nguyên **90 file, 13.946.570 byte** của hình nền `蓝夜花开`; đối chiếu từng byte CAML, ảnh và metadata với ZIP đầu vào. ZIP nguồn được giữ nguyên.
- Đối chiếu độc lập bằng Python `zipfile`: CRC hợp lệ, đúng tập 90 đường dẫn `descriptors/C06D5D08-CEE0-4DFB-AC5E-5B9CADBF3D03/...`, toàn bộ nội dung file giống nguồn. Gói tạo bằng code mới có dung lượng 8.619.657 byte.
- Parse cú pháp tất cả source Swift và test; kiểm tra kiểu của model giao diện bằng stub Foundation/backend. Kiểm tra nhánh điều phối file dành cho Apple bằng stub NSFileCoordinator. Các bước stub không thay thế build bằng Apple SDK.
- Parse Xcode project, kiểm tra tham chiếu, membership của source/test/thư viện và tài nguyên giấy phép; parse Info.plist, shared scheme XML và workflow YAML; kiểm tra `bash -n` các script và `git diff --check`.

SHA-256 của ZIP nguồn thực tế:

```text
cce348d48f0fb309e889476a4cf494d0cd083b4c419293c06451b3b206f17b83
```

SHA-256 của `.tendies` tạo trong lần kiểm tra này (metadata ZIP có thể thay đổi giữa các lần xuất):

```text
a7783154f0f47388798664c064b4050600fc648ac8ce60443f230a1179a29b56
```

## Chạy lại

Trên macOS có Xcode:

```bash
bash scripts/test-core.sh
bash scripts/test-ios.sh
```

Trên Linux đã cài Swift:

```bash
bash scripts/test-core.sh
```

Test dữ liệu thực tế là tùy chọn. Đặt `TENDIES_REAL_ARCHIVE` thành đường dẫn đến đúng `gm.zip` trước khi chạy test; nếu không có biến này, test đó được bỏ qua và các test tổng hợp vẫn chạy. ZIP và ảnh thực tế không được kèm trong source.

## Cần xác minh bằng Apple SDK và iPhone

Môi trường này không có Xcode/Apple SDK, nên **chưa build IPA, chưa chạy XCTest Apple hoặc UI trên simulator/iPhone**. Workflow GitHub đã có bước kiểm thử macOS, simulator và build IPA chưa ký. Cần kiểm tra chọn ZIP/thư mục từ Files/iCloud, hủy khi provider đang chờ, bảng chia sẻ và khả năng cài/phát hoạt ảnh của `.tendies` trên thiết bị.

Kết quả trên xác minh cơ chế đóng gói dữ liệu đã giải mã. Nó không chứng minh có thể giải mã WALLIVE2 còn mã hóa hoặc đọc vùng dữ liệu riêng của app khác.
