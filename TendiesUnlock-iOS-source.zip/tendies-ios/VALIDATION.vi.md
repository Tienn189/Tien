# Kiểm tra Denrindz 1.2.2 (build 11)

Ngày kiểm tra: 07/11/2026 UTC. Sửa giao diện và icon từ source Denrindz 1.2.1 đã giao trước đó.

- Parse cú pháp cả **16 file Swift**, gồm nhánh Liquid Glass có điều kiện compiler. Rà soát API gốc chỉ được tham chiếu trong `#if compiler(>=6.2)` và `if #available(iOS 26.0, *)`; nhánh cũ dùng SwiftUI material.
- Parse Info.plist, Xcode project/shared scheme và asset JSON; kiểm tra phiên bản 1.2.2 (11), tên Denrindz, icon RGB không có alpha 1024 × 1024 và BrandMark cùng nội dung.
- Đối chiếu ZIP 1.2.1: core giải mã/đóng gói/đọc file, các XCTest, script và workflow giữ nguyên byte. Model tác vụ và callback bộ chọn giữ nguyên; các thẻ feedback chỉ đổi cách trình bày trong ScrollView.
- Rà soát hai nút nhập, chặn xử lý đồng thời, hủy/thử lại và bảng chia sẻ vẫn gắn ở màn hình gốc. Giao diện giữ các khoá cài đặt đã lưu; chỉ đổi tên/màu bảng màu và cách chọn.
- Có nhánh nền đặc khi Giảm độ trong suốt, tắt hiệu ứng nhấn co giãn khi Giảm chuyển động và lưới màu hai cột khi cỡ chữ Trợ năng.

**Chưa biên dịch bằng Apple SDK hoặc chạy giao diện trên iPhone**: môi trường hiện tại là Linux, không có Swift/Xcode. Kiểm tra parser không thay thế typecheck hoặc xác minh hiệu ứng dựng hình. Cần build bằng Codemagic/Xcode; chọn Xcode 26 trở lên nếu muốn Liquid Glass gốc khi chạy iOS 26. Các test sẵn có vẫn chạy trước khi tạo IPA theo script hiện tại.

---

# Kiểm tra Denrindz 1.2.1 (build 10)

Ngày kiểm tra: 07/11/2026 UTC. Nguồn đầu vào là ZIP TendiesUnlock-iOS-source 1.2.0 (build 9) do người dùng gửi.

- Parse cú pháp thành công cho toàn bộ **16 file Swift** (source và test) bằng tree-sitter Swift. Đây là kiểm tra cú pháp, không thay thế trình biên dịch Swift/Apple SDK.
- Parse Xcode project: **67 object**, các tham chiếu, đường dẫn file, build phase, target và shared scheme hợp lệ. Parse Info.plist và xác nhận tên hiển thị **Denrindz**, phiên bản **1.2.1**, build **10**.
- Kiểm tra asset JSON và ảnh: AppIcon PNG RGB không có alpha, kích thước **1024 × 1024**; asset BrandMark dùng cùng biểu tượng móc khoá bị gãy.
- Đối chiếu ZIP đầu vào: các file core giải mã, đóng gói, đọc file/thư mục, kiểu file, toàn bộ test, script build và workflow giữ nguyên. Model tác vụ, callback nhập file và delegate bộ chọn cũng giữ nguyên trong hai file UI được sửa.
- Rà soát màn hình ban đầu: đúng hai dòng **Nhập file tendies** và **Nhập file zip**. ZIP dùng cùng điều kiện chặn khi có tác vụ hoặc kết quả chưa xóa; progress/error/result nằm trong Form sau thao tác; bộ chọn và bảng chia sẻ vẫn gắn vào màn hình gốc.
- Bộ kiểm thử sẵn có vẫn được giữ trong workflow và script build. Không bỏ hoặc sửa assertion để tạo IPA.

Môi trường hiện tại là Linux, không có Swift/Xcode/Apple SDK. **Chưa build IPA hoặc thử giao diện Denrindz trên iPhone.** Cần build lại bằng workflow hiện tại để xác nhận biên dịch iOS và thử nhập file, hủy, thử lại, lưu/chia sẻ trên thiết bị. Các kết quả kiểm thử phía dưới thuộc các lần làm trước của source đầu vào, không phải kết quả chạy lại trong lần sửa giao diện này.

---

# Kiểm tra bản 1.2.0 (build 9)

Ngày kiểm tra: 07/11/2026 UTC. Bản 1.1.2 đã được người dùng xác nhận hoạt động/build ổn trước khi thay giao diện.

## Thay đổi và kiểm tra

- Đối chiếu với source ZIP 1.1.2: các file core (giải mã, đọc file/thư mục, chọn kiểu và đóng gói), tất cả XCTest và phần triển khai model tác vụ giữ nguyên. Thay đổi nằm ở giao diện, lựa chọn màu/chế độ hiển thị, tích hợp source mới và tài liệu.
- Build SwiftPM và chạy **21 XCTest core đóng gói: 21 đạt, 0 lỗi**, gồm ZIP thực tế `gm.zip`. Bộ test và mẫu dữ liệu không bị bỏ để làm build qua.
- Model AppAppearance thực tế được trích xuất và biên dịch ở chế độ Swift 5 bằng Swift 6.0.3 trên Linux với stub UI. **32 kiểm tra** sử dụng Foundation.UserDefaults thật trong suite riêng đã đạt: mặc định, lưu/khôi phục các lựa chọn, màu RGB tùy chỉnh, đặt lại, dữ liệu cài đặt lỗi và lựa chọn chữ tương phản. Stub không xác minh dựng hình SwiftUI, chuyển đổi màu UIKit thật hoặc cơ chế observation trên iOS.
- Parse tất cả Swift, kiểm tra shell, parse plist/Xcode project/shared scheme và membership của AppearanceSettings.swift. Đối chiếu phiên bản 1.2.0(9), giấy phép và nội dung ZIP giao source.
- Rà soát độc lập: phần đóng gói không có NavigationStack/sheet riêng hoặc hủy do onDisappear; bộ chọn và bảng chia sẻ được gắn vào Form gốc, không phụ thuộc section đang hiện hoặc bị cuộn khỏi màn hình. Màn hình chính giữ StateObject cho model và trạng thái trình bày; cả hai luồng chặn khởi chạy đồng thời và kiểm tra lại ở callback bộ chọn. Hủy tác vụ vẫn dùng được.
- Mặc định không ép giao diện tối. Chữ các nút chính/cài đặt dùng màu ngữ nghĩa; màu chủ đề áp dụng cho icon/tiến trình. Nút có nền màu dùng chữ tương phản.

## Giới hạn xác minh

Môi trường là Linux, **chưa build giao diện 1.2.0 bằng Apple SDK hoặc thử trên iPhone**. Cần chạy Actions với ZIP mới để xác minh build iOS. Trên thiết bị cần kiểm tra: đóng gói trực tiếp từ màn hình chính; hủy/thử lại/chia sẻ; đổi Sáng/Tối/Hệ thống và màu khi đang có kết quả/tác vụ; mở lại app để kiểm tra lưu cài đặt; cỡ chữ lớn và Tệp/iCloud.

Các kiểm tra phía dưới thuộc các bản trước.

---

# Kiểm tra bản 1.1.2 (build 8)

Ngày kiểm tra: 07/11/2026 UTC. Môi trường Linux, Swift 6.0.3.

Log đầy đủ do người dùng gửi đã xác định lỗi còn lại của bản 1.1.1: `PosterBoardPackagerTests.swift:69` so sánh `result.archiveBytes` với số byte đọc thực tế; kết quả 307 khác 6.398. Tất cả kiểm tra nội dung tài nguyên trong test đó vẫn đạt. Log macOS ghi 48 test, 1 bỏ qua và 1 lỗi; ba bộ test DirectoryReader, DocumentReader, FilePickerTypes và bộ WalliveDecryptor đều đạt.

Nguyên nhân: `URL.resourceValues(.fileSizeKey)` có thể trả metadata đã lưu trên Apple. Vì cùng URL được đo sau mỗi mục ZIP, giá trị sau mục đầu tiên bị dùng lại cho kết quả cuối. ZIPFoundation 0.9.20 gọi `fflush` khi kết thúc mỗi `addEntry`; dùng một `FileHandle` mới với `seekToEnd()` đọc được kích thước hiện tại, không cần nạp toàn bộ file vào bộ nhớ. Cách này cũng sửa việc kiểm tra giới hạn kích thước ZIP trong lúc ghi.

Đã giữ nguyên assertion ở dòng báo lỗi, thêm test làm file tăng từ 307 lên 6.398 byte rồi giảm còn 11 byte sau khi đã đọc metadata trên cùng URL. Test dữ liệu thực tế cũng đối chiếu `archiveBytes` với số byte đọc từ file xuất.

Kết quả: **21 XCTest đóng gói đạt, 0 lỗi**, gồm `gm.zip`, kiểm tra giữ nguyên 90 file và đối chiếu dung lượng đầu ra. Script thông báo lỗi Actions đã qua 8 tình huống mô phỏng Linux/Darwin trên Bash 5, có kiểm tra mã thoát, ký tự %, CR/LF, UTF-8 và HTML. Đây là kiểm tra script bằng mô phỏng, không phải chạy XCTest Apple. Source Swift, shell, plist/project và ZIP giao source cũng được kiểm tra cú pháp/cấu trúc.

**Chưa chạy lại bản 1.1.2 trên macOS/iPhone và chưa tạo IPA tại môi trường này.** Cần thay ZIP nguồn trên GitHub rồi chạy Actions để xác nhận bằng Apple SDK. Các kết quả phía dưới là lịch sử; nguyên nhân lỗi còn lại của bản 1.1.1 đã được log mới xác nhận như trên.

---

# Kiểm tra bản 1.1.1 (build 7)

Ngày kiểm tra: 06/11/2026. Môi trường Linux, Swift 6.0.3. Đã chạy lại **20 XCTest đóng gói: 20 đạt, 0 lỗi**, gồm `gm.zip` và ba kiểm thử đường dẫn mới.

Bản ZIP mà GitHub Actions dùng ở lần lỗi `42312693285` có SHA-256 `3cb5b5b81c6637287ba15c3fef9b5fad08a4d336418a486a8466de1c4159d900`, trùng bản source 1.1.0 đã gửi. Ảnh log ghi 45 test, 1 bỏ qua, 9 lỗi (6 unexpected); các test giải mã WALLIVE đã đạt. Không tải được log chi tiết bằng truy cập GitHub công khai vì endpoint log yêu cầu quyền repository.

Phát hiện và sửa một lỗi đường dẫn trong `inventory`: Foundation trên Apple có thể liệt kê `/private/var/...` dù thư mục gốc dùng `/var/...`. So sánh trực tiếp chuỗi đường dẫn làm từ chối nhầm dữ liệu hợp lệ. Các test bị ảnh hưởng giải thích đúng tổng 9 lỗi/6 unexpected trong ảnh, nhưng cần log chi tiết hoặc chạy lại macOS để xác nhận toàn bộ nguyên nhân.

Script `test-core.sh` cũng đã được kiểm tra cú pháp và bằng sáu tình huống mô phỏng Linux/Darwin: thành công, Swift trả lỗi và tee trả lỗi. Mã thoát thất bại được giữ nguyên và các dòng lỗi cụ thể được in lại ở cuối log; không bỏ qua test. Đây là kiểm tra script bằng mô phỏng, không phải chạy XCTest Apple.

Ba test mới kiểm tra cùng file dưới hai cách viết của thư mục cha, đóng gói qua thư mục cha tương đương mà vẫn giữ nguyên byte, và từ chối symlink thư mục trỏ ra ngoài cấu hình. Kiểm tra trên Linux không thay thế XCTest trên Apple SDK; **chưa xác nhận bản sửa đạt Actions hoặc tạo IPA**.

Lệnh chạy lại, giới hạn môi trường và dữ liệu thực tế được ghi ở phần dưới. Các kết quả của 1.1.0 là lịch sử, không phải xác nhận build iOS của 1.1.1.

---

# Kiểm tra bản 1.1.0 (build 6)

Ngày kiểm tra: 06/11/2026. Môi trường: Linux, Swift 6.0.3 ở chế độ ngôn ngữ Swift 5; ZIPFoundation 0.9.20, revision `22787ffb59de99e5dc1fbfe80b19c97a904ad48d`.

## Đã chạy

- Biên dịch và chạy **17 XCTest của PosterBoardPackager: 17 đạt, 0 lỗi**, bao gồm bản xuất thực tế `gm.zip` do người dùng cung cấp.
- Bộ test kiểm tra đầu vào ZIP/thư mục, thư mục bao ngoài, nhiều descriptor, giữ nguyên metadata ẩn và phiên bản `versions/7`, bỏ cache trong bản sao, thiếu ảnh/CAML, đường dẫn thoát thư mục, liên kết, mục ZIP trùng tên, dữ liệu WALLIVE còn mã hóa, hủy tác vụ và dọn đầu ra.
- Kiểm tra metadata gợi ý là tùy chọn; cấu hình không có file suggestionMetadata vẫn được đóng gói.
- Kiểm thử dữ liệu thực tế giữ nguyên **90 file, 13.946.570 byte** của hình nền `蓝夜花开`; đối chiếu từng byte CAML, ảnh và metadata với ZIP đầu vào. ZIP nguồn được giữ nguyên.
- Đối chiếu độc lập bằng Python `zipfile`: CRC hợp lệ, đúng tập 90 đường dẫn `descriptors/C06D5D08-CEE0-4DFB-AC5E-5B9CADBF3D03/...`, toàn bộ nội dung file giống nguồn. Gói tạo bằng code mới có dung lượng 8.619.657 byte.
- Parse cú pháp tất cả source Swift và test; kiểm tra kiểu của model giao diện bằng stub Foundation/backend. Kiểm tra nhánh điều phối file dành cho Apple bằng stub NSFileCoordinator. Các bước stub không thay thế build bằng Apple SDK.
- Parse Xcode project, kiểm tra tham chiếu, membership của source/test/thư viện và tài nguyên giấy phép; parse Info.plist, shared scheme XML và workflow YAML; kiểm tra `bash -n` các script và `git diff --check`.

SHA-256 của ZIP nguồn thực tế:

```text
cce348d48f0fb309e889476a4cf494d0cd083b4c419293c06451b3b206f17b83
```

SHA-256 của `.tendies` tạo trong lần kiểm tra này (metadata ZIP có thể thay đổi giữa các lần xuất):

```text
a7783154f0f47388798664c064b4050600fc648ac8ce60443f230a1179a29b56
```

## Chạy lại

Trên macOS có Xcode:

```bash
bash scripts/test-core.sh
bash scripts/test-ios.sh
```

Trên Linux đã cài Swift:

```bash
bash scripts/test-core.sh
```

Test dữ liệu thực tế là tùy chọn. Đặt `TENDIES_REAL_ARCHIVE` thành đường dẫn đến đúng `gm.zip` trước khi chạy test; nếu không có biến này, test đó được bỏ qua và các test tổng hợp vẫn chạy. ZIP và ảnh thực tế không được kèm trong source.

## Cần xác minh bằng Apple SDK và iPhone

Môi trường này không có Xcode/Apple SDK, nên **chưa build IPA, chưa chạy XCTest Apple hoặc UI trên simulator/iPhone**. Workflow GitHub đã có bước kiểm thử macOS, simulator và build IPA chưa ký. Cần kiểm tra chọn ZIP/thư mục từ Files/iCloud, hủy khi provider đang chờ, bảng chia sẻ và khả năng cài/phát hoạt ảnh của `.tendies` trên thiết bị.

Kết quả trên xác minh cơ chế đóng gói dữ liệu đã giải mã. Nó không chứng minh có thể giải mã WALLIVE2 còn mã hóa hoặc đọc vùng dữ liệu riêng của app khác.
