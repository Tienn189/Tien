import Foundation
import XCTest
@testable import TendiesDecryptor

final class DirectoryReaderTests: XCTestCase {
    func testListsFilesWithUnknownExtensionsAndSubfoldersWithoutChangingContents() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let bytes = Data("unchanged source".utf8)
        for name in ["milk_frog.tendies", "OTHER.WALLIVE", "plain.ZIP", "ignore.txt"] {
            try bytes.write(to: root.appendingPathComponent(name))
        }
        let child = root.appendingPathComponent("Nested", isDirectory: true)
        try FileManager.default.createDirectory(at: child, withIntermediateDirectories: true)
        try bytes.write(to: child.appendingPathComponent("inside.tendies"))
        let entries = try await DirectoryReader.list(access: DocumentAccess(url: root))
        XCTAssertEqual(Set(entries.map(\.name)), Set(["Nested", "milk_frog.tendies", "OTHER.WALLIVE", "plain.ZIP", "ignore.txt"]))
        XCTAssertEqual(entries.first?.name, "Nested")
        XCTAssertTrue(entries.first?.isDirectory == true)
        XCTAssertEqual(try Data(contentsOf: root.appendingPathComponent("milk_frog.tendies")), bytes)
        XCTAssertFalse(entries.contains { $0.name == "inside.tendies" })
    }

    func testCloudStubsUseLogicalNamesAndURLsAndDeduplicateHydratedFiles() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let stubBytes = Data("placeholder, not document bytes".utf8)
        for name in [".milk_frog.tendies.icloud", ".hidden.name.tendies.icloud", ".unusual.blob.icloud"] {
            try stubBytes.write(to: root.appendingPathComponent(name))
        }
        let hydrated = root.appendingPathComponent("milk_frog.tendies")
        let documentBytes = Data("hydrated bytes".utf8)
        try documentBytes.write(to: hydrated)

        let entries = try await DirectoryReader.list(access: DocumentAccess(url: root))
        XCTAssertEqual(Set(entries.map(\.name)), Set(["milk_frog.tendies", "hidden.name.tendies", "unusual.blob"]))
        let milk = try XCTUnwrap(entries.first { $0.name == "milk_frog.tendies" })
        XCTAssertEqual(milk.url, hydrated)
        XCTAssertNil(milk.note, "The hydrated entry must replace the stub entry regardless of enumeration order")
        let placeholder = try XCTUnwrap(entries.first { $0.name == "hidden.name.tendies" })
        XCTAssertEqual(placeholder.url, root.appendingPathComponent("hidden.name.tendies"))
        XCTAssertTrue(placeholder.note?.contains("iCloud") == true)
        XCTAssertEqual(try Data(contentsOf: hydrated), documentBytes)
        XCTAssertEqual(try Data(contentsOf: root.appendingPathComponent(".milk_frog.tendies.icloud")), stubBytes)
    }

    func testHiddenDocumentsRemainVisibleAndSystemConfigurationAndSymlinksDoNot() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        for name in [".private.tendies", ".DS_Store", ".gitconfig", "._fork.tendies", "visible.unknown"] {
            try Data([1]).write(to: root.appendingPathComponent(name))
        }
        try FileManager.default.createDirectory(
            at: root.appendingPathComponent(".git", isDirectory: true), withIntermediateDirectories: true
        )
        try FileManager.default.createSymbolicLink(
            at: root.appendingPathComponent("linked.tendies"),
            withDestinationURL: root.appendingPathComponent(".private.tendies")
        )
        let entries = try await DirectoryReader.list(access: DocumentAccess(url: root), resourceValues: { url, keys in
            if url.lastPathComponent == "linked.tendies" {
                throw NSError(domain: "TestFileProvider", code: 403)
            }
            return try url.resourceValues(forKeys: keys)
        })
        XCTAssertEqual(Set(entries.map(\.name)), Set([".private.tendies", "visible.unknown"]))
        XCTAssertTrue(entries.first { $0.name == "visible.unknown" }?.note?.contains("kiểm tra nội dung") == true)
    }

    func testOneMetadataFailurePreservesOtherFilesAndOffersTheFailedItemWithANote() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        for name in ["available.tendies", "syncing.tendies"] {
            try Data([1, 2, 3]).write(to: root.appendingPathComponent(name))
        }
        let entries = try await DirectoryReader.list(access: DocumentAccess(url: root), resourceValues: { url, keys in
            if url.lastPathComponent == "syncing.tendies" {
                throw NSError(domain: "TestFileProvider", code: 401)
            }
            return try url.resourceValues(forKeys: keys)
        })
        XCTAssertEqual(Set(entries.map(\.name)), Set(["available.tendies", "syncing.tendies"]))
        let unavailable = try XCTUnwrap(entries.first { $0.name == "syncing.tendies" })
        XCTAssertEqual(unavailable.url, root.appendingPathComponent("syncing.tendies"))
        XCTAssertTrue(unavailable.note?.contains("TestFileProvider") == true)
        XCTAssertTrue(unavailable.note?.contains("401") == true)
    }

    func testMissingOrFailingRootMetadataStillAttemptsEnumeration() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        try Data([1]).write(to: root.appendingPathComponent("selected.tendies"))
        for metadataThrows in [false, true] {
            let entries = try await DirectoryReader.list(access: DocumentAccess(url: root), resourceValues: { url, keys in
                if keys == Set([URLResourceKey.isDirectoryKey]) {
                    if metadataThrows { throw NSError(domain: "TestFileProvider", code: 402) }
                    return URLResourceValues()
                }
                return try url.resourceValues(forKeys: keys)
            })
            XCTAssertEqual(entries.map(\.name), ["selected.tendies"])
        }
    }

    func testListsSubfolderWithParentScope() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let child = root.appendingPathComponent("Child", isDirectory: true)
        try FileManager.default.createDirectory(at: child, withIntermediateDirectories: true)
        try Data([1, 2, 3]).write(to: child.appendingPathComponent("selected.tendies"))
        let entries = try await DirectoryReader.list(access: DocumentAccess(url: child, scopeURL: root))
        XCTAssertEqual(entries.map(\.name), ["selected.tendies"])
    }

    func testAFileCannotBeUsedAsDirectory() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let file = root.appendingPathComponent("file.tendies")
        try Data([0]).write(to: file)
        do {
            _ = try await DirectoryReader.list(access: DocumentAccess(url: file))
            XCTFail("Expected a directory error")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .notADirectory)
        }
    }

    func testChildReaderAcquiresAndReleasesDirectoryGrant() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let child = root.appendingPathComponent("file.tendies")
        let bytes = Data([1, 2, 3])
        try bytes.write(to: child)
        let tracker = DirectoryScopeTracker()
        let closed = expectation(description: "Directory grant closed after child reader exits")
        let access = DocumentAccess(
            url: child, scopeURL: root,
            startAccess: { url in tracker.started(url); return true },
            stopAccess: { url in tracker.stopped(url); closed.fulfill() }
        )
        XCTAssertEqual(access.url, child)
        XCTAssertEqual(access.scopeURL, root)
        let data = try await DocumentReader.read(from: access)
        XCTAssertEqual(data, bytes)
        // Wait for the actual worker defer, which may run just after the async result.
        await fulfillment(of: [closed], timeout: 3)
        XCTAssertEqual(tracker.starts, [root])
        XCTAssertEqual(tracker.stops, [root])
        access.close()
        XCTAssertEqual(tracker.stops, [root])
    }

    private func temporaryDirectory() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
}

private final class DirectoryScopeTracker: @unchecked Sendable {
    private let lock = NSLock()
    private var startedURLs: [URL] = []
    private var stoppedURLs: [URL] = []
    var starts: [URL] { lock.lock(); defer { lock.unlock() }; return startedURLs }
    var stops: [URL] { lock.lock(); defer { lock.unlock() }; return stoppedURLs }
    func started(_ url: URL) { lock.lock(); startedURLs.append(url); lock.unlock() }
    func stopped(_ url: URL) { lock.lock(); stoppedURLs.append(url); lock.unlock() }
}
