import Foundation
import XCTest
@testable import TendiesDecryptor

final class DirectoryReaderTests: XCTestCase {
    func testListsSupportedFilesAndSubfoldersWithoutChangingContents() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let bytes = Data("unchanged source".utf8)
        for name in ["milk_frog.tendies", "OTHER.WALLIVE", "plain.ZIP", "ignore.txt"] {
            try bytes.write(to: root.appendingPathComponent(name))
        }
        let child = root.appendingPathComponent("Nested", isDirectory: true)
        try FileManager.default.createDirectory(at: child, withIntermediateDirectories: true)
        try bytes.write(to: child.appendingPathComponent("inside.tendies"))
        let entries = try await DirectoryReader.list(access: DocumentAccess(url: root))
        XCTAssertEqual(Set(entries.map(\.name)), Set(["Nested", "milk_frog.tendies", "OTHER.WALLIVE", "plain.ZIP"]))
        XCTAssertEqual(entries.first?.name, "Nested")
        XCTAssertTrue(entries.first?.isDirectory == true)
        XCTAssertEqual(try Data(contentsOf: root.appendingPathComponent("milk_frog.tendies")), bytes)
        XCTAssertFalse(entries.contains { $0.name == "inside.tendies" })
    }

    func testListsSubfolderWithParentScope() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let child = root.appendingPathComponent("Child", isDirectory: true)
        try FileManager.default.createDirectory(at: child, withIntermediateDirectories: true)
        try Data([1, 2, 3]).write(to: child.appendingPathComponent("selected.tendies"))
        let entries = try await DirectoryReader.list(access: DocumentAccess(url: child, scopeURL: root))
        XCTAssertEqual(entries.map(\.name), ["selected.tendies"])
    }

    func testAFileCannotBeUsedAsDirectory() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let file = root.appendingPathComponent("file.tendies")
        try Data([0]).write(to: file)
        do {
            _ = try await DirectoryReader.list(access: DocumentAccess(url: file))
            XCTFail("Expected a directory error")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .notADirectory)
        }
    }

    func testChildReaderAcquiresAndReleasesDirectoryGrant() async throws {
        let root = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: root) }
        let child = root.appendingPathComponent("file.tendies")
        let bytes = Data([1, 2, 3])
        try bytes.write(to: child)
        let tracker = DirectoryScopeTracker()
        let closed = expectation(description: "Directory grant closed after child reader exits")
        let access = DocumentAccess(
            url: child, scopeURL: root,
            startAccess: { url in tracker.started(url); return true },
            stopAccess: { url in tracker.stopped(url); closed.fulfill() }
        )
        XCTAssertEqual(access.url, child)
        XCTAssertEqual(access.scopeURL, root)
        let data = try await DocumentReader.read(from: access)
        XCTAssertEqual(data, bytes)
        // Wait for the actual worker defer, which may run just after the async result.
        await fulfillment(of: [closed], timeout: 3)
        XCTAssertEqual(tracker.starts, [root])
        XCTAssertEqual(tracker.stops, [root])
        access.close()
        XCTAssertEqual(tracker.stops, [root])
    }

    private func temporaryDirectory() throws -> URL {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
}

private final class DirectoryScopeTracker: @unchecked Sendable {
    private let lock = NSLock()
    private var startedURLs: [URL] = []
    private var stoppedURLs: [URL] = []
    var starts: [URL] { lock.lock(); defer { lock.unlock() }; return startedURLs }
    var stops: [URL] { lock.lock(); defer { lock.unlock() }; return stoppedURLs }
    func started(_ url: URL) { lock.lock(); startedURLs.append(url); lock.unlock() }
    func stopped(_ url: URL) { lock.lock(); stoppedURLs.append(url); lock.unlock() }
}
