import Foundation
import XCTest
import ZIPFoundation
@testable import TendiesDecryptor

final class PosterBoardPackagerTests: XCTestCase {
    func testConfigurationFolderPreservesVersionedMetadataAndAssetsAndOmitsCaches() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }

        let result = try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output)
        let exported = try entries(in: result.fileURL)
        let prefix = "descriptors/\(fixture.configuration.lastPathComponent)/"
        XCTAssertEqual(result.descriptorCount, 1)
        XCTAssertEqual(result.wallpaperNames, ["Synthetic Wallpaper"])
        XCTAssertEqual(result.fileCount, fixture.retained.count)
        XCTAssertEqual(result.originalBytes, Int64(fixture.retained.values.reduce(0) { $0 + $1.count }))
        XCTAssertEqual(result.archiveBytes, Int64(try Data(contentsOf: result.fileURL).count))
        XCTAssertEqual(result.omittedFiles, 4)
        XCTAssertEqual(result.fileURL.pathExtension, "tendies")
        XCTAssertEqual(Set(exported.keys), Set(fixture.retained.keys.map { prefix + $0 }))
        for (path, data) in fixture.retained {
            XCTAssertEqual(exported[prefix + path], data, "Changed original bytes at \(path)")
            XCTAssertEqual(try Data(contentsOf: fixture.configuration.appendingPathComponent(path)), data)
        }
        XCTAssertNotNil(exported[prefix + "versions/7/contents/.com.apple.posterkit.provider.contents.configurableOptions.plist"])
        XCTAssertFalse(exported.keys.contains { $0.contains("versions/0/") })
    }

    func testZIPInsideWrapperProducesSameDescriptorAndLeavesSourceUnchanged() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let source = fixture.root.appendingPathComponent("original.zip")
        let archiveBytes = storedZIP(fixture.allFiles.map { ("Export/descriptors/\(fixture.configuration.lastPathComponent)/" + $0.key, $0.value) })
        try archiveBytes.write(to: source)

        let result = try PosterBoardPackager.package(sourceURL: source, outputDirectory: fixture.output)
        let exported = try entries(in: result.fileURL)
        XCTAssertEqual(result.descriptorCount, 1)
        XCTAssertEqual(result.fileCount, fixture.retained.count)
        XCTAssertEqual(result.omittedFiles, 4)
        XCTAssertEqual(try Data(contentsOf: source), archiveBytes)
        XCTAssertTrue(exported.keys.allSatisfy { $0.hasPrefix("descriptors/\(fixture.configuration.lastPathComponent)/") })
        for (path, data) in fixture.retained {
            XCTAssertEqual(exported["descriptors/\(fixture.configuration.lastPathComponent)/" + path], data)
        }
    }

    func testExistingDescriptorsFolderSupportsMultipleConfigurations() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let wrapper = fixture.root.appendingPathComponent("Export/descriptors", isDirectory: true)
        try FileManager.default.createDirectory(at: wrapper, withIntermediateDirectories: true)
        try FileManager.default.copyItem(at: fixture.configuration, to: wrapper.appendingPathComponent(fixture.configuration.lastPathComponent))
        let secondID = "EDE80C37-8866-413B-AD51-FE66AB1AE9D3"
        try FileManager.default.copyItem(at: fixture.configuration, to: wrapper.appendingPathComponent(secondID))

        let result = try PosterBoardPackager.package(sourceURL: wrapper.deletingLastPathComponent(), outputDirectory: fixture.output)
        let exported = try entries(in: result.fileURL)
        XCTAssertEqual(result.descriptorCount, 2)
        XCTAssertEqual(result.fileCount, fixture.retained.count * 2)
        XCTAssertEqual(result.omittedFiles, 8)
        XCTAssertNotNil(exported["descriptors/\(secondID)/com.apple.posterkit.provider.descriptor.identifier"])
    }

    func testRepeatedExportsUseUniqueNamesAndRepackDoesNotOverwriteInput() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let first = try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output)
        let firstBytes = try Data(contentsOf: first.fileURL)
        let second = try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output)
        let third = try PosterBoardPackager.package(sourceURL: first.fileURL, outputDirectory: fixture.output)

        XCTAssertEqual(Set([first.fileURL, second.fileURL, third.fileURL]).count, 3)
        XCTAssertEqual(try Data(contentsOf: first.fileURL), firstBytes)
        XCTAssertEqual(try entries(in: first.fileURL), try entries(in: third.fileURL))
        XCTAssertEqual(try FileManager.default.contentsOfDirectory(at: fixture.output, includingPropertiesForKeys: nil).count, 3)
    }

    func testMissingCAMLImageFailsBeforeProducingArchive() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        try FileManager.default.removeItem(at: fixture.configuration.appendingPathComponent(assetPath))

        XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output)) { error in
            XCTAssertTrue(error.localizedDescription.contains("Thiếu"), error.localizedDescription)
        }
        try assertNoOutputs(in: fixture.output)
    }

    func testMissingIndexRootDocumentFailsBeforeProducingArchive() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        try FileManager.default.removeItem(at: fixture.configuration.appendingPathComponent(camlPath))
        XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output))
        try assertNoOutputs(in: fixture.output)
    }

    func testCAMLPathEscapeAndAbsolutePathsAreRejected() throws {
        for path in ["../../../../../outside.png", "/tmp/outside.png", "file:///tmp/outside.png"] {
            let fixture = try makeFixture()
            defer { try? FileManager.default.removeItem(at: fixture.root) }
            let caml = Data("<?xml version=\"1.0\"?><caml><CALayer><CGImage src=\"\(path)\"/></CALayer></caml>".utf8)
            try caml.write(to: fixture.configuration.appendingPathComponent(camlPath))
            XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output), path)
            try assertNoOutputs(in: fixture.output)
        }
    }

    func testManifestCAbundlePathEscapeIsRejected() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        var manifest = wallpaperManifest
        manifest["assets"] = ["lockAndHome": ["default": ["backgroundAnimationFileName": "../../Outside.ca"]]]
        try plist(manifest).write(to: fixture.configuration.appendingPathComponent(wallpaperPath + "/Wallpaper.plist"))
        XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output))
        try assertNoOutputs(in: fixture.output)
    }

    func testSymlinkIsRejectedWithoutFollowingIt() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let outside = fixture.root.appendingPathComponent("outside.png")
        let original = Data("outside bytes".utf8)
        try original.write(to: outside)
        try FileManager.default.removeItem(at: fixture.configuration.appendingPathComponent(assetPath))
        try FileManager.default.createSymbolicLink(at: fixture.configuration.appendingPathComponent(assetPath), withDestinationURL: outside)

        XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output))
        XCTAssertEqual(try Data(contentsOf: outside), original)
        try assertNoOutputs(in: fixture.output)
    }

    func testZIPTraversalAndDuplicateEntriesAreRejected() throws {
        for unsafeEntries in [[("../escaped.txt", Data([1]))], [("duplicate", Data([1])), ("duplicate", Data([2]))], [("/absolute.txt", Data([1]))], [("back\\slash.txt", Data([1]))]] {
            let fixture = try makeFixture()
            defer { try? FileManager.default.removeItem(at: fixture.root) }
            let source = fixture.root.appendingPathComponent("unsafe.zip")
            let files = fixture.retained.map { (fixture.configuration.lastPathComponent + "/" + $0.key, $0.value) }
            try storedZIP(files + unsafeEntries).write(to: source)

            XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: source, outputDirectory: fixture.output))
            XCTAssertFalse(FileManager.default.fileExists(atPath: fixture.root.appendingPathComponent("escaped.txt").path))
            try assertNoOutputs(in: fixture.output)
        }
    }

    func testZIPSymbolicLinkIsRejected() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let source = fixture.root.appendingPathComponent("symlink.zip")
        try storedZIP([("linked", Data("../outside".utf8))], unixMode: 0o120777).write(to: source)
        XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: source, outputDirectory: fixture.output))
        try assertNoOutputs(in: fixture.output)
    }

    func testEncryptedWalliveExplainsThatDecryptedExportIsRequired() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        for magic in ["WALLIVE1", "WALLIVE2"] {
            let source = fixture.root.appendingPathComponent(magic + ".tendies")
            try (Data(magic.utf8) + Data(repeating: 0, count: 128)).write(to: source)
            XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: source, outputDirectory: fixture.output)) { error in
                XCTAssertTrue(error.localizedDescription.contains(magic), error.localizedDescription)
                XCTAssertTrue(error.localizedDescription.contains("giải mã"), error.localizedDescription)
            }
        }
        try assertNoOutputs(in: fixture.output)
    }

    func testBareWallpaperExplainsThatFullConfigurationIsRequired() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let bare = fixture.configuration.appendingPathComponent(wallpaperPath, isDirectory: true)
        XCTAssertThrowsError(try PosterBoardPackager.package(sourceURL: bare, outputDirectory: fixture.output)) { error in
            XCTAssertTrue(error.localizedDescription.contains(".wallpaper"), error.localizedDescription)
        }
        try assertNoOutputs(in: fixture.output)
    }

    func testCancellationCleansUpPartialOutputAndPreservesSource() async throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let worker = Task.detached {
            try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output) { update in
                if update.completedBytes > 0 {
                    withUnsafeCurrentTask { $0?.cancel() }
                }
            }
        }
        do {
            _ = try await worker.value
            XCTFail("Expected cooperative cancellation")
        } catch is CancellationError {
            // Cancellation must escape as cancellation so the UI can avoid an error alert.
        }
        try assertNoOutputs(in: fixture.output)
        for (path, bytes) in fixture.allFiles {
            XCTAssertEqual(try Data(contentsOf: fixture.configuration.appendingPathComponent(path)), bytes)
        }
    }

    func testSuggestionMetadataIsOptional() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let optional = "com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist"
        try FileManager.default.removeItem(at: fixture.configuration.appendingPathComponent(optional))
        let result = try PosterBoardPackager.package(sourceURL: fixture.configuration, outputDirectory: fixture.output)
        let exported = try entries(in: result.fileURL)
        XCTAssertEqual(result.fileCount, fixture.retained.count - 1)
        for (path, data) in fixture.retained where path != optional {
            XCTAssertEqual(exported["descriptors/\(fixture.configuration.lastPathComponent)/" + path], data)
        }
    }

    func testExplicitCancellationTokenStopsSynchronousWorkerAndCleansOutput() throws {
        let fixture = try makeFixture()
        defer { try? FileManager.default.removeItem(at: fixture.root) }
        let cancellation = PosterBoardPackageCancellation()
        XCTAssertThrowsError(try PosterBoardPackager.package(
            sourceURL: fixture.configuration, outputDirectory: fixture.output, cancellation: cancellation
        ) { update in
            if update.completedBytes > 0 { cancellation.cancel() }
        }) { error in
            XCTAssertTrue(error is CancellationError)
        }
        try assertNoOutputs(in: fixture.output)
        for (path, bytes) in fixture.allFiles {
            XCTAssertEqual(try Data(contentsOf: fixture.configuration.appendingPathComponent(path)), bytes)
        }
    }

    // Optional integration fixture supplied by the owner. The archive and its
    // wallpaper assets are deliberately not included in this source project.
    func testRealPosterBoardExportPreservesEveryRetainedFile() throws {
        guard let path = ProcessInfo.processInfo.environment["TENDIES_REAL_ARCHIVE"] else {
            throw XCTSkip("Set TENDIES_REAL_ARCHIVE to the owner's gm.zip for the integration check")
        }
        let source = URL(fileURLWithPath: path)
        let original = try Data(contentsOf: source)
        let output = FileManager.default.temporaryDirectory.appendingPathComponent("RealPosterBoard-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: output) }
        let result = try PosterBoardPackager.package(sourceURL: source, outputDirectory: output)
        let exported = try entries(in: result.fileURL)
        let configuration = "C06D5D08-CEE0-4DFB-AC5E-5B9CADBF3D03"
        let sourceFiles = try entries(in: source)
        var expected: [String: Data] = [:]
        for (path, bytes) in sourceFiles {
            let components = path.split(separator: "/")
            guard components.first == Substring(configuration) else { continue }
            let relative = components.dropFirst()
            if relative.contains(where: { $0 == "scratch" || $0 == ".DS_Store" || $0 == "__MACOSX" || $0.hasPrefix("RuntimeSnapshot") }) { continue }
            expected["descriptors/\(configuration)/" + relative.joined(separator: "/")] = bytes
        }
        XCTAssertEqual(result.descriptorCount, 1)
        XCTAssertEqual(result.fileCount, 90)
        XCTAssertEqual(result.originalBytes, 13_946_570)
        XCTAssertEqual(result.wallpaperNames, ["蓝夜花开"])
        XCTAssertEqual(Set(exported.keys), Set(expected.keys))
        for (path, bytes) in expected {
            XCTAssertEqual(exported[path], bytes, "Changed original bytes at \(path)")
        }
        XCTAssertEqual(try Data(contentsOf: source), original)
        if let kept = ProcessInfo.processInfo.environment["TENDIES_REAL_OUTPUT"] {
            let destination = URL(fileURLWithPath: kept)
            try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            // Optional evidence artifact; never overwrite the input or a prior result.
            XCTAssertFalse(FileManager.default.fileExists(atPath: destination.path))
            try FileManager.default.copyItem(at: result.fileURL, to: destination)
        }
    }

    private let wallpaperPath = "versions/7/contents/Synthetic.wallpaper"
    private var camlPath: String { wallpaperPath + "/Layer.ca/main.caml" }
    private var assetPath: String { wallpaperPath + "/Layer.ca/assets/pixel.png" }
    private var wallpaperManifest: [String: Any] {
        ["identifier": 811040020, "name": "Synthetic Wallpaper", "family": "Test", "version": 1,
         "assets": ["lockAndHome": ["default": ["backgroundAnimationFileName": "Layer.ca", "identifier": 811040020, "name": "Synthetic Wallpaper", "type": "LayeredAnimation"]]]]
    }

    private struct Fixture: Sendable {
        let root: URL
        let configuration: URL
        let output: URL
        let retained: [String: Data]
        let omitted: [String: Data]
        var allFiles: [String: Data] { retained.merging(omitted) { first, _ in first } }
    }

    private func makeFixture() throws -> Fixture {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("PosterBoardPackagerTests-" + UUID().uuidString, isDirectory: true)
        let configuration = root.appendingPathComponent("7C116277-19E3-4F34-8712-1375FA754365", isDirectory: true)
        let output = root.appendingPathComponent("Output", isDirectory: true)
        let retained: [String: Data] = [
            "com.apple.posterkit.provider.descriptor.identifier": Data("811040020".utf8),
            "com.apple.posterkit.role.identifier": Data("com.apple.posterkit.role.lock".utf8),
            "providerInfo.plist": try plist(["providerIdentifier": "com.apple.WallpaperKit.CollectionsPoster"]),
            "com.apple.posterkit.provider.identifierURL.suggestionMetadata.plist": try plist(["identifier": "811040020.DYNAMIC", "name": "Synthetic Wallpaper"]),
            "versions/7/contents/.com.apple.posterkit.provider.contents.configurableOptions.plist": try plist(["hidden": true]),
            "versions/7/contents/com.apple.posterkit.provider.contents.userInfo": try plist(["wallpaperRepresentingIdentifier": "811040020", "wallpaperBundlePath": "Synthetic.wallpaper"]),
            "versions/7/contents/com.apple.posterkit.provider.contents.otherMetadata.plist": try plist(["originalMetadata": "preserve me"]),
            "versions/7/com.apple.posterkit.provider.instance.renderingConfiguration.plist": try plist(["keep": Data([1, 2, 3])]),
            "versions/7/supplements/0/com.apple.posterkit.provider.supplementURL.homescreenConfiguration.plist": try plist(["style": 7]),
            wallpaperPath + "/Wallpaper.plist": try plist(wallpaperManifest),
            wallpaperPath + "/Layer.ca/index.xml": try plist(["rootDocument": "main.caml", "documentWidth": 390.0, "documentHeight": 844.0]),
            camlPath: Data("<?xml version=\"1.0\"?><caml xmlns=\"http://www.apple.com/CoreAnimation/1.0\"><CALayer><contents><CGImage src=\"assets/pixel.png\"/></contents></CALayer></caml>".utf8),
            wallpaperPath + "/Layer.ca/assetManifest.caml": Data("<?xml version=\"1.0\"?><caml><MicaAssetManifest><modules type=\"NSArray\"/></MicaAssetManifest></caml>".utf8),
            assetPath: Data([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 1, 2, 3])
        ]
        let omitted: [String: Data] = [
            ".DS_Store": Data([0]),
            "versions/7/RuntimeSnapshot-lock.atx": Data([1]),
            "versions/7/RuntimeSnapshotMetadata-lock.plist": Data([2]),
            "versions/7/scratch/cache.db": Data([3])
        ]
        let fixture = Fixture(root: root, configuration: configuration, output: output, retained: retained, omitted: omitted)
        do {
            try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
            for (path, bytes) in fixture.allFiles {
                let file = configuration.appendingPathComponent(path)
                try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
                try bytes.write(to: file)
            }
            return fixture
        } catch {
            try? FileManager.default.removeItem(at: root)
            throw error
        }
    }

    private func plist(_ value: [String: Any]) throws -> Data {
        try PropertyListSerialization.data(fromPropertyList: value, format: .xml, options: 0)
    }

    private func entries(in url: URL) throws -> [String: Data] {
        let archive = try Archive(url: url, accessMode: .read)
        var files: [String: Data] = [:]
        for entry in archive where entry.type == .file {
            var bytes = Data()
            _ = try archive.extract(entry) { bytes.append($0) }
            files[entry.path] = bytes
        }
        return files
    }

    private func assertNoOutputs(in directory: URL, file: StaticString = #filePath, line: UInt = #line) throws {
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
        XCTAssertTrue(files.isEmpty, "Left output or temporary files: \(files)", file: file, line: line)
    }

    // A tiny stored-ZIP writer lets tests construct malicious entry names without
    // relying on an archiver that sanitizes them before the production reader sees them.
    private func storedZIP(_ files: [(String, Data)], unixMode: UInt32 = 0o100644) -> Data {
        var archive = Data()
        var centralDirectory = Data()
        for (path, bytes) in files {
            let name = Data(path.utf8)
            let offset = UInt32(archive.count)
            let crc = crc32(bytes)
            archive.appendLE(UInt32(0x04034b50))
            archive.appendLE(UInt16(20)); archive.appendLE(UInt16(0x0800)); archive.appendLE(UInt16(0))
            archive.appendLE(UInt16(0)); archive.appendLE(UInt16(0))
            archive.appendLE(crc); archive.appendLE(UInt32(bytes.count)); archive.appendLE(UInt32(bytes.count))
            archive.appendLE(UInt16(name.count)); archive.appendLE(UInt16(0))
            archive.append(name); archive.append(bytes)
            centralDirectory.appendLE(UInt32(0x02014b50))
            centralDirectory.appendLE(UInt16(0x0314)); centralDirectory.appendLE(UInt16(20))
            centralDirectory.appendLE(UInt16(0x0800)); centralDirectory.appendLE(UInt16(0))
            centralDirectory.appendLE(UInt16(0)); centralDirectory.appendLE(UInt16(0))
            centralDirectory.appendLE(crc); centralDirectory.appendLE(UInt32(bytes.count)); centralDirectory.appendLE(UInt32(bytes.count))
            centralDirectory.appendLE(UInt16(name.count)); centralDirectory.appendLE(UInt16(0)); centralDirectory.appendLE(UInt16(0))
            centralDirectory.appendLE(UInt16(0)); centralDirectory.appendLE(UInt16(0))
            centralDirectory.appendLE(unixMode << 16); centralDirectory.appendLE(offset); centralDirectory.append(name)
        }
        let centralOffset = UInt32(archive.count)
        archive.append(centralDirectory)
        archive.appendLE(UInt32(0x06054b50))
        archive.appendLE(UInt16(0)); archive.appendLE(UInt16(0))
        archive.appendLE(UInt16(files.count)); archive.appendLE(UInt16(files.count))
        archive.appendLE(UInt32(centralDirectory.count)); archive.appendLE(centralOffset); archive.appendLE(UInt16(0))
        return archive
    }

    private func crc32(_ bytes: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in bytes {
            crc ^= UInt32(byte)
            for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) == 1 ? 0xedb88320 : 0) }
        }
        return crc ^ 0xffffffff
    }
}

private extension Data {
    mutating func appendLE<T: FixedWidthInteger>(_ value: T) {
        var littleEndian = value.littleEndian
        Swift.withUnsafeBytes(of: &littleEndian) { append(contentsOf: $0) }
    }
}
