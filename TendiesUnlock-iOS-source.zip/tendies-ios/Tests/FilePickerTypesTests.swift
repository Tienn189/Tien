import UniformTypeIdentifiers
import XCTest
@testable import TendiesDecryptor

final class FilePickerTypesTests: XCTestCase {
    func testKeepsEveryRegisteredExtensionMapping() {
        // PDF is system registered even when the test host has no wallpaper app installed.
        let resolved = UTType.types(tag: "pdf", tagClass: .filenameExtension, conformingTo: nil)
        XCTAssertFalse(resolved.isEmpty)
        let accepted = Set(FilePickerTypes.contentTypes(for: ["pdf"]).map(\.identifier))
        XCTAssertTrue(Set(resolved.map(\.identifier)).isSubset(of: accepted))
        XCTAssertTrue(accepted.contains(UTType.pdf.identifier))
    }

    func testKeepsArchiveAndUnclassifiedDataFallbacks() {
        let accepted = Set(FilePickerTypes.contentTypes().map(\.identifier))
        for type in [UTType.item, .data, .content, .archive, .zip] {
            XCTAssertTrue(accepted.contains(type.identifier))
        }
    }

    func testOverlappingAndRepeatedMappingsDoNotDuplicateTypes() {
        let types = FilePickerTypes.contentTypes(for: ["zip", "zip", "tendies", "wallive"])
        XCTAssertEqual(types.count, Set(types.map(\.identifier)).count)
    }
}
