import Foundation
import XCTest
@testable import TendiesDecryptor

final class DocumentReaderTests: XCTestCase {
    func testReadsDocumentInPlaceAndKeepsOriginal() async throws {
        let url = temporaryFile()
        defer { try? FileManager.default.removeItem(at: url) }
        let bytes = Data(repeating: 0x6a, count: 600_000)
        try bytes.write(to: url)
        let access = DocumentAccess(url: url)
        let data = try await DocumentReader.read(from: access)
        XCTAssertEqual(data, bytes)
        XCTAssertEqual(try Data(contentsOf: url), bytes)
    }

    func testOversizedDocumentIsRejectedBeforeReading() async throws {
        let url = temporaryFile()
        XCTAssertTrue(FileManager.default.createFile(atPath: url.path, contents: nil))
        defer { try? FileManager.default.removeItem(at: url) }
        let handle = try FileHandle(forWritingTo: url)
        try handle.truncate(atOffset: UInt64(WalliveDecryptor.maximumFileBytes + 1))
        try handle.close()
        do {
            _ = try await DocumentReader.read(from: DocumentAccess(url: url))
            XCTFail("Expected a size limit error")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .tooLarge)
        }
    }

    func testProviderErrorRetainsItsDomainAndCode() async throws {
        do {
            _ = try await DocumentReader.read(from: DocumentAccess(url: temporaryFile()))
            XCTFail("Expected an unavailable file error")
        } catch {
            guard let failure = error as? DocumentReadError,
                  case .provider(let domain, let code, _) = failure else {
                return XCTFail("Expected the underlying provider error, got \(error)")
            }
            XCTAssertFalse(domain.isEmpty)
            XCTAssertNotEqual(code, 0)
        }
    }

    func testAlreadyCancelledTaskDoesNotStartReadingAndClosesScope() async throws {
        let tracker = ScopeTracker()
        let access = DocumentAccess(
            url: temporaryFile(), startAccess: { _ in true },
            stopAccess: { _ in tracker.didClose() }
        )
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try await DocumentReader.read(from: access, timeout: 2) { _ in
                tracker.didRead()
                return Data()
            }
        }
        do {
            _ = try await task.value
            XCTFail("Expected cancellation")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .cancelled)
        }
        XCTAssertEqual(tracker.readCount, 0)
        XCTAssertEqual(tracker.closeCount, 1)
    }

    func testTimeoutReturnsWithoutClosingScopeWhileWorkerStillUsesIt() async throws {
        let started = expectation(description: "Worker started")
        let closed = expectation(description: "Scope closed after worker exit")
        let gate = DispatchSemaphore(value: 0)
        defer { gate.signal() }
        let tracker = ScopeTracker()
        let access = DocumentAccess(
            url: temporaryFile(), startAccess: { _ in true },
            stopAccess: { _ in tracker.didClose(); closed.fulfill() }
        )
        let task = Task {
            try await DocumentReader.read(from: access, timeout: 1) { _ in
                started.fulfill()
                gate.wait()
                return Data([1, 2, 3])
            }
        }
        await fulfillment(of: [started], timeout: 3)
        do {
            _ = try await task.value
            XCTFail("Expected timeout while the provider worker is blocked")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .timedOut)
        }
        XCTAssertEqual(tracker.closeCount, 0)
        gate.signal()
        await fulfillment(of: [closed], timeout: 3)
        XCTAssertEqual(tracker.closeCount, 1)
        access.close()
        XCTAssertEqual(tracker.closeCount, 1)
        // A late success returns after the timeout. A second continuation resume
        // would crash this test instead of reaching the scope-close expectation.
    }

    func testUserCancellationReturnsWhileWorkerUnwinds() async throws {
        let started = expectation(description: "Worker started")
        let closed = expectation(description: "Worker released scope")
        let gate = DispatchSemaphore(value: 0)
        defer { gate.signal() }
        let tracker = ScopeTracker()
        let access = DocumentAccess(
            url: temporaryFile(), startAccess: { _ in true },
            stopAccess: { _ in tracker.didClose(); closed.fulfill() }
        )
        let task = Task {
            try await DocumentReader.read(from: access, timeout: 10) { _ in
                started.fulfill()
                gate.wait()
                return Data()
            }
        }
        await fulfillment(of: [started], timeout: 3)
        task.cancel()
        do {
            _ = try await task.value
            XCTFail("Expected user cancellation")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .cancelled)
        }
        XCTAssertEqual(tracker.closeCount, 0)
        gate.signal()
        await fulfillment(of: [closed], timeout: 3)
        XCTAssertEqual(tracker.closeCount, 1)
    }

    private func temporaryFile() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".tendies")
    }
}

private final class ScopeTracker: @unchecked Sendable {
    private let lock = NSLock()
    private var closes = 0
    private var reads = 0

    var closeCount: Int { lock.lock(); defer { lock.unlock() }; return closes }
    var readCount: Int { lock.lock(); defer { lock.unlock() }; return reads }
    func didClose() { lock.lock(); closes += 1; lock.unlock() }
    func didRead() { lock.lock(); reads += 1; lock.unlock() }
}
