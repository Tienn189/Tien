import Foundation
import XCTest
@testable import TendiesDecryptor

final class DocumentReaderTests: XCTestCase {
    func testImportsAnEncryptedTendiesFileAsRawBytesThenExportsZIP() async throws {
        // Independent AES-GCM fixture generated with Python cryptography; its
        // outer bytes are WALLIVE1, not a ZIP that a provider could recognize.
        let encrypted = Data([
            0x57, 0x41, 0x4c, 0x4c, 0x49, 0x56, 0x45, 0x31,
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
            0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16,
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
            0x08, 0x09, 0x0a, 0x0b, 0xf2, 0x43, 0x81, 0xb3,
            0xef, 0x7d, 0x2a, 0x56, 0x7e, 0x9c, 0x56, 0xed,
            0xc8, 0xdf, 0x3a, 0x6a, 0xeb, 0x6b, 0xcb, 0xb9,
            0x4f, 0xf1, 0xe8, 0x87, 0xcc, 0x12, 0xb9, 0xd5,
            0xe4, 0xe2, 0xec, 0x7b, 0xd2, 0x96, 0x56, 0xe0,
            0xab, 0x68
        ])
        let expectedZIP = Data([0x50, 0x4b, 0x05, 0x06] + [UInt8](repeating: 0, count: 18))
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        let source = directory.appendingPathComponent("encrypted.tendies")
        try encrypted.write(to: source)
        let input = try await DocumentReader.read(from: DocumentAccess(url: source))
        XCTAssertEqual(input, encrypted)
        let result = try WalliveDecryptor.decryptToZIP(input, originalName: source.lastPathComponent, outputDirectory: directory)
        XCTAssertEqual(try Data(contentsOf: result), expectedZIP)
        XCTAssertEqual(try Data(contentsOf: source), encrypted)
    }

    func testReadsDocumentInPlaceAndKeepsOriginal() async throws {
        let url = temporaryFile()
        defer { try? FileManager.default.removeItem(at: url) }
        let bytes = Data(repeating: 0x6a, count: 600_000)
        try bytes.write(to: url)
        let access = DocumentAccess(url: url)
        let data = try await DocumentReader.read(from: access)
        XCTAssertEqual(data, bytes)
        XCTAssertEqual(try Data(contentsOf: url), bytes)
    }

    func testOversizedDocumentIsRejectedBeforeReading() async throws {
        let url = temporaryFile()
        XCTAssertTrue(FileManager.default.createFile(atPath: url.path, contents: nil))
        defer { try? FileManager.default.removeItem(at: url) }
        let handle = try FileHandle(forWritingTo: url)
        try handle.truncate(atOffset: UInt64(WalliveDecryptor.maximumFileBytes + 1))
        try handle.close()
        do {
            _ = try await DocumentReader.read(from: DocumentAccess(url: url))
            XCTFail("Expected a size limit error")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .tooLarge)
        }
    }

    func testProviderErrorRetainsItsDomainAndCode() async throws {
        do {
            _ = try await DocumentReader.read(from: DocumentAccess(url: temporaryFile()))
            XCTFail("Expected an unavailable file error")
        } catch {
            guard let failure = error as? DocumentReadError,
                  case .provider(let domain, let code, _) = failure else {
                return XCTFail("Expected the underlying provider error, got \(error)")
            }
            XCTAssertFalse(domain.isEmpty)
            XCTAssertNotEqual(code, 0)
        }
    }

    func testAlreadyCancelledTaskDoesNotStartReadingAndClosesScope() async throws {
        let tracker = ScopeTracker()
        let access = DocumentAccess(
            url: temporaryFile(), startAccess: { _ in true },
            stopAccess: { _ in tracker.didClose() }
        )
        let task = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try await DocumentReader.read(from: access, timeout: 2) { _ in
                tracker.didRead()
                return Data()
            }
        }
        do {
            _ = try await task.value
            XCTFail("Expected cancellation")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .cancelled)
        }
        XCTAssertEqual(tracker.readCount, 0)
        XCTAssertEqual(tracker.closeCount, 1)
    }

    func testTimeoutReturnsWithoutClosingScopeWhileWorkerStillUsesIt() async throws {
        let started = expectation(description: "Worker started")
        let closed = expectation(description: "Scope closed after worker exit")
        let gate = DispatchSemaphore(value: 0)
        defer { gate.signal() }
        let tracker = ScopeTracker()
        let access = DocumentAccess(
            url: temporaryFile(), startAccess: { _ in true },
            stopAccess: { _ in tracker.didClose(); closed.fulfill() }
        )
        let task = Task {
            try await DocumentReader.read(from: access, timeout: 1) { _ in
                started.fulfill()
                gate.wait()
                return Data([1, 2, 3])
            }
        }
        await fulfillment(of: [started], timeout: 3)
        do {
            _ = try await task.value
            XCTFail("Expected timeout while the provider worker is blocked")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .timedOut)
        }
        XCTAssertEqual(tracker.closeCount, 0)
        gate.signal()
        await fulfillment(of: [closed], timeout: 3)
        XCTAssertEqual(tracker.closeCount, 1)
        access.close()
        XCTAssertEqual(tracker.closeCount, 1)
        // A late success returns after the timeout. A second continuation resume
        // would crash this test instead of reaching the scope-close expectation.
    }

    func testUserCancellationReturnsWhileWorkerUnwinds() async throws {
        let started = expectation(description: "Worker started")
        let closed = expectation(description: "Worker released scope")
        let gate = DispatchSemaphore(value: 0)
        defer { gate.signal() }
        let tracker = ScopeTracker()
        let access = DocumentAccess(
            url: temporaryFile(), startAccess: { _ in true },
            stopAccess: { _ in tracker.didClose(); closed.fulfill() }
        )
        let task = Task {
            try await DocumentReader.read(from: access, timeout: 10) { _ in
                started.fulfill()
                gate.wait()
                return Data()
            }
        }
        await fulfillment(of: [started], timeout: 3)
        task.cancel()
        do {
            _ = try await task.value
            XCTFail("Expected user cancellation")
        } catch {
            XCTAssertEqual(error as? DocumentReadError, .cancelled)
        }
        XCTAssertEqual(tracker.closeCount, 0)
        gate.signal()
        await fulfillment(of: [closed], timeout: 3)
        XCTAssertEqual(tracker.closeCount, 1)
    }

    private func temporaryFile() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".tendies")
    }
}

private final class ScopeTracker: @unchecked Sendable {
    private let lock = NSLock()
    private var closes = 0
    private var reads = 0

    var closeCount: Int { lock.lock(); defer { lock.unlock() }; return closes }
    var readCount: Int { lock.lock(); defer { lock.unlock() }; return reads }
    func didClose() { lock.lock(); closes += 1; lock.unlock() }
    func didRead() { lock.lock(); reads += 1; lock.unlock() }
}
