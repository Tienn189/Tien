import CryptoKit
import Foundation
import XCTest
@testable import TendiesDecryptor

final class WalliveDecryptorTests: XCTestCase {
    private let key = SymmetricKey(data: Data([
        0x9c, 0xd8, 0xfa, 0x4d, 0xbc, 0xc3, 0x57, 0x1a,
        0xcc, 0x3d, 0x21, 0xdc, 0xf6, 0x34, 0xd4, 0x30,
        0x5b, 0x58, 0xc3, 0xf1, 0xa0, 0x6d, 0x6c, 0xf5,
        0xfd, 0x29, 0x33, 0xaf, 0x9c, 0x8f, 0x7d, 0xef
    ]))
    // A valid empty ZIP archive (EOCD), without requiring a ZIP dependency.
    private let emptyZIP = Data([0x50, 0x4b, 0x05, 0x06] + [UInt8](repeating: 0, count: 18))

    private func encrypted(_ data: Data) throws -> Data {
        var header = Data("WALLIVE1".utf8) + Data(repeating: 0x12, count: 16)
        var length = UInt64(data.count).bigEndian
        withUnsafeBytes(of: &length) { header.append(contentsOf: $0) }
        let box = try AES.GCM.seal(data, using: key, authenticating: header)
        return header + box.combined!
    }

    func testAuthenticatesAndDecryptsZIP() throws {
        XCTAssertEqual(try WalliveDecryptor.decrypt(encrypted(emptyZIP)), emptyZIP)
    }

    func testCiphertextTamperingIsRejected() throws {
        var file = try encrypted(emptyZIP)
        file[44] ^= 1
        assertError(.authenticationFailed, from: file)
    }

    func testHeaderTamperingIsRejected() throws {
        var file = try encrypted(emptyZIP)
        file[8] ^= 1
        assertError(.authenticationFailed, from: file)
    }

    func testTruncationAndNewerFormatAreRecognized() throws {
        var file = try encrypted(emptyZIP)
        file.removeLast()
        assertError(.sizeMismatch, from: file)
        file[7] = UInt8(ascii: "2")
        assertError(.unsupportedVersion, from: file)
    }

    func testAlreadyDecryptedZIPIsRecognized() {
        assertError(.alreadyDecrypted, from: emptyZIP)
    }

    func testAlreadyDecryptedTendiesCanStillBeImportedAndExported() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let result = try WalliveDecryptor.decryptToZIP(
            emptyZIP, originalName: "already-decrypted.tendies", outputDirectory: directory
        )
        XCTAssertEqual(try Data(contentsOf: result), emptyZIP)
        XCTAssertEqual(result.lastPathComponent, "already-decrypted.decrypted.zip")
    }

    func testAuthenticatedNonZIPIsRejected() throws {
        assertError(.invalidPayload, from: try encrypted(Data("hello".utf8)))
    }

    func testForgedOversizedLengthIsRejectedWithoutOverflow() throws {
        var file = try encrypted(emptyZIP)
        for offset in 24..<32 { file[offset] = 0xff }
        assertError(.tooLarge, from: file)
    }

    func testSparseOversizedSourceIsRejectedBeforeReading() throws {
        let source = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        XCTAssertTrue(FileManager.default.createFile(atPath: source.path, contents: nil))
        defer { try? FileManager.default.removeItem(at: source) }
        let handle = try FileHandle(forWritingTo: source)
        try handle.truncate(atOffset: UInt64(WalliveDecryptor.maximumFileBytes + 1))
        try handle.close()
        XCTAssertThrowsError(try WalliveDecryptor.decryptFile(
            at: source, outputDirectory: FileManager.default.temporaryDirectory
        )) { error in
            XCTAssertEqual((error as? WalliveDecryptionError)?.localizedDescription,
                           WalliveDecryptionError.tooLarge.localizedDescription)
        }
    }

    func testFileOutputHasUniquePathAndPreservesSource() throws {
        let temporary = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: temporary, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: temporary) }
        let source = temporary.appendingPathComponent("milk_frog.tendies")
        let ciphertext = try encrypted(emptyZIP)
        try ciphertext.write(to: source)
        let first = try WalliveDecryptor.decryptFile(at: source, outputDirectory: temporary)
        let second = try WalliveDecryptor.decryptFile(at: source, outputDirectory: temporary)
        XCTAssertNotEqual(first, second)
        XCTAssertEqual(first.lastPathComponent, "milk_frog.decrypted.zip")
        XCTAssertEqual(try Data(contentsOf: first), emptyZIP)
        XCTAssertEqual(try Data(contentsOf: source), ciphertext)
    }

    private func assertError(_ expected: WalliveDecryptionError, from data: Data,
                             file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertThrowsError(try WalliveDecryptor.decrypt(data), file: file, line: line) { error in
            XCTAssertEqual((error as? WalliveDecryptionError)?.localizedDescription,
                           expected.localizedDescription, file: file, line: line)
        }
    }
}
