import SwiftUI
import UniformTypeIdentifiers
import UIKit

private struct DecryptionJob: Identifiable {
    enum Status {
        case processing(String)
        case complete(URL)
        case failed(String)
    }
    let id = UUID()
    let name: String
    var status: Status
}

@MainActor
private final class DecryptionModel: ObservableObject {
    @Published var jobs: [DecryptionJob] = []
    @Published var isWorking = false
    @Published var importError: String?
    @Published var activityText = ""
    @Published var lastImportEvent = "Chưa mở bộ chọn file."
    private var workTask: Task<Void, Never>?
    private var readingJobID: UUID?
    private var failedSources: [UUID: (url: URL, scopeURL: URL?)] = [:]

    var completedCount: Int {
        jobs.filter { if case .complete = $0.status { return true }; return false }.count
    }

    func process(_ urls: [URL], scopeURL: URL? = nil) {
        guard let source = urls.first else { return }
        guard !isWorking else {
            importError = "Đang xử lý một file. Hãy chờ hoàn tất hoặc nhấn Hủy trước."
            return
        }
        // This executes synchronously in the picker delegate, before dismissal.
        let access = DocumentAccess(url: source, scopeURL: scopeURL)
        let job = DecryptionJob(name: source.lastPathComponent, status: .processing("Đang nhận file…"))
        lastImportEvent = "Đã nhận file: \(source.lastPathComponent)"
        jobs.insert(job, at: 0)
        readingJobID = job.id
        isWorking = true
        activityText = "Đang nhận file…"
        importError = nil
        workTask = Task {
            defer {
                isWorking = false
                activityText = ""
                workTask = nil
                readingJobID = nil
            }
            do {
                let input = try await DocumentReader.read(from: access) { [weak self] progress in
                    Task { @MainActor [weak self] in
                        self?.showProgress(progress, for: job.id)
                    }
                }
                readingJobID = nil
                try Task.checkCancellation()
                lastImportEvent = "Đã đọc \(input.count) byte; đang kiểm tra dữ liệu mã hóa."
                activityText = "Đang giải mã…"
                update(job.id, status: .processing(activityText))
                let originalName = source.lastPathComponent
                let decryption = Task.detached(priority: .userInitiated) {
                    try Task.checkCancellation()
                    let cache = try FileManager.default.url(
                        for: .cachesDirectory, in: .userDomainMask,
                        appropriateFor: nil, create: true
                    ).appendingPathComponent("DecryptedExports", isDirectory: true)
                    let result = try WalliveDecryptor.decryptToZIP(
                        input, originalName: originalName, outputDirectory: cache
                    )
                    if Task.isCancelled {
                        try? FileManager.default.removeItem(at: result.deletingLastPathComponent())
                        throw CancellationError()
                    }
                    return result
                }
                let result = try await withTaskCancellationHandler {
                    try await decryption.value
                } onCancel: {
                    decryption.cancel()
                }
                if Task.isCancelled {
                    try? FileManager.default.removeItem(at: result.deletingLastPathComponent())
                    throw CancellationError()
                }
                update(job.id, status: .complete(result))
                lastImportEvent = "Đã xuất ZIP thành công."
            } catch is CancellationError {
                failedSources[job.id] = (source, scopeURL)
                update(job.id, status: .failed("Đã hủy nhập file."))
                lastImportEvent = "Đã hủy nhập file."
            } catch {
                failedSources[job.id] = (source, scopeURL)
                update(job.id, status: .failed(error.localizedDescription))
                lastImportEvent = error.localizedDescription
            }
        }
    }

    private func showProgress(_ progress: DocumentReadProgress, for id: UUID) {
        guard readingJobID == id,
              let job = jobs.first(where: { $0.id == id }), case .processing = job.status else { return }
        switch progress {
        case .preparing: activityText = "Đang kết nối với nơi lưu file…"
        case .downloading: activityText = "Đang tải file từ iCloud…"
        case .coordinating: activityText = "Đang nhận dữ liệu từ nơi lưu file…"
        case .reading(let bytes):
            let size = ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
            activityText = "Đang đọc file · \(size)"
        }
        lastImportEvent = activityText
        update(id, status: .processing(activityText))
    }

    func cancel() {
        workTask?.cancel()
    }

    func beginSelection() {
        importError = nil
        lastImportEvent = "Đã mở bộ chọn; đang chờ hệ thống bàn giao file."
    }

    func cancelSelection() {
        lastImportEvent = "Bộ chọn đã đóng mà chưa bàn giao file."
    }

    func retry(_ id: UUID) {
        guard !isWorking, let source = failedSources[id] else { return }
        process([source.url], scopeURL: source.scopeURL)
    }

    private func update(_ id: UUID, status: DecryptionJob.Status) {
        if let index = jobs.firstIndex(where: { $0.id == id }) {
            jobs[index].status = status
        }
    }

    func clear() {
        guard !isWorking else { return }
        for job in jobs {
            if case .complete(let url) = job.status {
                try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
            }
        }
        jobs.removeAll()
        failedSources.removeAll()
        importError = nil
    }
}

private struct SharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

private enum DenrindzTab: Hashable {
    case files, settings
}

private struct ImportActionLabelStyle: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(spacing: 16) {
            configuration.icon
                .font(.system(size: 22, weight: .medium))
                .frame(width: 48, height: 48)
                .background {
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(.tint).opacity(0.10)
                }
                .accessibilityHidden(true)
            configuration.title
                .font(.system(.body, design: .rounded).weight(.semibold))
                .multilineTextAlignment(.leading)
        }
    }
}

@MainActor
struct ContentView: View {
    @StateObject private var model = DecryptionModel()
    @StateObject private var exportModel = PosterBoardExportModel()
    @StateObject private var exportPresentation = PosterBoardExportPresentation()
    @State private var selectedTab: DenrindzTab = .files
    @State private var showImporter = false
    @State private var awaitingDecryptionSelection = false
    @State private var showInformation = false
    @State private var sharedFile: SharedFile?

    private var isWorking: Bool { model.isWorking || exportModel.isWorking }
    var body: some View {
        tabs
            .sheet(isPresented: $showImporter, onDismiss: {
                if awaitingDecryptionSelection {
                    model.cancelSelection()
                    awaitingDecryptionSelection = false
                }
            }) {
                LocalFilePicker(
                    onPick: { urls in
                        awaitingDecryptionSelection = false
                        receiveDecryptionFiles(urls)
                        showImporter = false
                    },
                    onCancel: {
                        awaitingDecryptionSelection = false
                        model.cancelSelection()
                        showImporter = false
                    }
                )
                .ignoresSafeArea()
                .denrindzDocumentSheet()
            }
            .sheet(item: $sharedFile) { file in
                ShareSheet(url: file.url)
                    .presentationDetents([.medium, .large])
            }
            .sheet(item: $exportPresentation.picker) { kind in
                PosterBoardSourcePicker(
                    kind: kind,
                    onPick: { url in receivePosterBoardExport(url) },
                    onCancel: { exportPresentation.picker = nil }
                )
                .ignoresSafeArea()
                .denrindzDocumentSheet()
            }
            .sheet(item: $exportPresentation.sharedFile) { file in
                PosterBoardShareSheet(url: file.url)
                    .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showInformation) { information }
            .onOpenURL { url in
                selectedTab = .files
                receiveDecryptionFiles([url])
            }
    }

    @ViewBuilder
    private var tabs: some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            nativeTabs
        } else {
            compatibleTabs
        }
        #else
        compatibleTabs
        #endif
    }

    private var nativeTabs: some View {
        TabView(selection: $selectedTab) {
            home
                .tabItem { Label("Nhập file", systemImage: "tray.and.arrow.down.fill") }
                .tag(DenrindzTab.files)
            settings
                .tabItem { Label("Cài đặt", systemImage: "gearshape.fill") }
                .tag(DenrindzTab.settings)
        }
    }

    // Keep both navigation stacks mounted so changing tabs preserves tasks and
    // the appearance page. iOS 26 uses the system's floating Liquid Glass bar.
    private var compatibleTabs: some View {
        ZStack {
            home
                .opacity(selectedTab == .files ? 1 : 0)
                .allowsHitTesting(selectedTab == .files)
                .accessibilityHidden(selectedTab != .files)
            settings
                .opacity(selectedTab == .settings ? 1 : 0)
                .allowsHitTesting(selectedTab == .settings)
                .accessibilityHidden(selectedTab != .settings)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            HStack(spacing: 4) {
                tabButton(.files, title: "Nhập file", icon: "tray.and.arrow.down.fill")
                tabButton(.settings, title: "Cài đặt", icon: "gearshape.fill")
            }
            .padding(6)
            .denrindzGlass(38)
            .padding(.horizontal, 26)
            .padding(.top, 8)
            .padding(.bottom, 6)
        }
    }

    private func tabButton(_ tab: DenrindzTab, title: String, icon: String) -> some View {
        let selected = selectedTab == tab
        return Button { selectedTab = tab } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 23, weight: .semibold))
                    .accessibilityHidden(true)
                Text(title).font(.caption.weight(.semibold))
            }
            .foregroundStyle(selected ? AnyShapeStyle(.tint) : AnyShapeStyle(.primary))
            .frame(maxWidth: .infinity, minHeight: 55)
            .background {
                if selected {
                    Capsule().fill(Color.primary.opacity(0.06))
                }
            }
            .contentShape(Capsule())
        }
        .buttonStyle(DenrindzPressStyle())
        .accessibilityLabel(title)
        .accessibilityValue(selected ? "Đang chọn" : "")
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private var home: some View {
        NavigationStack {
            ZStack {
                DenrindzBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        introduction
                        importSection
                        if model.isWorking || model.importError != nil { decryptionActivity }
                        PosterBoardExportFeedback(
                            model: exportModel,
                            presentation: exportPresentation,
                            isBlocked: model.isWorking,
                            canStart: { !model.isWorking }
                        )
                        if !model.jobs.isEmpty { results }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 14)
                    .padding(.bottom, 36)
                }
                .safeAreaInset(edge: .top, spacing: 0) { header }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var header: some View {
        HStack(spacing: 16) {
            Text("Denrindz")
                .font(.system(.largeTitle, design: .rounded).weight(.bold))
                .accessibilityAddTraits(.isHeader)
            Spacer(minLength: 8)
        }
        .padding(.horizontal, 22)
        .padding(.top, 8)
        .padding(.bottom, 18)
        .background { DenrindzHeaderBackdrop() }
    }

    private var settings: some View {
        NavigationStack {
            ZStack {
                DenrindzBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 26) {
                        HStack(spacing: 16) {
                            Image("BrandMark")
                                .resizable().scaledToFit()
                                .frame(width: 58, height: 58)
                                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                .accessibilityHidden(true)
                            VStack(alignment: .leading, spacing: 5) {
                                Text("Denrindz").font(.title3.weight(.bold))
                                Text("Phiên bản \(appVersion) (\(appBuild))")
                                    .font(.footnote).foregroundStyle(.secondary)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(22)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .denrindzGlass(30)

                        VStack(spacing: 0) {
                            NavigationLink {
                                AppearanceSettingsView()
                            } label: {
                                settingsRow("Giao diện", subtitle: "Màu sắc và chế độ hiển thị", icon: "paintpalette.fill")
                            }
                            Divider().padding(.leading, 74)
                            Button { showInformation = true } label: {
                                settingsRow("Hướng dẫn và thông tin", subtitle: "Cách nhập, lưu và chia sẻ file", icon: "book.closed.fill")
                            }
                        }
                        .buttonStyle(DenrindzPressStyle())
                        .denrindzGlass(30)

                        Label("File được xử lý trên thiết bị. Bản gốc được giữ nguyên.", systemImage: "lock.shield")
                            .font(.footnote).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.horizontal, 6)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 14)
                    .padding(.bottom, 36)
                }
                .safeAreaInset(edge: .top, spacing: 0) {
                    HStack {
                        Text("Cài đặt")
                            .font(.system(.largeTitle, design: .rounded).weight(.bold))
                            .accessibilityAddTraits(.isHeader)
                        Spacer()
                    }
                    .padding(.horizontal, 22).padding(.top, 8).padding(.bottom, 18)
                    .background { DenrindzHeaderBackdrop() }
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private func settingsRow(_ title: String, subtitle: String, icon: String) -> some View {
        HStack(spacing: 15) {
            Image(systemName: icon)
                .font(.system(size: 21, weight: .medium))
                .foregroundStyle(.tint)
                .frame(width: 36)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.body.weight(.semibold)).foregroundStyle(.primary)
                Text(subtitle).font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 8)
            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold)).foregroundStyle(.tertiary)
                .accessibilityHidden(true)
        }
        .padding(.horizontal, 20).padding(.vertical, 22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 21) {
            HStack {
                Text("KHÔNG GIAN CỦA BẠN")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.4)
                    .foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Text("v\(appVersion)")
                    .font(.caption2.monospaced().weight(.semibold))
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.primary.opacity(0.045), in: Capsule())
            }
            HStack(spacing: 16) {
                Image("BrandMark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 64, height: 64)
                    .clipShape(RoundedRectangle(cornerRadius: 19, style: .continuous))
                    .shadow(color: Color.blue.opacity(0.12), radius: 12, x: 0, y: 5)
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 5) {
                    Text("Denrindz")
                        .font(.system(.title2, design: .rounded).weight(.bold))
                    Text("Mở khoá sáng tạo.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            Text("Giải mã tendies. Đóng gói từ ZIP.\nNgay trên iPhone của bạn.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(24)
        .denrindzGlass(32)
    }

    private var importSection: some View {
        VStack(spacing: 0) {
            Button {
                beginDecryptionSelection()
            } label: {
                importRow("Nhập file tendies", systemImage: "square.and.arrow.down")
            }
            .disabled(isWorking)
            .accessibilityHint("Chọn file tendies mã hóa để giải mã thành ZIP")
            Divider().padding(.leading, 84)
            Button {
                guard !isWorking, exportModel.result == nil else { return }
                exportPresentation.selectionError = nil
                exportPresentation.picker = .zip
            } label: {
                importRow("Nhập file zip", systemImage: "doc.zipper")
            }
            .disabled(isWorking || exportModel.result != nil)
            .accessibilityHint("Chọn ZIP PosterBoard đã xuất để đóng gói thành tendies")
        }
        .buttonStyle(DenrindzPressStyle())
        .denrindzGlass(32)
    }

    private func importRow(_ title: String, systemImage: String) -> some View {
        HStack(spacing: 14) {
            AppActionLabel(title: title, systemImage: systemImage)
                .labelStyle(ImportActionLabelStyle())
            Spacer(minLength: 12)
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.tint)
                .opacity(0.45)
                .accessibilityHidden(true)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private var decryptionActivity: some View {
        DenrindzGlassSection("Đang giải mã") {
            if model.isWorking {
                HStack(spacing: 12) {
                    ProgressView()
                    Text(model.activityText)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Button("Hủy giải mã", role: .cancel) { model.cancel() }
                    .foregroundStyle(.primary)
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
            }
            if let message = model.importError {
                Label(message, systemImage: "exclamationmark.circle")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var results: some View {
        DenrindzGlassSection(
            "Kết quả giải mã · \(model.completedCount)/\(model.jobs.count)",
            footer: "Chọn nút chia sẻ → Lưu vào Tệp để giữ bản ZIP."
        ) {
            ForEach(model.jobs) { job in
                resultRow(job)
                Divider()
            }
            Button("Xóa kết quả giải mã", role: .destructive) { model.clear() }
                .disabled(isWorking)
                .accessibilityLabel("Xóa danh sách và các bản ZIP tạm")
        }
    }

    private func resultRow(_ job: DecryptionJob) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Group {
                switch job.status {
                case .processing: ProgressView()
                case .complete: Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                case .failed: Image(systemName: "exclamationmark.circle.fill").foregroundStyle(.red)
                }
            }
            .foregroundStyle(.secondary)
            .frame(width: 24, height: 24)
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 6) {
                Text(job.name)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(3)
                    .textSelection(.enabled)
                switch job.status {
                case .processing(let message):
                    Text(message).font(.caption).foregroundStyle(.secondary)
                case .complete(let url):
                    Text("ZIP sẵn sàng · \(fileSize(url))")
                        .font(.caption).foregroundStyle(.secondary)
                case .failed(let reason):
                    Text(reason).font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 18) {
                        Button("Thử lại") {
                            guard !isWorking else { return }
                            model.retry(job.id)
                        }
                        Button("Chọn lại") {
                            beginDecryptionSelection()
                        }
                    }
                    .buttonStyle(.borderless)
                    .foregroundStyle(.primary)
                    .disabled(isWorking)
                }
            }
            Spacer(minLength: 0)
            if case .complete(let url) = job.status {
                Button { sharedFile = SharedFile(url: url) } label: {
                    Image(systemName: "square.and.arrow.up")
                        .foregroundStyle(.primary)
                        .frame(minWidth: 44, minHeight: 44)
                        .denrindzGlass(22, interactive: true)
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Lưu hoặc chia sẻ bản giải mã của \(job.name)")
            }
        }
        .padding(.vertical, 4)
    }

    private var information: some View {
        NavigationStack {
            Form {
                Section("Giải mã file") {
                    Text("Nhấn Nhập file tendies để chọn file từ Tệp hoặc iCloud Drive. Khi hoàn tất, dùng nút chia sẻ và chọn Lưu vào Tệp.")
                    Text("Hỗ trợ WALLIVE1 cùng khóa với ứng dụng 交互壁纸 1.1.3 đã phân tích. File WALLIVE2 hoặc dùng khóa khác sẽ được báo lỗi.")
                }
                Section("Đóng gói .tendies") {
                    Text("Nhấn Nhập file zip để chọn ZIP PosterBoard đã xuất. Bản xuất cần có sẵn tài nguyên đã giải mã và thư mục cấu hình đầy đủ.")
                    Text("Tiến trình, kết quả và nút Lưu/chia sẻ .tendies xuất hiện ngay bên dưới. Chỉ các bộ chọn của Tệp và bảng chia sẻ mở riêng khi cần.")
                }
                Section("Giao diện") {
                    Text("Mở tab Cài đặt ở phía dưới, chọn Giao diện để đổi chế độ Sáng, Tối hoặc Theo hệ thống và màu chủ đề. Lựa chọn được lưu cho lần mở app tiếp theo.")
                }
                Section("Lưu trữ") {
                    Text("Các kết quả được lưu tạm trong bộ nhớ đệm. Dùng Lưu vào Tệp để giữ lâu dài. Xóa kết quả chỉ xóa bản tạm do app tạo trong phiên hiện tại.")
                    Text("Dữ liệu được xử lý trên thiết bị. File gốc được giữ nguyên.")
                }
                Section("Phiên bản") { Text(versionDescription) }
                Section("Bước nhập gần nhất") {
                    Text(model.lastImportEvent)
                        .font(.footnote)
                        .textSelection(.enabled)
                }
            }
            .scrollContentBackground(.hidden)
            .background { DenrindzBackground() }
            .navigationTitle("Denrindz")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { showInformation = false }
                        .foregroundStyle(.primary)
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.2.3"
    }

    private var appBuild: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "12"
    }

    private var versionDescription: String {
        "Denrindz · Phiên bản \(appVersion) (\(appBuild))"
    }

    private func beginDecryptionSelection() {
        guard !isWorking else { return }
        model.beginSelection()
        awaitingDecryptionSelection = true
        showImporter = true
    }

    private func receiveDecryptionFiles(_ urls: [URL], scopeURL: URL? = nil) {
        guard !isWorking else {
            model.importError = "Đang xử lý file khác. Hãy chờ hoàn tất rồi chọn lại."
            return
        }
        model.process(urls, scopeURL: scopeURL)
    }

    private func receivePosterBoardExport(_ url: URL) {
        defer { exportPresentation.picker = nil }
        guard !isWorking, exportModel.result == nil else {
            exportPresentation.selectionError = "Đang xử lý file khác. Hãy chọn lại sau khi hoàn tất."
            return
        }
        exportPresentation.selectionError = nil
        // The model acquires the provider scope synchronously before dismissal.
        exportModel.package(url)
    }

    private func fileSize(_ url: URL) -> String {
        let size = (try? PosterBoardPackager.fileSize(url)) ?? 0
        return ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }
}

/// Import raw bytes even when the provider cannot open a document in place.
@MainActor
private struct LocalFilePicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // Unknown .tendies UTIs can vary across providers. Validate bytes after import.
        let controller = UIDocumentPickerViewController(
            forOpeningContentTypes: FilePickerTypes.contentTypes(), asCopy: true
        )
        controller.allowsMultipleSelection = false
        controller.shouldShowFileExtensions = true
        controller.title = "Nhập file .tendies mã hóa"
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void
        private let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if urls.isEmpty { onCancel() } else { onPick(urls) }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
