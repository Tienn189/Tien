import SwiftUI
import UniformTypeIdentifiers
import UIKit

private struct DecryptionJob: Identifiable {
    enum Status {
        case processing(String)
        case complete(URL)
        case failed(String)
    }
    let id = UUID()
    let name: String
    var status: Status
}

@MainActor
private final class DecryptionModel: ObservableObject {
    @Published var jobs: [DecryptionJob] = []
    @Published var isWorking = false
    @Published var importError: String?
    @Published var activityText = ""
    @Published var lastImportEvent = "Chưa mở bộ chọn file."
    private var workTask: Task<Void, Never>?
    private var readingJobID: UUID?
    private var failedSources: [UUID: (url: URL, scopeURL: URL?)] = [:]

    var completedCount: Int {
        jobs.filter { if case .complete = $0.status { return true }; return false }.count
    }

    func process(_ urls: [URL], scopeURL: URL? = nil) {
        guard let source = urls.first else { return }
        guard !isWorking else {
            importError = "Đang xử lý một file. Hãy chờ hoàn tất hoặc nhấn Hủy trước."
            return
        }
        // This executes synchronously in the picker delegate, before dismissal.
        let access = DocumentAccess(url: source, scopeURL: scopeURL)
        let job = DecryptionJob(name: source.lastPathComponent, status: .processing("Đang nhận file…"))
        lastImportEvent = "Đã nhận file: \(source.lastPathComponent)"
        jobs.insert(job, at: 0)
        readingJobID = job.id
        isWorking = true
        activityText = "Đang nhận file…"
        importError = nil
        workTask = Task {
            defer {
                isWorking = false
                activityText = ""
                workTask = nil
                readingJobID = nil
            }
            do {
                let input = try await DocumentReader.read(from: access) { [weak self] progress in
                    Task { @MainActor [weak self] in
                        self?.showProgress(progress, for: job.id)
                    }
                }
                readingJobID = nil
                try Task.checkCancellation()
                lastImportEvent = "Đã đọc \(input.count) byte; đang kiểm tra dữ liệu mã hóa."
                activityText = "Đang giải mã…"
                update(job.id, status: .processing(activityText))
                let originalName = source.lastPathComponent
                let decryption = Task.detached(priority: .userInitiated) {
                    try Task.checkCancellation()
                    let cache = try FileManager.default.url(
                        for: .cachesDirectory, in: .userDomainMask,
                        appropriateFor: nil, create: true
                    ).appendingPathComponent("DecryptedExports", isDirectory: true)
                    let result = try WalliveDecryptor.decryptToZIP(
                        input, originalName: originalName, outputDirectory: cache
                    )
                    if Task.isCancelled {
                        try? FileManager.default.removeItem(at: result.deletingLastPathComponent())
                        throw CancellationError()
                    }
                    return result
                }
                let result = try await withTaskCancellationHandler {
                    try await decryption.value
                } onCancel: {
                    decryption.cancel()
                }
                if Task.isCancelled {
                    try? FileManager.default.removeItem(at: result.deletingLastPathComponent())
                    throw CancellationError()
                }
                update(job.id, status: .complete(result))
                lastImportEvent = "Đã xuất ZIP thành công."
            } catch is CancellationError {
                failedSources[job.id] = (source, scopeURL)
                update(job.id, status: .failed("Đã hủy nhập file."))
                lastImportEvent = "Đã hủy nhập file."
            } catch {
                failedSources[job.id] = (source, scopeURL)
                update(job.id, status: .failed(error.localizedDescription))
                lastImportEvent = error.localizedDescription
            }
        }
    }

    private func showProgress(_ progress: DocumentReadProgress, for id: UUID) {
        guard readingJobID == id,
              let job = jobs.first(where: { $0.id == id }), case .processing = job.status else { return }
        switch progress {
        case .preparing: activityText = "Đang kết nối với nơi lưu file…"
        case .downloading: activityText = "Đang tải file từ iCloud…"
        case .coordinating: activityText = "Đang nhận dữ liệu từ nơi lưu file…"
        case .reading(let bytes):
            let size = ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
            activityText = "Đang đọc file · \(size)"
        }
        lastImportEvent = activityText
        update(id, status: .processing(activityText))
    }

    func cancel() {
        workTask?.cancel()
    }

    func beginSelection() {
        importError = nil
        lastImportEvent = "Đã mở bộ chọn; đang chờ hệ thống bàn giao file."
    }

    func cancelSelection() {
        lastImportEvent = "Bộ chọn đã đóng mà chưa bàn giao file."
    }

    func retry(_ id: UUID) {
        guard !isWorking, let source = failedSources[id] else { return }
        process([source.url], scopeURL: source.scopeURL)
    }

    private func update(_ id: UUID, status: DecryptionJob.Status) {
        if let index = jobs.firstIndex(where: { $0.id == id }) {
            jobs[index].status = status
        }
    }

    func clear() {
        guard !isWorking else { return }
        for job in jobs {
            if case .complete(let url) = job.status {
                try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
            }
        }
        jobs.removeAll()
        failedSources.removeAll()
        importError = nil
    }
}

private struct SharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

private struct ImportActionLabelStyle: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(spacing: 14) {
            configuration.icon
                .font(.system(size: 21, weight: .semibold))
                .frame(width: 26)
                .accessibilityHidden(true)
            configuration.title
                .font(.body.weight(.semibold))
                .multilineTextAlignment(.leading)
        }
    }
}

@MainActor
struct ContentView: View {
    @Environment(\.colorScheme) private var colorScheme
    @StateObject private var model = DecryptionModel()
    @StateObject private var exportModel = PosterBoardExportModel()
    @StateObject private var exportPresentation = PosterBoardExportPresentation()
    @State private var showImporter = false
    @State private var showInformation = false
    @State private var showSettings = false
    @State private var sharedFile: SharedFile?

    private var isWorking: Bool { model.isWorking || exportModel.isWorking }
    private var backgroundColor: Color {
        colorScheme == .dark
            ? Color(red: 0.06, green: 0.06, blue: 0.08)
            : Color(red: 0.95, green: 0.95, blue: 0.975)
    }
    private var cardColor: Color {
        colorScheme == .dark
            ? Color(red: 0.12, green: 0.12, blue: 0.15)
            : .white
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                header
                Form {
                    introduction
                    importSection
                    if model.isWorking || model.importError != nil { decryptionActivity }
                    PosterBoardExportFeedback(
                        model: exportModel,
                        presentation: exportPresentation,
                        isBlocked: model.isWorking,
                        canStart: { !model.isWorking }
                    )
                    if !model.jobs.isEmpty { results }
                }
                .scrollContentBackground(.hidden)
            }
            .background(backgroundColor)
            .toolbar(.hidden, for: .navigationBar)
            .fullScreenCover(isPresented: $showImporter) {
                LocalFilePicker(
                    onPick: { urls in
                        receiveDecryptionFiles(urls)
                        showImporter = false
                    },
                    onCancel: {
                        model.cancelSelection()
                        showImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .sheet(item: $sharedFile) { file in
                ShareSheet(url: file.url)
                    .presentationDetents([.medium, .large])
            }
            .fullScreenCover(item: $exportPresentation.picker) { kind in
                PosterBoardSourcePicker(
                    kind: kind,
                    onPick: { url in receivePosterBoardExport(url) },
                    onCancel: { exportPresentation.picker = nil }
                )
                .ignoresSafeArea()
            }
            .sheet(item: $exportPresentation.sharedFile) { file in
                PosterBoardShareSheet(url: file.url)
                    .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showInformation) { information }
            .sheet(isPresented: $showSettings) { AppearanceSettingsView() }
            .onOpenURL { url in receiveDecryptionFiles([url]) }
        }
    }

    private var header: some View {
        HStack(spacing: 16) {
            Text("Denrindz")
                .font(.system(size: 23, weight: .bold, design: .rounded))
                .accessibilityAddTraits(.isHeader)
            Spacer(minLength: 8)
            HStack(spacing: 0) {
                Button { showInformation = true } label: {
                    Image(systemName: "info.circle")
                        .frame(width: 44, height: 44)
                }
                .accessibilityLabel("Hướng dẫn và thông tin")
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape")
                        .frame(width: 44, height: 44)
                }
                .accessibilityLabel("Cài đặt giao diện và màu chủ đề")
            }
            .font(.system(size: 20, weight: .medium))
            .foregroundStyle(.primary)
            .buttonStyle(.plain)
            .padding(.horizontal, 4)
            .background(cardColor, in: Capsule())
        }
        .padding(.horizontal, 24)
        .padding(.top, 12)
        .padding(.bottom, 2)
    }

    private var introduction: some View {
        Section {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 12) {
                    Image("BrandMark")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .accessibilityHidden(true)
                    Text("Denrindz")
                        .font(.system(size: 23, weight: .bold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    Spacer(minLength: 4)
                    Text("v\(appVersion)")
                        .font(.caption.monospaced().weight(.semibold))
                        .foregroundStyle(.tint)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background {
                            Capsule().fill(.tint).opacity(0.1)
                        }
                }
                Text("Giải mã tendies và đóng gói ZIP ngay trên iPhone.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(24)
            .background(cardColor, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
            .listRowInsets(EdgeInsets())
            .listRowBackground(Color.clear)
            .listRowSeparator(.hidden)
        }
    }

    private var importSection: some View {
        Section {
            VStack(spacing: 0) {
                Button {
                    guard !isWorking else { return }
                    model.beginSelection()
                    showImporter = true
                } label: {
                    importRow("Nhập file tendies", systemImage: "square.and.arrow.down")
                }
                .disabled(isWorking)
                .accessibilityHint("Chọn file tendies mã hóa để giải mã thành ZIP")
                Divider().padding(.leading, 62)
                Button {
                    guard !isWorking, exportModel.result == nil else { return }
                    exportPresentation.selectionError = nil
                    exportPresentation.picker = .zip
                } label: {
                    importRow("Nhập file zip", systemImage: "doc.zipper")
                }
                .disabled(isWorking || exportModel.result != nil)
                .accessibilityHint("Chọn ZIP PosterBoard đã xuất để đóng gói thành tendies")
            }
            .buttonStyle(.plain)
            .background(cardColor, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
            .listRowInsets(EdgeInsets())
            .listRowBackground(Color.clear)
            .listRowSeparator(.hidden)
        }
    }

    private func importRow(_ title: String, systemImage: String) -> some View {
        HStack(spacing: 14) {
            AppActionLabel(title: title, systemImage: systemImage)
                .labelStyle(ImportActionLabelStyle())
            Spacer(minLength: 12)
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(.tint)
                .opacity(0.45)
                .accessibilityHidden(true)
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private var decryptionActivity: some View {
        Section {
            if model.isWorking {
                HStack(spacing: 12) {
                    ProgressView()
                    Text(model.activityText)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Button("Hủy giải mã", role: .cancel) { model.cancel() }
                    .foregroundStyle(.primary)
            }
            if let message = model.importError {
                Label(message, systemImage: "exclamationmark.circle")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        } header: {
            Text("Đang giải mã")
        }
    }

    private var results: some View {
        Section {
            ForEach(model.jobs) { job in resultRow(job) }
            Button("Xóa kết quả giải mã", role: .destructive) { model.clear() }
                .disabled(isWorking)
                .accessibilityLabel("Xóa danh sách và các bản ZIP tạm")
        } header: {
            Text("Kết quả giải mã · \(model.completedCount)/\(model.jobs.count)")
        } footer: {
            Text("Chọn nút chia sẻ → Lưu vào Tệp để giữ bản ZIP.")
        }
    }

    private func resultRow(_ job: DecryptionJob) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Group {
                switch job.status {
                case .processing: ProgressView()
                case .complete: Image(systemName: "checkmark.circle")
                case .failed: Image(systemName: "exclamationmark.circle")
                }
            }
            .foregroundStyle(.secondary)
            .frame(width: 24, height: 24)
            .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 6) {
                Text(job.name)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(3)
                    .textSelection(.enabled)
                switch job.status {
                case .processing(let message):
                    Text(message).font(.caption).foregroundStyle(.secondary)
                case .complete(let url):
                    Text("ZIP sẵn sàng · \(fileSize(url))")
                        .font(.caption).foregroundStyle(.secondary)
                case .failed(let reason):
                    Text(reason).font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 18) {
                        Button("Thử lại") {
                            guard !isWorking else { return }
                            model.retry(job.id)
                        }
                        Button("Chọn lại") {
                            guard !isWorking else { return }
                            model.beginSelection()
                            showImporter = true
                        }
                    }
                    .buttonStyle(.borderless)
                    .foregroundStyle(.primary)
                    .disabled(isWorking)
                }
            }
            Spacer(minLength: 0)
            if case .complete(let url) = job.status {
                Button { sharedFile = SharedFile(url: url) } label: {
                    Image(systemName: "square.and.arrow.up")
                        .foregroundStyle(.primary)
                        .frame(minWidth: 44, minHeight: 44)
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Lưu hoặc chia sẻ bản giải mã của \(job.name)")
            }
        }
        .padding(.vertical, 4)
    }

    private var information: some View {
        NavigationStack {
            Form {
                Section("Giải mã file") {
                    Text("Nhấn Nhập file tendies để chọn file từ Tệp hoặc iCloud Drive. Khi hoàn tất, dùng nút chia sẻ và chọn Lưu vào Tệp.")
                    Text("Hỗ trợ WALLIVE1 cùng khóa với ứng dụng 交互壁纸 1.1.3 đã phân tích. File WALLIVE2 hoặc dùng khóa khác sẽ được báo lỗi.")
                }
                Section("Đóng gói .tendies") {
                    Text("Nhấn Nhập file zip để chọn ZIP PosterBoard đã xuất. Bản xuất cần có sẵn tài nguyên đã giải mã và thư mục cấu hình đầy đủ.")
                    Text("Tiến trình, kết quả và nút Lưu/chia sẻ .tendies xuất hiện ngay bên dưới. Chỉ các bộ chọn của Tệp và bảng chia sẻ mở riêng khi cần.")
                }
                Section("Giao diện") {
                    Text("Chọn nút bánh răng trên màn hình chính để đổi chế độ Sáng, Tối hoặc Theo hệ thống và màu chủ đề. Lựa chọn được lưu cho lần mở app tiếp theo.")
                }
                Section("Lưu trữ") {
                    Text("Các kết quả được lưu tạm trong bộ nhớ đệm. Dùng Lưu vào Tệp để giữ lâu dài. Xóa kết quả chỉ xóa bản tạm do app tạo trong phiên hiện tại.")
                    Text("Dữ liệu được xử lý trên thiết bị. File gốc được giữ nguyên.")
                }
                Section("Phiên bản") { Text(versionDescription) }
                Section("Bước nhập gần nhất") {
                    Text(model.lastImportEvent)
                        .font(.footnote)
                        .textSelection(.enabled)
                }
            }
            .navigationTitle("Denrindz")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { showInformation = false }
                        .foregroundStyle(.primary)
                }
            }
        }
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.2.1"
    }

    private var versionDescription: String {
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "10"
        return "Denrindz · Phiên bản \(appVersion) (\(build))"
    }

    private func receiveDecryptionFiles(_ urls: [URL], scopeURL: URL? = nil) {
        guard !isWorking else {
            model.importError = "Đang xử lý file khác. Hãy chờ hoàn tất rồi chọn lại."
            return
        }
        model.process(urls, scopeURL: scopeURL)
    }

    private func receivePosterBoardExport(_ url: URL) {
        defer { exportPresentation.picker = nil }
        guard !isWorking, exportModel.result == nil else {
            exportPresentation.selectionError = "Đang xử lý file khác. Hãy chọn lại sau khi hoàn tất."
            return
        }
        exportPresentation.selectionError = nil
        // The model acquires the provider scope synchronously before dismissal.
        exportModel.package(url)
    }

    private func fileSize(_ url: URL) -> String {
        let size = (try? PosterBoardPackager.fileSize(url)) ?? 0
        return ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }
}

/// Import raw bytes even when the provider cannot open a document in place.
@MainActor
private struct LocalFilePicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // Unknown .tendies UTIs can vary across providers. Validate bytes after import.
        let controller = UIDocumentPickerViewController(
            forOpeningContentTypes: FilePickerTypes.contentTypes(), asCopy: true
        )
        controller.allowsMultipleSelection = false
        controller.shouldShowFileExtensions = true
        controller.title = "Nhập file .tendies mã hóa"
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void
        private let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if urls.isEmpty { onCancel() } else { onPick(urls) }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
