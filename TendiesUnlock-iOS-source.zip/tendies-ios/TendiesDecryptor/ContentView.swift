import SwiftUI
import UniformTypeIdentifiers
import UIKit

private extension Color {
    static let unlockBackground = Color(red: 0.055, green: 0.075, blue: 0.09)
    static let unlockPanel = Color(red: 0.095, green: 0.12, blue: 0.14)
    static let unlockAccent = Color(red: 0.76, green: 0.96, blue: 0.43)
    static let unlockMuted = Color(red: 0.60, green: 0.67, blue: 0.70)
}

private struct DecryptionJob: Identifiable {
    enum Status {
        case processing(String)
        case complete(URL)
        case failed(String)
    }
    let id = UUID()
    let name: String
    var status: Status
}

@MainActor
private final class DecryptionModel: ObservableObject {
    @Published var jobs: [DecryptionJob] = []
    @Published var isWorking = false
    @Published var importError: String?
    @Published var activityText = ""
    private var workTask: Task<Void, Never>?
    private var readingJobID: UUID?
    private var failedSources: [UUID: (url: URL, scopeURL: URL?)] = [:]

    var completedCount: Int {
        jobs.filter { if case .complete = $0.status { return true }; return false }.count
    }

    func process(_ urls: [URL], scopeURL: URL? = nil) {
        guard let source = urls.first else { return }
        guard !isWorking else {
            importError = "Đang xử lý một file. Hãy chờ hoàn tất hoặc nhấn Hủy trước."
            return
        }
        // This executes synchronously in the picker delegate, before dismissal.
        let access = DocumentAccess(url: source, scopeURL: scopeURL)
        let job = DecryptionJob(name: source.lastPathComponent, status: .processing("Đang nhận file…"))
        jobs.insert(job, at: 0)
        readingJobID = job.id
        isWorking = true
        activityText = "Đang nhận file…"
        importError = nil
        workTask = Task {
            defer {
                isWorking = false
                activityText = ""
                workTask = nil
                readingJobID = nil
            }
            do {
                let input = try await DocumentReader.read(from: access) { [weak self] progress in
                    Task { @MainActor [weak self] in
                        self?.showProgress(progress, for: job.id)
                    }
                }
                readingJobID = nil
                try Task.checkCancellation()
                activityText = "Đang giải mã…"
                update(job.id, status: .processing(activityText))
                let originalName = source.lastPathComponent
                let decryption = Task.detached(priority: .userInitiated) {
                    try Task.checkCancellation()
                    let cache = try FileManager.default.url(
                        for: .cachesDirectory, in: .userDomainMask,
                        appropriateFor: nil, create: true
                    ).appendingPathComponent("DecryptedExports", isDirectory: true)
                    let result = try WalliveDecryptor.decryptToZIP(
                        input, originalName: originalName, outputDirectory: cache
                    )
                    if Task.isCancelled {
                        try? FileManager.default.removeItem(at: result.deletingLastPathComponent())
                        throw CancellationError()
                    }
                    return result
                }
                let result = try await withTaskCancellationHandler {
                    try await decryption.value
                } onCancel: {
                    decryption.cancel()
                }
                if Task.isCancelled {
                    try? FileManager.default.removeItem(at: result.deletingLastPathComponent())
                    throw CancellationError()
                }
                update(job.id, status: .complete(result))
            } catch is CancellationError {
                failedSources[job.id] = (source, scopeURL)
                update(job.id, status: .failed("Đã hủy nhập file."))
            } catch {
                failedSources[job.id] = (source, scopeURL)
                update(job.id, status: .failed(error.localizedDescription))
            }
        }
    }

    private func showProgress(_ progress: DocumentReadProgress, for id: UUID) {
        guard readingJobID == id,
              let job = jobs.first(where: { $0.id == id }), case .processing = job.status else { return }
        switch progress {
        case .preparing: activityText = "Đang kết nối với nơi lưu file…"
        case .downloading: activityText = "Đang tải file từ iCloud…"
        case .reading(let bytes):
            let size = ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
            activityText = "Đang đọc file · \(size)"
        }
        update(id, status: .processing(activityText))
    }

    func cancel() {
        workTask?.cancel()
    }

    func retry(_ id: UUID) {
        guard !isWorking, let source = failedSources[id] else { return }
        process([source.url], scopeURL: source.scopeURL)
    }

    private func update(_ id: UUID, status: DecryptionJob.Status) {
        if let index = jobs.firstIndex(where: { $0.id == id }) {
            jobs[index].status = status
        }
    }

    func clear() {
        guard !isWorking else { return }
        for job in jobs {
            if case .complete(let url) = job.status {
                try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
            }
        }
        jobs.removeAll()
        failedSources.removeAll()
        importError = nil
    }
}

private struct SharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

@MainActor
struct ContentView: View {
    @StateObject private var model = DecryptionModel()
    @State private var showImporter = false
    @State private var showFolderBrowser = false
    @State private var showInformation = false
    @State private var sharedFile: SharedFile?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    brand
                    introduction
                    importCard
                    if let message = model.importError {
                        Label(message, systemImage: "exclamationmark.triangle")
                            .font(.subheadline)
                            .foregroundStyle(.orange)
                    }
                    if !model.jobs.isEmpty { results }
                    privacyNote
                }
                .padding(24)
                .frame(maxWidth: 680, alignment: .leading)
                .frame(maxWidth: .infinity)
            }
            .background(Color.unlockBackground.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .fullScreenCover(isPresented: $showImporter) {
                LocalFilePicker(
                    onPick: { urls in
                        model.process(urls)
                        showImporter = false
                    },
                    onCancel: { showImporter = false }
                )
                .ignoresSafeArea()
            }
            .sheet(item: $sharedFile) { file in
                ShareSheet(url: file.url)
                    .presentationDetents([.medium, .large])
            }
            .sheet(isPresented: $showInformation) { information }
            .sheet(isPresented: $showFolderBrowser) {
                FolderImportView { file, folder in
                    model.process([file], scopeURL: folder)
                    showFolderBrowser = false
                }
            }
            .onOpenURL { url in
                if model.isWorking {
                    model.importError = "Đang xử lý file khác. Hãy chờ hoàn tất rồi mở lại file này."
                } else {
                    model.process([url])
                }
            }
        }
        .tint(Color.unlockAccent)
    }

    private var brand: some View {
        HStack(spacing: 10) {
            Image(systemName: "lock.open.fill")
                .foregroundStyle(Color.unlockBackground)
                .frame(width: 36, height: 36)
                .background(Color.unlockAccent, in: RoundedRectangle(cornerRadius: 12))
            Text("TENDIES UNLOCK")
                .font(.system(.caption, design: .monospaced, weight: .bold))
                .tracking(2)
            Spacer()
            Button { showInformation = true } label: {
                Image(systemName: "info.circle")
                    .font(.title3)
                    .foregroundStyle(Color.unlockMuted)
                    .frame(width: 44, height: 44)
            }
            .accessibilityLabel("Thông tin ứng dụng")
        }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("File của bạn.\nMở ngay trên máy.")
                .font(.system(size: 36, weight: .bold, design: .rounded))
                .tracking(-1)
                .fixedSize(horizontal: false, vertical: true)
            Text("Giải mã gói .tendies thành ZIP để xem và chỉnh sửa nội dung.")
                .font(.body)
                .foregroundStyle(Color.unlockMuted)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                badge("WALLIVE1", symbol: "doc.zipper")
                badge("Ngoại tuyến", symbol: "wifi.slash")
            }
        }
    }

    private func badge(_ title: String, symbol: String) -> some View {
        Label(title, systemImage: symbol)
            .font(.system(size: 11, weight: .medium))
            .foregroundStyle(Color.unlockAccent)
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(Color.unlockAccent.opacity(0.08), in: Capsule())
    }

    private var importCard: some View {
        VStack(spacing: 18) {
            ZStack {
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color.unlockAccent.opacity(0.07))
                    .frame(width: 86, height: 86)
                    .rotationEffect(.degrees(-8))
                Image(systemName: model.isWorking ? "lock.rotation" : "doc.badge.arrow.up")
                    .font(.system(size: 35, weight: .light))
                    .foregroundStyle(Color.unlockAccent)
            }
            VStack(spacing: 7) {
                Text(model.isWorking ? model.activityText : "Chọn file .tendies")
                    .font(.title3.weight(.semibold))
                Text(model.isWorking ? "Có thể hủy và thử lại ngay trong ứng dụng." : "Chọn file trực tiếp từ Tệp · Tối đa 64 MiB/file")
                    .font(.footnote)
                    .foregroundStyle(Color.unlockMuted)
                    .multilineTextAlignment(.center)
            }
            Button { showImporter = true } label: {
                HStack(spacing: 10) {
                    if model.isWorking {
                        ProgressView().tint(Color.unlockBackground)
                    } else {
                        Image(systemName: "folder.badge.plus")
                    }
                    Text(model.isWorking ? "Đang xử lý" : "Chọn file để giải mã")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 17)
                .foregroundStyle(Color.unlockBackground)
                .background(Color.unlockAccent, in: RoundedRectangle(cornerRadius: 15))
                .opacity(model.isWorking ? 0.65 : 1)
            }
            .buttonStyle(.plain)
            .disabled(model.isWorking)
            if !model.isWorking {
                Button { showFolderBrowser = true } label: {
                    Label("Chọn từ thư mục", systemImage: "folder")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                }
                Text("Nếu file bị mờ: chọn thư mục chứa file, rồi chọn file trong danh sách của app.")
                    .font(.caption)
                    .foregroundStyle(Color.unlockMuted)
                    .multilineTextAlignment(.center)
            }
            if model.isWorking {
                Button("Hủy nhập file", role: .cancel) { model.cancel() }
                    .font(.subheadline)
                    .padding(.vertical, 6)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.unlockPanel, in: RoundedRectangle(cornerRadius: 26))
        .overlay {
            RoundedRectangle(cornerRadius: 26)
                .strokeBorder(Color.white.opacity(0.07), lineWidth: 1)
        }
    }

    private var results: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Kết quả")
                    .font(.title3.weight(.semibold))
                Text("\(model.completedCount)/\(model.jobs.count)")
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(Color.unlockMuted)
                Spacer()
                Button("Xóa") { model.clear() }
                    .font(.subheadline)
                    .disabled(model.isWorking)
                    .accessibilityLabel("Xóa danh sách và các bản ZIP tạm")
            }
            ForEach(model.jobs) { job in
                resultRow(job)
            }
            Text("Nhấn nút chia sẻ rồi chọn “Lưu vào Tệp” để giữ bản ZIP. Các bản tạm có thể bị iOS dọn dẹp.")
                .font(.footnote)
                .foregroundStyle(Color.unlockMuted)
        }
    }

    private func resultRow(_ job: DecryptionJob) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Group {
                switch job.status {
                case .processing: ProgressView().tint(Color.unlockAccent)
                case .complete: Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.unlockAccent)
                case .failed: Image(systemName: "exclamationmark.circle.fill").foregroundStyle(.orange)
                }
            }
            .font(.title3)
            .frame(width: 24, height: 24)
            VStack(alignment: .leading, spacing: 6) {
                Text(job.name)
                    .font(.subheadline.weight(.medium))
                    .lineLimit(2)
                    .textSelection(.enabled)
                switch job.status {
                case .processing(let message):
                    Text(message)
                        .font(.caption).foregroundStyle(Color.unlockMuted)
                case .complete(let url):
                    Text("ZIP sẵn sàng · \(fileSize(url))")
                        .font(.caption).foregroundStyle(Color.unlockAccent)
                case .failed(let reason):
                    Text(reason).font(.caption).foregroundStyle(.orange)
                    HStack(spacing: 18) {
                        Button("Thử lại") { model.retry(job.id) }
                        Button("Chọn lại file") { showImporter = true }
                    }
                    .font(.subheadline.weight(.medium))
                    .disabled(model.isWorking)
                }
            }
            Spacer(minLength: 0)
            if case .complete(let url) = job.status {
                Button { sharedFile = SharedFile(url: url) } label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.title3)
                        .frame(width: 44, height: 44)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12))
                }
                .accessibilityLabel("Lưu hoặc chia sẻ bản giải mã của \(job.name)")
            }
        }
        .padding(16)
        .background(Color.unlockPanel, in: RoundedRectangle(cornerRadius: 18))
    }

    private var privacyNote: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.shield")
                .foregroundStyle(Color.unlockAccent)
            Text("File được xử lý hoàn toàn trên iPhone. Không tải lên máy chủ. File gốc được giữ nguyên.")
                .font(.footnote)
                .foregroundStyle(Color.unlockMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.bottom, 12)
    }

    private var information: some View {
        NavigationStack {
            List {
                Section("Cách dùng") {
                    Label("Chọn file từ Tệp hoặc iCloud Drive.", systemImage: "1.circle")
                    Label("Chờ ứng dụng xác thực và giải mã.", systemImage: "2.circle")
                    Label("Chia sẻ → Lưu vào Tệp. Nhấn ZIP trong Tệp để giải nén.", systemImage: "3.circle")
                    Text("File bị mờ trong bộ chọn iOS: dùng Chọn từ thư mục, mở thư mục chứa file rồi chọn .tendies từ danh sách bên trong app. File được đọc tại chỗ.")
                    Text("Ứng dụng đọc file trực tiếp và tự yêu cầu tải dữ liệu iCloud khi cần. Trong lúc chờ, có thể nhấn Hủy nhập file. Nếu nhà cung cấp file báo lỗi, nhấn Thử lại trong danh sách kết quả.")
                }
                Section("Định dạng hỗ trợ") {
                    Text("Gói WALLIVE1 dùng khóa của ứng dụng 交互壁纸 1.1.3 đã phân tích. Đuôi file có thể là .tendies hoặc .wallive.")
                    Text("WALLIVE2, file dùng khóa khác và ZIP chưa mã hóa không được hỗ trợ.")
                    Text("Tối đa 64 MiB mỗi file. Ứng dụng xuất ZIP; không cài hình nền và không mã hóa lại file đã sửa.")
                }
                Section("Lưu trữ") {
                    Text("ZIP được lưu tạm trong bộ nhớ đệm của ứng dụng. Dùng Lưu vào Tệp để giữ lâu dài. Nút Xóa chỉ xóa danh sách và các bản ZIP tạm của phiên hiện tại.")
                }
                Section("Phiên bản") {
                    Text(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0.3")
                }
            }
            .navigationTitle("Tendies Unlock")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { showInformation = false }
                }
            }
        }
        .tint(Color.unlockAccent)
    }

    private func fileSize(_ url: URL) -> String {
        let values = try? url.resourceValues(forKeys: [.fileSizeKey])
        return ByteCountFormatter.string(fromByteCount: Int64(values?.fileSize ?? 0), countStyle: .file)
    }
}

/// Open the selected document without requesting an imported copy.
@MainActor
private struct LocalFilePicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // Unknown .tendies UTIs can vary across providers. Validate bytes after import.
        let controller = UIDocumentPickerViewController(
            forOpeningContentTypes: FilePickerTypes.contentTypes(), asCopy: false
        )
        controller.allowsMultipleSelection = false
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void
        private let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if urls.isEmpty { onCancel() } else { onPick(urls) }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
