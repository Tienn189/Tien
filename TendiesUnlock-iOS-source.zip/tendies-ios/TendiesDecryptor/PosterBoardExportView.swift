import SwiftUI
import UniformTypeIdentifiers
import UIKit

/// The home view retains this model while the inline packaging section is displayed.
@MainActor
final class PosterBoardExportModel: ObservableObject {
    @Published private(set) var isWorking = false
    @Published private(set) var isCancelling = false
    @Published private(set) var progress: PosterBoardPackageProgress?
    @Published private(set) var result: PosterBoardPackageResult?
    @Published private(set) var errorMessage: String?
    @Published private(set) var sourceName: String?

    private var sourceURL: URL?
    private var resultDirectory: URL?
    private var workTask: Task<Void, Never>?
    private var activeCancellation: PosterBoardPackageCancellation?
    private var activeJobID: UUID?

    var canRetry: Bool { sourceURL != nil && !isWorking && result == nil }

    func package(_ url: URL) {
        guard !isWorking, result == nil else { return }
        // Acquire inside the picker delegate, before the picker relinquishes access.
        let access = DocumentAccess(url: url)
        let cancellation = PosterBoardPackageCancellation()
        let jobID = UUID()
        sourceURL = url
        sourceName = url.lastPathComponent
        activeJobID = jobID
        activeCancellation = cancellation
        errorMessage = nil
        progress = PosterBoardPackageProgress(
            message: "Đang nhận bản xuất PosterBoard…", completedBytes: 0, totalBytes: nil
        )
        isCancelling = false
        isWorking = true

        workTask = Task {
            var pendingDirectory: URL?
            defer {
                // Awaiting the detached worker also waits for cancellation cleanup.
                // Never release the provider's scope while that worker still runs.
                access.close()
                if let pendingDirectory {
                    try? FileManager.default.removeItem(at: pendingDirectory)
                }
                activeJobID = nil
                activeCancellation = nil
                isWorking = false
                isCancelling = false
                workTask = nil
            }
            do {
                let caches = try FileManager.default.url(
                    for: .cachesDirectory, in: .userDomainMask,
                    appropriateFor: nil, create: true
                )
                let directory = caches
                    .appendingPathComponent("PosterBoardExports", isDirectory: true)
                    .appendingPathComponent(jobID.uuidString, isDirectory: true)
                pendingDirectory = directory
                let report: @Sendable (PosterBoardPackageProgress) -> Void = { [weak self] update in
                    Task { @MainActor [weak self] in
                        guard let self, self.activeJobID == jobID,
                              self.isWorking, !self.isCancelling else { return }
                        self.progress = update
                    }
                }
                let worker = Task.detached(priority: .userInitiated) {
                    defer { access.close() }
                    do {
                        try Task.checkCancellation()
                        try FileManager.default.createDirectory(
                            at: directory, withIntermediateDirectories: true
                        )
                        let result = try PosterBoardPackager.package(
                            sourceURL: access.url, outputDirectory: directory,
                            cancellation: cancellation, progress: report
                        )
                        try Task.checkCancellation()
                        return result
                    } catch {
                        // Only this job's directory belongs to this operation.
                        try? FileManager.default.removeItem(at: directory)
                        throw error
                    }
                }
                let packaged = try await withTaskCancellationHandler {
                    try await worker.value
                } onCancel: {
                    cancellation.cancel()
                    worker.cancel()
                }
                try Task.checkCancellation()
                result = packaged
                resultDirectory = directory
                pendingDirectory = nil
                progress = nil
            } catch is CancellationError {
                progress = nil
                errorMessage = "Đã hủy đóng gói. Bạn có thể thử lại hoặc chọn bản xuất khác."
            } catch {
                progress = nil
                errorMessage = error.localizedDescription
            }
        }
    }

    func cancel() {
        guard isWorking else { return }
        isCancelling = true
        activeCancellation?.cancel()
        workTask?.cancel()
    }

    func retry() {
        guard canRetry, let sourceURL else { return }
        package(sourceURL)
    }

    func clear() {
        guard !isWorking else { return }
        if let resultDirectory {
            try? FileManager.default.removeItem(at: resultDirectory)
        }
        resultDirectory = nil
        result = nil
        progress = nil
        errorMessage = nil
        sourceURL = nil
        sourceName = nil
    }

    deinit {
        activeCancellation?.cancel()
        workTask?.cancel()
    }
}

/// Presentation state lives with the home screen, outside scrolling feedback.
@MainActor
final class PosterBoardExportPresentation: ObservableObject {
    @Published var picker: PosterBoardSourceKind?
    @Published var sharedFile: PosterBoardSharedFile?
    @Published var selectionError: String?
}

/// Progress, errors and results appear after the home screen's ZIP action is used.
@MainActor
struct PosterBoardExportFeedback: View {
    @ObservedObject var model: PosterBoardExportModel
    @ObservedObject var presentation: PosterBoardExportPresentation
    var isBlocked = false
    // Reads the parent's current workflow state before retrying.
    // The home screen applies the same live guard to the picker callback.
    var canStart: () -> Bool = { true }

    private var visibleError: String? { presentation.selectionError ?? model.errorMessage }

    var body: some View {
        Group {
            if model.isWorking { progressSection }
            if let message = visibleError { failureSection(message) }
            if let result = model.result { resultSection(result) }
        }
    }

    private var progressSection: some View {
        DenrindzGlassSection("Đang đóng gói") {
            HStack(alignment: .top, spacing: 12) {
                ProgressView()
                    .padding(.top, 2)
                VStack(alignment: .leading, spacing: 5) {
                    Text(model.isCancelling ? "Đang hủy và dọn file tạm…" : (model.progress?.message ?? "Đang đóng gói…"))
                        .font(.subheadline)
                        .fixedSize(horizontal: false, vertical: true)
                    if let name = model.sourceName {
                        Text(name)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                    }
                }
            }
            .padding(.vertical, 4)
            if !model.isCancelling, let progress = model.progress {
                if let total = progress.totalBytes, total > 0 {
                    VStack(alignment: .leading, spacing: 8) {
                        ProgressView(value: Double(min(max(progress.completedBytes, 0), total)), total: Double(total))
                            .accessibilityLabel("Tiến trình đóng gói")
                        Text("\(size(progress.completedBytes)) / \(size(total))")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 4)
                } else if progress.completedBytes > 0 {
                    Text("Đã xử lý \(size(progress.completedBytes))")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
            Button("Hủy đóng gói", role: .cancel) { model.cancel() }
                .foregroundStyle(.primary)
                .buttonStyle(.bordered)
                .buttonBorderShape(.capsule)
                .disabled(model.isCancelling)
        }
    }

    private func failureSection(_ message: String) -> some View {
        DenrindzGlassSection(
            "Chưa thể đóng gói",
            footer: "Nhấn Nhập file zip ở trên để chọn lại bản xuất đầy đủ."
        ) {
            Label {
                Text(message)
                    .font(.subheadline)
                    .fixedSize(horizontal: false, vertical: true)
            } icon: {
                Image(systemName: "exclamationmark.triangle")
                    .foregroundStyle(.red)
            }
            if presentation.selectionError == nil && model.canRetry {
                Button("Thử lại bản xuất này") {
                    guard !isBlocked, canStart() else {
                        presentation.selectionError = "Đang xử lý file khác. Hãy chọn lại sau khi hoàn tất."
                        return
                    }
                    presentation.selectionError = nil
                    model.retry()
                }
                .disabled(isBlocked || model.isWorking || model.result != nil)
                .foregroundStyle(.primary)
                .buttonStyle(.bordered)
                .buttonBorderShape(.capsule)
            }
        }
    }

    private func resultSection(_ result: PosterBoardPackageResult) -> some View {
        DenrindzGlassSection(
            "Kết quả đóng gói",
            footer: "Chọn “Lưu vào Tệp” trong bảng chia sẻ để giữ kết quả. File trong bộ nhớ đệm có thể bị iOS dọn dẹp."
        ) {
            Label("Đã tạo .tendies", systemImage: "checkmark.circle")
                .font(.headline)
                .foregroundStyle(.green)
            Text(result.fileURL.lastPathComponent)
                .font(.subheadline)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 7) {
                Text("\(result.descriptorCount) cấu hình · \(result.fileCount) file")
                Text("\(size(result.originalBytes)) → \(size(result.archiveBytes))")
                if !result.wallpaperNames.isEmpty {
                    Text("Hình nền: \(result.wallpaperNames.joined(separator: ", "))")
                }
                if result.omittedFiles > 0 {
                    Text("Đã bỏ qua \(result.omittedFiles) mục không thuộc tài nguyên hình nền.")
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)
            Button {
                presentation.sharedFile = PosterBoardSharedFile(url: result.fileURL)
            } label: {
                AppActionLabel(title: "Lưu/chia sẻ .tendies", systemImage: "square.and.arrow.up")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .denrindzGlass(24, interactive: true)
            }
            .buttonStyle(DenrindzPressStyle())
            Divider()
            Button("Xóa kết quả", role: .destructive) { model.clear() }
                .disabled(model.isWorking || presentation.sharedFile != nil)
                .accessibilityLabel("Xóa bản .tendies tạm của lần đóng gói này")
        }
    }

    private func size(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}

enum PosterBoardSourceKind: String, Identifiable {
    case zip, folder
    var id: String { rawValue }
}

@MainActor
struct PosterBoardSourcePicker: UIViewControllerRepresentable {
    let kind: PosterBoardSourceKind
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onCancel: onCancel) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let controller = UIDocumentPickerViewController(
            forOpeningContentTypes: kind == .folder ? [.folder] : [.zip, .archive, .data],
            asCopy: kind == .zip
        )
        controller.allowsMultipleSelection = false
        controller.shouldShowFileExtensions = true
        controller.title = kind == .folder ? "Chọn thư mục PosterBoard đã xuất" : "Chọn ZIP PosterBoard đã xuất"
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {
        context.coordinator.onPick = onPick
        context.coordinator.onCancel = onCancel
    }

    @MainActor
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        var onPick: (URL) -> Void
        var onCancel: () -> Void

        init(onPick: @escaping (URL) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let url = urls.first { onPick(url) } else { onCancel() }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onCancel() }
    }
}

struct PosterBoardSharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

struct PosterBoardShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
