import SwiftUI
import UniformTypeIdentifiers
import UIKit

private extension Color {
    static let posterBackground = Color(red: 0.055, green: 0.075, blue: 0.09)
    static let posterPanel = Color(red: 0.095, green: 0.12, blue: 0.14)
    static let posterAccent = Color(red: 0.76, green: 0.96, blue: 0.43)
    static let posterMuted = Color(red: 0.60, green: 0.67, blue: 0.70)
}

/// The home view retains this model so a completed export survives closing its sheet.
@MainActor
final class PosterBoardExportModel: ObservableObject {
    @Published private(set) var isWorking = false
    @Published private(set) var isCancelling = false
    @Published private(set) var progress: PosterBoardPackageProgress?
    @Published private(set) var result: PosterBoardPackageResult?
    @Published private(set) var errorMessage: String?
    @Published private(set) var sourceName: String?

    private var sourceURL: URL?
    private var resultDirectory: URL?
    private var workTask: Task<Void, Never>?
    private var activeCancellation: PosterBoardPackageCancellation?
    private var activeJobID: UUID?

    var canRetry: Bool { sourceURL != nil && !isWorking && result == nil }

    func package(_ url: URL) {
        guard !isWorking, result == nil else { return }
        // Acquire inside the picker delegate, before the picker relinquishes access.
        let access = DocumentAccess(url: url)
        let cancellation = PosterBoardPackageCancellation()
        let jobID = UUID()
        sourceURL = url
        sourceName = url.lastPathComponent
        activeJobID = jobID
        activeCancellation = cancellation
        errorMessage = nil
        progress = PosterBoardPackageProgress(
            message: "Đang nhận bản xuất PosterBoard…", completedBytes: 0, totalBytes: nil
        )
        isCancelling = false
        isWorking = true

        workTask = Task {
            var pendingDirectory: URL?
            defer {
                // Awaiting the detached worker also waits for cancellation cleanup.
                // Never release the provider's scope while that worker still runs.
                access.close()
                if let pendingDirectory {
                    try? FileManager.default.removeItem(at: pendingDirectory)
                }
                activeJobID = nil
                activeCancellation = nil
                isWorking = false
                isCancelling = false
                workTask = nil
            }
            do {
                let caches = try FileManager.default.url(
                    for: .cachesDirectory, in: .userDomainMask,
                    appropriateFor: nil, create: true
                )
                let directory = caches
                    .appendingPathComponent("PosterBoardExports", isDirectory: true)
                    .appendingPathComponent(jobID.uuidString, isDirectory: true)
                pendingDirectory = directory
                let report: @Sendable (PosterBoardPackageProgress) -> Void = { [weak self] update in
                    Task { @MainActor [weak self] in
                        guard let self, self.activeJobID == jobID,
                              self.isWorking, !self.isCancelling else { return }
                        self.progress = update
                    }
                }
                let worker = Task.detached(priority: .userInitiated) {
                    defer { access.close() }
                    do {
                        try Task.checkCancellation()
                        try FileManager.default.createDirectory(
                            at: directory, withIntermediateDirectories: true
                        )
                        let result = try PosterBoardPackager.package(
                            sourceURL: access.url, outputDirectory: directory,
                            cancellation: cancellation, progress: report
                        )
                        try Task.checkCancellation()
                        return result
                    } catch {
                        // Only this job's directory belongs to this operation.
                        try? FileManager.default.removeItem(at: directory)
                        throw error
                    }
                }
                let packaged = try await withTaskCancellationHandler {
                    try await worker.value
                } onCancel: {
                    cancellation.cancel()
                    worker.cancel()
                }
                try Task.checkCancellation()
                result = packaged
                resultDirectory = directory
                pendingDirectory = nil
                progress = nil
            } catch is CancellationError {
                progress = nil
                errorMessage = "Đã hủy đóng gói. Bạn có thể thử lại hoặc chọn bản xuất khác."
            } catch {
                progress = nil
                errorMessage = error.localizedDescription
            }
        }
    }

    func cancel() {
        guard isWorking else { return }
        isCancelling = true
        activeCancellation?.cancel()
        workTask?.cancel()
    }

    func retry() {
        guard canRetry, let sourceURL else { return }
        package(sourceURL)
    }

    func clear() {
        guard !isWorking else { return }
        if let resultDirectory {
            try? FileManager.default.removeItem(at: resultDirectory)
        }
        resultDirectory = nil
        result = nil
        progress = nil
        errorMessage = nil
        sourceURL = nil
        sourceName = nil
    }

    deinit {
        activeCancellation?.cancel()
        workTask?.cancel()
    }
}

@MainActor
struct PosterBoardExportView: View {
    @ObservedObject var model: PosterBoardExportModel
    @Environment(\.dismiss) private var dismiss
    @State private var picker: PosterBoardSourceKind?
    @State private var sharedFile: PosterBoardSharedFile?
    @State private var closeRequested = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    introduction
                    sourceCard
                    if model.isWorking { progressCard }
                    if let message = model.errorMessage { failureCard(message) }
                    if let result = model.result { resultCard(result) }
                    Label("Xử lý ngoại tuyến trên iPhone. Bản xuất gốc được giữ nguyên.", systemImage: "checkmark.shield")
                        .font(.footnote)
                        .foregroundStyle(Color.posterMuted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(24)
                .frame(maxWidth: 680, alignment: .leading)
                .frame(maxWidth: .infinity)
            }
            .background(Color.posterBackground.ignoresSafeArea())
            .navigationTitle("Đóng gói .tendies")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(model.isWorking ? "Hủy và đóng" : "Đóng") {
                        if model.isWorking {
                            closeRequested = true
                            model.cancel()
                        } else {
                            dismiss()
                        }
                    }
                    .disabled(closeRequested && model.isWorking)
                }
            }
            .fullScreenCover(item: $picker) { kind in
                PosterBoardSourcePicker(
                    kind: kind,
                    onPick: { url in
                        model.package(url)
                        picker = nil
                    },
                    onCancel: { picker = nil }
                )
                .ignoresSafeArea()
            }
            .sheet(item: $sharedFile) { file in
                PosterBoardShareSheet(url: file.url)
                    .presentationDetents([.medium, .large])
            }
        }
        .tint(Color.posterAccent)
        .interactiveDismissDisabled(model.isWorking)
        .onChange(of: model.isWorking) { working in
            if !working && closeRequested { dismiss() }
        }
        .onDisappear {
            // A forced dismissal still lets the worker unwind with its access lease.
            if model.isWorking { model.cancel() }
        }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: 34, weight: .light))
                .foregroundStyle(Color.posterAccent)
            Text("Từ bản xuất\nthành .tendies.")
                .font(.system(size: 32, weight: .bold, design: .rounded))
                .tracking(-0.7)
            Text("Chọn ZIP hoặc thư mục PosterBoard đã được xuất và giải mã sẵn từ Tệp / iCloud Drive. Ứng dụng tự tìm cấu hình và tài nguyên để đóng gói lại.")
                .font(.subheadline)
                .foregroundStyle(Color.posterMuted)
                .fixedSize(horizontal: false, vertical: true)
            Text("Ứng dụng chỉ đọc mục bạn chọn, không truy cập vùng dữ liệu riêng của ứng dụng khác. Tính năng này không giải mã WALLIVE2 và không cài hình nền.")
                .font(.footnote)
                .foregroundStyle(Color.posterMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var sourceCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Bản xuất PosterBoard")
                .font(.headline)
            Button { picker = .zip } label: {
                Label("Chọn ZIP đã xuất", systemImage: "doc.zipper")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .foregroundStyle(Color.posterBackground)
                    .background(Color.posterAccent, in: RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            Button { picker = .folder } label: {
                Label("Chọn thư mục", systemImage: "folder")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
            }
            .buttonStyle(.plain)
            Text(model.result == nil
                 ? "Chọn thư mục bao ngoài bản xuất, hoặc ZIP còn chứa cấu trúc thư mục và các file tài nguyên. File có đuôi .tendies cũng có thể được chọn nếu bên trong là ZIP đã giải mã."
                 : "Kết quả được giữ để bạn lưu hoặc chia sẻ. Xóa kết quả bên dưới trước khi đóng gói bản xuất khác.")
                .font(.caption)
                .foregroundStyle(Color.posterMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .disabled(model.isWorking || model.result != nil)
        .padding(20)
        .background(Color.posterPanel, in: RoundedRectangle(cornerRadius: 22))
    }

    private var progressCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                ProgressView().tint(Color.posterAccent)
                Text(model.isCancelling ? "Đang hủy và dọn file tạm…" : (model.progress?.message ?? "Đang đóng gói…"))
                    .font(.subheadline.weight(.medium))
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let name = model.sourceName {
                Text(name)
                    .font(.caption)
                    .foregroundStyle(Color.posterMuted)
                    .lineLimit(2)
            }
            if !model.isCancelling, let progress = model.progress {
                if let total = progress.totalBytes, total > 0 {
                    ProgressView(value: Double(min(max(progress.completedBytes, 0), total)), total: Double(total))
                        .tint(Color.posterAccent)
                    Text("\(size(progress.completedBytes)) / \(size(total))")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(Color.posterMuted)
                } else if progress.completedBytes > 0 {
                    Text("Đã xử lý \(size(progress.completedBytes))")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(Color.posterMuted)
                }
            }
            Button("Hủy đóng gói", role: .cancel) { model.cancel() }
                .font(.subheadline)
                .disabled(model.isCancelling)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.posterPanel, in: RoundedRectangle(cornerRadius: 22))
        .accessibilityElement(children: .contain)
    }

    private func failureCard(_ message: String) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Label(message, systemImage: "exclamationmark.triangle")
                .font(.subheadline)
                .foregroundStyle(.orange)
                .fixedSize(horizontal: false, vertical: true)
            if model.canRetry {
                Button("Thử lại bản xuất này") { model.retry() }
                    .font(.subheadline.weight(.semibold))
            }
            Text("Nếu Tệp không còn cấp quyền hoặc bản xuất chưa đầy đủ, hãy chọn lại ZIP hoặc thư mục ở trên.")
                .font(.caption)
                .foregroundStyle(Color.posterMuted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.posterPanel, in: RoundedRectangle(cornerRadius: 22))
    }

    private func resultCard(_ result: PosterBoardPackageResult) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("Đã tạo .tendies", systemImage: "checkmark.circle.fill")
                .font(.headline)
                .foregroundStyle(Color.posterAccent)
            Text(result.fileURL.lastPathComponent)
                .font(.subheadline.weight(.medium))
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
            VStack(alignment: .leading, spacing: 7) {
                Text("\(result.descriptorCount) cấu hình · \(result.fileCount) file")
                Text("Dữ liệu gốc \(size(result.originalBytes)) → .tendies \(size(result.archiveBytes))")
                if !result.wallpaperNames.isEmpty {
                    Text("Hình nền: \(result.wallpaperNames.joined(separator: ", "))")
                }
                if result.omittedFiles > 0 {
                    Text("Đã bỏ qua \(result.omittedFiles) mục không thuộc tài nguyên hình nền.")
                }
            }
            .font(.caption)
            .foregroundStyle(Color.posterMuted)
            .fixedSize(horizontal: false, vertical: true)
            Button {
                sharedFile = PosterBoardSharedFile(url: result.fileURL)
            } label: {
                Label("Lưu/chia sẻ .tendies", systemImage: "square.and.arrow.up")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .foregroundStyle(Color.posterBackground)
                    .background(Color.posterAccent, in: RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
            Text("Chọn “Lưu vào Tệp” trong bảng chia sẻ để giữ bản .tendies. Bản tạm có thể bị iOS dọn dẹp.")
                .font(.caption)
                .foregroundStyle(Color.posterMuted)
                .fixedSize(horizontal: false, vertical: true)
            Button("Xóa kết quả", role: .destructive) { model.clear() }
                .font(.subheadline)
                .accessibilityLabel("Xóa kết quả và bản .tendies tạm của lần đóng gói này")
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.posterPanel, in: RoundedRectangle(cornerRadius: 22))
    }

    private func size(_ bytes: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }
}

private enum PosterBoardSourceKind: String, Identifiable {
    case zip, folder
    var id: String { rawValue }
}

@MainActor
private struct PosterBoardSourcePicker: UIViewControllerRepresentable {
    let kind: PosterBoardSourceKind
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onCancel: onCancel) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let controller = UIDocumentPickerViewController(
            forOpeningContentTypes: kind == .folder ? [.folder] : [.zip, .archive, .data],
            asCopy: kind == .zip
        )
        controller.allowsMultipleSelection = false
        controller.shouldShowFileExtensions = true
        controller.title = kind == .folder ? "Chọn thư mục PosterBoard đã xuất" : "Chọn ZIP PosterBoard đã xuất"
        controller.delegate = context.coordinator
        return controller
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void

        init(onPick: @escaping (URL) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let url = urls.first { onPick(url) } else { onCancel() }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onCancel() }
    }
}

private struct PosterBoardSharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PosterBoardShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
