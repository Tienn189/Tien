import UniformTypeIdentifiers

/// Keep every registered extension mapping: different wallpaper apps use different UTIs.
enum FilePickerTypes {
    static let knownIdentifiers = [
        "com.leemin.tendies",
        "com.mutually.wallpaper.tendies",
        "app.tendiesunlock.package"
    ]

    static func contentTypes(for extensions: [String] = ["tendies", "wallive"]) -> [UTType] {
        var candidates: [UTType] = [.item, .data, .content, .archive, .zip]
        candidates += knownIdentifiers.compactMap { UTType($0) }
        for fileExtension in extensions {
            // Do not discard another app/provider's mapping based on its conformance.
            candidates += UTType.types(tag: fileExtension, tagClass: .filenameExtension, conformingTo: nil)
        }
        var identifiers = Set<String>()
        return candidates.filter { identifiers.insert($0.identifier).inserted }
    }
}
