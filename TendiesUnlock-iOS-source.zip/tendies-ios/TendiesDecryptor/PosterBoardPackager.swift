import Foundation
import ZIPFoundation
#if canImport(FoundationXML)
import FoundationXML
#endif

struct PosterBoardPackageProgress: Sendable {
    let message: String
    let completedBytes: Int64
    let totalBytes: Int64?
}

struct PosterBoardPackageResult: Sendable {
    let fileURL: URL
    let wallpaperNames: [String]
    let descriptorCount: Int
    let fileCount: Int
    let originalBytes: Int64
    let archiveBytes: Int64
    let omittedFiles: Int
}

/// Also interrupts a pending File Provider coordination, which cannot observe
/// Swift task cancellation while it is waiting for the provider to respond.
final class PosterBoardPackageCancellation: @unchecked Sendable {
    private enum Reason { case cancelled, timedOut }
    private let lock = NSLock()
    private var reason: Reason?
    private var handlers: [UUID: @Sendable () -> Void] = [:]

    init() {}

    func cancel() { stop(with: .cancelled) }

    fileprivate func timeOut() { stop(with: .timedOut) }

    fileprivate var isCancelled: Bool {
        lock.lock()
        defer { lock.unlock() }
        return reason != nil
    }

    fileprivate func check() throws {
        lock.lock()
        let stopped = reason
        lock.unlock()
        switch stopped {
        case .cancelled: throw CancellationError()
        case .timedOut: throw ProviderTimeout()
        case nil: return
        }
    }

    fileprivate func register(_ handler: @escaping @Sendable () -> Void) -> UUID {
        let id = UUID()
        lock.lock()
        let stopped = reason != nil
        if !stopped { handlers[id] = handler }
        lock.unlock()
        if stopped { handler() }
        return id
    }

    fileprivate func unregister(_ id: UUID) {
        lock.lock()
        handlers[id] = nil
        lock.unlock()
    }

    private func stop(with reason: Reason) {
        lock.lock()
        guard self.reason == nil else { lock.unlock(); return }
        self.reason = reason
        let pending = Array(handlers.values)
        handlers.removeAll()
        lock.unlock()
        for handler in pending { handler() }
    }

    private struct ProviderTimeout: LocalizedError {
        var errorDescription: String? {
            "Nhà cung cấp file chưa cấp quyền đọc sau 60 giây. Hãy tải bản xuất về Tệp rồi thử lại."
        }
    }
}

/// Repackages an already decrypted PosterBoard export. It never edits the source.
/// The caller keeps its document security scope open while this synchronous worker runs.
enum PosterBoardPackager {
    private static let archiveLimit: Int64 = 512 * 1_024 * 1_024
    private static let expandedLimit: Int64 = 768 * 1_024 * 1_024
    private static let entryLimit: Int64 = 256 * 1_024 * 1_024
    private static let entryCountLimit = 20_000
    private static let descriptorLimit = 64
    private static let chunkSize = 64 * 1_024
    private static let identifierFile = "com.apple.posterkit.provider.descriptor.identifier"
    private static let manager = FileManager.default
    @TaskLocal private static var activeCancellation: PosterBoardPackageCancellation?

    private struct PackageError: LocalizedError {
        let errorDescription: String?
        init(_ message: String) { errorDescription = message }
    }

    private struct Item {
        let path: String
        let size: Int64
        let isDirectory: Bool
    }

    static func package(
        sourceURL: URL,
        outputDirectory: URL,
        cancellation: PosterBoardPackageCancellation = PosterBoardPackageCancellation(),
        progress: @escaping @Sendable (PosterBoardPackageProgress) -> Void = { _ in }
    ) throws -> PosterBoardPackageResult {
        try $activeCancellation.withValue(cancellation) {
            try makePackage(sourceURL: sourceURL, outputDirectory: outputDirectory, progress: progress)
        }
    }

    private static func checkCancellation() throws {
        try Task.checkCancellation()
        try activeCancellation?.check()
    }

    private static func makePackage(
        sourceURL: URL,
        outputDirectory: URL,
        progress: @escaping @Sendable (PosterBoardPackageProgress) -> Void
    ) throws -> PosterBoardPackageResult {
        try checkCancellation()
        let workspace = manager.temporaryDirectory.appendingPathComponent("TendiesRepack-\(UUID().uuidString)", isDirectory: true)
        try manager.createDirectory(at: workspace, withIntermediateDirectories: true)
        defer { try? manager.removeItem(at: workspace) }
        let input = workspace.appendingPathComponent("input", isDirectory: true)
        let packed = workspace.appendingPathComponent("archive.tendies")
        var omittedPaths = Set<String>()
        var selectedFolderName: String?
        try emit("Đang đọc bản xuất PosterBoard…", completed: 0, total: nil, progress)

        // Copy while coordinated so iCloud/File Provider has a chance to hydrate the
        // document and all following validation operates on our private snapshot.
        try coordinatedRead(sourceURL) { coordinatedURL in
            let values = try coordinatedURL.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .isRegularFileKey, .fileSizeKey])
            guard values.isSymbolicLink != true else { throw PackageError("Không hỗ trợ liên kết tượng trưng trong bản xuất.") }
            if values.isDirectory == true {
                selectedFolderName = sourceURL.lastPathComponent
                try manager.createDirectory(at: input, withIntermediateDirectories: true)
                let items = try inventory(coordinatedURL)
                let total = items.filter { !$0.isDirectory && !shouldOmit($0.path) }.reduce(Int64(0)) { $0 + $1.size }
                var completed: Int64 = 0
                for item in items {
                    try checkCancellation()
                    if shouldOmit(item.path) {
                        if !item.isDirectory { omittedPaths.insert(item.path) }
                        continue
                    }
                    let destination = input.appendingPathComponent(item.path, isDirectory: item.isDirectory)
                    if item.isDirectory {
                        try manager.createDirectory(at: destination, withIntermediateDirectories: true)
                    } else {
                        try copyFile(from: coordinatedURL.appendingPathComponent(item.path), to: destination, expectedSize: item.size) { count in
                            completed += count
                            try emit("Đang sao chép bản xuất…", completed: completed, total: total, progress)
                        }
                    }
                }
            } else {
                guard values.isRegularFile == true else { throw PackageError("Hãy chọn thư mục cấu hình hoặc tệp ZIP/.tendies đã giải mã.") }
                let size = Int64(values.fileSize ?? 0)
                guard size <= archiveLimit else { throw PackageError("Tệp nén vượt giới hạn 512 MiB.") }
                let archiveURL = workspace.appendingPathComponent("source.zip")
                var completed: Int64 = 0
                try copyFile(from: coordinatedURL, to: archiveURL, expectedSize: size) { count in
                    completed += count
                    try emit("Đang đọc tệp nén…", completed: completed, total: size, progress)
                }
                let signature = try readPrefix(archiveURL, count: 8)
                for magic in ["WALLIVE1", "WALLIVE2"] where signature.starts(with: Data(magic.utf8)) {
                    throw PackageError("Tệp \(magic) vẫn được mã hóa. Hãy giải mã bằng ứng dụng trước, hoặc chọn bản xuất PosterBoard đã giải mã.")
                }
                let entries = try inspectZIP(archiveURL, size: size)
                try manager.createDirectory(at: input, withIntermediateDirectories: true)
                omittedPaths = try extractZIP(archiveURL, entries: entries, to: input, progress: progress)
            }
        }

        try emit("Đang kiểm tra cấu hình và tài nguyên CAML…", completed: 0, total: nil, progress)
        let items = try inventory(input)
        let descriptors = try findDescriptors(in: input, items: items)
        var names: [String] = []
        var outputFiles: [(path: String, source: URL, size: Int64)] = []
        var outputNames = Set<String>()
        var originalBytes: Int64 = 0
        var omittedFiles = 0
        for descriptor in descriptors {
            try checkCancellation()
            let descriptorURL = descriptor.isEmpty ? input : input.appendingPathComponent(descriptor, isDirectory: true)
            let leaf = descriptor.isEmpty ? (selectedFolderName ?? descriptorURL.lastPathComponent) : descriptorURL.lastPathComponent
            let identifier = UUID(uuidString: leaf) != nil ? leaf : UUID().uuidString
            guard outputNames.insert(identifier.lowercased()).inserted else {
                throw PackageError("Hai cấu hình có cùng tên thư mục UUID. Hãy xuất từng cấu hình riêng.")
            }
            let prefix = descriptor.isEmpty ? "" : descriptor + "/"
            names.append(contentsOf: try validateDescriptor(descriptorURL))
            for item in items where !item.isDirectory && (descriptor.isEmpty || item.path.hasPrefix(prefix)) {
                let relative = descriptor.isEmpty ? item.path : String(item.path.dropFirst(prefix.count))
                outputFiles.append(("descriptors/\(identifier)/\(relative)", input.appendingPathComponent(item.path), item.size))
                originalBytes += item.size
            }
            omittedFiles += omittedPaths.filter { descriptor.isEmpty || $0.hasPrefix(prefix) }.count
        }
        guard !outputFiles.isEmpty, outputFiles.count <= entryCountLimit else { throw PackageError("Bản xuất không có tệp hợp lệ hoặc có quá nhiều tệp.") }
        try writeZIP(packed, files: outputFiles.sorted { $0.path < $1.path }, total: originalBytes, progress: progress)
        let archiveBytes = try fileSize(packed)
        guard archiveBytes <= archiveLimit else { throw PackageError("Gói .tendies tạo ra vượt giới hạn 512 MiB.") }
        try emit("Đã kiểm tra và đóng gói xong.", completed: originalBytes, total: originalBytes, progress)

        // A random basename avoids replacing either the selected document or an
        // earlier result, even when the destination is the source's directory.
        try manager.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
        let destination = outputDirectory.appendingPathComponent("PosterBoard-\(UUID().uuidString).tendies")
        var installed = false
        defer { if !installed { try? manager.removeItem(at: destination) } }
        try checkCancellation()
        try manager.copyItem(at: packed, to: destination)
        try checkCancellation()
        installed = true
        return PosterBoardPackageResult(
            fileURL: destination, wallpaperNames: Array(Set(names)).sorted(), descriptorCount: descriptors.count,
            fileCount: outputFiles.count, originalBytes: originalBytes, archiveBytes: archiveBytes, omittedFiles: omittedFiles
        )
    }

    private static func emit(_ message: String, completed: Int64, total: Int64?, _ progress: @Sendable (PosterBoardPackageProgress) -> Void) throws {
        try checkCancellation()
        progress(PosterBoardPackageProgress(message: message, completedBytes: completed, totalBytes: total))
        try checkCancellation()
    }

    private static func coordinatedRead(_ url: URL, body: (URL) throws -> Void) throws {
        #if canImport(Darwin)
        let access = CoordinationWait()
        let cancellation = activeCancellation ?? PosterBoardPackageCancellation()
        let registration = cancellation.register { access.coordinator.cancel() }
        let timer = DispatchWorkItem {
            if access.stopWaiting() { cancellation.timeOut() }
        }
        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 60, execute: timer)
        defer {
            _ = access.stopWaiting()
            timer.cancel()
            cancellation.unregister(registration)
        }
        try checkCancellation()
        var coordinationError: NSError?
        var bodyError: Error?
        var accessed = false
        access.coordinator.coordinate(readingItemAt: url, options: [], error: &coordinationError) { coordinatedURL in
            _ = access.stopWaiting()
            timer.cancel()
            accessed = true
            do {
                try checkCancellation()
                try body(coordinatedURL)
            } catch { bodyError = error }
        }
        try checkCancellation()
        if let bodyError { throw bodyError }
        if let coordinationError { throw coordinationError }
        guard accessed else { throw PackageError("Không thể đọc tài liệu đã chọn.") }
        #else
        try body(url)
        #endif
    }

    #if canImport(Darwin)
    private final class CoordinationWait: @unchecked Sendable {
        let coordinator = NSFileCoordinator(filePresenter: nil)
        private let lock = NSLock()
        private var waiting = true

        // Only time out while waiting for the accessor, not while copying a
        // large export. Synchronization prevents a late timer cancelling it.
        func stopWaiting() -> Bool {
            lock.lock()
            defer { lock.unlock() }
            let wasWaiting = waiting
            waiting = false
            return wasWaiting
        }
    }
    #endif

    private static func inventory(_ root: URL) throws -> [Item] {
        // Apple may enumerate /private/var/... for an accessor URL spelled
        // /var/.... Start from one physical root and normalize each item's
        // existing parent before comparing paths. Never resolve the leaf: its
        // symlink type must remain visible and be rejected below.
        let root = root.resolvingSymlinksInPath().standardizedFileURL
        let keys: [URLResourceKey] = [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]
        var enumerationError: Error?
        guard let enumerator = manager.enumerator(at: root, includingPropertiesForKeys: keys, options: [], errorHandler: { _, error in
            enumerationError = error
            return false
        }) else { throw PackageError("Không thể đọc thư mục bản xuất.") }
        var items: [Item] = []
        var paths = Set<String>()
        var expanded: Int64 = 0
        for case let url as URL in enumerator {
            try checkCancellation()
            let values = try url.resourceValues(forKeys: Set(keys))
            guard values.isSymbolicLink != true else { throw PackageError("Không hỗ trợ liên kết tượng trưng: \(url.lastPathComponent)") }
            let path = try relativeInventoryPath(of: url, inside: root)
            guard paths.insert(path.precomposedStringWithCanonicalMapping.lowercased()).inserted else {
                throw PackageError("Bản xuất có đường dẫn trùng lặp: \(path)")
            }
            let isDirectory = values.isDirectory == true
            guard isDirectory || values.isRegularFile == true else { throw PackageError("Không hỗ trợ loại tệp đặc biệt: \(path)") }
            let size = isDirectory ? 0 : Int64(values.fileSize ?? -1)
            guard size >= 0, size <= entryLimit else { throw PackageError("Tệp vượt giới hạn 256 MiB: \(path)") }
            expanded += size
            guard expanded <= expandedLimit else { throw PackageError("Bản xuất vượt giới hạn giải nén 768 MiB.") }
            items.append(Item(path: path, size: size, isDirectory: isDirectory))
            guard items.count <= entryCountLimit else { throw PackageError("Bản xuất vượt giới hạn 20.000 mục.") }
        }
        if let enumerationError { throw enumerationError }
        return items.sorted { $0.path < $1.path }
    }

    /// A File Provider or Foundation enumerator may use either spelling of an
    /// ancestor alias. Resolving only the existing parent preserves the leaf's
    /// name and does not follow a leaf symlink into a different document.
    static func relativeInventoryPath(of url: URL, inside root: URL) throws -> String {
        let canonicalRoot = root.resolvingSymlinksInPath().standardizedFileURL
        let item = url.deletingLastPathComponent().resolvingSymlinksInPath()
            .appendingPathComponent(url.lastPathComponent, isDirectory: url.hasDirectoryPath)
            .standardizedFileURL
        let prefix = canonicalRoot.path.hasSuffix("/") ? canonicalRoot.path : canonicalRoot.path + "/"
        guard item.path.hasPrefix(prefix) else { throw PackageError("Đường dẫn trong bản xuất vượt ra ngoài thư mục.") }
        let path = String(item.path.dropFirst(prefix.count))
        try validatePath(path)
        return path
    }

    private static func shouldOmit(_ path: String) -> Bool {
        path.split(separator: "/").contains { component in
            component == "scratch" || component == ".DS_Store" || component == "__MACOSX" || component.hasPrefix("RuntimeSnapshot")
        }
    }

    private static func validatePath(_ path: String) throws {
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"), !path.contains(":"),
              !path.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
              !path.split(separator: "/", omittingEmptySubsequences: false).contains(where: { $0.isEmpty || $0 == "." || $0 == ".." }) else {
            throw PackageError("Đường dẫn không an toàn trong bản xuất: \(path)")
        }
    }

    private static func copyFile(from source: URL, to destination: URL, expectedSize: Int64, onChunk: (Int64) throws -> Void) throws {
        try manager.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        guard manager.createFile(atPath: destination.path, contents: nil) else { throw PackageError("Không thể tạo tệp tạm để đóng gói.") }
        let reader = try FileHandle(forReadingFrom: source)
        defer { try? reader.close() }
        let writer = try FileHandle(forWritingTo: destination)
        defer { try? writer.close() }
        var copied: Int64 = 0
        while true {
            try checkCancellation()
            let data = try reader.read(upToCount: chunkSize) ?? Data()
            if data.isEmpty { break }
            copied += Int64(data.count)
            guard copied <= expectedSize else { throw PackageError("Tệp nguồn đã thay đổi trong khi đọc. Hãy thử lại.") }
            try writer.write(contentsOf: data)
            try onChunk(Int64(data.count))
        }
        guard copied == expectedSize else { throw PackageError("Tệp nguồn chưa tải xong hoặc đã thay đổi. Hãy thử lại.") }
        try checkCancellation()
    }

    private static func fileSize(_ url: URL) throws -> Int64 {
        Int64(try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0)
    }

    private static func readPrefix(_ url: URL, count: Int) throws -> Data {
        let reader = try FileHandle(forReadingFrom: url)
        defer { try? reader.close() }
        return try reader.read(upToCount: count) ?? Data()
    }

    private static func findDescriptors(in root: URL, items: [Item]) throws -> [String] {
        var descriptors: [String] = []
        for item in items where !item.isDirectory && (item.path == identifierFile || item.path.hasSuffix("/" + identifierFile)) {
            try checkCancellation()
            let path = item.path == identifierFile ? "" : String(item.path.dropLast(identifierFile.count + 1))
            let url = path.isEmpty ? root : root.appendingPathComponent(path, isDirectory: true)
            guard try isNumericIdentifier(url.appendingPathComponent(identifierFile)) else {
                throw PackageError("Mã descriptor phải là mã số PosterBoard gốc: \(item.path)")
            }
            descriptors.append(path)
            guard descriptors.count <= descriptorLimit else { throw PackageError("Gói vượt giới hạn 64 cấu hình PosterBoard.") }
        }
        guard !descriptors.isEmpty else {
            throw PackageError("Không tìm thấy cấu hình PosterBoard đầy đủ. Thư mục .wallpaper riêng lẻ chưa đủ; hãy xuất thư mục UUID có tệp descriptor.identifier và versions/<số>/contents.")
        }
        descriptors.sort()
        for (index, descriptor) in descriptors.enumerated() {
            if descriptors.dropFirst(index + 1).contains(where: { descriptor.isEmpty || $0.hasPrefix(descriptor + "/") }) {
                throw PackageError("Bản xuất có cấu hình lồng nhau không hợp lệ.")
            }
        }
        return descriptors
    }

    private static func isNumericIdentifier(_ url: URL) throws -> Bool {
        guard try fileSize(url) <= 1_024 else { return false }
        let text = String(data: try Data(contentsOf: url), encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return !text.isEmpty && text.utf8.allSatisfy { $0 >= 48 && $0 <= 57 }
    }

    private static func validateDescriptor(_ root: URL) throws -> [String] {
        for name in ["com.apple.posterkit.role.identifier", "providerInfo.plist"] {
            guard manager.fileExists(atPath: root.appendingPathComponent(name).path) else {
                throw PackageError("Thiếu metadata của cấu hình PosterBoard: \(name). Hãy chọn bản xuất UUID đầy đủ.")
            }
        }
        let versionsURL = root.appendingPathComponent("versions", isDirectory: true)
        let versions = try childDirectories(versionsURL).filter { !$0.lastPathComponent.isEmpty && $0.lastPathComponent.utf8.allSatisfy { $0 >= 48 && $0 <= 57 } }
        guard !versions.isEmpty else { throw PackageError("Thiếu thư mục versions/<số> của cấu hình PosterBoard.") }
        var names: [String] = []
        for version in versions {
            try checkCancellation()
            let contents = version.appendingPathComponent("contents", isDirectory: true)
            let wallpapers = try childDirectories(contents).filter { $0.pathExtension.lowercased() == "wallpaper" }
            guard !wallpapers.isEmpty else { throw PackageError("Thiếu versions/\(version.lastPathComponent)/contents/*.wallpaper/Wallpaper.plist.") }
            for wallpaper in wallpapers {
                let manifest = try plist(wallpaper.appendingPathComponent("Wallpaper.plist"))
                guard let dictionary = manifest as? [String: Any] else { throw PackageError("Wallpaper.plist không phải danh sách thuộc tính hợp lệ.") }
                names.append((dictionary["name"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? wallpaper.deletingPathExtension().lastPathComponent)
                var caPaths = Set<String>()
                collectCAPaths(manifest, into: &caPaths)
                guard !caPaths.isEmpty else { throw PackageError("Wallpaper.plist không khai báo gói hoạt ảnh .ca. Hãy chọn bản xuất CAML đầy đủ.") }
                for path in caPaths.sorted() {
                    try checkCancellation()
                    let bundle = try dependency(path, relativeTo: wallpaper, boundary: wallpaper, directory: true)
                    let index = try plist(bundle.appendingPathComponent("index.xml"))
                    guard let dictionary = index as? [String: Any], let document = dictionary["rootDocument"] as? String, !document.isEmpty else {
                        throw PackageError("Thiếu rootDocument hợp lệ trong \(path)/index.xml.")
                    }
                    _ = try dependency(document, relativeTo: bundle, boundary: bundle)
                }
            }
        }
        // Check every CAML, including assetManifest and CAML modules that aren't
        // the initial rootDocument. This catches dependencies in later states.
        for item in try inventory(root) where !item.isDirectory && item.path.lowercased().hasSuffix(".caml") {
            try checkCancellation()
            let caml = root.appendingPathComponent(item.path)
            let parserDelegate = CAMLDependencies()
            guard let stream = InputStream(url: caml) else { throw PackageError("Không đọc được CAML: \(item.path)") }
            let parser = XMLParser(stream: stream)
            parser.shouldResolveExternalEntities = false
            parser.delegate = parserDelegate
            let parsed = parser.parse()
            try checkCancellation()
            guard parsed, parserDelegate.failure == nil else {
                throw PackageError("CAML XML không hợp lệ hoặc có khai báo thực thể không an toàn: \(item.path)")
            }
            for path in parserDelegate.paths {
                _ = try dependency(path, relativeTo: caml.deletingLastPathComponent(), boundary: root)
            }
        }
        return names
    }

    private static func childDirectories(_ url: URL) throws -> [URL] {
        var isDirectory: ObjCBool = false
        guard manager.fileExists(atPath: url.path, isDirectory: &isDirectory), isDirectory.boolValue else { return [] }
        return try manager.contentsOfDirectory(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: []).filter {
            try $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory == true
        }.sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    private static func plist(_ url: URL) throws -> Any {
        try checkCancellation()
        guard manager.fileExists(atPath: url.path) else { throw PackageError("Thiếu tệp bắt buộc: \(url.lastPathComponent)") }
        // Property lists are metadata, not image data. Bound their memory use
        // separately; binary and XML encodings are both accepted unchanged.
        guard try fileSize(url) <= 8 * 1_024 * 1_024 else { throw PackageError("Metadata quá lớn: \(url.lastPathComponent)") }
        do { return try PropertyListSerialization.propertyList(from: Data(contentsOf: url), options: [], format: nil) }
        catch { throw PackageError("Danh sách thuộc tính không hợp lệ: \(url.lastPathComponent)") }
    }

    private static func collectCAPaths(_ value: Any, into result: inout Set<String>) {
        if let string = value as? String, string.lowercased().hasSuffix(".ca") { result.insert(string) }
        else if let dictionary = value as? [String: Any] { for child in dictionary.values { collectCAPaths(child, into: &result) } }
        else if let array = value as? [Any] { for child in array { collectCAPaths(child, into: &result) } }
    }

    private static func dependency(_ rawPath: String, relativeTo directory: URL, boundary: URL, directory expectedDirectory: Bool = false) throws -> URL {
        guard let path = rawPath.removingPercentEncoding else { throw PackageError("Đường dẫn tài nguyên không hợp lệ: \(rawPath)") }
        try validatePath(path)
        let url = directory.appendingPathComponent(path, isDirectory: expectedDirectory).standardizedFileURL
        let prefix = boundary.standardizedFileURL.path + "/"
        guard url.path.hasPrefix(prefix) else { throw PackageError("Đường dẫn tài nguyên vượt ra ngoài cấu hình: \(rawPath)") }
        var isDirectory: ObjCBool = false
        guard manager.fileExists(atPath: url.path, isDirectory: &isDirectory), isDirectory.boolValue == expectedDirectory else {
            throw PackageError("Thiếu tài nguyên được tham chiếu: \(rawPath)")
        }
        return url
    }

    private final class CAMLDependencies: NSObject, XMLParserDelegate {
        var paths: [String] = []
        var failure: String?
        func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String: String]) {
            if let source = attributeDict["src"] { paths.append(source) }
            if paths.count > entryCountLimit { failure = "Quá nhiều tham chiếu"; parser.abortParsing() }
            if Task.isCancelled || activeCancellation?.isCancelled == true { failure = "Đã hủy"; parser.abortParsing() }
        }
        func parser(_ parser: XMLParser, foundInternalEntityDeclarationWithName name: String, value: String?) {
            failure = "Thực thể XML"; parser.abortParsing()
        }
        func parser(_ parser: XMLParser, foundExternalEntityDeclarationWithName name: String, publicID: String?, systemID: String?) {
            failure = "Thực thể XML ngoài"; parser.abortParsing()
        }
        func parser(_ parser: XMLParser, resolveExternalEntityName name: String, systemID: String?) -> Data? { nil }
    }

    private static func writeZIP(_ url: URL, files: [(path: String, source: URL, size: Int64)], total: Int64, progress: @Sendable (PosterBoardPackageProgress) -> Void) throws {
        let archive = try Archive(url: url, accessMode: .create)
        var completed: Int64 = 0
        for file in files {
            try checkCancellation()
            let reader = try FileHandle(forReadingFrom: file.source)
            defer { try? reader.close() }
            try archive.addEntry(with: file.path, type: .file, uncompressedSize: file.size, compressionMethod: .deflate, bufferSize: chunkSize) { position, count in
                try checkCancellation()
                try reader.seek(toOffset: UInt64(position))
                let data = try reader.read(upToCount: count) ?? Data()
                guard data.count == count else { throw PackageError("Tệp tạm thay đổi trong khi đóng gói.") }
                completed += Int64(data.count)
                try emit("Đang tạo gói .tendies…", completed: completed, total: total, progress)
                return data
            }
            guard try fileSize(url) <= archiveLimit else { throw PackageError("Gói .tendies vượt giới hạn 512 MiB.") }
        }
        try checkCancellation()
    }

    private struct ZIPItem {
        let path: String
        let size: Int64
        let compressedSize: UInt64
        let checksum: UInt32
        let isDirectory: Bool
    }

    // ZIPFoundation deliberately skips unsupported encrypted entries. Inspect
    // the central directory first so no malicious or invisible entry is ignored.
    private static func inspectZIP(_ url: URL, size: Int64) throws -> [ZIPItem] {
        guard size >= 22, size <= archiveLimit else { throw PackageError("Đây không phải ZIP/.tendies thuần hợp lệ, hoặc tệp vượt 512 MiB.") }
        let reader = try FileHandle(forReadingFrom: url)
        defer { try? reader.close() }
        func read(_ offset: UInt64, _ count: Int) throws -> Data {
            guard offset <= UInt64(size), UInt64(count) <= UInt64(size) - offset else { throw PackageError("Cấu trúc ZIP bị cắt ngắn.") }
            try reader.seek(toOffset: offset)
            let bytes = try reader.read(upToCount: count) ?? Data()
            guard bytes.count == count else { throw PackageError("Cấu trúc ZIP bị cắt ngắn.") }
            return bytes
        }
        let tailOffset = max(0, size - 65_557)
        let tail = try read(UInt64(tailOffset), Int(size - tailOffset))
        var end: Int?
        for index in stride(from: tail.count - 22, through: 0, by: -1) where tail.u32(index) == 0x06054b50 {
            if index + 22 + Int(tail.u16(index + 20)) == tail.count { end = index; break }
        }
        guard let end else { throw PackageError("Không tìm thấy cấu trúc ZIP thuần. Hãy chọn bản xuất đã giải mã.") }
        let entryCount = Int(tail.u16(end + 10))
        let centralSize = UInt64(tail.u32(end + 12))
        let centralOffset = UInt64(tail.u32(end + 16))
        guard tail.u16(end + 4) == 0, tail.u16(end + 6) == 0, tail.u16(end + 8) == UInt16(entryCount),
              entryCount > 0, entryCount <= entryCountLimit, entryCount != 65_535,
              centralSize != UInt64(UInt32.max), centralOffset != UInt64(UInt32.max),
              centralOffset + centralSize == UInt64(tailOffset + Int64(end)) else {
            throw PackageError("ZIP chia phần/ZIP64 hoặc số lượng mục không được hỗ trợ (tối đa 20.000).")
        }
        var position = centralOffset
        var items: [ZIPItem] = []
        var paths: [String: Bool] = [:]
        var ranges: [(UInt64, UInt64)] = []
        var expanded: Int64 = 0
        for _ in 0..<entryCount {
            try checkCancellation()
            let header = try read(position, 46)
            guard header.u32(0) == 0x02014b50 else { throw PackageError("Thư mục trung tâm ZIP không hợp lệ.") }
            let flags = header.u16(8)
            let method = header.u16(10)
            let compressedSize = UInt64(header.u32(20))
            let uncompressedSize = UInt64(header.u32(24))
            let nameLength = Int(header.u16(28))
            let extraLength = Int(header.u16(30))
            let commentLength = Int(header.u16(32))
            let localOffset = UInt64(header.u32(42))
            guard flags & 0x0041 == 0 else { throw PackageError("ZIP có mật khẩu/mã hóa. Hãy dùng bản xuất đã giải mã.") }
            guard (method == 0 || method == 8), header.u16(34) == 0, compressedSize != UInt64(UInt32.max),
                  uncompressedSize <= UInt64(entryLimit), localOffset < centralOffset else {
                throw PackageError("Mục ZIP không được hỗ trợ hoặc vượt giới hạn 256 MiB.")
            }
            let nameBytes = try read(position + 46, nameLength)
            guard let rawName = String(data: nameBytes, encoding: .utf8) else { throw PackageError("Tên mục ZIP phải là Unicode UTF-8 hợp lệ.") }
            let isDirectory = rawName.hasSuffix("/")
            let path = isDirectory ? String(rawName.dropLast()) : rawName
            try validatePath(path)
            let key = path.precomposedStringWithCanonicalMapping.lowercased()
            guard paths.updateValue(isDirectory, forKey: key) == nil else { throw PackageError("ZIP có đường dẫn trùng lặp: \(path)") }
            let mode = (header.u32(38) >> 16) & 0xf000
            guard mode != 0xa000 else { throw PackageError("ZIP chứa liên kết tượng trưng: \(path)") }
            guard mode == 0 || mode == 0x8000 || mode == 0x4000,
                  (mode != 0x4000 || isDirectory), (!isDirectory || uncompressedSize == 0) else {
                throw PackageError("ZIP chứa loại tệp đặc biệt không được hỗ trợ: \(path)")
            }
            try checkExtra(try read(position + 46 + UInt64(nameLength), extraLength))
            let local = try read(localOffset, 30)
            guard local.u32(0) == 0x04034b50, local.u16(6) == flags, local.u16(8) == method,
                  local.u16(26) == UInt16(nameLength),
                  try read(localOffset + 30, nameLength) == nameBytes else {
                throw PackageError("Tên hoặc tiêu đề mục ZIP không khớp.")
            }
            let localExtraLength = Int(local.u16(28))
            try checkExtra(try read(localOffset + 30 + UInt64(nameLength), localExtraLength))
            let dataEnd = localOffset + 30 + UInt64(nameLength + localExtraLength) + compressedSize
            guard dataEnd <= centralOffset else { throw PackageError("Dữ liệu mục ZIP vượt giới hạn tệp.") }
            if flags & 8 == 0 {
                guard local.u32(14) == header.u32(16), UInt64(local.u32(18)) == compressedSize,
                      UInt64(local.u32(22)) == uncompressedSize else { throw PackageError("Kích thước hoặc CRC ZIP không khớp.") }
            }
            ranges.append((localOffset, dataEnd))
            expanded += Int64(uncompressedSize)
            guard expanded <= expandedLimit else { throw PackageError("ZIP vượt giới hạn giải nén 768 MiB.") }
            items.append(ZIPItem(path: path, size: Int64(uncompressedSize), compressedSize: compressedSize, checksum: header.u32(16), isDirectory: isDirectory))
            position += UInt64(46 + nameLength + extraLength + commentLength)
            guard position <= centralOffset + centralSize else { throw PackageError("Thư mục trung tâm ZIP vượt giới hạn.") }
        }
        guard position == centralOffset + centralSize else { throw PackageError("Thư mục trung tâm ZIP có mục dư không hợp lệ.") }
        ranges.sort { $0.0 < $1.0 }
        for index in 1..<ranges.count where ranges[index].0 < ranges[index - 1].1 { throw PackageError("Các mục ZIP chồng lấn dữ liệu.") }
        for (path, _) in paths {
            var parent = (path as NSString).deletingLastPathComponent
            while !parent.isEmpty {
                if paths[parent] == false { throw PackageError("Đường dẫn ZIP dùng tệp làm thư mục: \(path)") }
                parent = (parent as NSString).deletingLastPathComponent
            }
        }
        return items
    }

    private static func checkExtra(_ extra: Data) throws {
        var offset = 0
        while offset < extra.count {
            guard extra.count - offset >= 4 else { throw PackageError("Trường mở rộng ZIP không hợp lệ.") }
            let identifier = extra.u16(offset)
            let size = Int(extra.u16(offset + 2))
            guard identifier != 1, identifier != 0x7075, offset + 4 + size <= extra.count else {
                throw PackageError("ZIP64 hoặc tên ZIP thay thế không được hỗ trợ.")
            }
            offset += 4 + size
        }
    }

    private static func extractZIP(_ url: URL, entries: [ZIPItem], to root: URL, progress: @Sendable (PosterBoardPackageProgress) -> Void) throws -> Set<String> {
        let archive = try Archive(url: url, accessMode: .read, pathEncoding: .utf8)
        let actualEntries = Array(archive)
        guard actualEntries.count == entries.count else { throw PackageError("ZIP có mục bị hỏng hoặc không được hỗ trợ.") }
        var omitted = Set<String>()
        let total = entries.reduce(Int64(0)) { $0 + $1.size }
        var completed: Int64 = 0
        for (entry, expected) in zip(actualEntries, entries) {
            try checkCancellation()
            let entryPath = entry.path.hasSuffix("/") ? String(entry.path.dropLast()) : entry.path
            guard entryPath == expected.path, entry.type != .symlink, entry.uncompressedSize == UInt64(expected.size),
                  entry.compressedSize == expected.compressedSize, entry.checksum == expected.checksum,
                  (entry.type == .directory) == expected.isDirectory else { throw PackageError("Thông tin mục ZIP không khớp: \(expected.path)") }
            if shouldOmit(expected.path) {
                if !expected.isDirectory { omitted.insert(expected.path) }
                continue
            }
            let destination = root.appendingPathComponent(expected.path, isDirectory: expected.isDirectory)
            if expected.isDirectory {
                try manager.createDirectory(at: destination, withIntermediateDirectories: true)
                continue
            }
            try manager.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            guard manager.createFile(atPath: destination.path, contents: nil) else { throw PackageError("Không tạo được tệp giải nén.") }
            let writer = try FileHandle(forWritingTo: destination)
            defer { try? writer.close() }
            var written: Int64 = 0
            let checksum = try archive.extract(entry, bufferSize: chunkSize) { data in
                try checkCancellation()
                written += Int64(data.count)
                guard written <= expected.size else { throw PackageError("Dữ liệu giải nén vượt kích thước khai báo.") }
                try writer.write(contentsOf: data)
                completed += Int64(data.count)
                try emit("Đang giải nén bản xuất…", completed: completed, total: total, progress)
            }
            guard written == expected.size, checksum == expected.checksum else { throw PackageError("Tệp ZIP bị hỏng (CRC/kích thước): \(expected.path)") }
        }
        return omitted
    }
}

private extension Data {
    func u16(_ offset: Int) -> UInt16 {
        UInt16(self[startIndex + offset]) | (UInt16(self[startIndex + offset + 1]) << 8)
    }
    func u32(_ offset: Int) -> UInt32 {
        UInt32(u16(offset)) | (UInt32(u16(offset + 2)) << 16)
    }
}
