import Foundation
import SwiftUI
import UIKit

/// Keep action titles legible even when a custom accent matches the background.
struct AppActionLabel: View {
    let title: String
    let systemImage: String
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        Label {
            Text(title)
                .foregroundStyle(isEnabled ? Color.primary : Color.secondary)
        } icon: {
            Image(systemName: systemImage)
                .foregroundStyle(.tint)
                .opacity(isEnabled ? 1 : 0.35)
        }
    }
}

enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
}

enum AccentChoice: String, CaseIterable, Identifiable {
    case monochrome, blue, purple, pink, orange, green, custom

    var id: String { rawValue }
    var title: String {
        switch self {
        case .monochrome: return "Than chì"
        case .blue: return "Đại dương"
        case .purple: return "Tím khói"
        case .pink: return "Đỏ đào"
        case .orange: return "Hổ phách"
        case .green: return "Lá xanh"
        case .custom: return "Màu của bạn"
        }
    }
}

/// One shared preference model keeps every screen and presentation in sync.
@MainActor
final class AppAppearance: ObservableObject {
    private enum Key {
        static let mode = "appearance.mode"
        static let accent = "appearance.accent"
        static let red = "appearance.custom.red"
        static let green = "appearance.custom.green"
        static let blue = "appearance.custom.blue"
    }

    private let defaults: UserDefaults

    @Published var mode: AppearanceMode {
        didSet { defaults.set(mode.rawValue, forKey: Key.mode) }
    }
    @Published var accent: AccentChoice {
        didSet { defaults.set(accent.rawValue, forKey: Key.accent) }
    }
    @Published private var red: Double {
        didSet { defaults.set(red, forKey: Key.red) }
    }
    @Published private var green: Double {
        didSet { defaults.set(green, forKey: Key.green) }
    }
    @Published private var blue: Double {
        didSet { defaults.set(blue, forKey: Key.blue) }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        mode = AppearanceMode(rawValue: defaults.string(forKey: Key.mode) ?? "") ?? .system
        accent = AccentChoice(rawValue: defaults.string(forKey: Key.accent) ?? "") ?? .blue
        red = Self.component(defaults, key: Key.red, fallback: 22.0 / 255)
        green = Self.component(defaults, key: Key.green, fallback: 136.0 / 255)
        blue = Self.component(defaults, key: Key.blue, fallback: 245.0 / 255)
    }

    var preferredColorScheme: ColorScheme? {
        switch mode {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    var customColor: Color {
        get { Color(red: red, green: green, blue: blue) }
        set {
            var r: CGFloat = 0
            var g: CGFloat = 0
            var b: CGFloat = 0
            var a: CGFloat = 0
            guard UIColor(newValue).getRed(&r, green: &g, blue: &b, alpha: &a) else { return }
            red = min(max(Double(r), 0), 1)
            green = min(max(Double(g), 0), 1)
            blue = min(max(Double(b), 0), 1)
            accent = .custom
        }
    }

    func tint(for scheme: ColorScheme) -> Color {
        color(for: accent, scheme: scheme)
    }

    func color(for choice: AccentChoice, scheme: ColorScheme) -> Color {
        switch choice {
        case .monochrome: return Color(red: 90.0 / 255, green: 99.0 / 255, blue: 114.0 / 255)
        case .blue: return Color(red: 22.0 / 255, green: 136.0 / 255, blue: 245.0 / 255)
        case .purple: return Color(red: 128.0 / 255, green: 98.0 / 255, blue: 205.0 / 255)
        case .pink: return Color(red: 195.0 / 255, green: 72.0 / 255, blue: 101.0 / 255)
        case .orange: return Color(red: 169.0 / 255, green: 107.0 / 255, blue: 20.0 / 255)
        case .green: return Color(red: 23.0 / 255, green: 132.0 / 255, blue: 91.0 / 255)
        case .custom: return customColor
        }
    }

    /// Native prominent buttons can need an explicit contrasting label when
    /// their tint is white in dark mode or a user-selected pale custom color.
    func foregroundOnTint(for scheme: ColorScheme) -> Color {
        let traits = UITraitCollection(userInterfaceStyle: scheme == .dark ? .dark : .light)
        let resolved = UIColor(tint(for: scheme)).resolvedColor(with: traits)
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard resolved.getRed(&r, green: &g, blue: &b, alpha: &a) else {
            return scheme == .dark ? .black : .white
        }
        let brightness = 0.2126 * Double(r) + 0.7152 * Double(g) + 0.0722 * Double(b)
        return brightness > 0.6 ? .black : .white
    }

    var customHex: String {
        String(format: "#%02X%02X%02X", Int((red * 255).rounded()),
               Int((green * 255).rounded()), Int((blue * 255).rounded()))
    }

    func reset() {
        mode = .system
        accent = .blue
        red = 22.0 / 255
        green = 136.0 / 255
        blue = 245.0 / 255
    }

    private static func component(_ defaults: UserDefaults, key: String, fallback: Double) -> Double {
        guard defaults.object(forKey: key) != nil else { return fallback }
        let value = defaults.double(forKey: key)
        return value.isFinite ? min(max(value, 0), 1) : fallback
    }
}

// The palette and spacing follow the 1809 source supplied as the UI reference.
// Navigation bars, tab bars, sheets and controls use the system appearance.
extension Color {
    static let denrindzBackground = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark
            ? UIColor.black
            : UIColor(red: 0.955, green: 0.965, blue: 0.995, alpha: 1)
    })
    static let denrindzSurface = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark ? UIColor(white: 0.11, alpha: 1) : UIColor.white
    })
    static let denrindzSuccess = Color(uiColor: UIColor { traits in
        traits.userInterfaceStyle == .dark
            ? UIColor(red: 0.30, green: 0.85, blue: 0.45, alpha: 1)
            : UIColor(red: 0.09, green: 0.45, blue: 0.22, alpha: 1)
    })
}

struct DenrindzBackground: View {
    var body: some View {
        Color.denrindzBackground.ignoresSafeArea()
    }
}

extension View {
    func denrindzCard(_ radius: CGFloat = 22) -> some View {
        background(Color.denrindzSurface,
                   in: RoundedRectangle(cornerRadius: radius, style: .continuous))
    }
}

struct DenrindzSection<Content: View>: View {
    let title: String
    let subtitle: String?
    let footer: String?
    private let content: Content

    init(_ title: String, subtitle: String? = nil, footer: String? = nil,
         @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.footer = footer
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.title3.bold()).accessibilityAddTraits(.isHeader)
                if let subtitle {
                    Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 4)
            VStack(alignment: .leading, spacing: 18) { content }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18)
                .denrindzCard()
            if let footer {
                Text(footer).font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 4)
            }
        }
    }
}

@MainActor
struct AppearanceSettingsView: View {
    @EnvironmentObject private var appearance: AppAppearance
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    private let palette: [AccentChoice] = [.blue, .green, .purple, .pink, .orange, .monochrome]
    private var effectiveScheme: ColorScheme { appearance.preferredColorScheme ?? colorScheme }
    private var accent: Color { appearance.tint(for: effectiveScheme) }
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12),
              count: dynamicTypeSize.isAccessibilitySize ? 2 : 3)
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                preview
                modeSelection
                colorSelection
                Button { appearance.reset() } label: {
                    Label("Khôi phục giao diện mặc định", systemImage: "arrow.counterclockwise")
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity, minHeight: 48)
                }
                .buttonStyle(.bordered)
            }
            .padding(20)
            .padding(.bottom, 12)
        }
        .background(Color.denrindzBackground)
        .navigationTitle("Giao diện")
        .navigationBarTitleDisplayMode(.large)
    }

    private var preview: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label("Xem trước", systemImage: "paintpalette").foregroundStyle(.secondary)
                Spacer()
                Text(appearance.accent == .custom ? "Tùy chỉnh" : appearance.accent.title)
                    .foregroundStyle(accent)
            }
            .font(.caption.weight(.semibold))
            HStack(spacing: 14) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.title2).foregroundStyle(accent)
                    .frame(width: 48, height: 48)
                    .background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Hình nền của bạn").font(.headline)
                    Text("Một chút màu, theo ý bạn.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            ViewThatFits(in: .horizontal) {
                HStack {
                    previewStatus
                    Spacer(minLength: 4)
                    previewAction
                }
                VStack(alignment: .leading, spacing: 12) {
                    previewStatus
                    previewAction
                }
            }
        }
        .padding(20)
        .denrindzCard(24)
        .overlay(alignment: .top) {
            Capsule().fill(accent).frame(width: 44, height: 4).accessibilityHidden(true)
        }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Bản xem trước giao diện")
    }

    private var previewStatus: some View {
        Label("Thành công", systemImage: "checkmark.circle.fill")
            .font(.caption.weight(.semibold))
            .foregroundStyle(Color.denrindzSuccess)
            .padding(.horizontal, 11).padding(.vertical, 7)
            .background(Color.denrindzSuccess.opacity(0.12), in: Capsule())
    }

    private var previewAction: some View {
        Text("+ Nhập gói")
            .font(.caption.weight(.semibold))
            .foregroundStyle(appearance.foregroundOnTint(for: effectiveScheme))
            .padding(.horizontal, 14).padding(.vertical, 9)
            .background(accent, in: Capsule())
            .accessibilityLabel("Xem trước nút nhập gói")
    }

    private var modeSelection: some View {
        VStack(alignment: .leading, spacing: 12) {
            heading("Chế độ hiển thị", subtitle: "Chọn cách ứng dụng xuất hiện.")
            VStack(spacing: 0) {
                ForEach(AppearanceMode.allCases) { mode in
                    Button { appearance.mode = mode } label: { modeRow(mode) }
                        .buttonStyle(.plain)
                        .accessibilityValue(appearance.mode == mode ? "Đã chọn" : "Chưa chọn")
                        .accessibilityAddTraits(appearance.mode == mode ? .isSelected : [])
                    if mode != AppearanceMode.allCases.last {
                        Divider().padding(.leading, 60)
                    }
                }
            }
            .denrindzCard(22)
        }
    }

    private func modeRow(_ mode: AppearanceMode) -> some View {
        HStack(spacing: 14) {
            Image(systemName: modeIcon(mode)).font(.title3)
                .foregroundStyle(accent).frame(width: 28).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text(mode.title).font(.body.weight(.medium)).foregroundStyle(.primary)
                Text(modeDescription(mode)).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            Image(systemName: appearance.mode == mode ? "checkmark.circle.fill" : "circle")
                .font(.title3)
                .foregroundStyle(appearance.mode == mode ? accent : Color.secondary.opacity(0.35))
                .accessibilityHidden(true)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private var colorSelection: some View {
        VStack(alignment: .leading, spacing: 14) {
            heading("Màu nhấn", subtitle: "Dùng cho nút, liên kết và mục đang chọn.")
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(palette) { choice in
                    Button { appearance.accent = choice } label: { swatch(choice) }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Màu \(choice.title)")
                        .accessibilityValue(appearance.accent == choice ? "Đã chọn" : "Chưa chọn")
                        .accessibilityAddTraits(appearance.accent == choice ? .isSelected : [])
                }
            }
            ColorPicker(selection: Binding(get: { accent }, set: { appearance.customColor = $0 }),
                        supportsOpacity: false) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Màu của bạn").font(.body.weight(.medium))
                    Text(appearance.accent == .custom ? "Tùy chỉnh · \(appearance.customHex)" : "Chọn một màu bất kỳ")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(18)
            .denrindzCard(20)
            Text("Trạng thái luôn dùng xanh lá cho thành công, đỏ cho lỗi hoặc không hỗ trợ và vàng khi cần thao tác.")
                .font(.footnote).foregroundStyle(.secondary)
                .padding(.horizontal, 4)
        }
    }

    private func swatch(_ choice: AccentChoice) -> some View {
        let selected = appearance.accent == choice
        let color = appearance.color(for: choice, scheme: effectiveScheme)
        return VStack(spacing: 9) {
            Circle().fill(color).frame(width: 32, height: 32)
                .overlay {
                    if selected {
                        Image(systemName: "checkmark").font(.caption.bold()).foregroundStyle(.white)
                    }
                }
            Text(choice.title)
                .font(.caption.weight(selected ? .semibold : .regular))
                .foregroundStyle(.primary).multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 8).padding(.vertical, 15)
        .background(selected ? color.opacity(0.10) : Color.denrindzSurface,
                    in: RoundedRectangle(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .strokeBorder(selected ? color : .clear, lineWidth: 1.5)
        }
        .contentShape(RoundedRectangle(cornerRadius: 18))
    }

    private func heading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.title3.bold()).accessibilityAddTraits(.isHeader)
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 4)
    }

    private func modeIcon(_ mode: AppearanceMode) -> String {
        switch mode {
        case .system: return "circle.lefthalf.filled"
        case .light: return "sun.max.fill"
        case .dark: return "moon.stars.fill"
        }
    }

    private func modeDescription(_ mode: AppearanceMode) -> String {
        switch mode {
        case .system: return "Tự đổi theo cài đặt của iPhone"
        case .light: return "Nền sáng, nội dung rõ ràng"
        case .dark: return "Nền tối, dịu mắt hơn"
        }
    }
}
