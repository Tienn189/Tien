import Foundation
import SwiftUI
import UIKit

/// Keep action titles legible even when a custom accent matches the background.
struct AppActionLabel: View {
    let title: String
    let systemImage: String
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        Label {
            Text(title)
                .foregroundStyle(isEnabled ? Color.primary : Color.secondary)
        } icon: {
            Image(systemName: systemImage)
                .foregroundStyle(.tint)
                .opacity(isEnabled ? 1 : 0.35)
        }
    }
}

enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
}

enum AccentChoice: String, CaseIterable, Identifiable {
    case monochrome, blue, purple, pink, orange, green, custom

    var id: String { rawValue }
    var title: String {
        switch self {
        case .monochrome: return "Trắng đen"
        case .blue: return "Xanh dương"
        case .purple: return "Tím"
        case .pink: return "Hồng"
        case .orange: return "Cam"
        case .green: return "Xanh lá"
        case .custom: return "Tùy chỉnh"
        }
    }
}

/// One shared preference model keeps every screen and presentation in sync.
@MainActor
final class AppAppearance: ObservableObject {
    private enum Key {
        static let mode = "appearance.mode"
        static let accent = "appearance.accent"
        static let red = "appearance.custom.red"
        static let green = "appearance.custom.green"
        static let blue = "appearance.custom.blue"
    }

    private let defaults: UserDefaults

    @Published var mode: AppearanceMode {
        didSet { defaults.set(mode.rawValue, forKey: Key.mode) }
    }
    @Published var accent: AccentChoice {
        didSet { defaults.set(accent.rawValue, forKey: Key.accent) }
    }
    @Published private var red: Double {
        didSet { defaults.set(red, forKey: Key.red) }
    }
    @Published private var green: Double {
        didSet { defaults.set(green, forKey: Key.green) }
    }
    @Published private var blue: Double {
        didSet { defaults.set(blue, forKey: Key.blue) }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        mode = AppearanceMode(rawValue: defaults.string(forKey: Key.mode) ?? "") ?? .system
        accent = AccentChoice(rawValue: defaults.string(forKey: Key.accent) ?? "") ?? .monochrome
        red = Self.component(defaults, key: Key.red, fallback: 0.18)
        green = Self.component(defaults, key: Key.green, fallback: 0.38)
        blue = Self.component(defaults, key: Key.blue, fallback: 0.96)
    }

    var preferredColorScheme: ColorScheme? {
        switch mode {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    var customColor: Color {
        get { Color(red: red, green: green, blue: blue) }
        set {
            var r: CGFloat = 0
            var g: CGFloat = 0
            var b: CGFloat = 0
            var a: CGFloat = 0
            guard UIColor(newValue).getRed(&r, green: &g, blue: &b, alpha: &a) else { return }
            red = min(max(Double(r), 0), 1)
            green = min(max(Double(g), 0), 1)
            blue = min(max(Double(b), 0), 1)
            accent = .custom
        }
    }

    func tint(for scheme: ColorScheme) -> Color {
        color(for: accent, scheme: scheme)
    }

    func color(for choice: AccentChoice, scheme: ColorScheme) -> Color {
        switch choice {
        case .monochrome: return scheme == .dark ? .white : .black
        case .blue: return .blue
        case .purple: return .purple
        case .pink: return .pink
        case .orange: return .orange
        case .green: return .green
        case .custom: return customColor
        }
    }

    /// Native prominent buttons can need an explicit contrasting label when
    /// their tint is white in dark mode or a user-selected pale custom color.
    func foregroundOnTint(for scheme: ColorScheme) -> Color {
        let traits = UITraitCollection(userInterfaceStyle: scheme == .dark ? .dark : .light)
        let resolved = UIColor(tint(for: scheme)).resolvedColor(with: traits)
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard resolved.getRed(&r, green: &g, blue: &b, alpha: &a) else {
            return scheme == .dark ? .black : .white
        }
        func linear(_ value: CGFloat) -> Double {
            let value = Double(value)
            return value <= 0.04045 ? value / 12.92 : pow((value + 0.055) / 1.055, 2.4)
        }
        let luminance = 0.2126 * linear(r) + 0.7152 * linear(g) + 0.0722 * linear(b)
        return luminance > 0.179 ? .black : .white
    }

    func reset() {
        mode = .system
        accent = .monochrome
        red = 0.18
        green = 0.38
        blue = 0.96
    }

    private static func component(_ defaults: UserDefaults, key: String, fallback: Double) -> Double {
        guard defaults.object(forKey: key) != nil else { return fallback }
        let value = defaults.double(forKey: key)
        return value.isFinite ? min(max(value, 0), 1) : fallback
    }
}

@MainActor
struct AppearanceSettingsView: View {
    @EnvironmentObject private var appearance: AppAppearance
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.dismiss) private var dismiss

    private var effectiveScheme: ColorScheme { appearance.preferredColorScheme ?? colorScheme }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Chế độ hiển thị", selection: $appearance.mode) {
                        ForEach(AppearanceMode.allCases) { mode in
                            Text(mode.title).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text("Giao diện")
                } footer: {
                    Text("Chọn Hệ thống để tự chuyển giữa giao diện sáng và tối theo iPhone.")
                }

                Section {
                    ForEach(AccentChoice.allCases) { choice in
                        Button {
                            appearance.accent = choice
                        } label: {
                            HStack(spacing: 12) {
                                Circle()
                                    .fill(appearance.color(for: choice, scheme: effectiveScheme))
                                    .frame(width: 22, height: 22)
                                    .overlay(Circle().strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.5))
                                    .accessibilityHidden(true)
                                Text(choice.title)
                                    .foregroundStyle(.primary)
                                Spacer()
                                if appearance.accent == choice {
                                    Image(systemName: "checkmark")
                                        .font(.body.weight(.semibold))
                                        .foregroundStyle(.primary)
                                        .accessibilityHidden(true)
                                }
                            }
                            .padding(.vertical, 3)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(choice.title)
                        .accessibilityValue(appearance.accent == choice ? "Đã chọn" : "")
                    }
                    ColorPicker(
                        "Màu tùy chỉnh",
                        selection: Binding(
                            get: { appearance.customColor },
                            set: { appearance.customColor = $0 }
                        ),
                        supportsOpacity: false
                    )
                } header: {
                    Text("Màu chủ đề")
                } footer: {
                    Text("Màu chủ đề áp dụng cho nút và các mục được chọn. Nền và nội dung giữ phong cách trắng đen.")
                }

                Section {
                    Button("Đặt lại giao diện") { appearance.reset() }
                        .foregroundStyle(.primary)
                } footer: {
                    Text("Khôi phục chế độ Hệ thống và màu Trắng đen. Lựa chọn giao diện được lưu trên thiết bị.")
                }
            }
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                        .foregroundStyle(.primary)
                }
            }
        }
        .preferredColorScheme(appearance.preferredColorScheme)
        .tint(appearance.tint(for: effectiveScheme))
    }
}
