import Foundation
import SwiftUI
import UIKit

/// Keep action titles legible even when a custom accent matches the background.
struct AppActionLabel: View {
    let title: String
    let systemImage: String
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        Label {
            Text(title)
                .foregroundStyle(isEnabled ? Color.primary : Color.secondary)
        } icon: {
            Image(systemName: systemImage)
                .foregroundStyle(.tint)
                .opacity(isEnabled ? 1 : 0.35)
        }
    }
}

enum AppearanceMode: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "Theo hệ thống"
        case .light: return "Sáng"
        case .dark: return "Tối"
        }
    }
}

enum AccentChoice: String, CaseIterable, Identifiable {
    case monochrome, blue, purple, pink, orange, green, custom

    var id: String { rawValue }
    var title: String {
        switch self {
        case .monochrome: return "Than chì"
        case .blue: return "Đại dương"
        case .purple: return "Tím khói"
        case .pink: return "Đỏ đào"
        case .orange: return "Hổ phách"
        case .green: return "Lá xanh"
        case .custom: return "Màu của bạn"
        }
    }
}

/// One shared preference model keeps every screen and presentation in sync.
@MainActor
final class AppAppearance: ObservableObject {
    private enum Key {
        static let mode = "appearance.mode"
        static let accent = "appearance.accent"
        static let red = "appearance.custom.red"
        static let green = "appearance.custom.green"
        static let blue = "appearance.custom.blue"
    }

    private let defaults: UserDefaults

    @Published var mode: AppearanceMode {
        didSet { defaults.set(mode.rawValue, forKey: Key.mode) }
    }
    @Published var accent: AccentChoice {
        didSet { defaults.set(accent.rawValue, forKey: Key.accent) }
    }
    @Published private var red: Double {
        didSet { defaults.set(red, forKey: Key.red) }
    }
    @Published private var green: Double {
        didSet { defaults.set(green, forKey: Key.green) }
    }
    @Published private var blue: Double {
        didSet { defaults.set(blue, forKey: Key.blue) }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        mode = AppearanceMode(rawValue: defaults.string(forKey: Key.mode) ?? "") ?? .light
        accent = AccentChoice(rawValue: defaults.string(forKey: Key.accent) ?? "") ?? .blue
        red = Self.component(defaults, key: Key.red, fallback: 0.18)
        green = Self.component(defaults, key: Key.green, fallback: 0.38)
        blue = Self.component(defaults, key: Key.blue, fallback: 0.96)
    }

    var preferredColorScheme: ColorScheme? {
        switch mode {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    var customColor: Color {
        get { Color(red: red, green: green, blue: blue) }
        set {
            var r: CGFloat = 0
            var g: CGFloat = 0
            var b: CGFloat = 0
            var a: CGFloat = 0
            guard UIColor(newValue).getRed(&r, green: &g, blue: &b, alpha: &a) else { return }
            red = min(max(Double(r), 0), 1)
            green = min(max(Double(g), 0), 1)
            blue = min(max(Double(b), 0), 1)
            accent = .custom
        }
    }

    func tint(for scheme: ColorScheme) -> Color {
        color(for: accent, scheme: scheme)
    }

    func color(for choice: AccentChoice, scheme: ColorScheme) -> Color {
        switch choice {
        case .monochrome:
            return scheme == .dark
                ? Color(red: 0.69, green: 0.73, blue: 0.79)
                : Color(red: 0.35, green: 0.39, blue: 0.45)
        case .blue: return Color(red: 0.07, green: 0.52, blue: 0.95)
        case .purple: return Color(red: 0.50, green: 0.37, blue: 0.77)
        case .pink: return Color(red: 0.75, green: 0.25, blue: 0.40)
        case .orange: return Color(red: 0.68, green: 0.42, blue: 0.08)
        case .green: return Color(red: 0.08, green: 0.51, blue: 0.37)
        case .custom: return customColor
        }
    }

    /// Native prominent buttons can need an explicit contrasting label when
    /// their tint is white in dark mode or a user-selected pale custom color.
    func foregroundOnTint(for scheme: ColorScheme) -> Color {
        let traits = UITraitCollection(userInterfaceStyle: scheme == .dark ? .dark : .light)
        let resolved = UIColor(tint(for: scheme)).resolvedColor(with: traits)
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 0
        guard resolved.getRed(&r, green: &g, blue: &b, alpha: &a) else {
            return scheme == .dark ? .black : .white
        }
        func linear(_ value: CGFloat) -> Double {
            let value = Double(value)
            return value <= 0.04045 ? value / 12.92 : pow((value + 0.055) / 1.055, 2.4)
        }
        let luminance = 0.2126 * linear(r) + 0.7152 * linear(g) + 0.0722 * linear(b)
        return luminance > 0.179 ? .black : .white
    }

    func reset() {
        mode = .light
        accent = .blue
        red = 0.18
        green = 0.38
        blue = 0.96
    }

    private static func component(_ defaults: UserDefaults, key: String, fallback: Double) -> Double {
        guard defaults.object(forKey: key) != nil else { return fallback }
        let value = defaults.double(forKey: key)
        return value.isFinite ? min(max(value, 0), 1) : fallback
    }
}

/// Shared surfaces keep the import screen, results and appearance page consistent.
struct DenrindzBackground: View {
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                (colorScheme == .dark
                    ? Color(red: 0.045, green: 0.055, blue: 0.085)
                    : Color(red: 0.946, green: 0.957, blue: 0.992))
                RadialGradient(
                    colors: [Color.blue.opacity(colorScheme == .dark ? 0.19 : 0.10), .clear],
                    center: .topTrailing, startRadius: 0, endRadius: proxy.size.width * 1.15
                )
                RadialGradient(
                    colors: [Color.cyan.opacity(colorScheme == .dark ? 0.09 : 0.07), .clear],
                    center: .bottomLeading, startRadius: 0, endRadius: proxy.size.width
                )
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

private struct DenrindzGlassModifier: ViewModifier {
    let radius: CGFloat
    let interactive: Bool
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    @ViewBuilder
    func body(content: Content) -> some View {
        // Xcode 26 / Swift 6.2 provide the native Liquid Glass API.
        // Older Xcode releases compile the material path without referencing it.
        #if compiler(>=6.2)
        if #available(iOS 26.0, *), !reduceTransparency {
            content.glassEffect(
                .regular.interactive(interactive),
                in: RoundedRectangle(cornerRadius: radius, style: .continuous)
            )
        } else {
            materialSurface(content)
        }
        #else
        materialSurface(content)
        #endif
    }

    private func materialSurface(_ content: Content) -> some View {
        content.background {
            let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
            ZStack {
                if reduceTransparency {
                    shape.fill(colorScheme == .dark
                        ? Color(red: 0.12, green: 0.14, blue: 0.18)
                        : Color.white)
                } else {
                    shape.fill(.ultraThinMaterial)
                    shape.fill(Color.white.opacity(colorScheme == .dark ? 0.035 : 0.60))
                }
                shape.strokeBorder(
                    LinearGradient(
                        colors: [Color.white.opacity(colorScheme == .dark ? 0.24 : 0.95),
                                 Color.white.opacity(colorScheme == .dark ? 0.04 : 0.30),
                                 Color.white.opacity(colorScheme == .dark ? 0.10 : 0.65)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ), lineWidth: 1
                )
            }
            .shadow(color: Color.black.opacity(colorScheme == .dark ? 0.16 : 0.035),
                    radius: 22, x: 0, y: 9)
        }
    }
}

extension View {
    func denrindzGlass(_ radius: CGFloat = 30, interactive: Bool = false) -> some View {
        modifier(DenrindzGlassModifier(radius: radius, interactive: interactive))
    }

    /// Present the real Files browser as a rounded sheet over the app.
    @ViewBuilder
    func denrindzDocumentSheet() -> some View {
        if #available(iOS 16.4, *) {
            self.presentationDetents([.large])
                .presentationDragIndicator(.hidden)
                .presentationCornerRadius(38)
        } else {
            self.presentationDetents([.large])
                .presentationDragIndicator(.hidden)
        }
    }
}

struct DenrindzPressStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.76 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.98 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.16), value: configuration.isPressed)
    }
}

struct DenrindzGlassSection<Content: View>: View {
    let title: String
    let subtitle: String?
    let footer: String?
    private let content: Content

    init(_ title: String, subtitle: String? = nil, footer: String? = nil,
         @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.footer = footer
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.title3.weight(.bold))
                    .accessibilityAddTraits(.isHeader)
                if let subtitle {
                    Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 5)
            VStack(alignment: .leading, spacing: 18) { content }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(22)
                .denrindzGlass()
            if let footer {
                Text(footer).font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 5)
            }
        }
    }
}

/// A soft blur lets scrolling content pass behind the floating header.
struct DenrindzHeaderBackdrop: View {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency

    var body: some View {
        Group {
            if reduceTransparency {
                Rectangle().fill(Color(uiColor: .systemBackground))
            } else {
                Rectangle().fill(.ultraThinMaterial)
            }
        }
            .mask {
                LinearGradient(colors: [.black, .black, .clear],
                               startPoint: .top, endPoint: .bottom)
            }
            .ignoresSafeArea(edges: .top)
            .allowsHitTesting(false)
            .accessibilityHidden(true)
    }
}

@MainActor
struct AppearanceSettingsView: View {
    @EnvironmentObject private var appearance: AppAppearance
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.dismiss) private var dismiss
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize

    private let palette: [AccentChoice] = [.blue, .green, .purple, .pink, .orange, .monochrome]
    private var effectiveScheme: ColorScheme { appearance.preferredColorScheme ?? colorScheme }
    private var accent: Color { appearance.tint(for: effectiveScheme) }
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12),
              count: dynamicTypeSize.isAccessibilitySize ? 2 : 3)
    }

    var body: some View {
        ZStack {
            DenrindzBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    preview
                    displayModes
                    accents
                    customColor
                    Text("Trạng thái dùng xanh lá khi hoàn tất, đỏ khi có lỗi và vàng khi cần chú ý.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.horizontal, 5)
                    resetButton
                }
                .padding(.horizontal, 20)
                .padding(.top, 14)
                .padding(.bottom, 32)
            }
            .safeAreaInset(edge: .top, spacing: 0) { header }
        }
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(appearance.preferredColorScheme)
        .tint(accent)
    }

    private var header: some View {
        HStack {
            Button { dismiss() } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 48, height: 48)
                    .denrindzGlass(24, interactive: true)
            }
            .buttonStyle(DenrindzPressStyle())
            .accessibilityLabel("Quay lại")
            Spacer()
            Text("Giao diện")
                .font(.system(size: 20, weight: .bold))
                .accessibilityAddTraits(.isHeader)
            Spacer()
            Color.clear.frame(width: 48, height: 48).accessibilityHidden(true)
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .padding(.bottom, 18)
        .background { DenrindzHeaderBackdrop() }
    }

    private var preview: some View {
        VStack(alignment: .leading, spacing: 23) {
            Capsule().fill(accent).frame(width: 44, height: 4)
                .frame(maxWidth: .infinity)
                .accessibilityHidden(true)
            HStack {
                Label("Xem trước", systemImage: "paintpalette")
                    .foregroundStyle(.secondary)
                Spacer(minLength: 8)
                Text(appearance.accent.title).foregroundStyle(accent)
            }
            .font(.footnote.weight(.semibold))
            HStack(spacing: 15) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 25, weight: .medium))
                    .foregroundStyle(accent)
                    .frame(width: 54, height: 54)
                    .background(accent.opacity(0.10), in: RoundedRectangle(cornerRadius: 18))
                    .accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 5) {
                    Text("Hình nền của bạn").font(.headline)
                    Text("Một chút màu, theo ý bạn.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }
            HStack(spacing: 12) {
                Label("Sẵn sàng", systemImage: "checkmark.circle.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Color.green)
                    .padding(.horizontal, 12).padding(.vertical, 9)
                    .background(Color.green.opacity(0.10), in: Capsule())
                Spacer(minLength: 0)
                Text("+ Nhập file")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(appearance.foregroundOnTint(for: effectiveScheme))
                    .padding(.horizontal, 17).padding(.vertical, 13)
                    .background(accent, in: Capsule())
            }
        }
        .padding(.horizontal, 22)
        .padding(.top, 0)
        .padding(.bottom, 22)
        .denrindzGlass(32)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Xem trước giao diện Denrindz, màu \(appearance.accent.title)")
    }

    private var displayModes: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeading("Chế độ hiển thị", subtitle: "Chọn cách ứng dụng xuất hiện.")
            VStack(spacing: 0) {
                ForEach(Array(AppearanceMode.allCases.enumerated()), id: \.element.id) { index, mode in
                    Button { appearance.mode = mode } label: { modeRow(mode) }
                        .buttonStyle(DenrindzPressStyle())
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(mode.title)
                        .accessibilityValue(appearance.mode == mode ? "Đã chọn" : "Chưa chọn")
                        .accessibilityAddTraits(appearance.mode == mode ? .isSelected : [])
                    if index < AppearanceMode.allCases.count - 1 {
                        Divider().padding(.leading, 65)
                    }
                }
            }
            .denrindzGlass(30)
        }
    }

    private func modeRow(_ mode: AppearanceMode) -> some View {
        HStack(spacing: 17) {
            Image(systemName: modeIcon(mode))
                .font(.system(size: 23, weight: .medium))
                .foregroundStyle(accent)
                .frame(width: 26)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(mode.title).font(.body.weight(.semibold)).foregroundStyle(.primary)
                Text(modeDescription(mode)).font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 8)
            selectionMark(appearance.mode == mode)
        }
        .padding(.horizontal, 22).padding(.vertical, 22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
    }

    private var accents: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionHeading("Màu nhấn", subtitle: "Dùng cho nút, liên kết và mục đang chọn.")
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(palette) { choice in
                    Button { appearance.accent = choice } label: { accentTile(choice) }
                        .buttonStyle(DenrindzPressStyle())
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(choice.title)
                        .accessibilityValue(appearance.accent == choice ? "Đã chọn" : "Chưa chọn")
                        .accessibilityAddTraits(appearance.accent == choice ? .isSelected : [])
                }
            }
        }
    }

    private func accentTile(_ choice: AccentChoice) -> some View {
        let selected = appearance.accent == choice
        let swatch = appearance.color(for: choice, scheme: effectiveScheme)
        return VStack(spacing: 11) {
            Circle().fill(swatch)
                .frame(width: 34, height: 34)
                .overlay {
                    if selected {
                        Image(systemName: "checkmark").font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
            Text(choice.title)
                .font(.footnote.weight(selected ? .semibold : .medium))
                .foregroundStyle(.primary)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 18).padding(.horizontal, 6)
        .frame(maxWidth: .infinity, minHeight: 100)
        .background {
            if selected {
                RoundedRectangle(cornerRadius: 25, style: .continuous).fill(swatch.opacity(0.12))
            }
        }
        .denrindzGlass(25, interactive: true)
        .overlay {
            RoundedRectangle(cornerRadius: 25, style: .continuous)
                .strokeBorder(selected ? swatch : .clear, lineWidth: 1.8)
        }
        .contentShape(RoundedRectangle(cornerRadius: 25))
    }

    private var customColor: some View {
        ColorPicker(
            selection: Binding(get: { appearance.customColor }, set: { appearance.customColor = $0 }),
            supportsOpacity: false
        ) {
            VStack(alignment: .leading, spacing: 5) {
                Text("Màu của bạn").font(.body.weight(.semibold)).foregroundStyle(.primary)
                Text("Chọn một màu bất kỳ.").font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(22)
        .denrindzGlass(28)
        .overlay {
            if appearance.accent == .custom {
                RoundedRectangle(cornerRadius: 28).strokeBorder(accent.opacity(0.7), lineWidth: 1.5)
            }
        }
        .accessibilityLabel("Màu của bạn")
        .accessibilityHint("Chọn màu tùy chỉnh cho giao diện")
    }

    private var resetButton: some View {
        Button { appearance.reset() } label: {
            Label("Khôi phục giao diện mặc định", systemImage: "arrow.counterclockwise")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 20).padding(.vertical, 22)
                .background(accent.opacity(0.12), in: Capsule())
                .denrindzGlass(40, interactive: true)
        }
        .buttonStyle(DenrindzPressStyle())
    }

    private func sectionHeading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.title3.weight(.bold)).accessibilityAddTraits(.isHeader)
            Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 5)
    }

    private func selectionMark(_ selected: Bool) -> some View {
        ZStack {
            Circle().strokeBorder(Color.secondary.opacity(0.25), lineWidth: 1.5)
            if selected {
                Circle().fill(accent)
                Image(systemName: "checkmark")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(appearance.foregroundOnTint(for: effectiveScheme))
            }
        }
        .frame(width: 19, height: 19)
        .accessibilityHidden(true)
    }

    private func modeIcon(_ mode: AppearanceMode) -> String {
        switch mode {
        case .system: return "circle.lefthalf.filled"
        case .light: return "sun.max.fill"
        case .dark: return "moon.stars.fill"
        }
    }

    private func modeDescription(_ mode: AppearanceMode) -> String {
        switch mode {
        case .system: return "Tự đổi theo cài đặt của iPhone"
        case .light: return "Nền sáng, nội dung rõ ràng"
        case .dark: return "Nền tối, dịu mắt hơn"
        }
    }
}
