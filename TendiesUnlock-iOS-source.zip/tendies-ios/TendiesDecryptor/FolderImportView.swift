import SwiftUI
import UniformTypeIdentifiers
import UIKit

@MainActor
private final class FolderImportModel: ObservableObject {
    @Published var entries: [DirectoryEntry] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published private(set) var currentDirectory: URL?
    private var rootAccess: DocumentAccess?
    private var navigation: [URL] = []
    private var listingTask: Task<Void, Never>?
    private var generation = UUID()

    var scopeURL: URL? { rootAccess?.scopeURL }
    var hasFolder: Bool { rootAccess != nil }
    var canGoBack: Bool { navigation.count > 1 }

    func chooseRoot(_ url: URL) {
        // Acquire before the native folder picker is dismissed.
        let access = DocumentAccess(url: url)
        listingTask?.cancel()
        rootAccess?.close()
        rootAccess = access
        navigation = [url]
        currentDirectory = url
        load()
    }

    func open(_ entry: DirectoryEntry) {
        guard entry.isDirectory, !isLoading else { return }
        navigation.append(entry.url)
        currentDirectory = entry.url
        load()
    }

    func goBack() {
        guard canGoBack, !isLoading else { return }
        navigation.removeLast()
        currentDirectory = navigation.last
        load()
    }

    func load() {
        guard let folder = currentDirectory, let scopeURL else { return }
        listingTask?.cancel()
        let ticket = UUID()
        generation = ticket
        let access = DocumentAccess(url: folder, scopeURL: scopeURL)
        isLoading = true
        entries = []
        errorMessage = nil
        listingTask = Task { [weak self] in
            do {
                let entries = try await DirectoryReader.list(access: access)
                guard let self, self.generation == ticket else { return }
                self.entries = entries
                self.isLoading = false
                self.listingTask = nil
            } catch {
                guard let self, self.generation == ticket else { return }
                self.errorMessage = error.localizedDescription
                self.isLoading = false
                self.listingTask = nil
            }
        }
    }

    func cancelListing() { listingTask?.cancel() }

    func close() {
        generation = UUID()
        listingTask?.cancel()
        listingTask = nil
        rootAccess?.close()
        rootAccess = nil
    }

    deinit {
        listingTask?.cancel()
        rootAccess?.close()
    }
}

/// Enumerates files inside a granted folder without the native per-file UTI filter.
@MainActor
struct FolderImportView: View {
    let onPick: (URL, URL) -> Void
    @Environment(\.dismiss) private var dismiss
    @StateObject private var model = FolderImportModel()
    @State private var showDirectoryPicker = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Chọn thư mục chứa file, rồi nhấn file .tendies trong danh sách của ứng dụng.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    if !model.hasFolder {
                        Button { showDirectoryPicker = true } label: {
                            Label("Chọn thư mục chứa file", systemImage: "folder.badge.plus")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .padding(.vertical, 6)
                        Text("Trong màn hình Tệp tiếp theo, mở thư mục chứa file rồi nhấn Mở để chọn thư mục. Sau đó chọn file trong ứng dụng.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    if let folder = model.currentDirectory {
                        Label(folder.lastPathComponent, systemImage: "folder.fill")
                            .font(.headline)
                    }
                    if model.canGoBack {
                        Button { model.goBack() } label: {
                            Label("Thư mục trước", systemImage: "chevron.left")
                        }
                        .disabled(model.isLoading)
                    }
                }

                if model.isLoading {
                    Section {
                        HStack(spacing: 12) {
                            ProgressView()
                            Text("Đang đọc danh sách file…")
                        }
                        Button("Hủy đọc thư mục", role: .cancel) { model.cancelListing() }
                    }
                } else if let message = model.errorMessage {
                    Section {
                        Label(message, systemImage: "exclamationmark.triangle")
                            .foregroundStyle(.orange)
                        Button("Thử lại") { model.load() }
                    }
                } else if model.hasFolder && model.entries.isEmpty {
                    Section {
                        Text("Không có thư mục con hoặc file .tendies, .wallive, .zip trong thư mục này.")
                            .foregroundStyle(.secondary)
                    }
                } else if model.hasFolder {
                    Section("Thư mục và file") {
                        ForEach(model.entries) { entry in
                            Button {
                                if entry.isDirectory {
                                    model.open(entry)
                                } else if let scopeURL = model.scopeURL {
                                    // The receiver acquires its own scope before this lease closes.
                                    onPick(entry.url, scopeURL)
                                    model.close()
                                    dismiss()
                                }
                            } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: entry.isDirectory ? "folder.fill" : "doc.zipper")
                                        .foregroundStyle(entry.isDirectory ? Color.blue : Color.accentColor)
                                        .frame(width: 24)
                                    Text(entry.name)
                                        .foregroundStyle(.primary)
                                        .lineLimit(3)
                                    Spacer(minLength: 4)
                                    Image(systemName: entry.isDirectory ? "chevron.right" : "arrow.down.doc")
                                        .font(.caption)
                                }
                                .padding(.vertical, 4)
                            }
                            .accessibilityLabel(entry.isDirectory ? "Mở thư mục \(entry.name)" : "Nhập file \(entry.name)")
                        }
                    }
                }
            }
            .navigationTitle("Chọn từ thư mục")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Đóng") { model.close(); dismiss() }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button(model.hasFolder ? "Đổi thư mục" : "Chọn thư mục") { showDirectoryPicker = true }
                }
            }
            .sheet(isPresented: $showDirectoryPicker) {
                FolderPicker(
                    onPick: { url in
                        model.chooseRoot(url)
                        showDirectoryPicker = false
                    },
                    onCancel: {
                        showDirectoryPicker = false
                    }
                )
                .ignoresSafeArea()
            }
        }
    }
}

@MainActor
private struct FolderPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick, onCancel: onCancel) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        picker.allowsMultipleSelection = false
        picker.title = "Chọn thư mục chứa .tendies"
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void
        init(onPick: @escaping (URL) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let url = urls.first { onPick(url) } else { onCancel() }
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { onCancel() }
    }
}
