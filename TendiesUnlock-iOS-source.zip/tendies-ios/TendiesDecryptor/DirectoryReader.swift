import Foundation

struct DirectoryEntry: Identifiable, Sendable, Equatable {
    let url: URL
    let name: String
    let isDirectory: Bool
    let note: String?
    var id: URL { url }

    init(url: URL, name: String, isDirectory: Bool, note: String? = nil) {
        self.url = url
        self.name = name
        self.isDirectory = isDirectory
        self.note = note
    }
}

enum DirectoryReader {
    static let maximumEntries = 5_000
    typealias ResourceReader = @Sendable (URL, Set<URLResourceKey>) throws -> URLResourceValues

    static func list(
        access: DocumentAccess, timeout: TimeInterval = 60,
        resourceValues: @escaping ResourceReader = { try $0.resourceValues(forKeys: $1) }
    ) async throws -> [DirectoryEntry] {
        let operation = DocumentOperation<[DirectoryEntry]>(access: access, onProgress: { _ in })
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                operation.install(continuation)
                if Task.isCancelled { operation.cancel(with: .cancelled) }
                operation.start(timeout: timeout) {
                    try coordinatedList($0, resourceValues: resourceValues)
                }
            }
        } onCancel: {
            operation.cancel(with: .cancelled)
        }
    }

    static func supportsFile(_ url: URL) -> Bool {
        ["tendies", "wallive", "zip"].contains(url.pathExtension.lowercased())
    }

    private static func coordinatedList(
        _ operation: DocumentOperation<[DirectoryEntry]>, resourceValues: ResourceReader
    ) throws -> [DirectoryEntry] {
        try operation.checkActive()
        let directory = operation.access.url
        guard directory.isFileURL else { throw DocumentReadError.notADirectory }
        var coordinationError: NSError?
        var contents: Result<[DirectoryEntry], Error>?
        operation.coordinator.coordinate(
            readingItemAt: directory, options: .withoutChanges, error: &coordinationError
        ) { coordinatedURL in
            contents = Result {
                try entries(at: coordinatedURL, operation: operation, resourceValues: resourceValues)
            }
        }
        try operation.checkActive()
        if let contents { return try contents.get() }
        if let coordinationError { throw coordinationError }
        throw DocumentReadError.unavailable
    }

    private static func entries(
        at directory: URL, operation: DocumentOperation<[DirectoryEntry]>, resourceValues: ResourceReader
    ) throws -> [DirectoryEntry] {
        try operation.checkActive()
        // The picker already selected a folder. Providers can omit metadata while
        // syncing, so only an explicit false can reject it before enumeration.
        let rootValues = try? resourceValues(directory, [.isDirectoryKey])
        guard rootValues?.isDirectory != false else { throw DocumentReadError.notADirectory }
        let keys: Set<URLResourceKey> = [.isDirectoryKey, .isSymbolicLinkKey, .nameKey]
        var enumerationErrors: [Error] = []
        guard let enumerator = FileManager.default.enumerator(
            at: directory, includingPropertiesForKeys: Array(keys),
            options: [.skipsSubdirectoryDescendants],
            errorHandler: { _, error in enumerationErrors.append(error); return true }
        ) else {
            throw DocumentReadError.unavailable
        }
        var result: [URL: (entry: DirectoryEntry, placeholder: Bool)] = [:]
        var seen = 0
        while let physicalURL = enumerator.nextObject() as? URL {
            try operation.checkActive()
            seen += 1
            guard seen <= maximumEntries else { throw DocumentReadError.tooManyEntries }
            var values: URLResourceValues?
            var notes: [String] = []
            do {
                values = try resourceValues(physicalURL, keys)
            } catch {
                let failure = error as NSError
                notes.append("Chưa đọc được thông tin file (\(failure.domain), mã \(failure.code)); vẫn có thể thử mở.")
            }
            // Fall back to lstat-style attributes when a provider's resource
            // metadata failed. Never intentionally offer a filesystem symlink.
            var attributes: [FileAttributeKey: Any]?
            if values == nil {
                attributes = try? FileManager.default.attributesOfItem(atPath: physicalURL.path)
            }
            let type = attributes?[.type] as? FileAttributeType
            guard values?.isSymbolicLink != true, type != .typeSymbolicLink else { continue }
            let isDirectory = values?.isDirectory ?? (type == .typeDirectory || physicalURL.hasDirectoryPath)
            let physicalName = physicalURL.lastPathComponent
            let logicalName = isDirectory ? nil : cloudPlaceholderName(physicalName)
            let url = logicalName.map {
                physicalURL.deletingLastPathComponent().appendingPathComponent($0, isDirectory: false)
            } ?? physicalURL
            let displayName = logicalName ?? values?.name ?? physicalName

            // Keep visible files even when the provider reports an unfamiliar
            // extension. Byte validation happens only after the user taps a row.
            // Hidden document files and old iCloud placeholders are also useful;
            // hide only system metadata and other hidden configuration items.
            guard physicalName != ".DS_Store", !physicalName.hasPrefix("._") else { continue }
            if physicalName.hasPrefix("."), logicalName == nil, !supportsFile(url) { continue }
            if logicalName != nil {
                notes.append("File đang ở iCloud; ứng dụng sẽ yêu cầu tải dữ liệu khi mở.")
            } else if !isDirectory, !supportsFile(url) {
                notes.append("Đuôi file chưa được nhận diện; ứng dụng sẽ kiểm tra nội dung khi mở.")
            }
            let entry = DirectoryEntry(
                url: url, name: displayName, isDirectory: isDirectory,
                note: notes.isEmpty ? nil : notes.joined(separator: " ")
            )
            let identity = url.standardizedFileURL
            // During hydration a provider may briefly expose both the stub and
            // the real file. The real file gives the better metadata and name.
            if let previous = result[identity], !previous.placeholder { continue }
            result[identity] = (entry, logicalName != nil)
        }
        if result.isEmpty, let error = enumerationErrors.first { throw error }
        var sorted = result.values.map { $0.entry }.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
        if let first = sorted.first, let error = enumerationErrors.first {
            let failure = error as NSError
            let warning = "Một số mục chưa đọc được (\(failure.domain), mã \(failure.code))."
            sorted[0] = DirectoryEntry(
                url: first.url, name: first.name, isDirectory: first.isDirectory,
                note: [first.note, warning].compactMap { $0 }.joined(separator: " ")
            )
        }
        return sorted
    }

    /// Older iCloud providers expose a hidden `.filename.ext.icloud` stub while
    /// the document's bytes are absent. The logical URL triggers coordinated
    /// hydration; reading the stub itself would only read placeholder metadata.
    private static func cloudPlaceholderName(_ name: String) -> String? {
        guard name.hasPrefix("."), name.lowercased().hasSuffix(".icloud") else { return nil }
        let original = String(name.dropFirst().dropLast(".icloud".count))
        guard !original.isEmpty, original != ".", original != ".." else { return nil }
        return original
    }
}
