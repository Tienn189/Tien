import Foundation

struct DirectoryEntry: Identifiable, Sendable, Equatable {
    let url: URL
    let name: String
    let isDirectory: Bool
    var id: URL { url }
}

enum DirectoryReader {
    static let maximumEntries = 5_000

    static func list(access: DocumentAccess, timeout: TimeInterval = 60) async throws -> [DirectoryEntry] {
        let operation = DocumentOperation<[DirectoryEntry]>(access: access, onProgress: { _ in })
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                operation.install(continuation)
                if Task.isCancelled { operation.cancel(with: .cancelled) }
                operation.start(timeout: timeout, action: coordinatedList)
            }
        } onCancel: {
            operation.cancel(with: .cancelled)
        }
    }

    static func supportsFile(_ url: URL) -> Bool {
        ["tendies", "wallive", "zip"].contains(url.pathExtension.lowercased())
    }

    private static func coordinatedList(_ operation: DocumentOperation<[DirectoryEntry]>) throws -> [DirectoryEntry] {
        try operation.checkActive()
        let directory = operation.access.url
        guard directory.isFileURL else { throw DocumentReadError.notADirectory }
        var coordinationError: NSError?
        var contents: Result<[DirectoryEntry], Error>?
        operation.coordinator.coordinate(
            readingItemAt: directory, options: .withoutChanges, error: &coordinationError
        ) { coordinatedURL in
            contents = Result { try entries(at: coordinatedURL, operation: operation) }
        }
        try operation.checkActive()
        if let contents { return try contents.get() }
        if let coordinationError { throw coordinationError }
        throw DocumentReadError.unavailable
    }

    private static func entries(
        at directory: URL, operation: DocumentOperation<[DirectoryEntry]>
    ) throws -> [DirectoryEntry] {
        try operation.checkActive()
        guard try directory.resourceValues(forKeys: [.isDirectoryKey]).isDirectory == true else {
            throw DocumentReadError.notADirectory
        }
        let keys: [URLResourceKey] = [.isDirectoryKey, .isSymbolicLinkKey, .nameKey]
        var enumerationError: Error?
        guard let enumerator = FileManager.default.enumerator(
            at: directory, includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles, .skipsSubdirectoryDescendants],
            errorHandler: { _, error in enumerationError = error; return false }
        ) else {
            throw DocumentReadError.unavailable
        }
        var result: [DirectoryEntry] = []
        var seen = 0
        while let url = enumerator.nextObject() as? URL {
            try operation.checkActive()
            seen += 1
            guard seen <= maximumEntries else { throw DocumentReadError.tooManyEntries }
            let values = try url.resourceValues(forKeys: Set(keys))
            // Do not follow filesystem links outside the user-granted subtree.
            guard values.isSymbolicLink != true else { continue }
            let isDirectory = values.isDirectory == true
            // A provider can return incomplete regular-file metadata before hydration.
            // Let the coordinated reader validate the bytes after the user selects it.
            let displayName = values.name ?? url.lastPathComponent
            let displayExtension = (displayName as NSString).pathExtension.lowercased()
            let supportedName = ["tendies", "wallive", "zip"].contains(displayExtension)
            guard isDirectory || supportsFile(url) || supportedName else { continue }
            result.append(DirectoryEntry(url: url, name: displayName, isDirectory: isDirectory))
        }
        if let enumerationError { throw enumerationError }
        return result.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }
}
