import CryptoKit
import Foundation

enum WalliveDecryptionError: LocalizedError {
    case tooLarge
    case tooShort
    case unsupportedVersion
    case unsupportedFormat
    case alreadyDecrypted
    case sizeMismatch
    case authenticationFailed
    case invalidPayload
    case cannotReadFile
    case cannotWriteFile

    var errorDescription: String? {
        switch self {
        case .tooLarge:
            return "File quá lớn. Ứng dụng hỗ trợ tối đa 64 MiB cho mỗi file."
        case .tooShort:
            return "File quá ngắn hoặc chưa được tải xuống đầy đủ."
        case .unsupportedVersion:
            return "File WALLIVE2 dùng cơ chế khoá khác. Ứng dụng này hỗ trợ WALLIVE1."
        case .unsupportedFormat:
            return "File không có định dạng WALLIVE1 được hỗ trợ."
        case .alreadyDecrypted:
            return "File này đã là gói ZIP, không cần giải mã. Bạn có thể đổi đuôi thành .zip để mở."
        case .sizeMismatch:
            return "Kích thước file không khớp. File có thể bị thiếu hoặc đã bị thay đổi."
        case .authenticationFailed:
            return "Giải mã không thành công: khoá không khớp hoặc file đã bị thay đổi."
        case .invalidPayload:
            return "Đã xác thực được dữ liệu nhưng nội dung không phải gói ZIP .tendies."
        case .cannotReadFile:
            return "Không đọc được dữ liệu file từ nơi lưu trữ. Hãy nhấn Thử lại trong ứng dụng."
        case .cannotWriteFile:
            return "Không lưu được kết quả. Hãy kiểm tra dung lượng trống trên iPhone."
        }
    }
}

struct WalliveDecryptor {
    static let maximumFileBytes = 64 * 1024 * 1024

    private static let key = SymmetricKey(data: Data([
        0x9c, 0xd8, 0xfa, 0x4d, 0xbc, 0xc3, 0x57, 0x1a,
        0xcc, 0x3d, 0x21, 0xdc, 0xf6, 0x34, 0xd4, 0x30,
        0x5b, 0x58, 0xc3, 0xf1, 0xa0, 0x6d, 0x6c, 0xf5,
        0xfd, 0x29, 0x33, 0xaf, 0x9c, 0x8f, 0x7d, 0xef
    ]))

    /// Authenticates and decrypts the entire WALLIVE1 file before returning ZIP bytes.
    static func decrypt(_ input: Data) throws -> Data {
        guard input.count <= maximumFileBytes else {
            throw WalliveDecryptionError.tooLarge
        }
        guard input.count >= 8 else {
            throw WalliveDecryptionError.tooShort
        }
        let magic = input.prefix(8)
        guard magic != Data("WALLIVE2".utf8) else {
            throw WalliveDecryptionError.unsupportedVersion
        }
        guard magic == Data("WALLIVE1".utf8) else {
            if isZIP(input) { throw WalliveDecryptionError.alreadyDecrypted }
            throw WalliveDecryptionError.unsupportedFormat
        }
        guard input.count >= 60 else {
            throw WalliveDecryptionError.tooShort
        }
        // The byte count is an unsigned, big-endian integer at offsets 24–31.
        let expectedSize = input.dropFirst(24).prefix(8).reduce(UInt64(0)) {
            ($0 << 8) | UInt64($1)
        }
        guard expectedSize <= UInt64(maximumFileBytes) else {
            throw WalliveDecryptionError.tooLarge
        }
        guard expectedSize == UInt64(input.count - 60) else {
            throw WalliveDecryptionError.sizeMismatch
        }
        let plaintext: Data
        do {
            // combined = nonce[12] + ciphertext + tag[16]; authenticate header[32].
            let box = try AES.GCM.SealedBox(combined: input.dropFirst(32))
            plaintext = try AES.GCM.open(box, using: key, authenticating: input.prefix(32))
        } catch {
            throw WalliveDecryptionError.authenticationFailed
        }
        guard plaintext.count == Int(expectedSize), isZIP(plaintext) else {
            throw WalliveDecryptionError.invalidPayload
        }
        return plaintext
    }

    /// The caller manages security-scoped access to the selected source URL.
    static func decryptFile(at source: URL, outputDirectory: URL) throws -> URL {
        let input: Data
        do {
            let values = try source.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
            if values.isRegularFile == false {
                throw WalliveDecryptionError.cannotReadFile
            }
            if let size = values.fileSize, size > maximumFileBytes {
                throw WalliveDecryptionError.tooLarge
            }
            input = try Data(contentsOf: source, options: .mappedIfSafe)
        } catch let error as WalliveDecryptionError {
            throw error
        } catch {
            throw WalliveDecryptionError.cannotReadFile
        }

        return try decryptToZIP(input, originalName: source.lastPathComponent, outputDirectory: outputDirectory)
    }

    /// Exports a decrypted package, or an already-unwrapped ZIP without another decryption.
    static func decryptToZIP(_ input: Data, originalName: String, outputDirectory: URL) throws -> URL {
        let plaintext: Data
        do {
            plaintext = try decrypt(input)
        } catch WalliveDecryptionError.alreadyDecrypted {
            plaintext = input
        }
        let directory = outputDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let basename = safeBasename((originalName as NSString).deletingPathExtension)
        let output = directory.appendingPathComponent(basename + ".decrypted.zip", isDirectory: false)
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            try plaintext.write(to: output, options: .atomic)
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw WalliveDecryptionError.cannotWriteFile
        }
        return output
    }

    private static func isZIP(_ data: Data) -> Bool {
        let signature = Array(data.prefix(4))
        return signature == [0x50, 0x4b, 0x03, 0x04] ||
            signature == [0x50, 0x4b, 0x05, 0x06]
    }

    private static func safeBasename(_ name: String) -> String {
        let forbidden = CharacterSet.controlCharacters.union(CharacterSet(charactersIn: "/\\:"))
        var sanitized = name.components(separatedBy: forbidden).joined(separator: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines.union(CharacterSet(charactersIn: ".")))
        while sanitized.utf8.count > 180 { sanitized.removeLast() }
        return sanitized.isEmpty ? "tendies" : sanitized
    }
}
