import SwiftUI

@main
@MainActor
struct TendiesDecryptorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
