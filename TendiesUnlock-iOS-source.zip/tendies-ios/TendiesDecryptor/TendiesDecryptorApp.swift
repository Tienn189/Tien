import SwiftUI

@main
@MainActor
struct TendiesDecryptorApp: App {
    @StateObject private var appearance = AppAppearance()

    var body: some Scene {
        WindowGroup {
            AppearanceRootView()
                .environmentObject(appearance)
                .environment(\.locale, Locale(identifier: "vi"))
                .preferredColorScheme(appearance.preferredColorScheme)
        }
    }
}

@MainActor
private struct AppearanceRootView: View {
    @EnvironmentObject private var appearance: AppAppearance
    @Environment(\.colorScheme) private var colorScheme

    var body: some View {
        ContentView()
            .tint(appearance.tint(for: appearance.preferredColorScheme ?? colorScheme))
            .accentColor(appearance.tint(for: appearance.preferredColorScheme ?? colorScheme))
    }
}
