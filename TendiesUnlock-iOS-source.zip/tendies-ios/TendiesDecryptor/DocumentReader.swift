import Foundation

/// Acquire this in the picker callback, before dismissing the picker.
/// A failed start is normal for files already inside the app's sandbox.
final class DocumentAccess: @unchecked Sendable {
    let url: URL
    let scopeURL: URL
    private let lock = NSLock()
    private var isOpen: Bool
    private let stopAccess: @Sendable (URL) -> Void

    init(
        url: URL,
        scopeURL: URL? = nil,
        startAccess: @Sendable (URL) -> Bool = { $0.startAccessingSecurityScopedResource() },
        stopAccess: @escaping @Sendable (URL) -> Void = { $0.stopAccessingSecurityScopedResource() }
    ) {
        let grantedURL = scopeURL ?? url
        self.url = url
        self.scopeURL = grantedURL
        self.stopAccess = stopAccess
        self.isOpen = startAccess(grantedURL)
    }

    /// The reader calls this only after its background worker exits.
    func close() {
        lock.lock()
        let shouldStop = isOpen
        isOpen = false
        lock.unlock()
        if shouldStop { stopAccess(scopeURL) }
    }

    deinit { close() }
}

enum DocumentReadProgress: Sendable {
    case preparing
    case downloading
    case coordinating
    case reading(bytes: Int)
}

enum DocumentReadError: LocalizedError, Equatable {
    case cancelled
    case timedOut
    case tooLarge
    case notAFile
    case notADirectory
    case tooManyEntries
    case unavailable
    case provider(domain: String, code: Int, message: String)

    var errorDescription: String? {
        switch self {
        case .cancelled:
            return "Đã hủy nhập file."
        case .timedOut:
            return "Nhà cung cấp file chưa trả dữ liệu sau 60 giây. Bạn có thể thử nhập lại ngay trong ứng dụng."
        case .tooLarge:
            return "File quá lớn. Ứng dụng hỗ trợ tối đa 64 MiB cho mỗi file."
        case .notAFile:
            return "Mục đã chọn không phải là một file."
        case .notADirectory:
            return "Mục đã chọn không phải là thư mục."
        case .tooManyEntries:
            return "Thư mục có quá nhiều mục. Hãy chọn một thư mục nhỏ hơn để duyệt."
        case .unavailable:
            return "Nhà cung cấp file không trả dữ liệu. Hãy thử nhập lại."
        case .provider(let domain, let code, let message):
            return "Không nhập được file: \(message) (\(domain), mã \(code))."
        }
    }

    static func wrapping(_ error: Error) -> Error {
        if let known = error as? DocumentReadError { return known }
        let value = error as NSError
        return DocumentReadError.provider(domain: value.domain, code: value.code, message: value.localizedDescription)
    }
}

enum DocumentReader {
    static func read(
        from access: DocumentAccess,
        timeout: TimeInterval = 60,
        onProgress: @escaping @Sendable (DocumentReadProgress) -> Void = { _ in }
    ) async throws -> Data {
        try await read(from: access, timeout: timeout, onProgress: onProgress, readAction: coordinatedRead)
    }

    // The injected action keeps timeout/cancellation behavior testable without a live iCloud account.
    static func read(
        from access: DocumentAccess,
        timeout: TimeInterval,
        onProgress: @escaping @Sendable (DocumentReadProgress) -> Void = { _ in },
        readAction: @escaping @Sendable (DocumentReadContext) throws -> Data
    ) async throws -> Data {
        let context = DocumentReadContext(access: access, onProgress: onProgress)
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                context.install(continuation)
                if Task.isCancelled { context.cancel(with: .cancelled) }
                context.start(timeout: timeout, action: readAction)
            }
        } onCancel: {
            context.cancel(with: .cancelled)
        }
    }

    private static func coordinatedRead(_ context: DocumentReadContext) throws -> Data {
        try context.checkActive()
        context.report(.preparing)
        let source = context.access.url
        guard source.isFileURL else { throw DocumentReadError.notAFile }

        // The coordinator can hydrate a provider's file. Explicitly request iCloud
        // downloads as well so there is visible progress before coordination waits.
        let cloudValues = try? source.resourceValues(forKeys: [
            .isUbiquitousItemKey, .ubiquitousItemDownloadingStatusKey
        ])
        if cloudValues?.isUbiquitousItem == true,
           cloudValues?.ubiquitousItemDownloadingStatus != .current {
            context.report(.downloading)
            // This hint is optional. External providers can reject the explicit
            // iCloud API while still supplying bytes through coordinated access.
            try? FileManager.default.startDownloadingUbiquitousItem(at: source)
        }
        try context.checkActive()

        var coordinationError: NSError?
        var contents: Result<Data, Error>?
        context.report(.coordinating)
        context.coordinator.coordinate(readingItemAt: source, options: [], error: &coordinationError) { url in
            contents = Result { try readBytes(at: url, context: context) }
        }
        try context.checkActive()
        if let contents { return try contents.get() }
        if let coordinationError { throw coordinationError }
        throw DocumentReadError.unavailable
    }

    private static func readBytes(at url: URL, context: DocumentReadContext) throws -> Data {
        try context.checkActive()
        // Provider metadata may be incomplete until the file is actually read.
        // Only reject a known directory; let opening the stream verify a file.
        let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
        guard values?.isDirectory != true else { throw DocumentReadError.notAFile }
        let maximum = WalliveDecryptor.maximumFileBytes
        if let size = values?.fileSize, size > maximum { throw DocumentReadError.tooLarge }
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var data = Data()
        if let size = values?.fileSize, size > 0 { data.reserveCapacity(min(size, maximum)) }
        context.report(.reading(bytes: 0))
        while true {
            try context.checkActive()
            // Reading one byte past the cap detects changing/misreported metadata
            // without loading an arbitrarily large provider file into memory.
            let count = min(256 * 1024, maximum - data.count + 1)
            guard let chunk = try handle.read(upToCount: count), !chunk.isEmpty else { break }
            guard chunk.count <= maximum - data.count else { throw DocumentReadError.tooLarge }
            data.append(chunk)
            context.report(.reading(bytes: data.count))
        }
        try context.checkActive()
        return data
    }
}

/// One synchronized completion gate owns the continuation, timeout and cancellation.
/// A timed-out provider worker may take time to unwind; its security scope stays
/// alive until it actually exits, and its late result cannot resume the task twice.
typealias DocumentReadContext = DocumentOperation<Data>

final class DocumentOperation<Value: Sendable>: @unchecked Sendable {
    let access: DocumentAccess
    let coordinator = NSFileCoordinator(filePresenter: nil)
    private let lock = NSLock()
    private let onProgress: @Sendable (DocumentReadProgress) -> Void
    private var continuation: CheckedContinuation<Value, Error>?
    private var result: Result<Value, Error>?
    private var timeoutItem: DispatchWorkItem?

    init(access: DocumentAccess, onProgress: @escaping @Sendable (DocumentReadProgress) -> Void) {
        self.access = access
        self.onProgress = onProgress
    }

    func install(_ continuation: CheckedContinuation<Value, Error>) {
        lock.lock()
        let completed = result
        if completed == nil { self.continuation = continuation }
        lock.unlock()
        if let completed { continuation.resume(with: completed) }
    }

    func start(timeout: TimeInterval, action: @escaping @Sendable (DocumentOperation<Value>) throws -> Value) {
        lock.lock()
        guard result == nil else {
            lock.unlock()
            access.close()
            return
        }
        let timer = DispatchWorkItem { [weak self] in self?.cancel(with: .timedOut) }
        timeoutItem = timer
        lock.unlock()

        DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + max(timeout, 0), execute: timer)
        DispatchQueue.global(qos: .userInitiated).async {
            defer { self.access.close() }
            do {
                try self.checkActive()
                self.finish(.success(try action(self)))
            } catch {
                self.finish(.failure(DocumentReadError.wrapping(error)))
            }
        }
    }

    func checkActive() throws {
        lock.lock()
        let completed = result
        lock.unlock()
        if let completed, case .failure(let error) = completed { throw error }
    }

    func report(_ progress: DocumentReadProgress) {
        lock.lock()
        let active = result == nil
        lock.unlock()
        if active { onProgress(progress) }
    }

    func cancel(with error: DocumentReadError) {
        finish(.failure(error))
        coordinator.cancel()
    }

    private func finish(_ result: Result<Value, Error>) {
        lock.lock()
        guard self.result == nil else { lock.unlock(); return }
        self.result = result
        let continuation = self.continuation
        self.continuation = nil
        let timer = timeoutItem
        timeoutItem = nil
        lock.unlock()
        timer?.cancel()
        continuation?.resume(with: result)
    }
}
