# Kiểm tra

- Source gồm 6 tệp SwiftUI native, project XcodeGen, tài nguyên JPG cục bộ và 4 tab.
- YAML của workflow/project đọc được; mọi khối run qua bash -n; helper Python kiểm tra cú pháp.
- Giải nén ZIP thật, chọn source root và ghi GITHUB_ENV: đạt.
- Các trường hợp ZIP đường dẫn nguy hiểm, symlink và nhiều project được rà soát qua helper.
- Helper icon đã kiểm tra với sips mô phỏng: 18 slot, 13 kích thước; chạy sips thật trên GitHub macOS.
- Chưa compile Swift, chạy Xcode, tạo IPA thật hoặc kiểm thử iPhone trong môi trường Linux này. Workflow GitHub Actions thực hiện compile trên macOS.
- Airlift, đăng nhập, quảng cáo thật, thanh toán VIP chưa tích hợp; không báo thành công giả.
