#!/usr/bin/env python3
"""Generate opaque iPhone, iPad and App Store icon assets using macOS sips."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess


def prepare_icons(source_root: Path) -> None:
    original = source_root / "Dynor/Resources/AppIcon.jpg"
    catalog = source_root / "Dynor/Assets.xcassets"
    output = catalog / "AppIcon.appiconset"
    if not original.is_file():
        raise FileNotFoundError(f"Missing supplied app icon: {original}")
    sips = shutil.which("sips")
    if not sips:
        raise RuntimeError("This script requires macOS sips; run it in the macOS build job.")
    output.mkdir(parents=True, exist_ok=True)
    if not (catalog / "Contents.json").exists():
        (catalog / "Contents.json").write_text(
            json.dumps({"info": {"author": "xcode", "version": 1}}, indent=2) + "\n",
            encoding="utf-8",
        )
    specs = []
    for points in (20, 29, 40, 60):
        for scale in (2, 3):
            specs.append(("iphone", points, scale))
    for points in (20, 29, 40, 76):
        for scale in (1, 2):
            specs.append(("ipad", points, scale))
    specs.extend([("ipad", 83.5, 2), ("ios-marketing", 1024, 1)])
    images = []
    generated = set()
    for idiom, points, scale in specs:
        pixels = round(points * scale)
        filename = f"Icon-{pixels}.png"
        if pixels not in generated:
            # The supplied JPEG is already opaque. Resample it to square app-icon dimensions.
            subprocess.run(
                [sips, "-s", "format", "png", "-z", str(pixels), str(pixels),
                 str(original), "--out", str(output / filename)],
                check=True, stdout=subprocess.DEVNULL,
            )
            generated.add(pixels)
        size = f"{points:g}x{points:g}"
        images.append({"idiom": idiom, "size": size, "scale": f"{scale}x", "filename": filename})
    (output / "Contents.json").write_text(
        json.dumps({"images": images, "info": {"author": "xcode", "version": 1}}, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"Generated {len(images)} icon slots using {len(generated)} opaque PNG files.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1])
    prepare_icons(parser.parse_args().source_root.resolve())
