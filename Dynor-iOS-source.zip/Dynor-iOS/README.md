# Dynor — ứng dụng iOS native

Dynor sử dụng **SwiftUI**, dành cho iPhone/iPad chạy iOS 17 trở lên. Không dùng WebView hoặc Capacitor. Mục tiêu build là ứng dụng arm64 đóng gói `.ipa`.

## Build trên GitHub không cần tự giải nén source

Kho GitHub ban đầu chỉ cần đúng hai tệp:

```text
.github/workflows/build-ipa.yml
Dynor-iOS-source.zip
```

1. Tạo repository GitHub của bạn.
2. Upload **Dynor-iOS-source.zip** vào thư mục gốc, giữ nguyên tên và không giải nén.
3. Tạo file `.github/workflows/build-ipa.yml`, dán nội dung file workflow được cung cấp, rồi Commit. Workflow chỉ nằm bên trong ZIP sẽ không tự chạy được.
4. Mở **Actions → Build Dynor native IPA → Run workflow**. Giữ tên source ZIP mặc định. GitHub cũng tự chạy khi push ZIP hoặc workflow.
5. Khi thành công, mở **Artifacts → Dynor-native-unsigned-IPA**. Giải nén artifact để lấy **Dynor-unsigned.ipa**.

Workflow dùng runner macOS 15: giải nén ZIP, tạo icon từ ảnh bạn cung cấp, chạy XcodeGen, archive bằng Xcode cho thiết bị iPhoneOS arm64, tạo `Payload/Dynor.app`, nén IPA rồi upload artifact. Không dùng khóa bí mật hoặc chứng chỉ để build unsigned.

Cũng có thể tự giải nén source vào repository, giữ `project.yml`, `Dynor/` và `scripts/` ở gốc. Workflow ưu tiên source native đã giải nén nếu tìm thấy `project.yml` và `Dynor/` ở gốc; khi đó thay ZIP sẽ không ghi đè source đang có. Nếu muốn build từ ZIP, dùng repo chỉ có hai tệp như trên.

## Cài lên iPhone

**IPA chưa được ký không thể cài trực tiếp.** Cần ký bằng chứng chỉ/provisioning hợp lệ cho thiết bị hoặc công cụ sideload phù hợp. Bản này không bao gồm chứng chỉ, Apple ID hay provisioning profile. Build unsigned không tạo quyền phát hành App Store/TestFlight. Thời hạn sử dụng phụ thuộc phương thức ký.

Nếu GitHub build lỗi, tải artifact `Dynor-build-log` (nếu bước archive đã bắt đầu). Không có công cụ Xcode/Swift compiler trong môi trường Linux đã tạo source nên chưa thể xác nhận biên dịch trước khi workflow chạy.

## Tính năng native hiện có

- Bốn mục: Khám phá, Thư viện, Pairing & Airlift, Cài đặt.
- Gallery, tìm kiếm/lọc danh mục, yêu thích, ảnh mẫu đóng gói trong app.
- Nhập nhiều ảnh/`.tendies` từ Tệp; lưu bản sao trong vùng ứng dụng; chọn và xóa nhiều tệp; chia sẻ tệp gốc. Mỗi tệp tối đa 50 MiB. Tên + kích thước trùng được bỏ qua; đây không phải kiểm tra trùng bằng hash.
- Lưu ảnh thật vào Photos sau khi người dùng cấp quyền. Sau đó mở Ảnh → Chia sẻ → Dùng làm hình nền. iOS yêu cầu người dùng tự xác nhận bước đặt hình nền.
- Chủ đề trắng/vàng; sáng/tối/tự động; hiệu ứng kính mờ bằng SwiftUI Material, tương thích iOS17.
- 5 lượt quảng cáo **mô phỏng**, mỗi lượt 4 giây khi app hoạt động. Đủ lượt mở lưu toàn bộ gallery đến 00:00 giờ Việt Nam; sang ngày mới phải xem lại. Dữ liệu chỉ lưu cục bộ, không phải bảo vệ doanh thu thật.
- Hồ sơ trải nghiệm có UUID riêng trên thiết bị, được ghi rõ chưa xác thực.
- Giao diện gói VIP tuần 39.000đ / tháng 59.000đ / vĩnh viễn 99.000đ.
- Mục pairing chỉ lưu tên/thời điểm chọn tệp; không đọc/copy nội dung hoặc báo kết nối thành công giả.

## Cần tích hợp trước khi phát hành đầy đủ

- Google Sign-In và OTP SMS, tài khoản/ID phía máy chủ, đồng bộ an toàn.
- Rewarded ads SDK và xác nhận quyền lợi phía máy chủ; thay bộ đếm quảng cáo mô phỏng.
- Sản phẩm StoreKit/In-App Purchase và máy chủ xác minh giao dịch/hoàn tiền/hết hạn/khôi phục; hiện không thu tiền hoặc cấp VIP.
- AirliftFFI/Rust, pairing handshake, VPN và Tendies engine từ nguồn tương thích. **Có IPA native không đồng nghĩa đã có tính năng Airlift.** Bản này chỉ import/quản lý Tendies, chưa cài Tendies lên hệ thống.
- Thông tin liên hệ thật và kiểm thử trên thiết bị iOS đích.

Nguồn tham khảo kỹ thuật: https://github.com/Mak5er/AirCard-iOS (MIT). Chưa sao chép mã của dự án này; cần kiểm tra giấy phép và hỗ trợ phiên bản iOS khi tích hợp. Icon là ảnh người dùng cung cấp. Nguồn ảnh mẫu: `Dynor/Resources/Wallpapers/sources.json` (Unsplash).

## Build trên máy Mac

Cài Xcode 16 trở lên, Command Line Tools và XcodeGen, sau đó:

```bash
python3 scripts/prepare_icons.py --source-root .
xcodegen generate --spec project.yml
xcodebuild -project Dynor.xcodeproj -scheme Dynor -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -archivePath build/Dynor.xcarchive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' archive
```

Workflow kèm bước đóng gói archive thành `.ipa`. Để chạy trực tiếp bằng Xcode, chọn team/bundle identifier của bạn và dùng signing hợp lệ.
