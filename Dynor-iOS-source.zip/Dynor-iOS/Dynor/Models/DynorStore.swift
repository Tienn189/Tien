import SwiftUI
import UIKit
import Combine
import Photos
import UniformTypeIdentifiers

struct WallpaperItem: Identifiable {
    let id: String
    let title: String
    let category: String
    let imageName: String

    static let samples: [WallpaperItem] = [
        .init(id: "dune", title: "Golden Silence", category: "Thiên nhiên", imageName: "dune"),
        .init(id: "alpine", title: "Alpine Dreams", category: "Thiên nhiên", imageName: "alpine"),
        .init(id: "liquid", title: "Liquid Flow", category: "Trừu tượng", imageName: "liquid"),
        .init(id: "forest", title: "Into the Green", category: "Thiên nhiên", imageName: "forest"),
        .init(id: "space", title: "Stardust", category: "Vũ trụ", imageName: "space"),
        .init(id: "ocean", title: "Ocean Therapy", category: "Thiên nhiên", imageName: "ocean"),
        .init(id: "minimal", title: "Soft Horizon", category: "Tối giản", imageName: "minimal"),
        .init(id: "sunset", title: "Last Light", category: "Thiên nhiên", imageName: "sunset"),
        .init(id: "coast", title: "Coastal Escape", category: "Thiên nhiên", imageName: "coast"),
        .init(id: "peak", title: "Above the Clouds", category: "Thiên nhiên", imageName: "mountain-hero")
    ]
}

func wallpaperImage(named name: String) -> UIImage? {
    guard let path = Bundle.main.path(forResource: name, ofType: "jpg") else { return nil }
    return UIImage(contentsOfFile: path)
}

enum ThemeMode: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var colorScheme: ColorScheme? {
        switch self { case .system: return nil; case .light: return .light; case .dark: return .dark }
    }
}

enum ThemeAccent: String, CaseIterable { case gold, white }
struct LocalProfile: Codable, Equatable { let id: String; let name: String }
enum ImportedKind: String, Codable { case image, tendies }
struct ImportedWallpaper: Codable, Identifiable {
    let id: UUID
    let displayName: String
    let storedFilename: String
    let kind: ImportedKind
    let addedAt: Date
    let byteCount: Int64
}

@MainActor
final class DynorStore: ObservableObject {
    @Published var theme: ThemeMode { didSet { defaults.set(theme.rawValue, forKey: "theme") } }
    @Published var accent: ThemeAccent { didSet { defaults.set(accent.rawValue, forKey: "accent") } }
    @Published var favorites: Set<String> { didSet { defaults.set(Array(favorites), forKey: "favorites") } }
    @Published private(set) var profile: LocalProfile?
    @Published private(set) var library: [ImportedWallpaper] = []
    @Published var message: String?
    @Published private var dailyDay: String
    @Published private var dailyCount: Int

    private let defaults: UserDefaults
    private let root: URL
    private var libraryDirectory: URL { root.appendingPathComponent("Library", isDirectory: true) }
    private var indexURL: URL { root.appendingPathComponent("library.json") }
    var accentColor: Color { accent == .gold ? Color(red: 0.82, green: 0.64, blue: 0.16) : Color.primary }
    var currentDayKey: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Asia/Ho_Chi_Minh")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }
    var adsWatched: Int { dailyDay == currentDayKey ? min(5, max(0, dailyCount)) : 0 }
    var isUnlocked: Bool { adsWatched >= 5 }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        theme = ThemeMode(rawValue: defaults.string(forKey: "theme") ?? "system") ?? .system
        accent = ThemeAccent(rawValue: defaults.string(forKey: "accent") ?? "gold") ?? .gold
        favorites = Set(defaults.stringArray(forKey: "favorites") ?? [])
        dailyDay = defaults.string(forKey: "dailyDay") ?? ""
        dailyCount = min(5, max(0, defaults.integer(forKey: "dailyCount")))
        if let data = defaults.data(forKey: "profile") { profile = try? JSONDecoder().decode(LocalProfile.self, from: data) }
        root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Dynor", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: libraryDirectory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: indexURL.path) {
                library = try JSONDecoder().decode([ImportedWallpaper].self, from: Data(contentsOf: indexURL))
            }
        } catch {
            message = "Không thể mở thư viện cục bộ: \(error.localizedDescription)"
        }
        refreshDailyAccess()
    }

    func refreshDailyAccess() {
        if dailyDay != currentDayKey {
            dailyDay = currentDayKey
            dailyCount = 0
            defaults.set(dailyDay, forKey: "dailyDay")
            defaults.set(0, forKey: "dailyCount")
        }
        objectWillChange.send()
    }

    @discardableResult
    func recordDemoAd(startDay: String) -> Bool {
        refreshDailyAccess()
        guard startDay == currentDayKey else {
            message = "Đã sang ngày mới theo giờ Việt Nam. Hãy bắt đầu lại tiến trình hôm nay."
            return false
        }
        dailyCount = min(5, dailyCount + 1)
        defaults.set(dailyCount, forKey: "dailyCount")
        return true
    }

    func toggleFavorite(_ id: String) {
        if favorites.contains(id) { favorites.remove(id) } else { favorites.insert(id) }
    }

    func createLocalProfile(name: String) {
        let cleanName = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(40))
        guard !cleanName.isEmpty else { return }
        let next = LocalProfile(id: profile?.id ?? "DYN-" + UUID().uuidString, name: cleanName)
        do {
            defaults.set(try JSONEncoder().encode(next), forKey: "profile")
            profile = next
        } catch { message = error.localizedDescription }
    }

    func deleteLocalProfile() {
        defaults.removeObject(forKey: "profile")
        profile = nil
    }

    func fileURL(for item: ImportedWallpaper) -> URL {
        libraryDirectory.appendingPathComponent(item.storedFilename)
    }

    func importWallpapers(urls: [URL]) {
        var added: [ImportedWallpaper] = []
        var skipped: [String] = []
        for url in urls {
            let scoped = url.startAccessingSecurityScopedResource()
            defer { if scoped { url.stopAccessingSecurityScopedResource() } }
            do {
                let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
                let bytes = values.fileSize ?? 0
                guard values.isRegularFile == true, bytes > 0, bytes <= 50 * 1024 * 1024 else {
                    skipped.append(url.lastPathComponent); continue
                }
                let ext = url.pathExtension.lowercased()
                let isTendies = ext == "tendies"
                guard isTendies || UTType(filenameExtension: ext)?.conforms(to: .image) == true else {
                    skipped.append(url.lastPathComponent); continue
                }
                if library.contains(where: { $0.displayName == url.lastPathComponent && $0.byteCount == Int64(bytes) }) ||
                    added.contains(where: { $0.displayName == url.lastPathComponent && $0.byteCount == Int64(bytes) }) {
                    skipped.append(url.lastPathComponent); continue
                }
                if !isTendies && UIImage(contentsOfFile: url.path) == nil {
                    skipped.append(url.lastPathComponent); continue
                }
                let id = UUID()
                let record = ImportedWallpaper(id: id, displayName: url.lastPathComponent,
                    storedFilename: id.uuidString + "." + ext, kind: isTendies ? .tendies : .image,
                    addedAt: Date(), byteCount: Int64(bytes))
                try FileManager.default.copyItem(at: url, to: fileURL(for: record))
                added.append(record)
            } catch { skipped.append(url.lastPathComponent) }
        }
        do {
            let next = Array(added.reversed()) + library
            try JSONEncoder().encode(Array(next)).write(to: indexURL, options: .atomic)
            library = Array(next)
            message = "Đã nhập \(added.count) tệp." + (skipped.isEmpty ? "" : " Bỏ qua \(skipped.count) tệp trùng, không đọc được hoặc quá 50 MB.")
        } catch {
            for item in added { try? FileManager.default.removeItem(at: fileURL(for: item)) }
            message = "Chưa lưu được thư viện: \(error.localizedDescription)"
        }
    }

    func removeImported(ids: Set<UUID>) {
        guard !ids.isEmpty else { return }
        let removed = library.filter { ids.contains($0.id) }
        let kept = library.filter { !ids.contains($0.id) }
        do {
            // Commit the visible index before reclaiming the corresponding files.
            try JSONEncoder().encode(kept).write(to: indexURL, options: .atomic)
            library = kept
            var failedCleanup = 0
            for item in removed {
                do { try FileManager.default.removeItem(at: fileURL(for: item)) }
                catch { failedCleanup += 1 }
            }
            message = "Đã xóa \(removed.count) tệp khỏi thư viện." + (failedCleanup > 0 ? " Có tệp chưa dọn được trên bộ nhớ." : "")
        } catch { message = "Chưa xóa được thư viện: \(error.localizedDescription)" }
    }

    func saveToPhotos(_ item: WallpaperItem) async {
        refreshDailyAccess()
        guard isUnlocked else { message = "Xem đủ 5 quảng cáo mô phỏng để lưu hình nền trong hôm nay."; return }
        guard let image = wallpaperImage(named: item.imageName) else { message = "Không tìm thấy ảnh trong ứng dụng."; return }
        await saveImage(image)
    }

    func saveImportedToPhotos(_ item: ImportedWallpaper) async {
        guard item.kind == .image, let image = UIImage(contentsOfFile: fileURL(for: item).path) else {
            message = "Tệp Tendies cần tích hợp Airlift để cài; chưa thể lưu như ảnh."; return
        }
        await saveImage(image)
    }

    private func saveImage(_ image: UIImage) async {
        let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
        guard status == .authorized || status == .limited else {
            message = "Hãy cho phép Dynor thêm ảnh trong Cài đặt → Quyền riêng tư → Ảnh."
            return
        }
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAsset(from: image)
            }
            message = "Đã lưu vào Ảnh. Mở Ảnh → Chia sẻ → Dùng làm hình nền để cài."
        } catch { message = "Chưa lưu được ảnh: \(error.localizedDescription)" }
    }
}
