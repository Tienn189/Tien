import SwiftUI
import UniformTypeIdentifiers

struct PairingView: View {
    @EnvironmentObject private var store: DynorStore
    @AppStorage("dynor.pairing.selectedFilename") private var selectedFilename = ""
    @AppStorage("dynor.pairing.selectedDate") private var selectedDate = ""
    @State private var showImporter = false
    @State private var notice: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("KẾT NỐI KHÔNG GIAN CỦA BẠN")
                            .font(.system(size: 10, weight: .medium)).tracking(1.6).foregroundStyle(.secondary)
                        Text("Pairing & Airlift").font(.system(size: 31, weight: .semibold, design: .rounded))
                        Text("Chuẩn bị thiết bị cho thế giới Tendies.")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 12)
                    Label {
                        Text("Thành phần Airlift chưa được tích hợp. Dynor hiện chưa ghép nối thiết bị hoặc cài Tendies.")
                    } icon: { Image(systemName: "info.circle") }
                    .font(.subheadline)
                    .padding(17)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(store.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 17))

                    PairingGlassCard {
                        VStack(alignment: .leading, spacing: 20) {
                            HStack {
                                Label("Pairing thiết bị", systemImage: "link").font(.headline)
                                Spacer()
                                PairingStatus(text: "Chưa ghép nối")
                            }
                            PairingStep(number: "01", title: "Chuẩn bị pairing record", detail: "Sử dụng tệp .mobiledevicepairing, .plist hoặc .mobilepair được tạo từ thiết bị của bạn.")
                            Divider()
                            PairingStep(number: "02", title: "Chọn tệp để chuẩn bị", detail: "Dynor chỉ ghi nhớ tên tệp đã chọn. Nội dung tệp không được đọc, sao chép hoặc gửi đi.")
                            Divider()
                            PairingStep(number: "03", title: "Tích hợp kết nối native", detail: "Pairing handshake, AirliftFFI và LocalDevVPN cần được triển khai trước khi kết nối thật.")
                            if !selectedFilename.isEmpty {
                                VStack(alignment: .leading, spacing: 8) {
                                    Label(selectedFilename, systemImage: "doc")
                                        .font(.subheadline.weight(.medium))
                                        .lineLimit(3)
                                    Text("Đã chọn tệp · Chưa ghép nối")
                                        .font(.caption).foregroundStyle(.secondary)
                                    if !selectedDate.isEmpty {
                                        Text(selectedDate).font(.caption2).foregroundStyle(.tertiary)
                                    }
                                }
                                .padding(14)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color(uiColor: .tertiarySystemFill), in: RoundedRectangle(cornerRadius: 12))
                            }
                            Button { showImporter = true } label: {
                                Label(selectedFilename.isEmpty ? "Chọn pairing record" : "Chọn tệp khác", systemImage: "square.and.arrow.down")
                                    .frame(maxWidth: .infinity).padding(9)
                            }
                            .buttonStyle(.borderedProminent)
                            if !selectedFilename.isEmpty {
                                Button("Bỏ tên tệp đã chọn", role: .destructive) {
                                    selectedFilename = ""
                                    selectedDate = ""
                                }
                                .font(.subheadline)
                            }
                        }
                    }
                    PairingGlassCard {
                        VStack(alignment: .leading, spacing: 19) {
                            HStack {
                                Label("Airlift", systemImage: "antenna.radiowaves.left.and.right").font(.headline)
                                Spacer()
                                PairingStatus(text: "Chưa tích hợp")
                            }
                            PairingDetailRow(title: "Kết nối thiết bị", value: "Chưa kết nối")
                            Divider()
                            PairingDetailRow(title: "AirliftFFI", value: "Chưa tích hợp")
                            Divider()
                            PairingDetailRow(title: "LocalDevVPN", value: "Chưa kiểm tra")
                            Divider()
                            PairingDetailRow(title: "Thư viện Tendies", value: "\(store.library.filter { $0.kind == .tendies }.count) tệp")
                            Text("Khả năng cài hình nền phụ thuộc phiên bản iOS và hỗ trợ của AirCard-iOS. Chọn tệp pairing không tự tạo kết nối hoặc bật VPN.")
                                .font(.caption).foregroundStyle(.secondary)
                            Link(destination: URL(string: "https://github.com/Mak5er/AirCard-iOS")!) {
                                Label("Tài liệu AirCard-iOS", systemImage: "arrow.up.right.square")
                                    .font(.subheadline.weight(.semibold))
                            }
                        }
                    }
                    Text("Pairing record có thể chứa dữ liệu nhạy cảm. Trong bản này Dynor không đọc nội dung của tệp.")
                        .font(.caption2).foregroundStyle(.secondary)
                        .padding(.bottom, 10)
                }
                .padding(20)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle("Pairing")
            .navigationBarTitleDisplayMode(.inline)
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    let allowed = ["mobiledevicepairing", "plist", "mobilepair"]
                    guard allowed.contains(url.pathExtension.lowercased()) else {
                        notice = "Hãy chọn tệp .mobiledevicepairing, .plist hoặc .mobilepair."
                        return
                    }
                    selectedFilename = url.lastPathComponent
                    selectedDate = Date.now.formatted(date: .abbreviated, time: .shortened)
                    notice = "Đã ghi nhớ tên tệp. Thiết bị vẫn chưa được ghép nối."
                case .failure(let error):
                    notice = "Chưa chọn được tệp: \(error.localizedDescription)"
                }
            }
            .alert("Pairing", isPresented: Binding(get: { notice != nil }, set: { if !$0 { notice = nil } })) {
                Button("Đã hiểu", role: .cancel) { notice = nil }
            } message: { Text(notice ?? "") }
        }
        .tint(store.accentColor)
    }
}

private struct PairingGlassCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content.padding(21).frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(Color.primary.opacity(0.06)))
    }
}

private struct PairingStatus: View {
    let text: String
    var body: some View {
        HStack(spacing: 5) {
            Circle().fill(.secondary).frame(width: 5, height: 5)
            Text(text)
        }
        .font(.system(size: 10, weight: .medium))
        .foregroundStyle(.secondary)
        .padding(.horizontal, 9).padding(.vertical, 6)
        .background(Color(uiColor: .tertiarySystemFill), in: Capsule())
    }
}

private struct PairingStep: View {
    @EnvironmentObject private var store: DynorStore
    let number: String
    let title: String
    let detail: String
    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Text(number).font(.caption.weight(.semibold))
                .frame(width: 30, height: 30)
                .background(store.accentColor.opacity(0.2), in: Circle())
            VStack(alignment: .leading, spacing: 6) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(detail).font(.caption).foregroundStyle(.secondary).lineSpacing(3)
            }
        }
    }
}

private struct PairingDetailRow: View {
    let title: String
    let value: String
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.medium).multilineTextAlignment(.trailing)
        }
        .font(.caption)
    }
}
